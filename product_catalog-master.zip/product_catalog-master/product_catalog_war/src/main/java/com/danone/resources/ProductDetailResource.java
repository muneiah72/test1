package com.danone.resources;

import java.io.InputStream;
import java.text.ParseException;
//import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
 
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.tika.Tika;
import org.apache.tika.metadata.HttpHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.MAKT;
import com.danone.entities.MAKTPK;
import com.danone.entities.MARA;
import com.danone.entities.MARAPK;
import com.danone.entities.MVKE;
import com.danone.entities.MVKEPK;
import com.danone.entities.PICTURES;
import com.danone.entities.PICTURESPK;
import com.danone.entities.PRICAT_K003;
import com.danone.entities.PRICAT_K003PK;
import com.danone.entities.PRICAT_K003Z;
import com.danone.entities.PRICAT_K004;
import com.danone.entities.PRICAT_K005;
import com.danone.entities.PRICAT_K006;
import com.danone.entities.PRICAT_K007;
import com.danone.entities.T002;
import com.danone.entities.T179T;
import com.danone.entities.TVM1T;
import com.danone.entities.ZPOTDIAM;
import com.danone.entities.ZPPFLAV;
import com.danone.entities.ZPPOVER;
import com.danone.entities.ZPPPRO1;
import com.danone.entities.ZPPPRO2;
import com.danone.entities.ZPPSIGN;
import com.danone.entities.ZPRODCAT_HDR;
import com.danone.entities.ZPRODCAT_ITEM;
import com.danone.entities.ZPRO_ASSORTMENT;
import com.danone.entities.ZPRO_ASSORTMENTPK;
import com.danone.entities.ZPRO_NUTBOARD;
import com.danone.entities.ZPRO_NUTRIENT;
import com.danone.entities.ZRANGE;
import com.danone.entities.ZSUBRANGE;
import com.danone.entities.ZPPMAR1;
import com.danone.entities.ZPPMAR2;
import com.danone.entities.ZPPMAR3;
import com.danone.entities.ZPPMAR4;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.AllergenDetailWrapper;
import com.danone.util.AllergenWrapper;
import com.danone.util.CmisHelper;
import com.danone.util.MultipackWrapper;
import com.danone.util.NutboardWrapper;
import com.danone.util.PictureWrapper;
//import com.sap.conn.jco.JCoField;
import com.danone.util.ProductDetailWrapper;
import com.danone.util.UoMWrapper;
import com.danone.util.Utils;
import com.danone.util.VersionWrapper;

@Path("/productdetail")
@Produces({ MediaType.APPLICATION_JSON })
public class ProductDetailResource {

	private final Logger LOGGER = LoggerFactory.getLogger(ProductDetailResource.class);

	@Context
	private HttpServletRequest servletRequest;

	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("{system}/{mandt}/{cat_guid}/{matnr}/{vkorg}/{vtweg}/{prinbr}/{productgroup}/{ean_upc_base}/{validity_base}/{language}/{plant}/{ecatd}")
	public Response getProductDetails(@QueryParam("format") String rformat, @PathParam("system") String system,
			@PathParam("mandt") Integer mandt, @PathParam("cat_guid") String cat_guid, @PathParam("matnr") String matnr,
			@PathParam("vkorg") String vkorg, @PathParam("vtweg") String vtweg, @PathParam("prinbr") String prinbr,
			@PathParam("productgroup") String productgroup, @PathParam("ean_upc_base") String ean_upc_base,
			@PathParam("validity_base") String validity_base, @PathParam("language") String language,
			@PathParam("plant") String plant, @PathParam("ecatd") String ecatd) throws ParseException {

		// First check authorizations
		// Check CBU
		// String rolename = "Prometheus_CBU_" + vkorg;
		// if (!servletRequest.isUserInRole(rolename)) {
		// return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You
		// do not have the required authorizations").build();
		// }


		// Convert date to YYYYMMDD format
		LOGGER.debug("getProductDetails: " + matnr.toString());
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		Date parsed = format.parse(validity_base);
		java.sql.Date newvalidityDate = new java.sql.Date(parsed.getTime());

		Boolean excel = false;

		ProductDetailWrapper fullProduct = null;
		fullProduct = getDetails(system, mandt, cat_guid, matnr, vkorg, vtweg, prinbr, productgroup, ean_upc_base,
				newvalidityDate, language, plant, ecatd, excel);

		if (fullProduct != null) {
			return Response.ok(fullProduct).header(HttpHeaders.CONTENT_TYPE,
					"xml".equals(rformat) ? MediaType.APPLICATION_XML : MediaType.APPLICATION_JSON).build();
		}

		return null;
	}

	public ProductDetailWrapper getDetails(String system, Integer mandt, String cat_guid, String matnr, String vkorg,
			String vtweg, String prinbr, String productgroup, String ean_upc_base, java.sql.Date validity_base,
			String language, String plant, String ecatd, Boolean excel) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {

			LOGGER.debug("JSON Obj: " + matnr.toString());

			while (matnr.length() < 18) {
				matnr = "0" + matnr;
			}

			// Get asort
			ZPRO_ASSORTMENT asort = ZPRO_ASSORTMENT.getZPRO_ASSORTMENTByKey(em,
					new ZPRO_ASSORTMENTPK(system, mandt, vkorg, vtweg));

			// Get SAP language spras from ISO language
			String spras = new String(T002.getSprasByLaiso(em, language));

			ProductDetailWrapper fullProduct = new ProductDetailWrapper();

			// ZPRODCAT_HDR & ZPRODCAT_ITEM
			fullProduct.setSystem(system);
			fullProduct.setMandt(mandt);
			fullProduct.setCat_guid(cat_guid);
			fullProduct.setVkorg(vkorg);
			fullProduct.setVtweg(vtweg);
			fullProduct.setPrinbr(prinbr);
			fullProduct.setProductgroup(productgroup);
			fullProduct.setEan_upc_base(ean_upc_base);
			fullProduct.setValidity_base(validity_base);

			// Last update date
			ZPRODCAT_HDR prodHdr = ZPRODCAT_HDR.getHeaderByCatGuid(em, system, cat_guid);
			if (prodHdr.getStatus() != null) {
			fullProduct.setStatus(prodHdr.getStatus());
			}
			if (prodHdr.getAedat() != null) {
				// if (prodHdr.getAedat().after(prodHdr.getErdat()))
				if (prodHdr.getAedat().compareTo(prodHdr.getErdat()) > 0) {
					fullProduct.setLast_update(prodHdr.getAedat());
				} else {
					fullProduct.setLast_update(prodHdr.getErdat());
				}
			} else {
				fullProduct.setLast_update(prodHdr.getErdat());
			}

			// Fetch version info
			List<ZPRODCAT_HDR> listHdrVersions = ZPRODCAT_HDR.getVersions(system, vkorg, vtweg, matnr, asort, em);
			// Authority check on version's statuses
			final HttpServletRequest request = (HttpServletRequest) ServletRequestStore.getServletRequest();			
			if (servletRequest == null)
			{
				servletRequest = request;
			}
			List<String> statusAllowed = SearchResource.getAllowedStatusList(em, servletRequest, vkorg);

			List<ZPRODCAT_HDR> deleteListAuth = new ArrayList<ZPRODCAT_HDR>();
			for (ZPRODCAT_HDR catHdr : listHdrVersions) {
				if (!statusAllowed.contains(catHdr.getStatus())) {
					deleteListAuth.add(catHdr);
				}
			}

			for (ZPRODCAT_HDR hdrDelAuth : deleteListAuth) {
				listHdrVersions.remove(hdrDelAuth);
			}


			List<VersionWrapper> versions = new ArrayList<VersionWrapper>();

			for (ZPRODCAT_HDR hdrVersion : listHdrVersions) {
				VersionWrapper vers = new VersionWrapper();
				vers.setVersionNo(hdrVersion.getVerno());
				vers.setCurrentStatus(hdrVersion.getStatus());
				vers.setModifDate(hdrVersion.getAedat());
				vers.setChangedBy(hdrVersion.getAenam());
				vers.setCatalogNo(hdrVersion.getPrinbr());
				vers.setCreationDate(hdrVersion.getErdat());
				vers.setPreviousStatus(hdrVersion.getStatus_prev());
				vers.setSystem(hdrVersion.getKey().getSystem());
				vers.setMandt(hdrVersion.getKey().getMandt());
				vers.setCat_guid(hdrVersion.getKey().getCat_guid());
				vers.setVkorg(hdrVersion.getVkorg());
				vers.setVtweg(hdrVersion.getVtweg());
				vers.setPrinbr(hdrVersion.getPrinbr());
				vers.setProductgroup(hdrVersion.getProductgroup());
				vers.setEan_upc_base(hdrVersion.getEan_upc_base());
				ZPRODCAT_ITEM itemVersion = ZPRODCAT_ITEM.getItemByGuidAndPostyp(em, system,
						hdrVersion.getKey().getCat_guid(), "P");
				if (itemVersion != null) {
					vers.setValidity_base(itemVersion.getValidity_base());
				}

				versions.add(vers);
			}

			fullProduct.setVersionList(versions);

			// Fetch picture info
			List<ZPRODCAT_ITEM> listItems = ZPRODCAT_ITEM.getItemsByType(em, system, mandt, cat_guid, "D");
			List<PictureWrapper> pictures = new ArrayList<PictureWrapper>();
			List<PictureWrapper> documents = new ArrayList<PictureWrapper>();

			for (ZPRODCAT_ITEM itemDoc : listItems) {
				// LOGGER.debug("Before PICTURESPK prepare");
				String dokar = itemDoc.getDokar();
				String doknr = itemDoc.getDoknr();
				String dokvr = itemDoc.getDokvr();
				String doktl = itemDoc.getDoktl();
				PICTURESPK picturesPK = new PICTURESPK(system, mandt, dokar, doknr, dokvr, doktl);
				PICTURES picturesEntry = PICTURES.getPICTURESByKey(em, picturesPK);
				if (picturesEntry != null) {
					// LOGGER.debug("picturesentry");
					PictureWrapper attachment = new PictureWrapper();
					attachment.setDocumentNr(picturesEntry.getKey().getDocument_number());
					attachment.setDocumentVr(picturesEntry.getKey().getDocument_version());
					attachment.setPictureName(picturesEntry.getPicture_name());
					attachment.setProductType(picturesEntry.getProduct_type());
					attachment.setContentType(picturesEntry.getContent_type());
					attachment.setMainFace(picturesEntry.getMain_face());
					attachment.setHorizontalAngle(picturesEntry.getHorizontal_angle());
					attachment.setFileNature(picturesEntry.getFile_nature());
					attachment.setValidFrom(picturesEntry.getValid_from());
					attachment.setValidTo(picturesEntry.getValid_to());
					attachment.setShootingDate(picturesEntry.getShooting_date());
					attachment.setCreationDate(picturesEntry.getCreation_date());
					attachment.setThumbnailId(picturesEntry.getThumbnail_id());
					attachment.setImageId(picturesEntry.getImage_id());

					if (!excel) {
						CmisHelper cmis = new CmisHelper();
						ContentStream contentStream = cmis.getDocumentStreamById(picturesEntry.getImage_id());
						InputStream inputStream = contentStream.getStream();
						byte[] aBlob = IOUtils.toByteArray(inputStream);
						String fileFormat = null;
						fileFormat = new Tika().detect(aBlob);
						String fileExtension = Utils.getFormat(fileFormat);
						if (fileFormat.contains("image")) {
							attachment.setThumbnailUrl("/main/ImageRenderer?DmsDocument=true&documentId="
									+ picturesEntry.getThumbnail_id());
							attachment.setDownloadUrl(
									"/main/ImageRenderer?DmsDocument=true&documentId=" + picturesEntry.getImage_id()
											+ "&fileName=" + picturesEntry.getPicture_name() + "&Download=" + "X");
							pictures.add(attachment);
						} else if (fileFormat.equalsIgnoreCase("application/pdf")) {
							attachment.setDownloadUrl(
									"/main/PdfRenderer?DmsDocPdf=true&documentId=" + picturesEntry.getImage_id()
											+ "&fileName=" + picturesEntry.getPicture_name() + "&Download=" + "X");
							documents.add(attachment);
						}
					}
				}
			}
			fullProduct.setPictureList(pictures);
			fullProduct.setDocumentList(documents);

			// Fetch and set MARA data
			MARAPK marapk = new MARAPK(system, mandt, matnr);
			MARA maraentry = MARA.getMARAByKey(em, marapk);
			if (maraentry != null) {
				fullProduct.setMatnr(maraentry.getKey().getMatnr().replaceFirst("^0+(?!$)", ""));
				fullProduct.setMhdhb(maraentry.getMhdhb());
				fullProduct.setZzsignature(maraentry.getZzsignature());
				fullProduct.setZzoverlay(maraentry.getZzoverlay());
				fullProduct.setZzcapacity(maraentry.getZzcapacity());
				fullProduct.setZzby(maraentry.getZzby());
				fullProduct.setZzprocess1(maraentry.getZzproces1());
				fullProduct.setZzprocess2(maraentry.getZzproces2());
				fullProduct.setStfak(maraentry.getStfak());
				ZPPSIGN zppsignentry = ZPPSIGN.getZPPSIGNByKey(em, system, mandt, maraentry.getZzsignature());
				if (zppsignentry != null) {
					fullProduct.setBrand(zppsignentry.getZdescription());
				}
				ZPPOVER zppoverentry = ZPPOVER.getZPPOVERByKey(em, system, mandt, maraentry.getZzoverlay());
				if (zppoverentry != null) {
					fullProduct.setSubbrand(zppoverentry.getZdescription());
				}
				ZPPFLAV zppflaventry = ZPPFLAV.getZPPFLAVByKey(em, system, mandt, maraentry.getZzflavor());
				if (zppflaventry != null) {
					fullProduct.setFlavor(zppflaventry.getZdescription());
				}
				ZPPPRO1 zpppro1entry = ZPPPRO1.getZPPPRO1ByKey(em, system, mandt, maraentry.getZzproces1());
				if (zpppro1entry != null) {
					fullProduct.setProcess1(zpppro1entry.getZdescription());
				}
				ZPPPRO2 zpppro2entry = ZPPPRO2.getZPPPRO2ByKey(em, system, mandt, maraentry.getZzproces2());
				if (zpppro2entry != null) {
					fullProduct.setProcess2(zpppro2entry.getZdescription());
				}
				ZPOTDIAM zpotdiamentry = ZPOTDIAM.getZPOTDIAMByKey(em, system, mandt, maraentry.getZzpot_diam());
				if (zpotdiamentry != null) {
					fullProduct.setPotdiameter(zpotdiamentry.getZzpot_diam_desc());
				}
				ZRANGE zrangeentry = ZRANGE.getZRANGEByKey(em, system, mandt, maraentry.getZzrange());
				if (zrangeentry != null) {
					fullProduct.setRange(zrangeentry.getZzrange_desc());
				}
				ZSUBRANGE zsubrangeentry = ZSUBRANGE.getZSUBRANGEByKey(em, system, mandt, maraentry.getZzsub_range());
				if (zsubrangeentry != null) {
					fullProduct.setSubrange(zsubrangeentry.getZzsub_range_desc());
				}
			}

			// Fetch and set MAKT data
			MAKTPK maktpk = new MAKTPK(system, mandt, matnr, "E");
			MAKT maktentry = MAKT.getMAKTByKey(em, maktpk);
			if (maktentry != null) {
				fullProduct.setMaktx(maktentry.getMaktx());
			}

			// Fetch and set MVKE data
			MVKEPK mvkepk = new MVKEPK(system, mandt, matnr, vkorg, vtweg);
			MVKE mvkeentry = MVKE.getMVKEByKey(em, mvkepk);
			if (mvkeentry != null) {
				fullProduct.setMvgr1(mvkeentry.getMvgr1());
				fullProduct.setZzproductvar(mvkeentry.getZzproductvar());
				fullProduct.setZzforcastunit(mvkeentry.getZzforcastunit());
				fullProduct.setProdh(mvkeentry.getProdh());
				TVM1T tvm1tentry = TVM1T.getTVM1TByKey(em, system, mandt, spras, mvkeentry.getMvgr1());
				if (tvm1tentry != null) {
					fullProduct.setPromo(tvm1tentry.getBezei());
				}
				T179T t179tentry1 = T179T.getT179TByKey(em, system, mandt, spras, mvkeentry.getProdh().substring(0, 2));
				if (t179tentry1 != null) {
					fullProduct.setProdhl1desc(t179tentry1.getVtext());
				}
				T179T t179tentry2 = T179T.getT179TByKey(em, system, mandt, spras, mvkeentry.getProdh().substring(0, 5));
				if (t179tentry2 != null) {
					fullProduct.setProdhl2desc(t179tentry2.getVtext());
				}
				T179T t179tentry3 = T179T.getT179TByKey(em, system, mandt, spras, mvkeentry.getProdh().substring(0, 9));
				if (t179tentry3 != null) {
					fullProduct.setProdhl3desc(t179tentry3.getVtext());
				}
				T179T t179tentry4 = T179T.getT179TByKey(em, system, mandt, spras,
						mvkeentry.getProdh().substring(0, 11));
				if (t179tentry4 != null) {
					fullProduct.setProdhl4desc(t179tentry4.getVtext());
				}
				T179T t179tentry5 = T179T.getT179TByKey(em, system, mandt, spras,
						mvkeentry.getProdh().substring(0, 14));
				if (t179tentry5 != null) {
					fullProduct.setProdhl5desc(t179tentry5.getVtext());
				}
				T179T t179tentry6 = T179T.getT179TByKey(em, system, mandt, spras,
						mvkeentry.getProdh().substring(0, 18));
				if (t179tentry6 != null) {
					fullProduct.setProdhl6desc(t179tentry6.getVtext());
				}
				ZPPMAR1 zppmar1entry = ZPPMAR1.getZPPMAR1ByKey(em, system, mandt, mvkeentry.getZzmarki());
				if (zppmar1entry != null) {
					fullProduct.setZzmarki(zppmar1entry.getZdescription());
				}
				ZPPMAR2 zppmar2entry = ZPPMAR2.getZPPMAR2ByKey(em, system, mandt, mvkeentry.getZzmarkii());
				if (zppmar2entry != null) {
					fullProduct.setZzmarkii(zppmar2entry.getZdescription());
				}
				ZPPMAR3 zppmar3entry = ZPPMAR3.getZPPMAR3ByKey(em, system, mandt, mvkeentry.getZzmarkiii());
				if (zppmar3entry != null) {
					fullProduct.setZzmarkiii(zppmar3entry.getZdescription());
				}
				ZPPMAR4 zppmar4entry = ZPPMAR4.getZPPMAR4ByKey(em, system, mandt, mvkeentry.getZzmarkiv());
				if (zppmar4entry != null) {
					fullProduct.setZzmarkiv(zppmar4entry.getZdescription());
				}
			}

			// Fetch and set MARC data
			// MARCPK marcpk = new MARCPK(system, mandt, matnr, plant);
			// MARC marcentry = MARC.getMARCByKey(em, marcpk);
			// if (marcentry != null)
			// {
			// fullProduct.setHerkl(marcentry.getHerkl());
			// }

			// Fetch and set PRICAT_K003 data
			PRICAT_K003PK k003pk1 = new PRICAT_K003PK(system, mandt, prinbr, productgroup, ean_upc_base, validity_base);
			PRICAT_K003 k003entry = PRICAT_K003.getPRICAT_K003ByKey(em, k003pk1);
			if (k003entry != null) {
				fullProduct.setHerkl(k003entry.getCountryori());
			}

			// Fetch and set PRICAT_K003Z data
			PRICAT_K003PK k003pk = new PRICAT_K003PK(system, mandt, prinbr, productgroup, ean_upc_base, validity_base);
			PRICAT_K003Z k003zcentry = PRICAT_K003Z.getPRICAT_K003ZByKey(em, k003pk);
			if (k003zcentry != null) {
				fullProduct.setComm_code(k003zcentry.getComm_code());
			}

			// Fetch and set PRICAT_K004 data (Dimensions)
			// LOGGER.debug("Fetch K004 data");

			List<PRICAT_K004> list4 = PRICAT_K004.getK004With(em, system, mandt, prinbr, productgroup, ean_upc_base,
					validity_base);

			List<UoMWrapper> uomlist = new ArrayList<UoMWrapper>();
			UoMWrapper uomfirst = null;
			UoMWrapper uomsecond = null;
			UoMWrapper uomthird = null;
			Integer layQuantitySubline = null;
			int count = 0;

			// First get the lay quantity subline
			for (PRICAT_K004 element : list4) {
				if (element.getAlt_unit().equalsIgnoreCase("LAY")) {
					layQuantitySubline = element.getQuantity_subline();
					break;
				}
			}

			for (PRICAT_K004 element : list4) {
				UoMWrapper uom = new UoMWrapper();
				uom.setAlt_unit(element.getAlt_unit());
				uom.setEan_upc_altunit(element.getKey().getEan_upc_altunit());
				uom.setNet_weight(element.getNet_weight());
				uom.setUnit_of_net(element.getUnit_of_net());
				uom.setGross_wt(element.getGross_wt());
				uom.setUnit_of_wt(element.getUnit_of_wt());
				uom.setVolume(element.getVolume());
				uom.setVolumeunit(element.getVolumeunit());
				uom.setLength(element.getLength());
				uom.setWidth(element.getWidth());
				uom.setHeight(element.getHeight());
				uom.setUnit_length(element.getUnit_length());
				uom.setUnit_width(element.getUnit_width());
				uom.setUnit_height(element.getUnit_height());
				uom.setQuantity_subline(element.getQuantity_subline());

				if (count == 0) {
					uomfirst = uom;
				} else if (count == 1) {
					uomsecond = uom;
				} else if (count == 2) {
					uomthird = uom;
				}

				if (count > 0) {
					uom.setNb_per_first(element.getQuantity_subline() / uomfirst.getQuantity_subline());
				}
				if (count > 1) {
					uom.setNb_per_second(element.getQuantity_subline() / uomsecond.getQuantity_subline());
				}
				if (count > 2) {
					uom.setNb_per_third(element.getQuantity_subline() / uomthird.getQuantity_subline());
				}

				if (layQuantitySubline != null) {
					uom.setNb_per_lay(layQuantitySubline / uom.getQuantity_subline());
					uom.setNb_of_lay(uom.getQuantity_subline() / layQuantitySubline);
				}

				uomlist.add(uom);
				count++;
			}

			fullProduct.setUomlist(uomlist);

			// Fetch and set PRICAT_K005 data (Texts)
			String texttypes[] = { "GRUN", "ZING", "ZCME", "ZMKG", "FS" };
			List<PRICAT_K005> listK005 = PRICAT_K005.getK005With(em, system, mandt, prinbr, productgroup, ean_upc_base,
					validity_base, language, texttypes);

			for (PRICAT_K005 element : listK005) {

				if (element.getKey().getTexttyp() != null && element.getText_line() != null) {
					LOGGER.debug("K005 element" + element.getKey().getTexttyp().toString());

					if (element.getKey().getTexttyp().equalsIgnoreCase("GRUN")) {
						try {
							// LOGGER.debug("K005 element" +
							// element.getText_line().substring(0,9) );
							// LOGGER.debug("K005 element" +
							// element.getText_line() );

							if (element.getText_line().contains(vkorg + "-" + ecatd + ":"))
								// element.getText_line().substring(0,9).equalsIgnoreCase(vkorg
								// + "-CAT:"))
							{
								String value = element.getText_line().replace(vkorg + "-" + ecatd + ":", "");
								// LOGGER.debug(value);
								fullProduct.setEcatdescription(value);
							}
						} catch (Exception e) {
							fullProduct.setEcatdescription("");
							LOGGER.debug("Error with GRUN text setting ecatdescription: " + e.toString());
						}

					} else if (element.getKey().getTexttyp().equalsIgnoreCase("ZING")) {
						try {
							if (fullProduct.getIngredientlist() == null) {
								fullProduct.setIngredientlist(element.getText_line());
							} else {
								fullProduct.setIngredientlist(fullProduct.getIngredientlist() + element.getText_line());
							}
						} catch (Exception e) {
							fullProduct.setIngredientlist("");
							LOGGER.debug("Error with ZING text setting ingredientlist: " + e.toString());
						}

					} else if (element.getKey().getTexttyp().equalsIgnoreCase("ZCME")) {
						if (fullProduct.getZcmetext() == null) {
							fullProduct.setZcmetext(element.getText_line());
						} else {
							fullProduct.setZcmetext(fullProduct.getZcmetext() + element.getText_line());
						}

					} else if (element.getKey().getTexttyp().equalsIgnoreCase("ZMKG")) {
						if (fullProduct.getMarketingtexts() == null) {
							fullProduct.setMarketingtexts(element.getText_line());
						} else {
							fullProduct.setMarketingtexts(fullProduct.getMarketingtexts() + element.getText_line());
						}
					} else if (element.getKey().getTexttyp().equalsIgnoreCase("FS")) {
						if (fullProduct.getStddescription() == null) {
							fullProduct.setStddescription(element.getText_line());
						} else {
							fullProduct.setStddescription(fullProduct.getStddescription() + element.getText_line());
						}

					}
				}
			}

			// Check if ZCME texts are filled, and if so try to parse different
			// claims.
			if (fullProduct.getZcmetext() != null) {
				if (StringUtils.countMatches(fullProduct.getZcmetext(), "CM_BEFORE") == 2) {
					String cm_before = StringUtils.substringBetween(fullProduct.getZcmetext(), "CM_BEFORE");
					fullProduct.setBeforeopening(cm_before);
				}

				if (StringUtils.countMatches(fullProduct.getZcmetext(), "CM_AFTER") == 2) {
					String cm_after = StringUtils.substringBetween(fullProduct.getZcmetext(), "CM_AFTER");
					fullProduct.setAfteropening(cm_after);
				}

				if (StringUtils.countMatches(fullProduct.getZcmetext(), "CM_ADMNO") == 2) {
					String cm_adm = StringUtils.substringBetween(fullProduct.getZcmetext(), "CM_ADMNO");
					fullProduct.setInstructionsuse(cm_adm);
				}

				if (StringUtils.countMatches(fullProduct.getZcmetext(), "CM_ADMLI") == 2) {
					String cm_admli = StringUtils.substringBetween(fullProduct.getZcmetext(), "CM_ADMLI");
					fullProduct.setInstructionsuselight(cm_admli);
				}

			}

			// Check if marketing texts are filled, and if so try to parse
			// different claims.
			if (fullProduct.getMarketingtexts().length() > 0) {
				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_TEXTURE") == 2) {
					String mktexture = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_TEXTURE");

					if (mktexture.length() > 0) {
						fullProduct.setMktexture(mktexture);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_INGREDIENT") == 2) {
					String mkingredient = StringUtils.substringBetween(fullProduct.getMarketingtexts(),
							"MK_INGREDIENT");

					if (mkingredient.length() > 0) {
						fullProduct.setMkingredient(mkingredient);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_BENEFITS") == 2) {
					String mkbenefits = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_BENEFITS");

					if (mkbenefits.length() > 0) {
						fullProduct.setMkbenefits(mkbenefits);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_OTHER") == 2) {
					String mkother = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_OTHER");
					if (mkother.length() > 0) {
						fullProduct.setMkother(mkother);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_CLAIM1") == 2) {
					String mkclaim1 = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_CLAIM1");

					if (mkclaim1.length() > 0) {
						fullProduct.setClaim1(mkclaim1);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_CLAIM2") == 2) {
					String mkclaim2 = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_CLAIM2");

					if (mkclaim2.length() > 0) {
						fullProduct.setClaim2(mkclaim2);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_CLAIM3") == 2) {
					String mkclaim3 = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_CLAIM3");

					if (mkclaim3.length() > 0) {
						fullProduct.setClaim3(mkclaim3);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_CLAIM4") == 2) {
					String mkclaim4 = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_CLAIM4");

					if (mkclaim4.length() > 0) {
						fullProduct.setClaim4(mkclaim4);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_CLAIM5") == 2) {
					String mkclaim5 = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_CLAIM5");

					if (mkclaim5.length() > 0) {
						fullProduct.setClaim5(mkclaim5);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_NAMECOMM") == 2) {
					String mknamecomm = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_NAMECOMM");
					if (mknamecomm.length() > 0) {
						fullProduct.setCommercialDescription(mknamecomm);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_DESCRIPTION") == 2) {
					String mkdesc = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_DESCRIPTION");
					if (mkdesc.length() > 0) {
						fullProduct.setInternetdescription(mkdesc);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_CONSUMPTION") == 2) {
					String mkconsumption = StringUtils.substringBetween(fullProduct.getMarketingtexts(),
							"MK_CONSUMPTION");
					if (mkconsumption.length() > 0) {
						fullProduct.setConsumptionmoment(mkconsumption);
					}
				}

				if (StringUtils.countMatches(fullProduct.getMarketingtexts(), "MK_FORMAT") == 2) {
					String mkformat = StringUtils.substringBetween(fullProduct.getMarketingtexts(), "MK_FORMAT");
					if (mkformat.length() > 0) {
						fullProduct.setFormat(mkformat);
					}
				}
			}

			// Fetch and set PRICAT_K006 data (Characteristics)

			LOGGER.debug("K006 data");

			List<AllergenWrapper> fullAllergenList = new ArrayList<AllergenWrapper>();
			List<AllergenDetailWrapper> detailAllergensContain = new ArrayList<AllergenDetailWrapper>();
			List<AllergenDetailWrapper> detailAllergensMayContain = new ArrayList<AllergenDetailWrapper>();
			List<AllergenDetailWrapper> detailAllergensNotPresent = new ArrayList<AllergenDetailWrapper>();

			ArrayList<String> characteristics = new ArrayList<String>();
			characteristics.add("FR8_PROJECT_CODE");
			characteristics.add("FR8_CONSUMPTION_AGE");
			characteristics.add("DENOMIN");
			characteristics.add("ADRESS_COM");
			characteristics.add("PRECAUTION");
			characteristics.add("MILK_PAVES");
			characteristics.add("INDICATION");
			characteristics.add("LEG_STATE");
			characteristics.add("ALLERGENS_NOT_PRESENT");
			characteristics.add("ALLERGENS_PRESENT");
			characteristics.add("FR8_GOOD_SUPPLIER_AGREEMENT");
			characteristics.add("CONTAIN");
			characteristics.add("MAY_CONTAIN");
			characteristics.add("ALLERGENS_NOT_PRESENT");
			characteristics.add("CROSS_CONTAMINATION");
			characteristics.add("MOD_ATM");
			characteristics.add("ZZ_FP_MIN_SHELF_LIFE_PRODUCTIO");
			characteristics.add("ZZ_FP_MIN_SHELF_LIFE_DELIVERY");
			characteristics.add("LABELLING_CODE");
			characteristics.add("ZZ_FPW_CONSIGNE");
			characteristics.add("ZZ_FPW_PALETTISATION");
			characteristics.add("ARTEMIS_SKU");
			characteristics.add("FR8_GOOD_SUPPLIER");
			characteristics.add("FR8_SC_MILKY_PRODUCTS");
			characteristics.add("ZZ_FP_GMO");
			characteristics.add("ZZ_FP_ORGANIC");
			characteristics.add("ZZ_GPC_BRICK");
			characteristics.add("CONSUMPTION_TIME");
			characteristics.add("CLICK_2_BUY");

			List<PRICAT_K006> list = PRICAT_K006.getK006With(em, system, mandt, prinbr, productgroup, ean_upc_base,
					validity_base, characteristics);

			// LOGGER.debug("testqfqsdfqds");
			// LOGGER.debug("PRICAT_K006 entrees: " + list.size());
			for (PRICAT_K006 element : list) {

				if (element.getKey().getCharacteristic().equalsIgnoreCase("LABELLING_CODE")) {
					fullProduct.setCode_labelling(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("FR8_PROJECT_CODE")) {
					fullProduct.setProject_code(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("DENOMIN")) {
					fullProduct.setLegaldeno(element.getKey().getMention(em, language));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ADRESS_COM")) {
					fullProduct.setTradename(element.getKey().getMention(em, language));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("PRECAUTION")) {
					if (fullProduct.getAdviseuse().length() == 0) {
						fullProduct.setAdviseuse(element.getKey().getMention(em, language));
					} else {
						fullProduct.setAdviseuse(
								fullProduct.getAdviseuse() + " " + element.getKey().getMention(em, language));
					}
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("MILK_PAVES")) {
					fullProduct.setNoticemilk(element.getKey().getMention(em, language));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("INDICATION")) {
					if (fullProduct.getSpecificindic().length() == 0) {
						fullProduct.setSpecificindic(element.getKey().getMention(em, language));
					} else {
						fullProduct.setSpecificindic(
								fullProduct.getSpecificindic() + " " + element.getKey().getMention(em, language));
					}
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("LEG_STATE")) {
					fullProduct.setRegulcce(element.getKey().getMention(em, language));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ALLERGENS_PRESENT")) {
					AllergenWrapper fullAllergen = new AllergenWrapper();
					fullAllergen.setAllergen(element.getKey().getAllergen(em, language));
					fullAllergen.setPresence("Yes");
					fullAllergenList.add(fullAllergen);
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ALLERGENS_NOT_PRESENT")) {
					AllergenWrapper fullAllergen = new AllergenWrapper();
					fullAllergen.setAllergen(element.getKey().getAllergen(em, language));
					fullAllergen.setPresence("No");
					fullAllergenList.add(fullAllergen);
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("FR8_GOOD_SUPPLIER_AGREEMENT")) {
					fullProduct.setAgreement(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("CONTAIN")) {
					AllergenDetailWrapper detailAllergen = new AllergenDetailWrapper();
					detailAllergen.setCode(element.getKey().getDescription());
					detailAllergen.setDescription(element.getKey().getAllergen(em, language));
					detailAllergensContain.add(detailAllergen);
					if (fullProduct.getAllergen_contain().length() == 0) {
						fullProduct.setAllergen_contain(element.getKey().getAllergen(em, language));
					} else {
						fullProduct.setAllergen_contain(
								fullProduct.getAllergen_contain() + ", " + element.getKey().getAllergen(em, language));
					}
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("MAY_CONTAIN")) {
					AllergenDetailWrapper detailAllergen = new AllergenDetailWrapper();
					detailAllergen.setCode(element.getKey().getDescription());
					detailAllergen.setDescription(element.getKey().getAllergen(em, language));
					detailAllergensMayContain.add(detailAllergen);
					if (fullProduct.getAllergen_may_contain().length() == 0) {
						fullProduct.setAllergen_may_contain(element.getKey().getAllergen(em, language));
					} else {
						fullProduct.setAllergen_may_contain(fullProduct.getAllergen_may_contain() + ", "
								+ element.getKey().getAllergen(em, language));
					}
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ALLERGENS_NOT_PRESENT")) {
					AllergenDetailWrapper detailAllergen = new AllergenDetailWrapper();
					detailAllergen.setCode(element.getKey().getDescription());
					detailAllergen.setDescription(element.getKey().getAllergen(em, language));
					detailAllergensNotPresent.add(detailAllergen);
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("CROSS_CONTAMINATION")) {
					if (fullProduct.getCross_contamination().length() == 0) {
						fullProduct.setCross_contamination(element.getKey().getAllergen(em, language));
					} else {
						fullProduct.setCross_contamination(fullProduct.getCross_contamination() + ", "
								+ element.getKey().getAllergen(em, language));
					}
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("MOD_ATM")) {
					fullProduct.setRegulatory(element.getKey().getMention(em, language));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ZZ_FP_MIN_SHELF_LIFE_PRODUCTIO")) {
					fullProduct.setLifetime_day(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ZZ_FP_MIN_SHELF_LIFE_DELIVERY")) {
					fullProduct.setDlsc(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ZZ_FPW_CONSIGNE")) {
					fullProduct.setConsigne(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ZZ_FPW_PALETTISATION")) {
					fullProduct.setPalettisation(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ARTEMIS_SKU")) {
					fullProduct.setArtemis_sku(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("FR8_GOOD_SUPPLIER")) {
					fullProduct.setGoodsupplier(element.getKey().getDescription());
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("FR8_SC_MILKY_PRODUCTS")) {
					fullProduct.setMilkyproduct(element.getKey().getCharvaltxt(em, spras));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ZZ_FP_GMO")) {
					fullProduct.setGmo(element.getKey().getCharvaltxt(em, spras));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ZZ_FP_ORGANIC")) {
					fullProduct.setOrganic(element.getKey().getCharvaltxt(em, spras));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ZZ_GPC_BRICK")) {
					fullProduct.setBrick(element.getKey().getCharvaltxt(em, spras));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("CONSUMPTION_TIME")) {
					if (fullProduct.getConsumptiontime().length() == 0) {
						fullProduct.setConsumptiontime(element.getKey().getCharvaltxt(em, spras));
					} else {
						fullProduct.setConsumptiontime(fullProduct.getConsumptiontime() + ", "
								+ element.getKey().getCharvaltxt(em, spras));
					}
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("FR8_CONSUMPTION_AGE")) {
					fullProduct.setConsumptionage(element.getKey().getCharvaltxt(em, spras));
				} else if (element.getKey().getCharacteristic().equalsIgnoreCase("CLICK_2_BUY")) {
					fullProduct.setClick2buy(element.getKey().getDescription());
				}
			}

			// LOGGER.debug("testafter");

			fullProduct.setAllergenList(fullAllergenList);
			fullProduct.setAllergensContainList(detailAllergensContain);
			fullProduct.setAllergensMayContainList(detailAllergensMayContain);
			fullProduct.setAllergensNotPresentList(detailAllergensNotPresent);

			LOGGER.debug("ZPRO_NUTBOARD data");

			List<ZPRO_NUTBOARD> nutboard = ZPRO_NUTBOARD.getNutboardByMatnrAndValidityAndLabelcod(em, system, matnr,
					fullProduct.getCode_labelling());
			List<NutboardWrapper> nutboardWrap = new ArrayList<NutboardWrapper>();

			for (ZPRO_NUTBOARD nut : nutboard) {
				NutboardWrapper newWrap = new NutboardWrapper();
				newWrap.setPorid(nut.getKey().getPorid());
				newWrap.setNutid(nut.getKey().getNutid());
				newWrap.setPoridun(nut.getPoridun());
				newWrap.setPoridtext(nut.getPoridtext());
				newWrap.setRank(nut.getRank());
				newWrap.setPoridva(nut.getPoridva());
				newWrap.setPoridvaro(nut.getPoridvaro());
				newWrap.setValueun(nut.getValueun());
				newWrap.setAjrc(nut.getAjrc());
				newWrap.setAjrcun(nut.getAjrcun());
				newWrap.setDisplay(nut.getDisplay());
				newWrap.setPoridsign(nut.getPoridsign());

				ZPRO_NUTRIENT nutr = ZPRO_NUTRIENT.getZPRO_NUTRIENTBySubid(em, system, mandt, nut.getKey().getNutid(),
						language);

				if (nutr != null) {
					newWrap.setNutidtext(nutr.getContent().trim());
				}

				nutboardWrap.add(newWrap);
			}

			fullProduct.setNutboard(nutboardWrap);

			LOGGER.debug("ZPRICAT_K007 data");

			try {
				// Fetch multi variétés
				List<PRICAT_K007> listPackMulti = PRICAT_K007.getK007With(em, system, mandt, prinbr, productgroup,
						ean_upc_base, validity_base);
				List<MultipackWrapper> multi = new ArrayList<MultipackWrapper>();

				for (PRICAT_K007 pr007 : listPackMulti) {
					MultipackWrapper multiwrap = new MultipackWrapper();

					LOGGER.debug("before Query MultiPack");

					String queryString = "SELECT distinct p FROM ZPRODCAT_HDR p, ZPRODCAT_ITEM i where "
							+ "p.key.cat_guid = i.key.cat_guid and " + "p.key.system = :system and "
							+ "p.key.mandt = :mandt and " + "p.matnr = :matnr and " + "p.vkorg = :vkorg and "
							+ "p.vtweg = :vtweg and " + "p.prinbr = :prinbr and "
							// + "p.productgroup = :productgroup and "
							+ "p.ean_upc_base = :ean_upc_base and " + "p.asort = :asort " + "ORDER BY p.verno DESC";
					Query query = em.createQuery(queryString, ZPRODCAT_HDR.class).setParameter("system", system)
							.setParameter("mandt", mandt).setParameter("matnr", pr007.getEan_matnr())
							.setParameter("vkorg", vkorg).setParameter("vtweg", vtweg).setParameter("prinbr", prinbr)
							// .setParameter("productgroup", productgroup)
							.setParameter("ean_upc_base", pr007.getKey().getEan_upc_subline())
							.setParameter("asort", asort.getAsort());

					List<ZPRODCAT_HDR> hdrList = ZPRODCAT_HDR.getAllProductsWithQuery(em, query);

					LOGGER.debug("after Query MultiPack");

					if (hdrList.size() > 0) {
						ZPRODCAT_HDR hdrMulti = null;
						for (ZPRODCAT_HDR hdrMultiLoop : hdrList) {
							if (hdrMulti == null) {
								hdrMulti = hdrMultiLoop;
							} else {
								if (Integer.parseInt(hdrMultiLoop.getStatus()) <= Integer
										.parseInt(hdrMulti.getStatus())) {
									hdrMulti = hdrMultiLoop;
								}
							}
						}

						ZPRODCAT_ITEM item = ZPRODCAT_ITEM.getItemByGuidAndPostyp(em, hdrMulti.getKey().getSystem(),
								hdrMulti.getKey().getCat_guid(), "P");

						if (item != null) {
							multiwrap.setValidity_base(item.getValidity_base());
						}

						multiwrap.setCurrentStatus(hdrMulti.getStatus());
						multiwrap.setCat_guid(hdrMulti.getKey().getCat_guid());
						multiwrap.setEan_upc_base(hdrMulti.getEan_upc_base());
						multiwrap.setMatnr(hdrMulti.getMatnr().replaceFirst("^0+(?!$)", ""));

						ArrayList<String> characterist = new ArrayList<String>();
						characterist.add("LABELLING_CODE");
						characterist.add("ARTEMISCODE");
						characterist.add("PACKPRINT_LABCODE");
						characterist.add("LABEL_STATUS");
						characteristics.add("ARTEMIS_SKU");

						List<PRICAT_K006> listMulti = PRICAT_K006.getK006With(em, system, mandt, hdrMulti.getPrinbr(),
								hdrMulti.getProductgroup(), hdrMulti.getEan_upc_base(), item.getValidity_base(),
								characterist);

						for (PRICAT_K006 element : listMulti) {

							if (element.getKey().getCharacteristic().equalsIgnoreCase("LABELLING_CODE")) {
								multiwrap.setCode_labelling(element.getKey().getDescription());
							}

							if (element.getKey().getCharacteristic().equalsIgnoreCase("PACKPRINT_LABCODE")) {
								multiwrap.setLsf(element.getKey().getDescription());
							} else if (element.getKey().getCharacteristic().equalsIgnoreCase("LABEL_STATUS")) {
								multiwrap.setLabel_status(element.getKey().getDescription());
							} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ARTEMISCODE")) {
								multiwrap.setCode_output(element.getKey().getDescription());
							} else if (element.getKey().getCharacteristic().equalsIgnoreCase("ARTEMIS_SKU")) {
								multiwrap.setArtemis_sku(element.getKey().getDescription());
							}
						}

						MAKTPK maktmultipk = new MAKTPK(system, mandt, hdrMulti.getMatnr(), "E");
						MAKT maktmultientry = MAKT.getMAKTByKey(em, maktmultipk);
						if (maktmultientry != null) {
							multiwrap.setDescription(maktmultientry.getMaktx());
						}

						List<PRICAT_K007> listK007 = PRICAT_K007.getK007With(em, system, mandt, prinbr, productgroup,
								ean_upc_base, validity_base);
						for (PRICAT_K007 k007 : listK007) {
							if (k007.getKey().getEan_upc_subline().equalsIgnoreCase(hdrMulti.getEan_upc_base())) {
								multiwrap.setQuantity_subline(k007.getQuantity_subline());
								break;
							}
						}

						List<ZPRO_NUTBOARD> nutboardmulti = ZPRO_NUTBOARD.getNutboardByMatnrAndValidityAndLabelcod(em,
								system, hdrMulti.getMatnr(), multiwrap.getCode_labelling());
						LOGGER.debug("nutboardmulti size" + nutboardmulti.size());
						List<NutboardWrapper> nutboarmultidWrap = new ArrayList<NutboardWrapper>();

						for (ZPRO_NUTBOARD nut : nutboardmulti) {
							NutboardWrapper newWrap = new NutboardWrapper();
							newWrap.setPorid(nut.getKey().getPorid());
							newWrap.setNutid(nut.getKey().getNutid());
							newWrap.setPoridun(nut.getPoridun());
							newWrap.setPoridtext(nut.getPoridtext());
							newWrap.setRank(nut.getRank());
							newWrap.setPoridva(nut.getPoridva());
							newWrap.setPoridvaro(nut.getPoridvaro());
							newWrap.setValueun(nut.getValueun());
							newWrap.setAjrc(nut.getAjrc());
							newWrap.setAjrcun(nut.getAjrcun());
							newWrap.setDisplay(nut.getDisplay());
							newWrap.setPoridsign(nut.getPoridsign());

							ZPRO_NUTRIENT nutr = ZPRO_NUTRIENT.getZPRO_NUTRIENTBySubid(em, system, mandt,
									nut.getKey().getNutid(), language);

							if (nutr != null) {
								newWrap.setNutidtext(nutr.getContent().trim());
							}

							nutboarmultidWrap.add(newWrap);
						}
						multiwrap.setNutboard(nutboarmultidWrap);

						multi.add(multiwrap);
					}
				}

				fullProduct.setMultiList(multi);

			} catch (Exception e) {
				LOGGER.error("Error getting pack multi variétés in details: " + e.toString());
			}

			return fullProduct;

		} catch (Exception e) {
			LOGGER.error("Error getting products details: " + e.toString());
		} finally {
			em.close();
		}

		return null;
	}
}
