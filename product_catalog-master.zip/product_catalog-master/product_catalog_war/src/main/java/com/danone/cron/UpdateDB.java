package com.danone.cron;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.imaging.Imaging;
import org.apache.tika.Tika;
import org.imgscalr.Scalr;
import org.imgscalr.Scalr.Method;
import org.imgscalr.Scalr.Mode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.MAKT;
import com.danone.entities.MAKTPK;
import com.danone.entities.MARA;
import com.danone.entities.MARAPK;
import com.danone.entities.MARC;
import com.danone.entities.MARCPK;
import com.danone.entities.MVKE;
import com.danone.entities.MVKEPK;
import com.danone.entities.PICTURES;
import com.danone.entities.PICTURESPK;
import com.danone.entities.PRICAT_K001;
import com.danone.entities.PRICAT_K001PK;
import com.danone.entities.PRICAT_K002;
import com.danone.entities.PRICAT_K002PK;
import com.danone.entities.PRICAT_K003;
import com.danone.entities.PRICAT_K003PK;
import com.danone.entities.PRICAT_K003Z;
import com.danone.entities.PRICAT_K004;
import com.danone.entities.PRICAT_K004PK;
import com.danone.entities.PRICAT_K005;
import com.danone.entities.PRICAT_K005PK;
import com.danone.entities.PRICAT_K006;
import com.danone.entities.PRICAT_K006PK;
import com.danone.entities.PRICAT_K007;
import com.danone.entities.PRICAT_K007PK;
import com.danone.entities.PRICAT_K00A;
import com.danone.entities.PRICAT_K00APK;
import com.danone.entities.PRICAT_K010_ZPRO_VPRICAT_S;
import com.danone.entities.PRICAT_K010_ZPRO_VPRICAT_SPK;
import com.danone.entities.ReplicationInfo;
import com.danone.entities.ZPRODCAT_HDR;
import com.danone.entities.ZPRODCAT_HDRPK;
import com.danone.entities.ZPRODCAT_ITEM;
import com.danone.entities.ZPRODCAT_ITEMPK;
import com.danone.entities.ZPROEU_GRP_PROD;
import com.danone.entities.ZPROEU_GRP_PRODPK;
import com.danone.entities.ZPROEU_PLANT;
import com.danone.entities.ZPROEU_PLANTPK;
import com.danone.entities.ZPROEU_QTY;
import com.danone.entities.ZPROEU_QTYPK;
import com.danone.entities.ZPRO_ASSORTMENT;
import com.danone.entities.ZPRO_ASSORTMENTPK;
import com.danone.entities.ZPRO_NUTBOARD;
import com.danone.entities.ZPRO_NUTBOARDPK;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.CmisHelper;
import com.danone.util.Utils;
//import com.danone.util.JpegReader;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoListMetaData;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

public class UpdateDB extends TimerTask {

	@Context
	private HttpServletRequest servletRequest;

	private static Logger LOGGER = LoggerFactory.getLogger(UpdateDB.class);
	// private static String destinationName = "PRODCATALOG-SAP";
	private static List<String> destinations = null;
	private String currentDestination = null;
	private JCoRepository repo = null;
	private JCoDestination destination = null;
	private static UpdateDB instance = null;

	protected UpdateDB() {
		// Exists only to defeat instantiation.
	}

	public static UpdateDB getInstance() {
		if (instance == null) {
			instance = new UpdateDB();
			destinations = new ArrayList<String>();
			destinations.add("PRODCATALOG-SAP");
			destinations.add("PRODCATALOG-SAP1");
			destinations.add("PRODCATALOG-SAP2");
			destinations.add("PRODCATALOG-SAP3");
			// destinations.add("PRODCATALOG-SAP4");
			// destinations.add("PRODCATALOG-SAP5");
			// destinations.add("PRODCATALOG-SAP6");
			// destinations.add("PRODCATALOG-SAP7");
			// destinations.add("PRODCATALOG-SAP8");
			// destinations.add("PRODCATALOG-SAP9");
		}

		return instance;
	}

	public void startManual(String username) {

		LOGGER.debug("Start manual synchronisation");

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();

			ReplicationInfo info = new ReplicationInfo();
			info.setIsManual(true);

			Calendar calendar = Calendar.getInstance();
			java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
			info.setStartDate(ourJavaDateObject);
			info.setUser(username);
			info.setTime(new java.sql.Time(calendar.getTime().getTime()));

			em.merge(info);
			transaction.commit();

		} catch (Exception e) {
			LOGGER.error("Exception while creating ReplicationInfo " + e.toString());
		} finally {
			em.close();
		}

		// Automatic start
		start(false, "", "");
	}

	public void startSingle(String guid, String system) {

		LOGGER.debug("Start single synchronisation");

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {

			transaction.begin();

			ReplicationInfo info = new ReplicationInfo();
			info.setIsManual(false);

			Calendar calendar = Calendar.getInstance();
			java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
			info.setStartDate(ourJavaDateObject);
			info.setUser("BATCH - SINGLE");
			info.setTime(new java.sql.Time(calendar.getTime().getTime()));

			em.merge(info);
			transaction.commit();

		} catch (Exception e) {
			LOGGER.error("Exception while creating ReplicationInfo " + e.toString());
		} finally {
			em.close();
		}

		start(true, guid, system);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {

			transaction.begin();

			ReplicationInfo info = new ReplicationInfo();
			info.setIsManual(false);

			Calendar calendar = Calendar.getInstance();
			java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
			info.setStartDate(ourJavaDateObject);
			info.setUser("BATCH");
			info.setTime(new java.sql.Time(calendar.getTime().getTime()));

			em.merge(info);
			transaction.commit();

		} catch (Exception e) {
			LOGGER.error("Exception while creating ReplicationInfo " + e.toString());
		} finally {
			em.close();
		}

		// Automatic start
		start(false, "", "");
	}

	public void start(Boolean isSingle, String guid, String system) {

		if (isSingle) {
			repo = null;
			currentDestination = system;
			doProcessing(isSingle, guid);
		} else {
			for (String dest : destinations) {
				repo = null;
				currentDestination = dest;
				LOGGER.debug("start processing");
				doProcessing(isSingle, guid);
				LOGGER.debug("end processing");
				try {
					LOGGER.debug("Start waiting");
					Thread.sleep(5000);
					LOGGER.debug("Finished waiting");
				} catch (InterruptedException e) {
					LOGGER.error("Error while sleeping: " + e.getLocalizedMessage());
				}
			}
		}
	}

	public void doProcessing(Boolean isSingle, String guid) {
		LOGGER.debug("UpdateDB is running on system: " + currentDestination);
		int numberOfItemsReplicatedOnSystem = 0;

		try {
			destination = null;
			repo = null;
			LOGGER.debug("Initializing Repository on destination: " + currentDestination);
			destination = JCoDestinationManager.getDestination(currentDestination);
			repo = destination.getRepository();
			// JCo.setProperty("jco.use_repository_roundtrip_optimization",
			// "1");
			List<String> functions = new ArrayList<String>();
			functions.add("ZSHCP_PROM_FETCH_UPDATES");
			functions.add("ZSHCP_PROM_SET_STATUS_DONE");
			functions.add("ZSHCP_PROM_FETCH_SINGLE_UPDATE");
			functions.add("ZSHCP_PROM_FETCH_DOC_PHOTO");
			// JCo.queryMetaDataSet(repo, functions, null, null);
			LOGGER.debug("Initializing Finished....");

		} catch (JCoException e) {
			LOGGER.error("Exception during Repository Initiliazation: " + e.getLocalizedMessage());
			repo = null;
		}

		if (!isSingle && repo != null) {
			JCoTable itemTable = null;

			try {
				LOGGER.debug("Access RFC");
				// access the RFC Destination via Cloud Connector
				// JCoDestination destination =
				// JCoDestinationManager.getDestination(currentDestination);
				// JCoRepository repo = destination.getRepository();

				// make an invocation of FUNCTION in the back-end
				JCoFunction stfcConnection = null;
				try {
					 stfcConnection = repo.getFunction("ZSHCP_PROM_FETCH_UPDATES");
				} catch (Throwable t) {
					LOGGER.debug("An exception occurred " + t.getLocalizedMessage());
				}

				Boolean doneFetchingAllValues = false;

				while (!doneFetchingAllValues) {
					// Run the Function module
					LOGGER.debug("Before execute");
					try {
						stfcConnection.execute(destination);
					} catch (Throwable t) {
						LOGGER.debug("An exception occurred " + t.getLocalizedMessage());
					}
					LOGGER.debug("After execute");

					// Get results
					JCoParameterList exports = stfcConnection.getExportParameterList();
					JCoListMetaData exportParameters = exports.getListMetaData();

					/*
					 * Check if FM fetched all values, or if the FM needs to run
					 * again
					 */
					JCoStructure struct = exports.getStructure("ES_EXPORT_STRUCTURE");

					if (struct != null) {
						JCoTable tabl = struct.getTable("ZPRODCAT_HDR");
						if (tabl != null) {
							numberOfItemsReplicatedOnSystem = numberOfItemsReplicatedOnSystem + tabl.getNumRows();

							if (tabl.getNumRows() < 5 || numberOfItemsReplicatedOnSystem >= 100) {
								doneFetchingAllValues = true;
							}
						} else {
							doneFetchingAllValues = true;
						}
					} else {
						doneFetchingAllValues = true;
					}

					LOGGER.debug("start loop over export");
					for (int i = 0; i < exportParameters.getFieldCount(); i++) {
						String paramName = exportParameters.getName(i);

						try {
							/*
							 * if
							 * (paramName.equalsIgnoreCase("ET_PRODUCT_DETAILS")
							 * ) { LOGGER.debug("ET_PRODUCT_DETAILS"); JCoTable
							 * outputTable = exports.getTable(paramName);
							 * handlePicture(outputTable); }else
							 */
							if (paramName.equalsIgnoreCase("ES_EXPORT_STRUCTURE")) {
								LOGGER.debug("ES_EXPORT_STRUCTURE");
								JCoStructure structure = exports.getStructure(paramName);
								deleteValues(currentDestination, structure.getTable("ZPRODCAT_HDR"),
										structure.getTable("ZPRODCAT_ITEM"));
								fillZPROASSORTMENT(currentDestination, structure.getTable("ZPRO_ASSORTMENT"));
								fillMara(currentDestination, structure.getTable("MARA"));
								fillMakt(currentDestination, structure.getTable("MAKT"));
								fillMarc(currentDestination, structure.getTable("MARC"));
								fillMvke(currentDestination, structure.getTable("MVKE"));
								fillZPRODCAT_HDR(currentDestination, structure.getTable("ZPRODCAT_HDR"));
								cleanZPRODCAT_ITEM(currentDestination, structure.getTable("ZPRODCAT_HDR"));
								fillZPRODCAT_ITEM(currentDestination, structure.getTable("ZPRODCAT_ITEM"));
								fillPricatK001(currentDestination, structure.getTable("PRICAT_K001"));
								fillPricatK002(currentDestination, structure.getTable("PRICAT_K002"));
								fillPricatK003(currentDestination, structure.getTable("PRICAT_K003"));
								fillPricatK003Z(currentDestination, structure.getTable("PRICAT_K003Z"));
								fillPricatK004(currentDestination, structure.getTable("PRICAT_K004"));
								fillPricatK005(currentDestination, structure.getTable("PRICAT_K005"));
								fillPricatK006(currentDestination, structure.getTable("PRICAT_K006"));
								fillPricatK007(currentDestination, structure.getTable("PRICAT_K007"));
								fillPricatK00A(currentDestination, structure.getTable("PRICAT_K00A"));
								fillPricatK010_ZPRO_VPRICAT_S(currentDestination,
										structure.getTable("PRICAT_K010_ZPRO_VPRICAT_S"));
								cleanZPRO_NUTBOARD(currentDestination, structure.getTable("ZPRODCAT_HDR"));
								fillZPRO_NUTBOARD(currentDestination, structure.getTable("ZPRO_NUTBOARD"));
								fillZPROEU_GRP_PROD(currentDestination, structure.getTable("ZPROEU_GRP_PROD"));
								fillZPROEU_QTY(currentDestination, structure.getTable("ZPROEU_QTY"));
								fillZPROEU_PLANT(currentDestination, structure.getTable("ZPROEU_PLANT"));
								processZPRODCAT_ITEM(currentDestination, structure.getTable("ZPRODCAT_ITEM"));
								updateStatusProcessingDone(destination, repo, structure.getTable("ZPRODCAT_HDR"));
							}
						} catch (Exception e) {
							e.getCause();
							LOGGER.error("Exception upon execute" + e.toString());
						}
					}
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER.error("Error during RFC " + e.toString());
			}

		} else {
			if (repo != null) {
				try {
					LOGGER.debug("Access RFC");
					// access the RFC Destination via Cloud Connector
					// JCoDestination destination =
					// JCoDestinationManager.getDestination(currentDestination);
					// JCoRepository repo = destination.getRepository();

					// make an invocation of FUNCTION in the back-end
					JCoFunction stfcConnection = repo.getFunction("ZSHCP_PROM_FETCH_SINGLE_UPDATE");

					// Set import parameters
					JCoParameterList imports = stfcConnection.getImportParameterList();
					JCoListMetaData importParameters = imports.getListMetaData();

					for (int i = 0; i < importParameters.getFieldCount(); i++) {

						String paramName = importParameters.getName(i);

						if (paramName.equalsIgnoreCase("I_CAT_GUID")) {
							imports.setValue(paramName, guid);
						}
					}

					// Run the Function module
					stfcConnection.execute(destination);

					// Get results
					JCoParameterList exports = stfcConnection.getExportParameterList();
					JCoListMetaData exportParameters = exports.getListMetaData();

					LOGGER.debug("start loop over export");
					for (int i = 0; i < exportParameters.getFieldCount(); i++) {
						String paramName = exportParameters.getName(i);

						try {
							if (paramName.equalsIgnoreCase("ES_EXPORT_STRUCTURE")) {
								LOGGER.debug("ES_EXPORT_STRUCTURE");
								JCoStructure structure = exports.getStructure(paramName);
								fillZPRODCAT_HDR(currentDestination, structure.getTable("ZPRODCAT_HDR"));
								updateStatusProcessingDone(destination, repo, structure.getTable("ZPRODCAT_HDR"));
							}

						} catch (Exception e) {
							e.getCause();
							LOGGER.error(e.toString());
						}
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOGGER.error("Error during RFC " + e.toString());
				}
			}
		}
	}

	public void updateStatusProcessingDone(JCoDestination dest, JCoRepository repo, JCoTable headerTable) {

		try {

			Boolean shouldRun = false;

			// make an invocation of FUNCTION in the back-end
			JCoFunction stfcConnection = repo.getFunction("ZSHCP_PROM_SET_STATUS_DONE");

			// Set import parameters
			JCoParameterList imports = stfcConnection.getImportParameterList();
			JCoListMetaData importParameters = imports.getListMetaData();

			for (int i = 0; i < importParameters.getFieldCount(); i++) {

				String paramName = importParameters.getName(i);

				if (paramName.equals("IT_GUIDS")) {
					JCoTable dataTable = imports.getTable("IT_GUIDS");

					for (int j = 0; j < headerTable.getNumRows(); j++) {
						headerTable.setRow(j);

						JCoField oComponent = headerTable.getField("CAT_GUID");

						dataTable.appendRow();
						dataTable.setValue(0, oComponent.getValue().toString());
						shouldRun = true;
					}
				}
			}

			// Run the Function module
			if (shouldRun) {
				stfcConnection.execute(dest);
			}

		} catch (JCoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Delete Nutritional data for catalog header replicated
	public void cleanZPRO_NUTBOARD(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {
				// get fields of current record
				JCoField mandtField = outputTable.getField("MANDT");
				Integer mandt = Integer.parseInt(mandtField.getValue().toString());
				JCoField guidField = outputTable.getField("MATNR");
				String matnr = guidField.getValue().toString();

				transaction.begin();
				// Get nutritional data linked to the material
				List<ZPRO_NUTBOARD> listNutboard = ZPRO_NUTBOARD.getNutboardByMatnr(em, system, mandt, matnr);
				for (ZPRO_NUTBOARD itemNut : listNutboard) {
					ZPRO_NUTBOARD itemNutRemove = em.merge(itemNut);
					em.remove(itemNutRemove);
				}

				transaction.commit();

			} catch (Exception e) {
				LOGGER.error("Exception while cleaning ZPRODCAT_ITEM " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	private void fillZPRO_NUTBOARD(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				ZPRO_NUTBOARD pronut = new ZPRO_NUTBOARD();
				ZPRO_NUTBOARDPK pronutpk = new ZPRO_NUTBOARDPK();
				pronutpk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pronut, pronutpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling ZPRO_NUTBOARD field " + paramName + " " + ex.toString());
						}
					}
				}

				pronut.setKey(pronutpk);

				em.merge(pronut);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling ZPRO_NUTBOARD " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	private void fillZPROEU_GRP_PROD(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				ZPROEU_GRP_PROD prodgrp = new ZPROEU_GRP_PROD();
				ZPROEU_GRP_PRODPK prodgrppk = new ZPROEU_GRP_PRODPK();
				prodgrppk.setSystem(system);
				prodgrp.setGroup1("");
				prodgrp.setGroup2("");
				prodgrp.setGroup3("");
				prodgrp.setGroup4("");
				prodgrp.setGroup5("");
				prodgrp.setGroup6("");
				prodgrp.setGroup7("");
				prodgrp.setGroup8("");
				prodgrp.setGroup9("");
				prodgrp.setGroup10("");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(prodgrp, prodgrppk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error(
									"Error while filling ZPROEU_GRP_PROD field " + paramName + " " + ex.toString());
						}
					}
				}

				prodgrp.setKey(prodgrppk);

				em.merge(prodgrp);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling ZPROEU_GRP_PROD " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	private void fillZPROEU_QTY(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				ZPROEU_QTY prodqty = new ZPROEU_QTY();
				ZPROEU_QTYPK prodqtypk = new ZPROEU_QTYPK();
				prodqtypk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(prodqty, prodqtypk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling ZPROEU_QTY field " + paramName + " " + ex.toString());
						}
					}
				}

				prodqty.setKey(prodqtypk);

				em.merge(prodqty);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling ZPROEU_QTY " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	private void fillZPROEU_PLANT(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				ZPROEU_PLANT prodplant = new ZPROEU_PLANT();
				ZPROEU_PLANTPK prodplantpk = new ZPROEU_PLANTPK();
				prodplantpk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(prodplant, prodplantpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling ZPROEU_PLANT field " + paramName + " " + ex.toString());
						}
					}
				}

				prodplant.setKey(prodplantpk);

				em.merge(prodplant);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling ZPROEU_PLANT " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	private void fillZPROASSORTMENT(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				ZPRO_ASSORTMENT proassort = new ZPRO_ASSORTMENT();
				ZPRO_ASSORTMENTPK proassortpk = new ZPRO_ASSORTMENTPK();
				proassortpk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(proassort, proassortpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error(
									"Error while filling ZPRO_ASSORTMENT field " + paramName + " " + ex.toString());
						}
					}
				}

				proassort.setKey(proassortpk);

				em.merge(proassort);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling ZPRO_ASSORTMENT " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void deleteValues(String system, JCoTable outputTable, JCoTable outputTableItem) {

		EntityManager em = PersistenceAdapter.getEntityManager();

		try {

			EntityTransaction transaction = em.getTransaction();
			transaction.begin();

			for (int i = 0; i < outputTable.getNumRows(); i++) {

				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();

				ZPRODCAT_HDR prodcat = new ZPRODCAT_HDR();
				ZPRODCAT_HDRPK prodcatpk = new ZPRODCAT_HDRPK();
				prodcatpk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(prodcat, prodcatpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling ZPRODCAT_HDR field " + paramName + " " + ex.toString());
						}
					}
				}

				prodcat.setKey(prodcatpk);

				// Find the validity date in the item table
				java.sql.Date validDate = null;
				for (int a = 0; a < outputTableItem.getNumRows(); a++) {
					outputTableItem.setRow(a);
					JCoFieldIterator ita = outputTableItem.getFieldIterator();

					ZPRODCAT_ITEM prodcatitem = new ZPRODCAT_ITEM();
					ZPRODCAT_ITEMPK prodcatitempk = new ZPRODCAT_ITEMPK();
					prodcatitempk.setSystem(system);

					// get fields of current record
					while (ita.hasNextField()) {

						JCoField oComponent = ita.nextField();

						if (oComponent.getValue() != "" && oComponent.getValue() != null) {
							String paramName = (String) oComponent.getName();
							paramName = paramName.replace("/", "");

							try {
								// Attempt to fill the field
								setFieldDynamically(prodcatitem, prodcatitempk, paramName, oComponent.getValue());
							} catch (Exception ex) {
								LOGGER.error(
										"Error while filling ZPRODCAT_ITEM field " + paramName + " " + ex.toString());
							}
						}
					}

					prodcatitem.setKey(prodcatitempk);

					if (prodcatitem.getKey().getCat_guid().equalsIgnoreCase(prodcat.getKey().getCat_guid())) {
						validDate = prodcatitem.getValidity_base();
						break;
					}
				}

				if (validDate != null) {
					List<PRICAT_K005> valuesToDelete1 = PRICAT_K005.getK005With(em, prodcat.getKey().getSystem(),
							prodcat.getKey().getMandt(), prodcat.getPrinbr(), prodcat.getProductgroup(),
							prodcat.getEan_upc_base(), validDate);

					LOGGER.debug("Delete " + valuesToDelete1.size() + " values from PRICAT_K005 for prodcat "
							+ prodcat.getKey().getCat_guid());
					for (PRICAT_K005 delete : valuesToDelete1) {
						em.remove(delete);
					}

					List<PRICAT_K006> valuesToDelete2 = PRICAT_K006.getK006With(em, prodcat.getKey().getSystem(),
							prodcat.getKey().getMandt(), prodcat.getPrinbr(), prodcat.getProductgroup(),
							prodcat.getEan_upc_base(), validDate);
					LOGGER.debug("Delete " + valuesToDelete2.size() + " values from PRICAT_K006 for prodcat "
							+ prodcat.getKey().getCat_guid());
					for (PRICAT_K006 delete : valuesToDelete2) {
						em.remove(delete);
					}

					List<PRICAT_K007> valuesToDelete3 = PRICAT_K007.getK007With(em, prodcat.getKey().getSystem(),
							prodcat.getKey().getMandt(), prodcat.getPrinbr(), prodcat.getProductgroup(),
							prodcat.getEan_upc_base(), validDate);
					LOGGER.debug("Delete " + valuesToDelete3.size() + " values from PRICAT_K007 for prodcat "
							+ prodcat.getKey().getCat_guid());
					for (PRICAT_K007 delete : valuesToDelete3) {
						em.remove(delete);
					}

					List<PRICAT_K003> valuesToDelete4 = PRICAT_K003.getK003With(em, prodcat.getKey().getSystem(),
							prodcat.getKey().getMandt(), prodcat.getPrinbr(), prodcat.getProductgroup(),
							prodcat.getEan_upc_base(), validDate);

					LOGGER.debug("Delete " + valuesToDelete4.size() + " values from PRICAT_K003 for prodcat "
							+ prodcat.getKey().getCat_guid());
					for (PRICAT_K003 delete : valuesToDelete4) {
						em.remove(delete);
					}

					List<PRICAT_K003Z> valuesToDelete5 = PRICAT_K003Z.getK003ZWith(em, prodcat.getKey().getSystem(),
							prodcat.getKey().getMandt(), prodcat.getPrinbr(), prodcat.getProductgroup(),
							prodcat.getEan_upc_base(), validDate);

					LOGGER.debug("Delete " + valuesToDelete5.size() + " values from PRICAT_K003Z for prodcat "
							+ prodcat.getKey().getCat_guid());
					for (PRICAT_K003Z delete : valuesToDelete5) {
						em.remove(delete);
					}

					List<PRICAT_K004> valuesToDelete6 = PRICAT_K004.getK004With(em, prodcat.getKey().getSystem(),
							prodcat.getKey().getMandt(), prodcat.getPrinbr(), prodcat.getProductgroup(),
							prodcat.getEan_upc_base(), validDate);

					LOGGER.debug("Delete " + valuesToDelete6.size() + " values from PRICAT_K004 for prodcat "
							+ prodcat.getKey().getCat_guid());
					for (PRICAT_K004 delete : valuesToDelete6) {
						em.remove(delete);
					}

					PRICAT_K010_ZPRO_VPRICAT_SPK K010key = new PRICAT_K010_ZPRO_VPRICAT_SPK(
							prodcat.getKey().getSystem(), prodcat.getKey().getMandt(), prodcat.getPrinbr(),
							prodcat.getProductgroup(), prodcat.getEan_upc_base(), validDate);
					PRICAT_K010_ZPRO_VPRICAT_S valueToDelete7 = PRICAT_K010_ZPRO_VPRICAT_S
							.getPRICAT_K010_ZPRO_VPRICAT_SByKey(em, K010key);
					if (valueToDelete7 != null) {
						LOGGER.debug("Delete value from PRICAT_K010_ZPRO_VPRICAT_S for prodcat "
								+ prodcat.getKey().getCat_guid());
						em.remove(valueToDelete7);
					}
				} else {
					LOGGER.debug("ERROR WHILE DELETING VALUES: NO VALIDITY DATE FOUND");
				}
			}

			transaction.commit();
		} finally {
			em.close();
		}
	}

	public void fillZPRODCAT_HDR(String system, JCoTable outputTable) {
		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				ZPRODCAT_HDR prodcat = new ZPRODCAT_HDR();
				ZPRODCAT_HDRPK prodcatpk = new ZPRODCAT_HDRPK();
				prodcatpk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(prodcat, prodcatpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling ZPRODCAT_HDR field " + paramName + " " + ex.toString());
						}
					}
				}

				prodcat.setKey(prodcatpk);

				em.merge(prodcat);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling ZPRODCAT_HDR " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	// Delete document items for catalog header replicated
	public void cleanZPRODCAT_ITEM(String system, JCoTable outputTable) {

		// LOGGER.debug("cleanZPRODCAT_ITEM starts");

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {
				// get fields of current record
				JCoField mandtField = outputTable.getField("MANDT");
				Integer mandt = Integer.parseInt(mandtField.getValue().toString());
				JCoField guidField = outputTable.getField("CAT_GUID");
				String catguid = guidField.getValue().toString();

				transaction.begin();
				// Get document items linked to the catalog header
				List<ZPRODCAT_ITEM> listItems = ZPRODCAT_ITEM.getItemsByType(em, system, mandt, catguid, "D");
				for (ZPRODCAT_ITEM itemDoc : listItems) {
					// LOGGER.debug("cleanZPRODCAT_ITEM doc:" +
					// itemDoc.getDoknr().toString() +
					// itemDoc.getDokvr().toString());
					ZPRODCAT_ITEM itemDocRemove = em.merge(itemDoc);
					em.remove(itemDocRemove);
				}

				transaction.commit();

			} catch (Exception e) {
				LOGGER.error("Exception while cleaning ZPRODCAT_ITEM " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillZPRODCAT_ITEM(String system, JCoTable outputTable) {
		// LOGGER.debug("fillZPRODCAT_ITEM starts");
		/*
		 * Integer numRows = outputTable.getNumRows(); LOGGER.debug(
		 * "fill itemTable rows = " + numRows.toString());
		 */
		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				ZPRODCAT_ITEM prodcat = new ZPRODCAT_ITEM();
				ZPRODCAT_ITEMPK prodcatpk = new ZPRODCAT_ITEMPK();
				prodcatpk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(prodcat, prodcatpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling ZPRODCAT_ITEM field " + paramName + " " + ex.toString());
						}
					}
				}

				prodcat.setKey(prodcatpk);

				em.merge(prodcat);
				transaction.commit();

			} catch (Exception e) {
				LOGGER.error("Exception while filling ZPRODCAT_ITEM " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void processZPRODCAT_ITEM(String system, JCoTable itemTable) {

		// LOGGER.debug("processZPRODCAT_ITEM starts");

		Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("JPEG");
		while (readers.hasNext()) {
			LOGGER.debug("reader: " + readers.next());
		}

		CmisHelper cmis = new CmisHelper();
		Integer numRows = itemTable.getNumRows();
		LOGGER.debug("Process itemTable on " + system + " with rows = " + numRows.toString());

		for (int i = 0; i < itemTable.getNumRows(); i++) {

			itemTable.setRow(i);

			// Get item type
			JCoField postypField = itemTable.getField("CAT_POSTYP");
			String postyp = (String) postypField.getValue();
			// LOGGER.debug("item postyp = " + postyp);

			// Process only document items
			if (postyp.equals("D")) {
				// Get Document keys
				JCoField mandtField = itemTable.getField("MANDT");
				Integer mandt = Integer.parseInt(mandtField.getValue().toString());
				JCoField dokarField = itemTable.getField("DOKAR");
				String dokar = (String) dokarField.getValue();
				JCoField doknrField = itemTable.getField("DOKNR");
				String doknr = (String) doknrField.getValue();
				JCoField dokvrField = itemTable.getField("DOKVR");
				String dokvr = (String) dokvrField.getValue();
				JCoField doktlField = itemTable.getField("DOKTL");
				String doktl = (String) doktlField.getValue();

				// Prepare file id
				String imageName = currentDestination + dokar + doknr + dokvr + doktl;

				// Check if the picture already exists
				EntityManager em = PersistenceAdapter.getEntityManager();
				PICTURESPK picturespk = new PICTURESPK(system, mandt, dokar, doknr, dokvr, doktl);
				PICTURES picturesentry = PICTURES.getPICTURESByKey(em, picturespk);
				LOGGER.debug("processZPRODCAT_ITEM check exist" + imageName);

				// If not, create a new document
				if (picturesentry == null) {
					LOGGER.debug("processZPRODCAT_ITEM image to create" + imageName);
					picturesentry = new PICTURES();
					try {

						// access the RFC Destination via Cloud Connector
						JCoDestination destination = JCoDestinationManager.getDestination(currentDestination);
						JCoRepository repo = destination.getRepository();

						// make an invocation of FUNCTION in the back-end
						JCoFunction stfcConnection = repo.getFunction("ZSHCP_PROM_FETCH_DOC_PHOTO");

						// Set import parameters
						JCoParameterList imports = stfcConnection.getImportParameterList();
						JCoListMetaData importParameters = imports.getListMetaData();

						for (int j = 0; j < importParameters.getFieldCount(); j++) {

							String paramName = importParameters.getName(j);

							if (paramName.equalsIgnoreCase("I_DOKAR")) {
								imports.setValue(paramName, dokar);
							} else if (paramName.equalsIgnoreCase("I_DOKNR")) {
								imports.setValue(paramName, doknr);
							} else if (paramName.equalsIgnoreCase("I_DOKVR")) {
								imports.setValue(paramName, dokvr);
							} else if (paramName.equalsIgnoreCase("I_DOKTL")) {
								imports.setValue(paramName, doktl);
							}
						}

						// Run the Function module
						stfcConnection.execute(destination);

						// Get results
						JCoParameterList exports = stfcConnection.getExportParameterList();
						JCoListMetaData exportParameters = exports.getListMetaData();

						// First loop on results to get text data
						for (int j = 0; j < exportParameters.getFieldCount(); j++) {
							String paramName = exportParameters.getName(j);
							try {
								if (exports.getValue(paramName) != null) {
									if (paramName.equalsIgnoreCase("E_NAME")) {
										picturesentry.setPicture_name(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_PRODUCT_TYPE")) {
										picturesentry.setProduct_type(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_CONTENT_TYPE")) {
										picturesentry.setContent_type(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_MAIN_FACE")) {
										picturesentry.setMain_face(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_HORIZONTAL_ANGLE")) {
										picturesentry.setHorizontal_angle(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_FILE_NATURE")) {
										picturesentry.setFile_nature(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_VALID_FROM")) {
										picturesentry.setValid_from(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_VALID_TO")) {
										picturesentry.setValid_to(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_SHOOTING_DATE")) {
										picturesentry.setShooting_date(exports.getValue(paramName).toString());
									} else if (paramName.equalsIgnoreCase("E_CREATION_DATE")) {
										String fieldName = "CREATION_DATE";
										JCoField oComponent = exports.getField(paramName);

										if (oComponent.getValue() != "" && oComponent.getValue() != null) {
											try {
												// Attempt to fill the field
												setFieldDynamically(picturesentry, picturespk, fieldName,
														oComponent.getValue());
											} catch (Exception ex) {
												LOGGER.error("Error while filling PICTURES field " + fieldName + " "
														+ oComponent.getValue() + " " + ex.toString());
											}
										}
									}
								}
							} catch (Exception e) {
								e.getCause();
								LOGGER.error(e.toString());
							}

						}

						// Second loop on results to get attached document
						// content
						for (int j = 0; j < exportParameters.getFieldCount(); j++) {

							String paramName = exportParameters.getName(j);

							try {

								if (exports.getValue(paramName) != null) {
									if (paramName.equalsIgnoreCase("E_PHOTO_STR")) {
										File imageFile = null;
										File thumbFile = null;
										File pdfFile = null;

										try {

											String base64string = exports.getValue(paramName).toString();
											byte[] imageDataBytes = Base64.decodeBase64(base64string);
											BufferedImage bufferedImage = null;
											ByteArrayInputStream bis = new ByteArrayInputStream(imageDataBytes);

											LOGGER.debug("Step 1");
											String fileFormat = null;
											// fix to mime type

											fileFormat = new Tika().detect(imageDataBytes);

											if (fileFormat.equalsIgnoreCase("application/pdf")) {
												String fileExtension = Utils.getFormat(fileFormat);
												pdfFile = new File(imageName + "." + fileExtension);
												OutputStream outputStream = new FileOutputStream(pdfFile);
												int read = 0;
												byte[] bytes = new byte[4096];
												while ((read = bis.read(bytes)) != -1) {
													outputStream.write(bytes, 0, read);
													;
												}
												outputStream.close();
											} else {
												bufferedImage = ImageIO.read(bis);
												// String format =
												// Imaging.guessFormat(imageDataBytes).getName();
												String fileExtension = Utils.getFormat(fileFormat);
												String imageId = imageName + "." + fileExtension;
												imageFile = new File(imageId);
												ImageIO.write(bufferedImage, fileExtension, imageFile);

												// String imageId = imageName +
												// "_Image";
												// bufferedImage =
												// Imaging.getBufferedImage(imageDataBytes);
												// imageFile = new
												// File(imageId);
												// final ImageFormat format =
												// Imaging.guessFormat(imageDataBytes);
												// final Map<String, Object>
												// optionalParams = new
												// HashMap<String, Object>();
												// Imaging.writeImage(bufferedImage,
												// imageFile, format,
												// optionalParams);

												// bufferedImage =
												// ImageIO.read(bis);
												// String imageId = imageName +
												// ".jpg";
												// imageFile = new
												// File(imageId);
												// ImageIO.write(bufferedImage,
												// "jpg", imageFile);

												LOGGER.debug("Step 4");

												String thumbId = imageName + "_Thumbnail";
												BufferedImage thumbImg = Scalr.resize(bufferedImage, Method.QUALITY,
														Mode.AUTOMATIC, 50, 50, Scalr.OP_ANTIALIAS);
												thumbFile = new File(thumbId);
												ImageIO.write(thumbImg, fileExtension, thumbFile);

												// Imaging.writeImage(thumbImg,
												// thumbFile, format,
												// optionalParams);

												// String thumbId = imageName +
												// "_Thumbnail" + ".jpg";
												// thumbFile = new
												// File(thumbId);
												// BufferedImage thumbImg =
												// Scalr.resize(bufferedImage,
												// Method.QUALITY,
												// Mode.AUTOMATIC, 50, 50,
												// Scalr.OP_ANTIALIAS);
												// ImageIO.write(thumbImg,
												// "jpg", thumbFile);

											}

										} catch (Exception e) {
											LOGGER.error("Error while converting the base64 image " + e.toString());
										}

										if (imageFile != null) {
											try {
												Document doc = cmis.addDocument(imageFile);
												if (doc != null) {
													LOGGER.debug("Image doc added, id=" + doc.getId());
													picturesentry.setImage_id(doc.getId());
												} else {
													LOGGER.error("ERROR while replication image for "
															+ exports.getValue(paramName).toString());
												}
											} catch (IOException e) {
												LOGGER.error("Error while adding image to CMS " + e.toString());
											}
											// Delete temporary created image:
											imageFile.delete();
										}
										if (thumbFile != null) {
											try {
												Document thb = cmis.addDocument(thumbFile);
												if (thb != null) {
													LOGGER.debug("Thumbnail doc added, id=" + thb.getId());
													picturesentry.setThumbnail_id(thb.getId());
												} else {
													LOGGER.error("ERROR while replication thumbnail image for "
															+ exports.getValue(paramName).toString());
												}

											} catch (IOException e) {
												LOGGER.error("Error while adding thumbnail to CMS " + e.toString());
											}
											// Delete temporary created image:
											thumbFile.delete();
										}
										if (pdfFile != null) {
											try {
												Document pdf = cmis.addDocument(pdfFile);
												if (pdf != null) {
													LOGGER.debug("Document pdf added, id=" + pdf.getId());
													picturesentry.setImage_id(pdf.getId());
												} else {
													LOGGER.error("ERROR while replication document for "
															+ exports.getValue(paramName).toString());
												}
											} catch (IOException e) {
												LOGGER.error("Error while adding pdf to CMS " + e.toString());
											}
											// Delete temporary created image:
											pdfFile.delete();
										}
									}
								}
							} catch (Exception e) {
								e.getCause();
								LOGGER.error(e.toString());
							}
						}

						// Create new entity PICTURES with document data
						LOGGER.debug("PICTURES entity1, doc:" + picturespk.getDocument_number().toString() + " version:"
								+ picturespk.getDocument_version().toString());
						if (picturesentry.getImage_id() != null) {
							LOGGER.debug("PICTURES entity2, doc:" + picturespk.getDocument_number().toString()
									+ " version:" + picturespk.getDocument_version().toString());
							EntityTransaction transaction = em.getTransaction();
							transaction.begin();
							picturesentry.setKey(picturespk);
							em.merge(picturesentry);
							transaction.commit();
						}

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						LOGGER.error("Error during RFC " + e.toString());
					}
				}

				em.close();
			}
		}
	}

	public void fillPricatK010_ZPRO_VPRICAT_S(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K010_ZPRO_VPRICAT_S pricat010 = new PRICAT_K010_ZPRO_VPRICAT_S();
				PRICAT_K010_ZPRO_VPRICAT_SPK pricat010pk = new PRICAT_K010_ZPRO_VPRICAT_SPK();
				pricat010pk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat010, pricat010pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K010_ZPRO_VPRICAT_S field " + paramName + " "
									+ ex.toString());
						}
					}
				}

				pricat010.setKey(pricat010pk);

				em.merge(pricat010);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PRICAT_K010_ZPRO_VPRICAT_S " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK001(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K001 pricat001 = new PRICAT_K001();
				PRICAT_K001PK pricat001pk = new PRICAT_K001PK();
				pricat001pk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat001, pricat001pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K001 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat001.setKey(pricat001pk);

				em.merge(pricat001);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK001 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK002(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K002 pricat002 = new PRICAT_K002();
				PRICAT_K002PK pricat002pk = new PRICAT_K002PK();
				pricat002pk.setSystem(system);

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat002, pricat002pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K002 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat002.setKey(pricat002pk);

				em.merge(pricat002);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK002 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK003(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K003 pricat003 = new PRICAT_K003();
				PRICAT_K003PK pricat003pk = new PRICAT_K003PK();
				pricat003pk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for PRICAT_K003
				// & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat003, pricat003pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K003 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat003.setKey(pricat003pk);

				em.merge(pricat003);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK003 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK003Z(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K003Z pricat003z = new PRICAT_K003Z();
				PRICAT_K003PK pricat003pk = new PRICAT_K003PK();
				pricat003pk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for PRICAT_K003
				// & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat003z, pricat003pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K003 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat003z.setKey(pricat003pk);

				em.merge(pricat003z);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK003 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK004(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K004 pricat004 = new PRICAT_K004();
				PRICAT_K004PK pricat004pk = new PRICAT_K004PK();
				pricat004pk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for PRICAT_K004
				// & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat004, pricat004pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K004 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat004.setKey(pricat004pk);

				em.merge(pricat004);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK004 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK005(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K005 pricat005 = new PRICAT_K005();
				PRICAT_K005PK pricat005pk = new PRICAT_K005PK();
				pricat005pk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for PRICAT_K005
				// & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat005, pricat005pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K005 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat005.setKey(pricat005pk);

				em.merge(pricat005);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK005 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK006(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K006 pricat006 = new PRICAT_K006();
				PRICAT_K006PK pricat006pk = new PRICAT_K006PK();
				pricat006pk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for PRICAT_K006
				// & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat006, pricat006pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K006 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat006.setKey(pricat006pk);

				em.merge(pricat006);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK006 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK007(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K007 pricat007 = new PRICAT_K007();
				PRICAT_K007PK pricat007pk = new PRICAT_K007PK();
				pricat007pk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for PRICAT_K007
				// & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat007, pricat007pk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K007 field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat007.setKey(pricat007pk);

				em.merge(pricat007);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK007 " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillPricatK00A(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				PRICAT_K00A pricat00A = new PRICAT_K00A();
				PRICAT_K00APK pricat00Apk = new PRICAT_K00APK();
				pricat00Apk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for PRICAT_K00A
				// & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(pricat00A, pricat00Apk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling PRICAT_K00A field " + paramName + " " + ex.toString());
						}
					}
				}

				pricat00A.setKey(pricat00Apk);

				em.merge(pricat00A);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling PricatK00A " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillMara(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				MARA mara = new MARA();
				MARAPK marapk = new MARAPK();
				marapk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for mara & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(mara, marapk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling mara field " + paramName + " " + ex.toString());
						}
					}
				}

				mara.setKey(marapk);

				em.merge(mara);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling mara " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillMakt(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				MAKT makt = new MAKT();
				MAKTPK maktpk = new MAKTPK();
				maktpk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for makt & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(makt, maktpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling makt field " + paramName + " " + ex.toString());
						}
					}
				}

				makt.setKey(maktpk);

				em.merge(makt);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling makt " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillMarc(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				MARC marc = new MARC();
				MARCPK marcpk = new MARCPK();
				marcpk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for marc & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(marc, marcpk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling marc field " + paramName + " " + ex.toString());
						}
					}
				}

				marc.setKey(marcpk);

				em.merge(marc);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling marc " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	public void fillMvke(String system, JCoTable outputTable) {

		for (int i = 0; i < outputTable.getNumRows(); i++) {

			outputTable.setRow(i);
			JCoFieldIterator it = outputTable.getFieldIterator();

			EntityManager em = PersistenceAdapter.getEntityManager();
			EntityTransaction transaction = em.getTransaction();

			try {

				transaction.begin();

				MVKE mvke = new MVKE();
				MVKEPK mvkepk = new MVKEPK();
				mvkepk.setSystem(system);
				// LOGGER.debug("Loop over fields and fill them for mvke & PK");

				// get fields of current record
				while (it.hasNextField()) {

					JCoField oComponent = it.nextField();

					if (oComponent.getValue() != "" && oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(mvke, mvkepk, paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.error("Error while filling mvke field " + paramName + " " + ex.toString());
						}
					}
				}

				mvke.setKey(mvkepk);

				em.merge(mvke);
				transaction.commit();
			} catch (Exception e) {
				LOGGER.error("Exception while filling mvke " + e.toString());
			} finally {
				em.close();
			}
		}
	}

	// Set dynamically
	public static boolean setFieldDynamically(Object object, Object pk, String fieldName, Object fieldValue)
			throws NoSuchFieldException, SecurityException {
		Class<?> clazz = object.getClass();

		try {
			Field field = clazz.getDeclaredField(fieldName.toLowerCase());
			field.setAccessible(true);

			setOnObject(field, object, fieldValue);

			return true;
		} catch (NoSuchFieldException e) {

			// No such field on the object, must be on the PK
			Class<?> pkclazz = pk.getClass();
			Field field = pkclazz.getDeclaredField(fieldName.toLowerCase());
			field.setAccessible(true);
			setOnPkObject(field, pk, fieldValue);
		} catch (Exception e) {

			throw new IllegalStateException(e);
		}

		return false;
	}

	@SuppressWarnings("unused")
	public static void setOnPkObject(Field field, Object object, Object fieldValue) {

		// PK cannot contain null in JPA
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

		try {
			if (fieldValue.toString() != null) {
				if (field.getType().getName().equalsIgnoreCase("java.lang.Integer")) {
					Integer value = Integer.parseInt(fieldValue.toString());
					if (value == null) {
						value = 0;
					}

					field.set(object, value);
				} else if (field.getType().getName().equalsIgnoreCase("java.lang.Long")) {
					Long value = Long.parseLong(fieldValue.toString());
					if (value == null) {
						value = new Integer(0).longValue();
					}

					field.set(object, value);
				} else if (field.getType().getName().equalsIgnoreCase("java.lang.String")) {

					String value = fieldValue.toString();
					if (value == null) {
						value = "";
					}
					field.set(object, value);

				} else if (field.getType().getName().equalsIgnoreCase("java.sql.Date")) {

					java.sql.Date sqlDate;

					if (fieldValue == null) {
						sqlDate = (java.sql.Date) df.parse("00/00/0000");
					} else {
						java.util.Date utilDate = (java.util.Date) fieldValue;
						sqlDate = new java.sql.Date(utilDate.getTime());
					}

					field.set(object, sqlDate);

				} else if (field.getType().getName().equalsIgnoreCase("java.lang.Float")) {

					Float value = Float.parseFloat(fieldValue.toString());

					if (value == null) {
						value = new Float("0.0");
					}

					field.set(object, value);
				} else {
					LOGGER.debug(field.getType().getName());
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Error setOnObject" + ex.toString());
		}
	}

	public static void setOnObject(Field field, Object object, Object fieldValue) {

		try {
			if (fieldValue.toString() != null) {
				if (field.getType().getName().equalsIgnoreCase("java.lang.Integer")) {
					field.set(object, Integer.parseInt(fieldValue.toString()));
				} else if (field.getType().getName().equalsIgnoreCase("java.lang.Long")) {
					field.set(object, Long.parseLong(fieldValue.toString()));
				} else if (field.getType().getName().equalsIgnoreCase("java.lang.String")) {
					field.set(object, (String) fieldValue);
				} else if (field.getType().getName().equalsIgnoreCase("java.sql.Date")) {

					java.util.Date utilDate = (java.util.Date) fieldValue;
					java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
					field.set(object, sqlDate);

				} else if (field.getType().getName().equalsIgnoreCase("java.lang.Float")) {
					field.set(object, Float.parseFloat(fieldValue.toString()));
				} else if (field.getType().getName().equalsIgnoreCase("double")) {
					field.set(object, Double.parseDouble(fieldValue.toString()));
				} else if (field.getType().getName().equalsIgnoreCase("java.lang.Boolean")) {
					if (fieldValue.toString().equalsIgnoreCase("X")) {
						field.set(object, true);
					} else {
						field.set(object, false);
					}
				} else {
					LOGGER.debug(field.getType().getName());
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Error setOnObject" + ex.toString());
		}
	}

	/*
	 * public void handlePicture(JCoTable outputTable) {
	 * 
	 * try {
	 * 
	 * for (int j = 0; j < outputTable.getNumRows(); j++) {
	 * 
	 * outputTable.setRow(j);
	 * 
	 * if (outputTable.getField("PICTURE").getValue() != "") { LOGGER.debug(
	 * "Processing this picture"); JCoField field =
	 * outputTable.getField("PICTURE_STR");
	 * 
	 * String imageStringBase64 = (String) field.getValue(); byte[]
	 * imageDataBytes = Base64.decodeBase64(imageStringBase64);
	 * 
	 * File imageFile = null;
	 * 
	 * try { BufferedImage bufferedImage = null; ByteArrayInputStream bis = new
	 * ByteArrayInputStream(imageDataBytes); bufferedImage = ImageIO.read(bis);
	 * 
	 * imageFile = new File(outputTable.getField("MATNR").getValue() + ".jpg");
	 * ImageIO.write(bufferedImage, "jpg", imageFile); }catch (Exception e) {
	 * LOGGER.error("Error while converting the base64 image " + e.toString());
	 * }
	 * 
	 * if (imageFile != null) { cmis.addDocument(imageFile);
	 * 
	 * //Delete temporary created image: imageFile.delete(); } } } }catch
	 * (Exception e) { e.printStackTrace(); LOGGER.error(
	 * "Error during handlePicture " + e.toString()); } }
	 */
}
