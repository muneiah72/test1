package com.danone.util;

public class UoMWrapper {
	
	private String alt_unit;
	private String ean_upc_altunit;
	private double net_weight;
	private String unit_of_net;
	private double gross_wt;
	private String unit_of_wt;
	private double volume;
	private String volumeunit;
	private double length;
	private double width;
	private double height;
	private String unit_length;
	private String unit_width;
	private String unit_height;
	private Integer quantity_subline;
	private Integer nb_per_first;
	private Integer nb_per_second;
	private Integer nb_per_third;
	private Integer nb_per_lay;
	private Integer nb_of_lay;
	
	public UoMWrapper() {
		this.alt_unit = "";
		this.ean_upc_altunit = "";
		this.unit_of_net = "";
		this.unit_of_wt = "";
		this.volumeunit = "";
		this.unit_length = "";
		this.unit_width = "";
		this.unit_height = "";
	}
	
	public String getEan_upc_altunit() {
		if (ean_upc_altunit != null)
		{
			return ean_upc_altunit;	
		}else {
			return "";
		}
	}
	
	public void setEan_upc_altunit(String ean_upc_altunit) {
		this.ean_upc_altunit = ean_upc_altunit;
	}

	public double getNet_weight() {
		return net_weight;
	}

	public void setNet_weight(double net_weight) {
		this.net_weight = net_weight;
	}

	public String getUnit_of_net() {
		if (unit_of_net != null)
		{
			return unit_of_net;	
		}else {
			return "";
		}
	}

	public void setUnit_of_net(String unit_of_net) {
		this.unit_of_net = unit_of_net;
	}

	public double getGross_wt() {
		return gross_wt;
	}

	public void setGross_wt(double gross_wt) {
		this.gross_wt = gross_wt;
	}

	public String getUnit_of_wt() {
		if (unit_of_wt != null)
		{
			return unit_of_wt;	
		}else {
			return "";
		}
	}

	public void setUnit_of_wt(String unit_of_wt) {
		this.unit_of_wt = unit_of_wt;
	}

	public String getVolumeunit() {
		if (volumeunit != null)
		{
			return volumeunit;	
		}else {
			return "";
		}
	}

	public void setVolumeunit(String volumeunit) {
		this.volumeunit = volumeunit;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getUnit_length() {
		if (unit_length != null)
		{
			return unit_length;	
		}else {
			return "";
		}
	}

	public void setUnit_length(String unit_length) {
		this.unit_length = unit_length;
	}

	public String getUnit_height() {
		if (unit_height != null)
		{
			return unit_height;	
		}else {
			return "";
		}
	}

	public void setUnit_height(String unit_height) {
		this.unit_height = unit_height;
	}

	public String getUnit_width() {
		if (unit_width != null)
		{
			return unit_width;	
		}else {
			return "";
		}
	}

	public void setUnit_width(String unit_width) {
		this.unit_width = unit_width;
	}

	public Integer getQuantity_subline() {
		if (quantity_subline != null)
		{
			return quantity_subline;	
		}else {
			return 0;
		}
	}

	public void setQuantity_subline(Integer quantity_subline) {
		this.quantity_subline = quantity_subline;
	}

	public String getAlt_unit() {
		if (alt_unit != null)
		{
			return alt_unit;	
		}else {
			return "";
		}
	}

	public void setAlt_unit(String alt_unit) {
		this.alt_unit = alt_unit;
	}

	public Integer getNb_per_first() {
		if (nb_per_first != null)
		{
			return nb_per_first;	
		}else {
			return 0;
		}
	}

	public void setNb_per_first(Integer nb_per_first) {
		this.nb_per_first = nb_per_first;
	}

	public Integer getNb_per_second() {
		if (nb_per_second != null)
		{
			return nb_per_second;	
		}else {
			return 0;
		}
		
	}

	public void setNb_per_second(Integer nb_per_second) {
		this.nb_per_second = nb_per_second;
	}

	public Integer getNb_per_third() {
		if (nb_per_third != null)
		{
			return nb_per_third;	
		}else {
			return 0;
		}
	}

	public void setNb_per_third(Integer nb_per_third) {
		this.nb_per_third = nb_per_third;
	}

	public Integer getNb_per_lay() {
		if (nb_per_lay != null)
		{
			return nb_per_lay;	
		}else {
			return 0;
		}
	}

	public void setNb_per_lay(Integer nb_per_lay) {
		this.nb_per_lay = nb_per_lay;
	}

	public Integer getNb_of_lay() {
		if (nb_of_lay != null)
		{
			return nb_of_lay;	
		}else {
			return 0;
		}
	}

	public void setNb_of_lay(Integer nb_of_lay) {
		this.nb_of_lay = nb_of_lay;
	}
}
