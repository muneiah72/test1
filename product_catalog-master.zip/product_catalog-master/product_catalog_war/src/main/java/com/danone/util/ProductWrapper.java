package com.danone.util;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.json.JSONException;
import org.json.JSONObject;

public class ProductWrapper {
	
	//ZPRODCAT_HDR
	private String system;
	private Integer mandt;
	private String cat_guid;
	private String fullmatnr;
	private String matnr;
	private String vkorg;
	private String vtweg;
	private Integer verno;
	private String status;
	private String prinbr;
	private String productgroup;
	
	//ZPRODCAT_ITEM
	private String ean_upc_base;
	private java.sql.Date validity_base;
	
	//MAKT
	private String maktx;

	//MVKE
	private String mvgr1;
	
	//PRICAT_K005
	private String stddescription;
		
	//PRICAT_K006
	private String code_output;
	private String code_labelling;
	private String lsf;
	private String label_status;
	
	//PRICAT_K010_ZPRO_VPRICAT_S
	private String zzpaccod;
	private String vmsta;
	private java.sql.Date zzlaunchdate;
	
	//Picture thumbnail
	private String thumbnailUrl;
		
	//Dummy's
	private Boolean exportexcel;
	private String statustext;
	private Boolean status_allowed;
	//dummy
	
		
	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

	public Integer getVerno() {
		return verno;
	}

	public void setVerno(Integer verno) {
		this.verno = verno;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMaktx() {
		return maktx;
	}

	public void setMaktx(String maktx) {
		this.maktx = maktx;
	}

	public Date getZzlaunchdate() {
		return zzlaunchdate;
	}

	public void setZzlaunchdate(Date zzlaunchdate) {
		this.zzlaunchdate = zzlaunchdate;
	}

	public String getVmsta() {
		return vmsta;
	}

	public void setVmsta(String vmsta) {
		this.vmsta = vmsta;
	}

	public String getMvgr1() {
		return mvgr1;
	}

	public void setMvgr1(String mvgr1) {
		this.mvgr1 = mvgr1;
	}

	public String getEan_upc_base() {
		return ean_upc_base;
	}

	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}

	public String getCode_output() {
		return code_output;
	}

	public void setCode_output(String code_output) {
		this.code_output = code_output;
	}

	public String getCode_labelling() {
		return code_labelling;
	}

	public void setCode_labelling(String code_labelling) {
		this.code_labelling = code_labelling;
	}

	public String getLsf() {
		return lsf;
	}

	public void setLsf(String lsf) {
		this.lsf = lsf;
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public java.sql.Date getValidity_base() {
		return validity_base;
	}

	public void setValidity_base(java.sql.Date validity_base) {
		this.validity_base = validity_base;
	}

	public String getPrinbr() {
		return prinbr;
	}

	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}

	public String getProductgroup() {
		return productgroup;
	}

	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}

	public String getCat_guid() {
		return cat_guid;
	}

	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}

	public Boolean getExportexcel() {
		return exportexcel;
	}

	public void setExportexcel(Boolean exportexcel) {
		this.exportexcel = exportexcel;
	}
	
	public static ProductWrapper convertFromJSONToMyClass(JSONObject json) throws JSONException, ParseException {
	    if (json == null) {
	        return null;
	    }
	    
		//SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
	    SimpleDateFormat format = new SimpleDateFormat("MMM d, yyyy");
	    
	    ProductWrapper result = new ProductWrapper();
	    if (json.has("system"))
	    {
	    	result.system = (String) json.get("system");
	    }
	    if (json.has("mandt"))
	    {
	    	result.mandt = (Integer) json.get("mandt");
	    }
	    if (json.has("cat_guid"))
	    {
	    	result.cat_guid = (String) json.get("cat_guid");
	    }
	    if (json.has("matnr"))
	    {
	    	result.matnr = (String) json.get("matnr");
	    }
	    if (json.has("fullmatnr"))
	    {
	    	result.fullmatnr = (String) json.get("fullmatnr");
	    }
	    if (json.has("vkorg"))
	    {
	    	result.vkorg = (String) json.get("vkorg");
	    }
	    if (json.has("vtweg"))
	    {
	    	result.vtweg = (String) json.get("vtweg");
	    }
	    if (json.has("verno"))
	    {
	    	result.verno = (Integer) json.get("verno");
	    }
	    if (json.has("status"))
	    {
	    	 result.status = (String) json.get("status");
	    }
	    if (json.has("prinbr"))
	    {
	    	result.prinbr = (String) json.get("prinbr");
	    }
	    if (json.has("productgroup"))
	    {
	    	result.productgroup = (String) json.get("productgroup");
	    }
	    if (json.has("ean_upc_base"))
	    {
	    	result.ean_upc_base = (String) json.get("ean_upc_base");
	    }
	    if (json.has("validity_base"))
	    {
	    	java.util.Date parsedValdity = format.parse((String) json.get("validity_base"));
			java.sql.Date validityDate = new java.sql.Date(parsedValdity.getTime());
		    result.validity_base = validityDate;
	    }
	    if (json.has("maktx"))
	    {
	    	result.maktx = (String) json.get("maktx");
	    }
	    if (json.has("zzlaunchdate"))
	    {
	    	java.util.Date parsedZzlaunchdate = format.parse((String) json.get("zzlaunchdate"));
			java.sql.Date zzLaunchDate = new java.sql.Date(parsedZzlaunchdate.getTime());
		    result.zzlaunchdate = zzLaunchDate;
	    }
	    if (json.has("vmsta"))
	    {
	    	result.vmsta = (String) json.get("vmsta");
	    }
	    if (json.has("mvgr1"))
	    {
	    	result.mvgr1 = (String) json.get("mvgr1");
	    }
	    if (json.has("code_output"))
	    {
	    	result.code_output = (String) json.get("code_output");
	    }
	    if (json.has("code_labelling"))
	    {
	    	result.code_labelling = (String) json.get("code_labelling");
	    }
	    if (json.has("lsf"))
	    {
	    	result.lsf = (String) json.get("lsf");
	    }
	    if (json.has("exportexcel"))
	    {
	    	result.exportexcel = (Boolean) json.get("exportexcel");
	    }
	    if (json.has("statustext"))
	    {
	    	result.setStatustext((String) json.get("statustext"));
	    }
	    if (json.has("zzpaccod"))
	    {
	    	result.zzpaccod = (String) json.get("zzpaccod");
	    }
	    if (json.has("label_status"))
	    {
	    	result.label_status = (String) json.get("label_status");
	    }
	    
	    return result;
	}

	public String getZzpaccod() {
		return zzpaccod;
	}

	public void setZzpaccod(String zzpaccod) {
		this.zzpaccod = zzpaccod;
	}

	public String getLabel_status() {
		return label_status;
	}

	public void setLabel_status(String label_status) {
		this.label_status = label_status;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public String getStatustext() {
		return statustext;
	}

	public void setStatustext(String statustext) {
		this.statustext = statustext;
	}

	public String getFullmatnr() {
		return fullmatnr;
	}

	public void setFullmatnr(String fullmatnr) {
		this.fullmatnr = fullmatnr;
	}

	public Boolean getStatus_allowed() {
		return status_allowed;
	}

	public void setStatus_allowed(Boolean status_allowed) {
		this.status_allowed = status_allowed;
	}

	public String getStddescription() {
		if (stddescription != null)
		{
			return stddescription;	
		}else {
			return "";
		}
	}

	public void setStddescription(String stddescription) {
		this.stddescription = stddescription;
	}

}
