package com.danone.proxy;

import org.apache.http.HttpResponse;

public class CacheEntry2 {

	private ProxyRequest request;
	private String response;

	public CacheEntry2(ProxyRequest request, String response) {
		this.request = request;
		this.response = response;
	}

	public ProxyRequest getClientRequest() {
		return request;
	}

	public void setClientRequest(ProxyRequest request) {
		this.request = request;
	}

	public String getBackendResponse() {
		return response;
	}

	public void setBackendResponse(String response) {
		this.response = response;
	}

}
