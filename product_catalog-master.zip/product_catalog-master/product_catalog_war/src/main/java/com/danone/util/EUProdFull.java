package com.danone.util;

import java.util.List;

public class EUProdFull {
	
	private Integer mandt;
	private String cat_guid;
	private String title;
	private String pictureId;
	private String description;
	
	//First block of info
	private String brand;
	private String brandCode;
	private String processTechnology;
	private String cupDiameter;
	private String weight;
	private double shelflife;
	private String topper;
	private String multilayer;
	
	//Second block of info
	private String format;
	private String flavors;
	
	//Third block of info
	private String nutritionalvaluesCol1;
	private String nutritionalvaluesCol2;
	private String ingredientslist;
	
	//Fourth block of info
	private String factories;
	private String sellingcountries;
	private String sellingcountriesCapacity;
	private String capacity;
	private String transferprice;
	
	//SKU List
	private List<EUProdSKUList> skuList;
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
	
	public String getCat_guid() {
		return cat_guid;
	}
	
	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPictureId() {
		return pictureId;
	}

	public void setPictureId(String pictureId) {
		this.pictureId = pictureId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getProcessTechnology() {
		return processTechnology;
	}

	public void setProcessTechnology(String processTechnology) {
		this.processTechnology = processTechnology;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getCupDiameter() {
		return cupDiameter;
	}

	public void setCupDiameter(String cupDiameter) {
		this.cupDiameter = cupDiameter;
	}

	public double getShelflife() {
		return shelflife;
	}

	public void setShelflife(double shelflife) {
		this.shelflife = shelflife;
	}

	public String getTopper() {
		return topper;
	}

	public void setTopper(String topper) {
		this.topper = topper;
	}

	public String getMultilayer() {
		return multilayer;
	}

	public void setMultilayer(String multilayer) {
		this.multilayer = multilayer;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getFlavors() {
		return flavors;
	}

	public void setFlavors(String flavors) {
		this.flavors = flavors;
	}

	public String getIngredientslist() {
		return ingredientslist;
	}

	public void setIngredientslist(String ingredientslist) {
		this.ingredientslist = ingredientslist;
	}

	public String getFactories() {
		return factories;
	}

	public void setFactories(String factories) {
		this.factories = factories;
	}

	public String getSellingcountries() {
		return sellingcountries;
	}

	public void setSellingcountries(String sellingcountries) {
		this.sellingcountries = sellingcountries;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getTransferprice() {
		return transferprice;
	}

	public void setTransferprice(String transferprice) {
		this.transferprice = transferprice;
	}

	public String getNutritionalvaluesCol1() {
		return nutritionalvaluesCol1;
	}

	public void setNutritionalvaluesCol1(String nutritionalvaluesCol1) {
		this.nutritionalvaluesCol1 = nutritionalvaluesCol1;
	}

	public String getNutritionalvaluesCol2() {
		return nutritionalvaluesCol2;
	}

	public void setNutritionalvaluesCol2(String nutritionalvaluesCol2) {
		this.nutritionalvaluesCol2 = nutritionalvaluesCol2;
	}

	public String getSellingcountriesCapacity() {
		return sellingcountriesCapacity;
	}

	public void setSellingcountriesCapacity(String sellingcountriesCapacity) {
		this.sellingcountriesCapacity = sellingcountriesCapacity;
	}

	public String getBrandCode() {
		return brandCode;
	}

	public void setBrandCode(String brandCode) {
		this.brandCode = brandCode;
	}

	public List<EUProdSKUList> getSkuList() {
		return skuList;
	}

	public void setSkuList(List<EUProdSKUList> skuList) {
		this.skuList = skuList;
	}
	
	
}
