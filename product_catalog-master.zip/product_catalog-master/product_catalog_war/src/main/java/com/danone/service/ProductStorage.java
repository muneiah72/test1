/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.danone.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.olingo.commons.api.data.ComplexValue;
import org.apache.olingo.commons.api.data.Entity;
import org.apache.olingo.commons.api.data.EntityCollection;
import org.apache.olingo.commons.api.data.Property;
import org.apache.olingo.commons.api.data.ValueType;
import org.apache.olingo.commons.api.edm.EdmEntitySet;
import org.apache.olingo.commons.api.edm.EdmEntityType;
import org.apache.olingo.commons.api.edm.FullQualifiedName;
import org.apache.olingo.commons.api.ex.ODataRuntimeException;
import org.apache.olingo.server.api.uri.UriParameter;
import org.eclipse.persistence.internal.jpa.config.PropertyImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.ZPRODCAT_HDR;
import com.danone.entities.ZPRODCAT_ITEM;
import com.danone.entities.ZPROWS_ORG;
import com.danone.persistence.PersistenceAdapter;
import com.danone.resources.ConfigResource;
import com.danone.resources.ProductDetailResource;
import com.danone.util.AllergenDetailWrapper;
import com.danone.util.ConfigWrapper;
import com.danone.util.NutboardWrapper;
import com.danone.util.ProductDetailWrapper;
import com.danone.util.UoMWrapper;

public class ProductStorage {

	private final Logger LOGGER = LoggerFactory.getLogger(ProductStorage.class);
	
	// represent our database
	private List<Entity> productList;
	private List<Entity> salesorgList;

	public ProductStorage() {

		productList = new ArrayList<Entity>();
		salesorgList = new ArrayList<Entity>();

	}

	/* PUBLIC FACADE */

	public EntityCollection readEntitySetData(EdmEntitySet edmEntitySet) {
		EntityCollection entitySet = null;

		if (edmEntitySet.getName().equals(ProductEdmProvider.ES_PRODUCTS_NAME)) {
			entitySet = ProductStorage.getProducts(this.productList);
		} else if (edmEntitySet.getName().equals(ProductEdmProvider.ES_SALESORGS_NAME)) {
			entitySet = ProductStorage.getSalesorgs(this.salesorgList);
		}

		return entitySet;
	}

	public Entity readEntityData(EdmEntitySet edmEntitySet, List<UriParameter> keyParams) {
		Entity entity = null;

		EdmEntityType edmEntityType = edmEntitySet.getEntityType();

		if (edmEntityType.getName().equals(ProductEdmProvider.ET_PRODUCT_NAME)) {
			entity = getProduct(edmEntityType, keyParams);
		} else if (edmEntityType.getName().equals(ProductEdmProvider.ET_SALESORG_NAME)) {
			entity = getCategory(edmEntityType, keyParams);
		}

		return entity;
	}

	// Navigation

	public Entity getRelatedEntity(Entity entity, EdmEntityType relatedEntityType) {
		EntityCollection collection = getRelatedEntityCollection(entity, relatedEntityType);
		if (collection.getEntities().isEmpty()) {
			return null;
		}
		return collection.getEntities().get(0);
	}

	public Entity getRelatedEntity(Entity entity, EdmEntityType relatedEntityType, List<UriParameter> keyPredicates) {

		EntityCollection relatedEntities = getRelatedEntityCollection(entity, relatedEntityType);
		return Util.findEntity(relatedEntityType, relatedEntities, keyPredicates);
	}

	public EntityCollection getRelatedEntityCollection(Entity sourceEntity, EdmEntityType targetEntityType) {
		EntityCollection navigationTargetEntityCollection = new EntityCollection();

		FullQualifiedName relatedEntityFqn = targetEntityType.getFullQualifiedName();
		String sourceEntityFqn = sourceEntity.getType();

		if (sourceEntityFqn.equals(ProductEdmProvider.ET_PRODUCT_FQN.getFullQualifiedNameAsString())
				&& relatedEntityFqn.equals(ProductEdmProvider.ET_SALESORG_FQN)) {
			// relation Products->Category (result all categories)
			int productID = (Integer) sourceEntity.getProperty("ID").getValue();
			if (productID == 1 || productID == 2) {
				navigationTargetEntityCollection.getEntities().add(salesorgList.get(0));
			} else if (productID == 3 || productID == 4) {
				navigationTargetEntityCollection.getEntities().add(salesorgList.get(1));
			} else if (productID == 5 || productID == 6) {
				navigationTargetEntityCollection.getEntities().add(salesorgList.get(2));
			}
		} else if (sourceEntityFqn.equals(ProductEdmProvider.ET_SALESORG_FQN.getFullQualifiedNameAsString())
				&& relatedEntityFqn.equals(ProductEdmProvider.ET_PRODUCT_FQN)) {
			LOGGER.debug("getRelatedEntityCollection for products ");
			// relation Category->Products (result all products)
			EntityManager em = PersistenceAdapter.getEntityManager();
			// Retrieve SalesOrg customizing
			String vkorg = (String) sourceEntity.getProperty("SalesOrg").getValue();
			String vtweg = (String) sourceEntity.getProperty("DistCh").getValue();
			LOGGER.debug("getRelatedEntityCollection - SalesOrg: " + vkorg.toString());
			LOGGER.debug("getRelatedEntityCollection - DistChan: " + vtweg.toString());
			ZPROWS_ORG salesOrg = ZPROWS_ORG.getByKey(em, vkorg, vtweg);
			String configParam = new String("config");
			ConfigResource configRes = new ConfigResource();
			try {
				configRes.getConfig(configParam);
			} catch (Exception e) {
				
			}
			
//			ConfigWrapper configResponse = configRes.getConfig(configParam);
			
			// Get Headers with status customized
			String queryString = new String();
			if (salesOrg.getWsprotyp() == "EAN")
			{
				queryString =
						  "SELECT p FROM ZPRODCAT_HDR p "
						+ "INNER JOIN (SELECT system, mandt, cat_guid, MAX(matnr), vkorg, vtweg, status, ean_upc_base "
								  + "FROM ZPRODCAT_HDR "
								  + "WHERE " + "vkorg = :vkorg AND " + "vtweg = :vtweg AND " 
								  			 + "status = :status "
								  + "GROUP BY ean_upc_base) groupep "
								  
						+ "ON p.system = groupep.system " 
							+ "AND p.mandt = groupep.mandt " 
							+ "AND p.cat_guid = groupep.cat_guid " 
						+ "ORDER BY p.matnr ASC";
			}else
			{
				queryString = "SELECT distinct p FROM ZPRODCAT_HDR p, ZPRODCAT_ITEM i where "
					+ "p.key.cat_guid = i.key.cat_guid and " + "p.vkorg = :vkorg and "
					+ "p.vtweg = :vtweg and " + "p.status = :status "
					+ "ORDER BY p.matnr ASC";
			}

			Query query = em.createQuery(queryString, ZPRODCAT_HDR.class).setParameter("vkorg", vkorg)
					.setParameter("vtweg", vtweg).setParameter("status", salesOrg.getStatus());
			List<ZPRODCAT_HDR> hdrList = ZPRODCAT_HDR.getAllProductsWithQuery(em, query);
			productList.clear();
			Boolean excel = false;
			
			for (ZPRODCAT_HDR hdr : hdrList) {
				ProductDetailResource prodRes = new ProductDetailResource();
				ZPRODCAT_ITEM item = ZPRODCAT_ITEM.getItemByGuidAndPostyp(em, hdr.getKey().getSystem(),
						hdr.getKey().getCat_guid(), "P");
				if (item != null)
				{
					ProductDetailWrapper prodDetail = prodRes.getDetails(hdr.getKey().getSystem(), hdr.getKey().getMandt(),
							hdr.getKey().getCat_guid(), hdr.getMatnr(), hdr.getVkorg(), hdr.getVtweg(), hdr.getPrinbr(),
							hdr.getProductgroup(), hdr.getEan_upc_base(), item.getValidity_base(), salesOrg.getLaiso(),
							salesOrg.getPlant(), salesOrg.getEcatd(), excel);
					if (prodDetail != null)
					{
						Entity entity = new Entity();
						// Code
						entity.addProperty(new Property(null, "InternalCode", ValueType.PRIMITIVE, prodDetail.getMatnr()));
						entity.addProperty(new Property(null, "EANCode", ValueType.PRIMITIVE, prodDetail.getEan_upc_base()));
						// Grouping
						entity.addProperty(new Property(null, "LanguageISO", ValueType.PRIMITIVE, salesOrg.getLaiso()));	
						entity.addProperty(new Property(null, "LastUpdated", ValueType.PRIMITIVE, prodDetail.getLast_update()));
						entity.addProperty(new Property(null, "Brand", ValueType.PRIMITIVE, prodDetail.getBrand()));
						entity.addProperty(new Property(null, "SubBrand", ValueType.PRIMITIVE, prodDetail.getSubbrand()));
						entity.addProperty(new Property(null, "Flavor", ValueType.PRIMITIVE, prodDetail.getFlavor()));
						entity.addProperty(new Property(null, "By", ValueType.PRIMITIVE, prodDetail.getZzby()));
						entity.addProperty(new Property(null, "Promo", ValueType.PRIMITIVE, prodDetail.getPromo()));
						entity.addProperty(new Property(null, "Process1", ValueType.PRIMITIVE, prodDetail.getProcess1()));
						entity.addProperty(new Property(null, "Process2", ValueType.PRIMITIVE, prodDetail.getProcess2()));
						entity.addProperty(new Property(null, "PotDiameter", ValueType.PRIMITIVE, prodDetail.getPotdiameter()));
						entity.addProperty(new Property(null, "Range", ValueType.PRIMITIVE, prodDetail.getRange()));
						entity.addProperty(new Property(null, "Subrange", ValueType.PRIMITIVE, prodDetail.getSubrange()));
						entity.addProperty(new Property(null, "MkgGroupI", ValueType.PRIMITIVE, prodDetail.getZzmarki()));
						entity.addProperty(new Property(null, "MkgGroupII", ValueType.PRIMITIVE, prodDetail.getZzmarkii()));
						entity.addProperty(new Property(null, "MkgGroupIII", ValueType.PRIMITIVE, prodDetail.getZzmarkiii()));
						entity.addProperty(new Property(null, "MkgGroupIV", ValueType.PRIMITIVE, prodDetail.getZzmarkiv()));
						entity.addProperty(new Property(null, "ProdHier_L1", ValueType.PRIMITIVE, prodDetail.getProdh().substring(0, 2)));
						entity.addProperty(new Property(null, "ProdHier_L1_Desc", ValueType.PRIMITIVE, prodDetail.getProdhl1desc()));
						entity.addProperty(new Property(null, "ProdHier_L2", ValueType.PRIMITIVE, prodDetail.getProdh().substring(0, 5)));
						entity.addProperty(new Property(null, "ProdHier_L2_Desc", ValueType.PRIMITIVE, prodDetail.getProdhl2desc()));
						entity.addProperty(new Property(null, "ProdHier_L3", ValueType.PRIMITIVE, prodDetail.getProdh().substring(0, 9)));
						entity.addProperty(new Property(null, "ProdHier_L3_Desc", ValueType.PRIMITIVE, prodDetail.getProdhl3desc()));
						entity.addProperty(new Property(null, "ProdHier_L4", ValueType.PRIMITIVE, prodDetail.getProdh().substring(0, 11)));
						entity.addProperty(new Property(null, "ProdHier_L4_Desc", ValueType.PRIMITIVE, prodDetail.getProdhl4desc()));
						entity.addProperty(new Property(null, "ProdHier_L5", ValueType.PRIMITIVE, prodDetail.getProdh().substring(0, 14)));
						entity.addProperty(new Property(null, "ProdHier_L5_Desc", ValueType.PRIMITIVE, prodDetail.getProdhl5desc()));
						entity.addProperty(new Property(null, "ProdHier_L6", ValueType.PRIMITIVE, prodDetail.getProdh().substring(0, 18)));
						entity.addProperty(new Property(null, "ProdHier_L6_Desc", ValueType.PRIMITIVE, prodDetail.getProdhl6desc()));
						// Dimensions
						List<UoMWrapper> uomlist = prodDetail.getUomlist();
						for (UoMWrapper wrap : uomlist) {
							if (wrap.getAlt_unit().equalsIgnoreCase("ST")) {
								entity.addProperty(new Property(null, "NetWeight_UC", ValueType.PRIMITIVE, wrap.getNet_weight()));
								entity.addProperty(new Property(null, "NetWeightUnit_UC", ValueType.PRIMITIVE, wrap.getUnit_of_net()));
								entity.addProperty(new Property(null, "GrossWeight_UC", ValueType.PRIMITIVE, wrap.getGross_wt()));
								entity.addProperty(new Property(null, "GrossWeightUnit_UC", ValueType.PRIMITIVE, wrap.getUnit_of_wt()));
								entity.addProperty(new Property(null, "Volume_UC", ValueType.PRIMITIVE, wrap.getVolume()));
								entity.addProperty(new Property(null, "VolumeUnit_UC", ValueType.PRIMITIVE, wrap.getVolumeunit()));
								entity.addProperty(new Property(null, "Length_UC", ValueType.PRIMITIVE, wrap.getLength()));
								entity.addProperty(new Property(null, "LengthUnit_UC", ValueType.PRIMITIVE, wrap.getUnit_length()));
								entity.addProperty(new Property(null, "Width_UC", ValueType.PRIMITIVE, wrap.getWidth()));
								entity.addProperty(new Property(null, "WidthUnit_UC", ValueType.PRIMITIVE, wrap.getUnit_width()));
								entity.addProperty(new Property(null, "Height_UC", ValueType.PRIMITIVE, wrap.getHeight()));
								entity.addProperty(new Property(null, "HeightUnit_UC", ValueType.PRIMITIVE, wrap.getUnit_height()));
								entity.addProperty(new Property(null, "NbPerLayer", ValueType.PRIMITIVE, wrap.getNb_per_lay()));
							} else if (wrap.getAlt_unit().equalsIgnoreCase("KAR")) {
								entity.addProperty(new Property(null, "NetWeight_UL", ValueType.PRIMITIVE, wrap.getNet_weight()));
								entity.addProperty(new Property(null, "NetWeightUnit_UL", ValueType.PRIMITIVE, wrap.getUnit_of_net()));
								entity.addProperty(new Property(null, "GrossWeight_UL", ValueType.PRIMITIVE, wrap.getGross_wt()));
								entity.addProperty(new Property(null, "GrossWeightUnit_UL", ValueType.PRIMITIVE, wrap.getUnit_of_wt()));
								entity.addProperty(new Property(null, "Volume_UL", ValueType.PRIMITIVE, wrap.getVolume()));
								entity.addProperty(new Property(null, "VolumeUnit_UL", ValueType.PRIMITIVE, wrap.getVolumeunit()));
								entity.addProperty(new Property(null, "Length_UL", ValueType.PRIMITIVE, wrap.getLength()));
								entity.addProperty(new Property(null, "LengthUnit_UL", ValueType.PRIMITIVE, wrap.getUnit_length()));
								entity.addProperty(new Property(null, "Width_UL", ValueType.PRIMITIVE, wrap.getWidth()));
								entity.addProperty(new Property(null, "WidthUnit_UL", ValueType.PRIMITIVE, wrap.getUnit_width()));
								entity.addProperty(new Property(null, "Height_UL", ValueType.PRIMITIVE, wrap.getHeight()));
								entity.addProperty(new Property(null, "HeightUnit_UL", ValueType.PRIMITIVE, wrap.getUnit_height()));
								entity.addProperty(new Property(null, "NbOfUCPerUL", ValueType.PRIMITIVE, wrap.getNb_per_first()));
							} else if (wrap.getAlt_unit().equalsIgnoreCase("PAL")) {
								entity.addProperty(new Property(null, "NetWeight_PAL", ValueType.PRIMITIVE, wrap.getNet_weight()));
								entity.addProperty(new Property(null, "NetWeightUnit_PAL", ValueType.PRIMITIVE, wrap.getUnit_of_net()));
								entity.addProperty(new Property(null, "GrossWeight_PAL", ValueType.PRIMITIVE, wrap.getGross_wt()));
								entity.addProperty(new Property(null, "GrossWeightUnit_PAL", ValueType.PRIMITIVE, wrap.getUnit_of_wt()));
								entity.addProperty(new Property(null, "Volume_PAL", ValueType.PRIMITIVE, wrap.getVolume()));
								entity.addProperty(new Property(null, "VolumeUnit_PAL", ValueType.PRIMITIVE, wrap.getVolumeunit()));
								entity.addProperty(new Property(null, "Length_PAL", ValueType.PRIMITIVE, wrap.getLength()));
								entity.addProperty(new Property(null, "LengthUnit_PAL", ValueType.PRIMITIVE, wrap.getUnit_length()));
								entity.addProperty(new Property(null, "Width_PAL", ValueType.PRIMITIVE, wrap.getWidth()));
								entity.addProperty(new Property(null, "WidthUnit_PAL", ValueType.PRIMITIVE, wrap.getUnit_width()));
								entity.addProperty(new Property(null, "Height_PAL", ValueType.PRIMITIVE, wrap.getHeight()));
								entity.addProperty(new Property(null, "HeightUnit_PAL", ValueType.PRIMITIVE, wrap.getUnit_height()));
								entity.addProperty(new Property(null, "NbOfUCPerPAL", ValueType.PRIMITIVE, wrap.getNb_per_first()));
								entity.addProperty(new Property(null, "NbOfULPerPAL", ValueType.PRIMITIVE, wrap.getNb_per_second()));
								entity.addProperty(new Property(null, "NbOfLayer", ValueType.PRIMITIVE, wrap.getNb_of_lay()));
							}
						}
						// Descriptions
						entity.addProperty(new Property(null, "ShortDescription", ValueType.PRIMITIVE, prodDetail.getMaktx()));
						entity.addProperty(new Property(null, "DescriptionLong", ValueType.PRIMITIVE, prodDetail.getEcatdescription()));
						entity.addProperty(new Property(null, "IngredientList", ValueType.PRIMITIVE, prodDetail.getIngredientlist()));
						entity.addProperty(new Property(null, "ConsumptionAge", ValueType.PRIMITIVE, prodDetail.getConsumptionage()));
						entity.addProperty(new Property(null, "LegalDenomination", ValueType.PRIMITIVE, prodDetail.getLegaldeno()));
						entity.addProperty(new Property(null, "MentionConsBefore", ValueType.PRIMITIVE, prodDetail.getBeforeopening()));
						entity.addProperty(new Property(null, "MentionConsAfter", ValueType.PRIMITIVE, prodDetail.getAfteropening()));
						entity.addProperty(new Property(null, "RegulatoryMentions", ValueType.PRIMITIVE, prodDetail.getRegulatory()));
						entity.addProperty(new Property(null, "AdviseOfUse", ValueType.PRIMITIVE, prodDetail.getAdviseuse()));
						entity.addProperty(new Property(null, "NoticeMilk", ValueType.PRIMITIVE, prodDetail.getNoticemilk()));
						entity.addProperty(new Property(null, "Indication", ValueType.PRIMITIVE, prodDetail.getSpecificindic()));
						entity.addProperty(new Property(null, "InstructionsUse", ValueType.PRIMITIVE, prodDetail.getInstructionsuse()));
						entity.addProperty(new Property(null, "InstructionsUseLight", ValueType.PRIMITIVE, prodDetail.getInstructionsuselight()));
						// Allergens
						List<AllergenDetailWrapper> allergenclist = prodDetail.getAllergensContainList();
//						entity.addProperty(createAllergen("AllergensContain", allergenclist));
  						entity.addProperty(createAllergenColl("AllergensContainColl", "AllergensContain", allergenclist));
						List<AllergenDetailWrapper> allergenmclist = prodDetail.getAllergensMayContainList();
//						entity.addProperty(createAllergen("AllergensMayContain", allergenmclist));
						entity.addProperty(createAllergenColl("AllergensMayContainColl", "AllergensMayContain", allergenmclist));
						List<AllergenDetailWrapper> allergennplist = prodDetail.getAllergensNotPresentList();
//						entity.addProperty(createAllergen("AllergensNotPresent", allergennplist));
						entity.addProperty(createAllergenColl("AllergensNotPresentColl", "AllergensNotPresent", allergennplist));

						// Nutritional values
						List<NutboardWrapper> nutboardlist = prodDetail.getNutboard(); 
//						entity.addProperty(createNutboard("NutritionalValues", nutboardlist)); 
						entity.addProperty(createNutboardColl("NutritionalValuesColl", "NutritionalValues", nutboardlist)); 
					    // General
						entity.addProperty(new Property(null, "DescriptionComm", ValueType.PRIMITIVE, prodDetail.getCommercialDescription()));
						entity.addProperty(new Property(null, "DescriptionWeb", ValueType.PRIMITIVE, prodDetail.getInternetdescription()));
						entity.addProperty(new Property(null, "MkgFormat", ValueType.PRIMITIVE, prodDetail.getFormat()));
						entity.addProperty(new Property(null, "ConsumptionTime", ValueType.PRIMITIVE, prodDetail.getConsumptiontime()));
						entity.addProperty(new Property(null, "Click2Buy", ValueType.PRIMITIVE, prodDetail.getClick2buy()));
						entity.addProperty(new Property(null, "Texture", ValueType.PRIMITIVE, prodDetail.getMktexture()));
						entity.addProperty(new Property(null, "AdditionalIngredients", ValueType.PRIMITIVE, prodDetail.getMkingredient()));
						entity.addProperty(new Property(null, "Benefits", ValueType.PRIMITIVE, prodDetail.getMkbenefits()));
						entity.addProperty(new Property(null, "MkgOther", ValueType.PRIMITIVE, prodDetail.getMkother()));
						entity.addProperty(new Property(null, "CountryOfOrigin", ValueType.PRIMITIVE, prodDetail.getHerkl()));
						entity.addProperty(new Property(null, "GoodSupplierAgreement", ValueType.PRIMITIVE, prodDetail.getGoodsupplier()));
						entity.addProperty(new Property(null, "CEEGoodSupplierAgreement", ValueType.PRIMITIVE, prodDetail.getAgreement()));
						entity.addProperty(new Property(null, "MilkyProducts", ValueType.PRIMITIVE, prodDetail.getMilkyproduct()));
						entity.addProperty(new Property(null, "GMO", ValueType.PRIMITIVE, prodDetail.getGmo()));
						entity.addProperty(new Property(null, "OrganicBio", ValueType.PRIMITIVE, prodDetail.getOrganic()));
						entity.addProperty(new Property(null, "Brick", ValueType.PRIMITIVE, prodDetail.getBrick()));
						entity.addProperty(new Property(null, "CustomsList", ValueType.PRIMITIVE, prodDetail.getComm_code()));
						entity.addProperty(new Property(null, "ShelfLifeDelivery", ValueType.PRIMITIVE, prodDetail.getDlsc()));
						entity.addProperty(new Property(null, "ShelfLifeProduction", ValueType.PRIMITIVE, prodDetail.getLifetime_day()));
						//
						entity.setType(ProductEdmProvider.ET_PRODUCT_FQN.getFullQualifiedNameAsString());
						entity.setId(ProductStorage.createId(entity, "InternalCode"));
						productList.add(entity);
					} 
				}
			}
			
			navigationTargetEntityCollection.getEntities().addAll(productList);
			
			LOGGER.debug("getRelatedEntityCollection - productList: " + productList.size());
			
/*			int salesorgID = (Integer) sourceEntity.getProperty("ID").getValue();
			if (salesorgID == 1) {
				// the first 2 products are notebooks
				navigationTargetEntityCollection.getEntities().addAll(productList.subList(0, 2));
			} else if (salesorgID == 2) {
				// the next 2 products are organizers
				navigationTargetEntityCollection.getEntities().addAll(productList.subList(2, 4));
			} else if (salesorgID == 3) {
				// the first 2 products are monitors
				navigationTargetEntityCollection.getEntities().addAll(productList.subList(4, 6));
			}*/
		}

		if (navigationTargetEntityCollection.getEntities().isEmpty()) {
			return null;
		}

		return navigationTargetEntityCollection;
	}

	/* INTERNAL */

	private static EntityCollection getProducts(List<Entity> productList) {
		EntityCollection retEntitySet = new EntityCollection();

		for (Entity productEntity : productList) {
			retEntitySet.getEntities().add(productEntity);
		}

		return retEntitySet;
	}

	private Entity getProduct(EdmEntityType edmEntityType, List<UriParameter> keyParams) {

		// the list of entities at runtime
		EntityCollection entityCollection = ProductStorage.getProducts(this.productList);

		/* generic approach to find the requested entity */
		return Util.findEntity(edmEntityType, entityCollection, keyParams);
	}

	private static EntityCollection getSalesorgs(List<Entity> salesorgList) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityCollection entitySet = new EntityCollection();
		List<ZPROWS_ORG> listSalesorgs = ZPROWS_ORG.getAllSalesorgs(em);
		salesorgList.clear();

		for (ZPROWS_ORG salesorg : listSalesorgs) {
			Entity entity = new Entity();
			entity.addProperty(new Property(null, "SalesOrg", ValueType.PRIMITIVE, salesorg.getKey().getVkorg()));
			entity.addProperty(new Property(null, "DistCh", ValueType.PRIMITIVE, salesorg.getKey().getVtweg()));
			entity.addProperty(new Property(null, "SalesOrgDescr", ValueType.PRIMITIVE, salesorg.getVkorg_descr()));
			entity.addProperty(new Property(null, "DistChDescr", ValueType.PRIMITIVE, salesorg.getVtweg_descr()));
			entity.setType(ProductEdmProvider.ET_SALESORG_FQN.getFullQualifiedNameAsString());
			entity.setId(ProductStorage.createId(entity, "SalesOrg"));
			salesorgList.add(entity);
		}

		for (Entity salesorgEntity : salesorgList) {
			entitySet.getEntities().add(salesorgEntity);
		}

		return entitySet;
	}

	private Entity getCategory(EdmEntityType edmEntityType, List<UriParameter> keyParams) {

		// the list of entities at runtime
		EntityCollection entitySet = getSalesorgs(this.salesorgList);

		/* generic approach to find the requested entity */
		return Util.findEntity(edmEntityType, entitySet, keyParams);
	}

	/* HELPER */

	private static URI createId(Entity entity, String idPropertyName) {
		return ProductStorage.createId(entity, idPropertyName, null);
	}

	private static URI createId(Entity entity, String idPropertyName, String navigationName) {
		try {
			StringBuilder sb = new StringBuilder(ProductStorage.getEntitySetName(entity)).append("(");
			final Property property = entity.getProperty(idPropertyName);
			sb.append(property.asPrimitive()).append(")");
			if (navigationName != null) {
				sb.append("/").append(navigationName);
			}
			return new URI(sb.toString());
		} catch (URISyntaxException e) {
			throw new ODataRuntimeException("Unable to create (Atom) id for entity: " + entity, e);
		}
	}

	private static String getEntitySetName(Entity entity) {
		if (ProductEdmProvider.ET_SALESORG_FQN.getFullQualifiedNameAsString().equals(entity.getType())) {
			return ProductEdmProvider.ES_SALESORGS_NAME;
		} else if (ProductEdmProvider.ET_PRODUCT_FQN.getFullQualifiedNameAsString().equals(entity.getType())) {
			return ProductEdmProvider.ES_PRODUCTS_NAME;
		}
		return entity.getType();
	}
	
	private Property createAllergen(String name, List<AllergenDetailWrapper> allergenlist) {
		List<Property> allergenProperties = new ArrayList<Property>();
		for (AllergenDetailWrapper allergendetail : allergenlist) {
			allergenProperties.add(new Property(null, name + "Code", ValueType.PRIMITIVE,allergendetail.getCode()));
			allergenProperties.add(new Property(null, name + "CodeDesc", ValueType.PRIMITIVE,allergendetail.getDescription()));
		}
		ComplexValue complexValue = new ComplexValue();
		for (final Property property : allergenProperties) {		    
		    complexValue.getValue().add(property);
		    //complexCollection.add(complexValue);
		  }
		// return allergenProperties;
		return new Property(null, name, ValueType.COMPLEX, complexValue);
	}
	private Property createAllergenColl(String collname, String typename, List<AllergenDetailWrapper> allergenlist) {
		List<ComplexValue> complexCollection = new ArrayList<ComplexValue>();
				
		for (AllergenDetailWrapper allergendetail : allergenlist) {
			ComplexValue complexValue = new ComplexValue();
			complexValue.getValue().add(new Property(null, typename + "Code", ValueType.PRIMITIVE,allergendetail.getCode()));
			complexValue.getValue().add(new Property(null, typename + "CodeDesc", ValueType.PRIMITIVE,allergendetail.getDescription()));
			complexCollection.add(complexValue);
		}
		return new Property(null, collname, ValueType.COLLECTION_COMPLEX, complexCollection);
	}
	private Property createNutboardColl(String collname, String typename, List<NutboardWrapper> nutboardlist) {
		List<ComplexValue> complexCollection = new ArrayList<ComplexValue>();
		 
		for (NutboardWrapper nutboarddetail : nutboardlist) {
			ComplexValue complexValue = new ComplexValue();
			complexValue.getValue().add(new Property(null, "ServingSize", ValueType.PRIMITIVE,nutboarddetail.getPorid()));
			complexValue.getValue().add(new Property(null, "UnitServingSize", ValueType.PRIMITIVE,nutboarddetail.getPoridun()));
			complexValue.getValue().add(new Property(null, "ServingSizeDesc", ValueType.PRIMITIVE,nutboarddetail.getPoridtext()));
			complexValue.getValue().add(new Property(null, "RankNutrients", ValueType.PRIMITIVE,nutboarddetail.getRank()));
			complexValue.getValue().add(new Property(null, "NutrientCode", ValueType.PRIMITIVE,nutboarddetail.getNutid()));
			complexValue.getValue().add(new Property(null, "NutrientCodeDesc", ValueType.PRIMITIVE,nutboarddetail.getNutidtext()));
			complexValue.getValue().add(new Property(null, "ValueNutrient", ValueType.PRIMITIVE,nutboarddetail.getPoridva()));
			complexValue.getValue().add(new Property(null, "ValueRoundedNutrient", ValueType.PRIMITIVE,nutboarddetail.getPoridvaro()));
			complexValue.getValue().add(new Property(null, "UnitValueNutrient", ValueType.PRIMITIVE,nutboarddetail.getValueun()));
			complexValue.getValue().add(new Property(null, "AJRC", ValueType.PRIMITIVE,nutboarddetail.getAjrc()));
			complexValue.getValue().add(new Property(null, "AJRCUnit", ValueType.PRIMITIVE,nutboarddetail.getAjrcun()));
			complexValue.getValue().add(new Property(null, "SignNutrient", ValueType.PRIMITIVE,nutboarddetail.getPoridsign()));
			complexCollection.add(complexValue);
		}
		return new Property(null, collname, ValueType.COLLECTION_COMPLEX, complexCollection);
	}
	private Property createNutboard(String name, List<NutboardWrapper> nutboardlist) {
		List<Property> nutboardProperties = new ArrayList<Property>();
		for (NutboardWrapper nutboarddetail : nutboardlist) {
			nutboardProperties.add(new Property(null, "ServingSize", ValueType.PRIMITIVE,nutboarddetail.getPorid()));
			nutboardProperties.add(new Property(null, "UnitServingSize", ValueType.PRIMITIVE,nutboarddetail.getPoridun()));
			nutboardProperties.add(new Property(null, "ServingSizeDesc", ValueType.PRIMITIVE,nutboarddetail.getPoridtext()));
			nutboardProperties.add(new Property(null, "RankNutrients", ValueType.PRIMITIVE,nutboarddetail.getRank()));
			nutboardProperties.add(new Property(null, "NutrientCode", ValueType.PRIMITIVE,nutboarddetail.getNutid()));
			nutboardProperties.add(new Property(null, "NutrientCodeDesc", ValueType.PRIMITIVE,nutboarddetail.getNutidtext()));
			nutboardProperties.add(new Property(null, "ValueNutrient", ValueType.PRIMITIVE,nutboarddetail.getPoridva()));
			nutboardProperties.add(new Property(null, "ValueRoundedNutrient", ValueType.PRIMITIVE,nutboarddetail.getPoridvaro()));
			nutboardProperties.add(new Property(null, "UnitValueNutrient", ValueType.PRIMITIVE,nutboarddetail.getValueun()));
			nutboardProperties.add(new Property(null, "AJRC", ValueType.PRIMITIVE,nutboarddetail.getAjrc()));
			nutboardProperties.add(new Property(null, "AJRCUnit", ValueType.PRIMITIVE,nutboarddetail.getAjrcun()));
			nutboardProperties.add(new Property(null, "SignNutrient", ValueType.PRIMITIVE,nutboarddetail.getPoridsign()));
		}
		ComplexValue complexValue = new ComplexValue();
		for (final Property property : nutboardProperties) {		    
		    complexValue.getValue().add(property);
		  }
		return new Property(null, name, ValueType.COMPLEX, complexValue);
	}
}
