package com.danone.proxy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.servlet.ServletContext;

import org.apache.http.HttpResponse;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.message.BasicHttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.persistence.CacheCommands;
import com.danone.persistence.CacheCommands.Commands;
import com.danone.persistence.PersistenceAdapter;

public class ProxyUtil {

	private static Logger LOGGER = LoggerFactory.getLogger(ProxyUtil.class);
	private static long cacheExpirationTime = 1000 * 60 * 60 * 24; // 24 hours
	private static long checkCacheCommandsIntervall = 1000 * 60; // 1 minute

	public static List<String> readDataFromFile(ServletContext ctx,
			String filename) {
		InputStream is = null;
		List<String> data = new ArrayList<String>();
		try {
			is = ctx.getResourceAsStream(filename);
			if (is != null) {
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(is, "UTF-8"));
				String line = null;
				while ((line = reader.readLine()) != null) {
					if (!line.equals(""))
						data.add(line);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Could not read file: " + filename, e);
			return data;
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
				}
			}
		}
		return data;
	}

	public static boolean uriShouldBeCached(ProxyRequest request) {
		LOGGER.debug("In URI Should Be Cached");
		if (request.getMethod().equals("POST")
				|| request.getMethod().equals("PUT")) {
			LOGGER.debug("In post or put");
			String forcecache = request.getHeader("x-crm-forcecache");
			if (forcecache != null && forcecache.equalsIgnoreCase("true")) {
				LOGGER.debug("true");
				return true;
			}
			LOGGER.debug("false");
			return false;
		}
		String xsrf = request.getHeader("x-csrf-token");
		if (xsrf != null && xsrf.equalsIgnoreCase("Fetch")) {
			return false;
		}
		String nocache = request.getHeader("x-crm-nocache");
		if (nocache != null && nocache.equalsIgnoreCase("true")) {
			return false;
		}
		return true;
	}

	public static String cloneResponse2(String json) throws IOException {
		String clone = new String(json);
		return clone;
	}

	public static HttpResponse cloneResponse(HttpResponse backendResponse)
			throws IOException {
		HttpResponse clone = new BasicHttpResponse(
				backendResponse.getStatusLine());
		clone.setHeaders(backendResponse.getAllHeaders());
		if (backendResponse.getEntity() != null) {
			BufferedHttpEntity cloneEntity = new BufferedHttpEntity(
					backendResponse.getEntity());
			clone.setEntity(cloneEntity);
		}
		return clone;
	}

	public static void scheduleCacheTask(Timer timer) {
		Calendar date = Calendar.getInstance();
		date.set(Calendar.HOUR_OF_DAY, 0);
		date.set(Calendar.MINUTE, 10);
		date.set(Calendar.SECOND, 0);
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				LOGGER.debug("Clear the cache");
				LRUCache<String, CacheEntry2> cache = ProxyServlet.getCache();
				cache.clearCache();
			}

		}, date.getTime(), cacheExpirationTime);

		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				EntityManager em = PersistenceAdapter.getEntityManager();
				try {
					long lastCheckNumber = ProxyServlet.getCheckNumber();
					LOGGER.debug("Check for new cache commands with id > "
							+ lastCheckNumber);
					List<CacheCommands> commands = em
							.createQuery(
									"SELECT c FROM CacheCommands c WHERE c.id > :id ORDER BY c.id",
									CacheCommands.class)
							.setParameter("id", lastCheckNumber)
							.getResultList();
					if (!commands.isEmpty()) {
						for (CacheCommands command : commands) {
							ProxyServlet.setCheckNumber(command.getID());
							LOGGER.debug("Execute command: "
									+ command.toString());
							executeCommands(command);
						}
					} else {
						LOGGER.debug("No new commands found");
					}
				} catch (Exception e) {
					// do nothing since subsequent executions should occur !
					LOGGER.error(
							"Could not execute check for new cache commands ",
							e);
				} finally {
					em.close();
				}
			}

		}, checkCacheCommandsIntervall, checkCacheCommandsIntervall);
	}

	private static void executeCommands(CacheCommands commandEntry) {
		switch (commandEntry.getCommand()) {
		case ACTIVATE_CACHE:
			if (commandEntry.getValue().equalsIgnoreCase("TRUE")) {
				ProxyServlet.activateCache(true);
			} else if (commandEntry.getValue().equalsIgnoreCase("FALSE")) {
				ProxyServlet.activateCache(false);
			}
			break;
		case CLEAR_CACHE:
			if (commandEntry.getValue().equalsIgnoreCase("TRUE")) {
				LRUCache<String, CacheEntry2> cache = ProxyServlet.getCache();
				cache.clearCache();
			}
			break;
		case DELETE_ENTRY:
			LRUCache<String, CacheEntry2> cache = ProxyServlet.getCache();
			cache.remove(commandEntry.getValue());
			break;
		}
	}

	public static void writeClearCacheCommand() {
		LOGGER.debug("Write CLEAR_CACHE command to DB");
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {
			CacheCommands command = new CacheCommands();
			command.setCommand(Commands.CLEAR_CACHE);
			command.setValue("true");
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();
			em.persist(command);
			transaction.commit();
		} finally {
			em.close();
		}
	}

	public static void writeDeleteEntryCommand(String requestURI) {
		LOGGER.debug("Write DELETE_ENTRY command for " + requestURI + " to DB");
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {
			CacheCommands command = new CacheCommands();
			command.setCommand(Commands.DELETE_ENTRY);
			command.setValue(requestURI);
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();
			em.persist(command);
			transaction.commit();
		} finally {
			em.close();
		}
	}

	public static void writeActivateCacheCommand(String value) {
		LOGGER.debug("Write ACTIVATE_CACHE command with value " + value
				+ " to DB");
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {
			CacheCommands command = new CacheCommands();
			command.setCommand(Commands.ACTIVATE_CACHE);
			command.setValue(value);
			EntityTransaction transaction = em.getTransaction();
			transaction.begin();
			em.persist(command);
			transaction.commit();
		} finally {
			em.close();
		}
	}
}
