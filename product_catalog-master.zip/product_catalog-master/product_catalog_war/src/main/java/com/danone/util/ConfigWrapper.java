package com.danone.util;

import java.util.List;

public class ConfigWrapper {
	List<String> allergens;
	List<String> zzoverlay;
	List<String> consumationfrom;
	List<String> mvgr1;
	List<String> vmsta;
	List<String> zzsignature;
	List<String> zzproductvar;
	List<String> zzforcastunit;
	List<String> zzproces1;
	List<String> zzproces2;
	
	private String userid;
	private String usercompany;
	private String usersalesorg;
	private Boolean samesorg;
	
	public List<String> getAllergens() {
		return allergens;
	}

	public void setAllergens(List<String> allergens) {
		this.allergens = allergens;
	}
	
	public List<String> getZzoverlay() {
		return zzoverlay;
	}

	public void setZzoverlay(List<String> zzoverlay) {
		this.zzoverlay = zzoverlay;
	}
		
	public List<String> getConsumationfrom() {
		return consumationfrom;
	}
	
	public void setConsumationfrom(List<String> consumationfrom){
		this.consumationfrom = consumationfrom;
	}
	
	public List<String> getMvgr1() {
		return mvgr1;
	}
	
	public void setMvgr1(List<String> mvgr1){
		this.mvgr1 = mvgr1;
	}
	
	public List<String> getVmsta() {
		return vmsta;
	}
	
	public void setVmsta(List<String> vmsta){
		this.vmsta = vmsta;
	}
	
	public List<String> getZzproductvar() {
		return zzproductvar;
	}

	public void setZzproductvar(List<String> zzproductvar) {
		this.zzproductvar = zzproductvar;
	}

	public List<String> getZzforcastunit() {
		return zzforcastunit;
	}

	public void setZzforcastunit(List<String> zzforcastunit) {
		this.zzforcastunit = zzforcastunit;
	}
	
	public List<String> getZzsignature() {
		return zzsignature;
	}

	public void setZzsignature(List<String> zzsignature) {
		this.zzsignature = zzsignature;
	}
	
	public List<String> getZzproces1() {
		return zzproces1;
	}

	public void setZzproces1(List<String> zzproces1) {
		this.zzproces1 = zzproces1;
	}
	
	public List<String> getZzproces2() {
		return zzproces2;
	}

	public void setZzproces2(List<String> zzproces2) {
		this.zzproces2 = zzproces2;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsercompany() {
		return usercompany;
	}

	public void setUsercompany(String usercompany) {
		this.usercompany = usercompany;
	}

	public String getUsersalesorg() {
		return usersalesorg;
	}

	public void setUsersalesorg(String usersalesorg) {
		this.usersalesorg = usersalesorg;
	}

	public Boolean getSamesorg() {
		return samesorg;
	}

	public void setSamesorg(Boolean samesorg) {
		this.samesorg = samesorg;
	}
}
