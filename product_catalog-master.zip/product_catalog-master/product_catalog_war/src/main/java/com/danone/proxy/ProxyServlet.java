package com.danone.proxy;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.persistence.PersistenceAdapter;
import com.danone.resources.SearchResource;
import com.danone.util.JCoHelper;
import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCo;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoListMetaData;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
import com.sap.core.connectivity.api.DestinationFactory;
import com.sap.core.connectivity.api.http.HttpDestination;

public class ProxyServlet extends HttpServlet {
	private static final long serialVersionUID = -8620841319466021287L;

	private static String[] BLOCKED_REQUEST_HEADERS = { "host", "content-length", "authorization" };

	private static final int IO_BUFFER_SIZE = 4 * 1024;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProxyServlet.class);

	private static DestinationFactory destinationFactory;

	private static LRUCache<String, CacheEntry2> cache;

	private static Timer timer = new Timer("IvalidateCache");

	private static boolean cacheActive = true;

	private static long checkNumber = -1;
	
	private static String destinationName = "PRODCATALOG-SAP";

	private Map<String, HashMap<String, String>> urlStore;
	private JCoRepository repo = null;
	JCoDestination destination = null;

	public void init(ServletConfig servletConfig) throws ServletException {
		super.init(servletConfig);
		urlStore = new HashMap<String, HashMap<String, String>>();
		cache = new LRUCache<String, CacheEntry2>(500);
		ProxyUtil.scheduleCacheTask(ProxyServlet.timer);

		try {
			LOGGER.debug("Initializing Repository....");
			destination = JCoDestinationManager.getDestination(destinationName);
			repo = destination.getRepository();
			LOGGER.debug("repo:" + repo + " destination:" + destination);
			JCo.setProperty("jco.use_repository_roundtrip_optimization", "1");
			List<String> functions = new ArrayList<String>();
			functions.add("ZSHCP_PROM_FETCH_UPDATES");
			functions.add("ZSHCP_PROM_FETCH_CONFIG");
			functions.add("ZSHCP_CATALOG_STATUS_CHANGE");
			functions.add("ZSHCP_PROM_SET_STATUS_DONE");
			functions.add("ZSHCP_PROM_FETCH_SINGLE_UPDATE");
			JCo.queryMetaDataSet(repo, functions, null, null);
			LOGGER.debug("Initializing Finished....");

		} catch (JCoException e) {
			LOGGER.debug("Exception during Repository Initiliazation: " + e.getLocalizedMessage());
			e.printStackTrace();
		}
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOGGER.debug("In Proxy servlet...V2.0");
		
		String userSalesorg = new String();
		try {
			userSalesorg = request.getSession().getAttribute("Usersalesorg").toString();
		} catch (Exception e) {
			userSalesorg = "";
		}	

		ProxyRequest proxyRequest = new ProxyRequest(request);
		if (proxyRequest.getRequestURI().indexOf(proxyRequest.getContextPath() + proxyRequest.getServletPath() + "/") == -1) {
			throw new ServletException(writeMessage("no destination specified"));
		}

		response.setCharacterEncoding("UTF-8");
		response.addHeader("Content-type", "application/json; charset=utf-8");
		// never cache responses on the browser
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-cache, no-store");

		if (cacheActive) {
			LOGGER.debug("Cache is active.");
			if (ProxyUtil.uriShouldBeCached(proxyRequest)) {
				LOGGER.debug("--- Try to load URI " + proxyRequest.getCompleteRequestURI() + " from cache");
				String header = proxyRequest.getHeader("x-crm-invalidate-cache");
				if (header != null && header.equals("true")) {
					LOGGER.info("--- Try to invalidate cache entries with key " + proxyRequest.getCompleteRequestURI());
					invalidateCacheEntryAndReload(proxyRequest, response);
					return;
				}
				loadFromCache2(proxyRequest, response);
			} else {
				LOGGER.debug("Do not use cache for " + proxyRequest.getCompleteRequestURI());
				// loadBackendData(proxyRequest, response, false);
				processRequest(proxyRequest, response, request.getMethod(), false);
			}
		} else {
			LOGGER.info("Cache is inactive.");
			// loadBackendData(proxyRequest, response, false);
			processRequest(proxyRequest, response, request.getMethod(), false);
		}

	}

	private void invalidateCacheEntryAndReload(ProxyRequest proxyRequest, HttpServletResponse response) throws ServletException, IOException {
		List<CacheEntry2> entriesToInvalidate = new ArrayList<CacheEntry2>();
		if (proxyRequest.getCompleteRequestURI().endsWith("*")) {
			// several cache entries should be reloaded
			LOGGER.info("Several cache entries should be invalidated");
			String completeURI = proxyRequest.getCompleteRequestURI();
			completeURI = completeURI.substring(0, completeURI.length() - 1);
			synchronized (cache) {
				for (Map.Entry<String, CacheEntry2> entry : cache.entrySet()) {
					if (entry.getKey().startsWith(completeURI)) {
						LOGGER.info("Invalidate cache entry with key " + entry.getKey());
						entriesToInvalidate.add(entry.getValue());

					}
				}
			}
		} else {
			// one entry should be reloaded
			LOGGER.info("One cache entry should be invalidated");
			String input = getPostParameters(proxyRequest);
			CacheEntry2 cacheEntry = cache.get(proxyRequest.getCompleteRequestURI() + input);
			if (cacheEntry != null) {
				LOGGER.info("Invalidate cache entry with key " + proxyRequest.getCompleteRequestURI());
				entriesToInvalidate.add(cacheEntry);
			} else {
				LOGGER.warn("Could not invalidate a cache entry for URI " + proxyRequest.getCompleteRequestURI() + " because it did not exist");
			}
		}

		for (CacheEntry2 cacheEntry : entriesToInvalidate) {
			ProxyRequest cachedRequest = cacheEntry.getClientRequest();
			// HttpResponse newClonedBackendResponse = loadBackendData(
			// cachedRequest, response, true);

			String newClonedBackendResponse;
			try {
				newClonedBackendResponse = processRequest(cachedRequest, response, cachedRequest.getMethod(), true);
				String string = new String(newClonedBackendResponse.getBytes("UTF-8"), Charset.forName("UTF-8"));
				String input = getPostParameters(cachedRequest);
				cache.put(cachedRequest.getCompleteRequestURI() + input, new CacheEntry2(cachedRequest, string));
			} catch (IOException e) {
				LOGGER.warn("Could not invalidate URI " + proxyRequest.getCompleteRequestURI() + ". Response code from backend ");
			}
			// if (newClonedBackendResponse.getStatusLine().getStatusCode() <
			// 400) {

			// } else {
			// LOGGER.warn("Could not invalidate URI "
			// + proxyRequest.getCompleteRequestURI()
			// + ". Response code from backend "
			// + newClonedBackendResponse.getStatusLine()
			// .getStatusCode());
			// }
		}
	}

	private String getPostParameters(ProxyRequest request) throws ServletException, IOException {
		String input = "";
		if (request.getMethod().equals("POST") || request.getMethod().equals("PUT")) {
			String forcecache = request.getHeader("x-crm-forcecache");
			if (forcecache != null && forcecache.equalsIgnoreCase("true")) {
				input = IOUtils.toString(request.getEntity().getContent(), Charsets.UTF_8);
				if (input != null && input.indexOf("PARAMETERS") != -1) {
					input = input.substring(11); // length of PARAMETERS + 1
				}
				input = "_" + URLDecoder.decode(input, "UTF-8");
			}
		}
		return input;
	}

	private void loadFromCache2(ProxyRequest request, HttpServletResponse response) throws ServletException, IOException {
		String input = getPostParameters(request);
		CacheEntry2 cacheEntry = cache.get(request.getCompleteRequestURI() + input);
		if (cacheEntry == null) {
			LOGGER.debug("URI " + request.getCompleteRequestURI() + " was not in cache");
			// HttpResponse clonedBackendResponse = loadBackendData(request,
			// response, true);
			String clonedBackendResponse = processRequest(request, response, request.getMethod(), true);
			String string = new String(clonedBackendResponse.getBytes("UTF-8"), Charset.forName("UTF-8"));
			cacheEntry = new CacheEntry2(request, string);
			// if (clonedBackendResponse.getStatusLine().getStatusCode() < 400)
			// {

			cache.put(request.getCompleteRequestURI() + input, cacheEntry);
			// } else {
			// LOGGER.warn("Response not put into cache because backend request returned with status code "
			// + clonedBackendResponse.getStatusLine().getStatusCode());
			// }
		} else {
			LOGGER.debug("URI " + request.getCompleteRequestURI() + " found in cache with value" + cacheEntry.getBackendResponse());
		}

		copyBackendResponseToClient2(response.getWriter(), cacheEntry.getBackendResponse());
	}

	// private void loadFromCache(ProxyRequest request,
	// HttpServletResponse response) throws ServletException, IOException {
	// CacheEntry cacheEntry = cache.get(request.getCompleteRequestURI());
	// if (cacheEntry == null) {
	// LOGGER.debug("URI " + request.getCompleteRequestURI()
	// + " was not in cache");
	// HttpResponse clonedBackendResponse = loadBackendData(request,
	// response, true);
	// cacheEntry = new CacheEntry(request, clonedBackendResponse);
	// if (clonedBackendResponse.getStatusLine().getStatusCode() < 400) {
	// cache.put(request.getCompleteRequestURI(), cacheEntry);
	// } else {
	// LOGGER.warn("Response not put into cache because backend request returned with status code "
	// + clonedBackendResponse.getStatusLine().getStatusCode());
	// }
	// } else {
	// LOGGER.debug("URI " + request.getCompleteRequestURI()
	// + " found in cache");
	// }
	// copyBackendResponseToClient(response, cacheEntry.getBackendResponse());
	// }

	private HttpResponse loadBackendData(ProxyRequest request, HttpServletResponse response, boolean cloneResponseForCache) throws ServletException {
		int contextPathLength = request.getContextPath().length();
		int servletPathLength = request.getServletPath().length();
		String pathInfo = request.getRequestURI().substring(contextPathLength + servletPathLength + 1);
		String destinationName = getDestinationFromUrl(request.getServletPath());
		String urlToService = getRelativePathFromUrl(pathInfo, request.getQueryString());
		LOGGER.debug("URL To Service " + urlToService);
		LOGGER.debug("Destination name is " + destinationName);

		HttpDestination dest = getDestination(destinationName);
		HttpClient httpClient = null;
		try {
			httpClient = dest.createHttpClient();
			HttpRequestBase backendRequest = createBackendRequest(request, urlToService);
			String cookieString = "";
			HashMap<String, String> cookieStore = this.readStore("TEST");
			Iterator it = cookieStore.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				String key = pairs.getKey().toString();
				cookieString += key + "=" + pairs.getValue() + ";";
				// it.remove(); // avoids a ConcurrentModificationException

			}
			LOGGER.debug("Value of CookieString is " + cookieString);
			backendRequest.addHeader("Cookie", cookieString);
			HttpResponse backendResponse = httpClient.execute(backendRequest);

			Header[] headers = backendResponse.getHeaders("Set-Cookie");
			for (Header h : headers) {
				LOGGER.debug("cookie = " + h.getValue().toString());

				String value = h.getValue();
				String[] rawCookieParams = value.split(";");
				String[] rawCookieNameAndValue = rawCookieParams[0].split("=");
				cookieStore.put(rawCookieNameAndValue[0], rawCookieNameAndValue[1]);
			}

			if (cloneResponseForCache) {
				return ProxyUtil.cloneResponse(backendResponse);
			} else {
				copyBackendResponseToClient(response, backendResponse);
				return null;
			}

		} catch (Exception e) {
			throw new ServletException(e);
		} finally {
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}
	}

	private HashMap<String, String> readStore(String key) {
		if (urlStore.containsKey(key)) {
			LOGGER.debug("Using cookieStore and key " + key);
			return urlStore.get(key);
		} else {
			LOGGER.debug("Creating a new cookieStore with key " + key);
			HashMap<String, String> cookieStore = new HashMap<String, String>();
			urlStore.put(key, cookieStore);
			return this.readStore(key);

		}

	}

	private HttpRequestBase createBackendRequest(ProxyRequest request, String urlToService) throws IOException {
		String method = request.getMethod();
		HttpRequestBase backendRequest = null;
		if ("POST".equals(method)) {
			HttpPost post = new HttpPost(urlToService);
			post.setEntity(request.getEntity());
			backendRequest = post;
		} else if ("GET".equals(method)) {
			HttpGet get = new HttpGet(urlToService);
			backendRequest = get;
		} else if ("PUT".equals(method)) {
			HttpPut put = new HttpPut(urlToService);
			put.setEntity(request.getEntity());
			backendRequest = put;
		} else if ("DELETE".equals(method)) {
			HttpDelete delete = new HttpDelete(urlToService);
			backendRequest = delete;
		}

		List<String> blockedHeaders = Arrays.asList(BLOCKED_REQUEST_HEADERS);
		LOGGER.debug("Headers from Client passed to Backend Request");

		Map<String, String> headers = request.getHeaders();
		for (Map.Entry<String, String> header : headers.entrySet()) {
			if (!blockedHeaders.contains(header.getKey().toLowerCase())) {
				backendRequest.addHeader(header.getKey(), header.getValue());
				LOGGER.debug("    => " + header.getKey() + ": " + header.getValue());
			} else {
				LOGGER.debug("    => " + header.getKey() + " with value = " + header.getValue() + ": is not send to backend");
			}
		}

		return backendRequest;
	}

	private String copyBackendResponseToClient2(PrintWriter responseWriter, String json) throws IOException, ServletException {
		// int status = backendResponse.getStatusLine().getStatusCode();
		// response.setStatus(status);
		// if (status >= 400) {
		// LOGGER.error("Backend Response code: " + status);
		// }
		// LOGGER.debug("Backend response code: " + status);
		//
		// List<String> blockedHeaders = Arrays.asList("transfer-encoding",
		// "content-length");
		//
		// LOGGER.debug("Headers from Backend passed to Client Response");
		// for (Header header : backendResponse.getAllHeaders()) {
		// if (!blockedHeaders.contains(header.getName().toLowerCase())) {
		// response.addHeader(header.getName(), header.getValue());
		// LOGGER.debug("    => " + header.getName() + ": "
		// + header.getValue());
		// } else {
		// LOGGER.debug("    => " + header.getName() + ": "
		// + header.getValue() + " is not sent to client");
		// }
		// }

		// proxy responses should never be cached on client

		// copy content
		// HttpEntity backendEntity = backendResponse.getEntity();
		//
		// if (backendEntity != null) {
		// pipe(backendEntity.getContent(), response.getOutputStream());
		// EntityUtils.consume(backendEntity);
		// }

		LOGGER.error("Copying backend response to client: " + json);
		responseWriter.write(json);
		return json;
	}

	private void copyBackendResponseToClient(HttpServletResponse response, HttpResponse backendResponse) throws IOException, ServletException {
		int status = backendResponse.getStatusLine().getStatusCode();
		response.setStatus(status);
		if (status >= 400) {
			LOGGER.error("Backend Response code: " + status);
		}
		LOGGER.debug("Backend response code: " + status);

		List<String> blockedHeaders = Arrays.asList("transfer-encoding", "content-length");

		LOGGER.debug("Headers from Backend passed to Client Response");
		for (Header header : backendResponse.getAllHeaders()) {
			if (!blockedHeaders.contains(header.getName().toLowerCase())) {
				response.addHeader(header.getName(), header.getValue());
				LOGGER.debug("    => " + header.getName() + ": " + header.getValue());
			} else {
				LOGGER.debug("    => " + header.getName() + ": " + header.getValue() + " is not sent to client");
			}
		}

		// proxy responses should never be cached on client
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-cache, no-store");

		// copy content
		HttpEntity backendEntity = backendResponse.getEntity();
		if (backendEntity != null) {
			pipe(backendEntity.getContent(), response.getOutputStream());
			EntityUtils.consume(backendEntity);
		}
	}

	protected HttpDestination getDestination(String destinationName) throws ServletException {
		try {
			if (destinationFactory == null) {
				Context ctx = new InitialContext();
				destinationFactory = (DestinationFactory) ctx.lookup(DestinationFactory.JNDI_NAME);
			}
			HttpDestination dest = (HttpDestination) destinationFactory.getDestination(destinationName);
			return dest;
		} catch (Exception e) {
			throw new ServletException(writeMessage("Unable to resolve destination " + destinationName), e);
		}
	}

	protected String getDestinationFromUrl(String servletPath) throws ServletException {
		String destinationName = null;
		int index = servletPath.lastIndexOf("/");
		if (index != -1) {
			destinationName = servletPath.substring(index + 1, servletPath.length());

		}
		if (destinationName == null) {
			throw new ServletException(writeMessage("no destination specified"));
		}
		LOGGER.debug("destination read from URL path: " + destinationName);
		return destinationName;
	}

	protected String getRelativePathFromUrl(String path, String queryString) {
		path = path.replace(" ", "%20");

		if (queryString != null && !queryString.isEmpty()) {
			path += "?" + queryString;
		}

		LOGGER.debug("relative path to service, incl. query string: " + path);
		return path;
	}

	public static void pipe(InputStream in, OutputStream out) throws IOException {
		byte[] b = new byte[IO_BUFFER_SIZE];
		int read;
		while ((read = in.read(b)) != -1) {
			out.write(b, 0, read);
		}
		out.flush();
	}

	private String writeMessage(String message) {
		StringBuilder b = new StringBuilder();
		b.append("\nInvalid usage: ").append(message);
		b.append("\n");
		b.append("\nUsage of proxy servlet:");
		b.append("\n=======================");
		b.append("\nIt is assumed that the URL to the servlet follows the pattern ");
		b.append("\n==> /<context-path>/proxy/<destination-name>/<relative-path-below-destination-target>");
		b.append("\n");
		return b.toString();
	}

	public static LRUCache<String, CacheEntry2> getCache() {
		return cache;
	}

	public static boolean cacheActive() {
		return cacheActive;
	}

	public static synchronized void activateCache(boolean cacheActive) {
		ProxyServlet.cacheActive = cacheActive;
	}

	public static long getCheckNumber() {
		return ProxyServlet.checkNumber;
	}

	public static synchronized void setCheckNumber(long id) {
		ProxyServlet.checkNumber = id;
	}

	protected String processRequest(ProxyRequest request, HttpServletResponse response, String method, boolean cloneResponseForCache) throws ServletException, IOException {

		LOGGER.debug("In proxy servlet");
		
		// ProxyRequest proxyRequest = new ProxyRequest(request);

		// response.setCharacterEncoding("UTF-8");
		// response.addHeader("Content-type",
		// "application/json; charset=utf-8");
		// // never cache responses on the browser
		// response.setDateHeader("Expires", 0);
		// response.setHeader("Cache-Control", "no-cache, no-store");
		PrintWriter responseWriter = response.getWriter();

		if (request.getRequestURI().indexOf(request.getContextPath() + request.getServletPath() + "/") == -1) {
			throw new ServletException(writeMessage("no destination specified"));
		}

		try {
			// Input as json

			JSONObject jsonInput = null;
			LOGGER.debug(request.getParameter("PARAMETERS"));
			
			if ("POST".equals(method)) {

				String input = IOUtils.toString(request.getEntity().getContent(), Charsets.UTF_8);
				if (input != null && input.indexOf("PARAMETERS") != -1) {
					input = input.substring(11); // length of PARAMETERS + 1
				}
				
				input = URLDecoder.decode(input, "UTF-8");
				LOGGER.debug("Input text:");
				LOGGER.debug(input);
				if (input.length() > 1)
				{
					jsonInput = new JSONObject(input);
				}
				
			} else {
				jsonInput = new JSONObject(request.getParameter("PARAMETERS"));
			}
			
			if (jsonInput != null)
			{
				LOGGER.debug(jsonInput.toString());
			}
			
			int contextPathLength = request.getContextPath().length();
			int servletPathLength = request.getServletPath().length();
			
			String pathInfo = request.getRequestURI().substring(contextPathLength + servletPathLength + 1);
			
			LOGGER.debug(pathInfo);
			
			//String destinationName = pathInfo.split("/")[0];
			String functionName = pathInfo.split("/")[1];
			
			try {
				
				// access the RFC Destination via Cloud Connector
				
				// make an invocation of FUNCTION in the back-end
				JCoFunction stfcConnection = repo.getFunction(functionName);
				
				// Set import parameters
				JCoParameterList imports = stfcConnection.getImportParameterList();
				JCoListMetaData importParameters = imports.getListMetaData();
				
				for (int i = 0; i < importParameters.getFieldCount(); i++) {
					
					String paramName = importParameters.getName(i);
					String paramType = importParameters.getTypeAsString(i);
					
					if (paramName.equals("IT_STATUS_FILTER")) { 
						/*
						 * list of status allowed to the user are sent to
						 * backend if the FM has IT_STATUS_FILTER in its signature
						 */
						EntityManager em = PersistenceAdapter.getEntityManager();
						String vkorg = jsonInput.getString("IV_SALESORG");
						List<String> statusAllowed = SearchResource.getAllowedStatusList(em, request.getOriginalRequest(), vkorg);						
						Iterator<String> statusIterator = statusAllowed.iterator();
						String allStatus = "[";
						while (statusIterator.hasNext()) {
							String group = statusIterator.next();
							allStatus += "{\"STATUS_ID\":\"";
							allStatus += group;
							allStatus += "\"}";
							if (statusIterator.hasNext()) {
								allStatus += ",";
							}
						}
						allStatus += "]";
						String statusAsString = "{\"IT_STATUS_FILTER\":" + allStatus + "}";
						JSONObject statusAsJson = new JSONObject(statusAsString);
						fillTable(imports, paramName, statusAsJson, response);
					}
					
					else if (paramName.equals("IT_STATUS_ADMIN")) {
						/*
						 * list of admin status allowed to the user are sent to
						 * backend if the FM has IT_STATUS_ADMIN in its signature
						 */
						EntityManager em = PersistenceAdapter.getEntityManager(); 
						List<String> statusAdmin = SearchResource.getAdminStatusList(em, request.getOriginalRequest());
						
						Iterator<String> statusIterator = statusAdmin.iterator();
						String allStatus = "[";
						while (statusIterator.hasNext()) {
							String group = statusIterator.next();
							allStatus += "{\"STATUS_ID\":\"";
							allStatus += group;
							allStatus += "\"}";
							if (statusIterator.hasNext()) {
								allStatus += ",";
							}
						}
						allStatus += "]";
						String statusAsString = "{\"IT_STATUS_ADMIN\":" + allStatus + "}";
						JSONObject statusAsJson = new JSONObject(statusAsString);
						fillTable(imports, paramName, statusAsJson, response);
					}
					
					else if (jsonInput.has(paramName)) {
						// create table input
						if (paramType.equals("TABLE")) {
							fillTable(imports, paramName, jsonInput, response);
						} else if (paramType.equals("STRUCTURE")) {
							fillStructure(imports, paramName, jsonInput, response);
						} else {
							imports.setValue(paramName, jsonInput.getString(paramName));
						}
					}
				}
				
				// Run the Function module
				stfcConnection.execute(destination);

				// Get results
				JCoParameterList exports = stfcConnection.getExportParameterList();
				JCoListMetaData exportParameters = exports.getListMetaData();

				JCoParameterList tables = stfcConnection.getTableParameterList();
				JCoListMetaData tableParameters = null;
				
				if (tables != null)
				{
					tableParameters = tables.getListMetaData();
				}
				
				JSONObject jsonData = new JSONObject();

				for (int i = 0; i < exportParameters.getFieldCount(); i++) {
					String paramName = exportParameters.getName(i);
					String paramType = exportParameters.getTypeAsString(i);

					// do what you need to do with the field and value
					try {

						// parse table output
						if (paramType.equals("TABLE")) {
							JCoTable jcoTable = exports.getTable(paramName);
							jsonData.put(paramName, JCoHelper.parseTable(jcoTable));

							// parse structure output
						} else if (paramType.equals("STRUCTURE")) {
							JCoStructure jcoStructure = exports.getStructure(paramName);
							jsonData.put(paramName, JCoHelper.parseStructure(jcoStructure));
						} else {
							jsonData.put(paramName, exports.getValue(paramName));
						}
					} catch (JSONException e) {
						e.getCause();
					}
				}
				
				if (tableParameters != null)
				{
					for (int i = 0; i < tableParameters.getFieldCount(); i++) {
						String paramName = tableParameters.getName(i);
						String paramType = tableParameters.getTypeAsString(i);

						// do what you need to do with the field and value
						try {

							// parse table output
							if (paramType.equals("TABLE")) {
								JCoTable jcoTable = tables.getTable(paramName);
								jsonData.put(paramName, JCoHelper.parseTable(jcoTable));

								// parse structure output
							} else if (paramType.equals("STRUCTURE")) {
								JCoStructure jcoStructure = tables.getStructure(paramName);
								jsonData.put(paramName, JCoHelper.parseStructure(jcoStructure));
							} else {
								jsonData.put(paramName, tables.getValue(paramName));
							}
						} catch (JSONException e) {
							e.getCause();
						}
					}
				}
				
				// responseWriter.print(jsonData.toString());
				// LOGGER.debug("Reponse from the Service is: "
				// + jsonData.toString());

				if (cloneResponseForCache) {
					return ProxyUtil.cloneResponse2(jsonData.toString());
				} else {
					return copyBackendResponseToClient2(responseWriter, jsonData.toString());
				}

			} catch (AbapException ae) {

				responseWriter.print(ae.toString());
				LOGGER.debug(ae.toString());
				return ae.toString();

			} catch (JCoException e) {

				responseWriter.print(e.toString());
				LOGGER.debug(e.toString());
				return e.toString();

			} catch (Exception exc) {

				responseWriter.print(exc.toString());
				LOGGER.debug(exc.toString());
				return exc.toString();
			}

		} catch (JSONException e) {
			responseWriter.print("Json failed" + e.toString());
			LOGGER.debug(e.toString());
			return e.toString();
		}
	}

	protected void fillTable(JCoParameterList imports, String tableName, JSONObject jsonRecord, HttpServletResponse response) throws IOException {

		PrintWriter responseWriter = response.getWriter();
		
		JCoTable dataTable = imports.getTable(tableName);
		JSONArray jsonArr;

		try {
			jsonArr = jsonRecord.getJSONArray(tableName);

			for (int j = 0; j < jsonArr.length(); j++) {
				JSONObject obj = jsonArr.getJSONObject(j);
				Iterator<?> myIter = obj.keys();

				dataTable.appendRow();

				while (myIter.hasNext()) {
					String key = (String) myIter.next();

					if (obj.has(key)) {
						String str = new String(obj.getString(key).getBytes("ISO-8859-1"), "UTF-8");
						dataTable.setValue(key, str);
					} else {
						responseWriter.print("Import table doesn't contain: " + key);
					}
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void fillStructure(JCoParameterList imports, String structName, JSONObject jsonRecord, HttpServletResponse response) throws IOException, JSONException {
		
		//PrintWriter responseWriter = response.getWriter();
		JCoStructure inputStructure = imports.getStructure(structName);
		JSONObject jsonObj = jsonRecord.getJSONObject(structName);
		
		JCoFieldIterator it = inputStructure.getFieldIterator();
		
		// set fields of current record
		while (it.hasNextField()) {
			String fieldName = (String) it.nextField().getName();
			
			try {
				inputStructure.setValue(fieldName, new String(jsonObj.getString(fieldName).getBytes("ISO-8859-1"), "UTF-8"));
				
			} catch (Exception e) {
				e.getCause();
			}
		}
	}
}