package com.danone.resources;

import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.CMSCAROUSEL;
import com.danone.entities.CMSCAROUSELPK;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.CMSCarouselWrapper;
import com.danone.util.CarouselWrapper;

@Path("/cmscarousel")
@Produces({ MediaType.APPLICATION_JSON })
public class CMSCarouselResource {
	private final Logger LOGGER = LoggerFactory.getLogger(CMSCarouselResource.class);

	@Context
	private HttpServletRequest servletRequest;

	@GET
	public Response getAllCarousels() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {
			List<CMSCAROUSEL> allDocuments = CMSCAROUSEL.getAllCarousels(em);
			List<CarouselWrapper> allCarousels = new ArrayList<CarouselWrapper>();
			for (CMSCAROUSEL document : allDocuments) {
				CarouselWrapper carousel = new CarouselWrapper();
				carousel.setId(document.getKey().getId());
				carousel.setTitle(document.getTitle());
				carousel.setValidFrom(document.getValidFrom());
				carousel.setValidTo(document.getValidTo());
				carousel.setLanguage(document.getLanguage());
				carousel.setDocumentName(document.getDocumentName());
				carousel.setPictureName(document.getPictureName());
				allCarousels.add(carousel);
			}
			return Response.ok(allCarousels).build();
		} finally {
			em.close();
		}
	}

	@DELETE
	public Response deleteDocument(CMSCAROUSEL item) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;
		LOGGER.debug("deleteDocument id: " + item.getKey().getId().toString());
		
		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}

		boolean error = false;
		try {
			CMSCAROUSEL itemToDelete = CMSCAROUSEL.getCarouselByKey(em, item.getKey());
			if (itemToDelete != null) {
				LOGGER.debug("deleteDocument itemToDelete found, id: " + item.getKey().getId().toString());
				transaction.begin();
				em.remove(itemToDelete);
				transaction.commit();
			}

		} catch (PersistenceException e) {
			LOGGER.error("Failed to delete Webshop document via REST", e);
			error = true;
		} finally {
			if (transaction.isActive()) {
				LOGGER.debug("deleteDocument rollback");
				transaction.rollback();
			}
			LOGGER.debug("deleteDocument close");
			em.close();
		}

		if (error) {
			LOGGER.debug("deleteDocument error");
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
					.entity("An error occurred when deleting one or more resource").build();
		} else {
			LOGGER.debug("deleteDocument ok");
			response = Response.status(HttpURLConnection.HTTP_OK).build();
		}

		return response;
	}

	@Path("activelist")
	@GET
	public Response getActiveCarousels() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		List<CarouselWrapper> carousels = new ArrayList<CarouselWrapper>();
		try {
			String language = "EN";
			java.util.Calendar calendar = java.util.Calendar.getInstance();
			int iyear = calendar.get(java.util.Calendar.YEAR);
			int imonth = calendar.get(java.util.Calendar.MONTH) + 1; // Note:
																		// zero
																		// based!
			int iday = calendar.get(java.util.Calendar.DAY_OF_MONTH);
			String yyyy = Integer.toString(iyear);
			String mm = Integer.toString(imonth);
			String dd = Integer.toString(iday);
			String strDate = yyyy + (imonth < 10 ? "0" + mm : mm) + (iday < 10 ? "0" + dd : dd);
			Integer intDate = Integer.parseInt(strDate);
			List<Object[]> allActives = CMSCAROUSEL.getActives(em, language, intDate);
			for (Object[] carousel : allActives) {
				Integer carId = (Integer) carousel[0];
				CarouselWrapper car = new CarouselWrapper();
				car.setId(carId);
				car.setTitle((String) carousel[1]);
				car.setPictureUrl("/ImageRenderer?webshopImage=true&id=" + String.valueOf(carId));
				car.setDocumentUrl("/PdfRenderer?webshopDoc=true&id=" + String.valueOf(carId));
				carousels.add(car);
			}
			ResponseBuilder respBuilder = Response.ok(carousels);
			respBuilder.encoding("utf-8");
			return respBuilder.build();
		} finally {
			em.close();
		}
	}

	@Path("multipledelete")
	@PUT
	public Response deleteDocuments(List<CMSCarouselWrapper> list) {
		LOGGER.debug("multipledelete start");
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = null;
		Response response;

		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}
		 
		if (list != null) {
			LOGGER.debug("multipledelete list size: " + list.size());
		} else {
			LOGGER.debug("Multipledelete list has size 0");
		}

		boolean error = false;
		for (CMSCarouselWrapper item : list) {
			CMSCAROUSELPK keyToDelete = new CMSCAROUSELPK(Integer.valueOf(item.getId()));

			LOGGER.debug("multipledelete id: " + item.getId());
			try {
				transaction = em.getTransaction();
				CMSCAROUSEL itemToDelete = CMSCAROUSEL.getCarouselByKey(em, keyToDelete);
				if (itemToDelete != null) {
					LOGGER.debug("multipledelete itemToDelete found, id: " + item.getId());
					transaction.begin();
					em.remove(itemToDelete);
					transaction.commit();
				} else {
					LOGGER.debug("multipledelete itemToDelete not found");
					error = true;
				}

			} catch (PersistenceException e) {
				LOGGER.error("Failed to delete Webshop document via REST", e);
				error = true;
			} finally {
				if (transaction != null && transaction.isActive()) {
					LOGGER.debug("multipledelete rollback");
					transaction.rollback();
				}

			}
		}
		LOGGER.debug("multipledelete close");
		em.close();
		if (error) {
			LOGGER.debug("multipledelete error");
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
					.entity("An error occurred when deleting one or more resource").build();
		} else {
			LOGGER.debug("multipledelete ok");
			response = Response.status(HttpURLConnection.HTTP_OK).build();
		}

		return response;
	}

	// @Path("multipledelete")
	// @DELETE
	// public Response deleteDocuments(List<CMSCAROUSEL> list) {
	// logger.debug("multipledelete start");
	// EntityManager em = PersistenceAdapter.getEntityManager();
	// EntityTransaction transaction = null;
	// Response response;
	//
	// /*
	// if (!servletRequest.isUserInRole(Roles.ADMIN)) {
	// response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You
	// do not have the right to do so")
	// .build();
	// return response;
	// }
	// */
	// logger.debug("multipledelete list size: " + list.size());
	// Iterator<CMSCAROUSEL> it = list.iterator();
	// CMSCAROUSEL item;
	// boolean error = false;
	// while (it.hasNext()) {
	// item = it.next();
	// logger.debug("multipledelete id: " + item.getKey().getId().toString());
	// try {
	// transaction = em.getTransaction();
	// CMSCAROUSEL itemToDelete = CMSCAROUSEL.getCarouselByKey(em,
	// item.getKey());
	// if (itemToDelete != null) {
	// logger.debug("multipledelete itemToDelete found, id: " +
	// item.getKey().getId().toString());
	// transaction.begin();
	// em.remove(itemToDelete);
	// transaction.commit();
	// } else {
	// logger.debug("multipledelete itemToDelete not found");
	// error = true;
	// }
	//
	// } catch (PersistenceException e) {
	// logger.error("Failed to delete Webshop document via REST", e);
	// error = true;
	// } finally {
	// if (transaction != null && transaction.isActive()) {
	// logger.debug("multipledelete rollback");
	// transaction.rollback();
	// }
	//
	// }
	// }
	// logger.debug("multipledelete close");
	// em.close();
	// if (error) {
	// logger.debug("multipledelete error");
	// response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
	// .entity("An error occurred when deleting one or more resource").build();
	// } else {
	// logger.debug("multipledelete ok");
	// response = Response.status(HttpURLConnection.HTTP_OK).build();
	// }
	//
	// return response;
	// }

	@Path("single")
	@POST
	public Response createDocument(CMSCAROUSEL webshopDocument) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}

		try {
			CMSCAROUSEL exists = CMSCAROUSEL.getCarouselByKey(em, webshopDocument.getKey());
			if (exists != null) {
				LOGGER.error("The entry exists already");
				response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("The entry exists already")
						.build();
				return response;
			}

			transaction.begin();
			em.persist(webshopDocument);
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to create document via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		response = Response.created(UriBuilder.fromPath("/webshopdocument/{id}").build(webshopDocument.getKey()))
				.entity(webshopDocument).build();
		return response;
	}

	@Path("multiple")
	@POST
	public Response createDocuments(List<CMSCAROUSEL> list) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = null;
		Response response;

		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}

		Iterator<CMSCAROUSEL> it = list.iterator();
		CMSCAROUSEL item;
		LOGGER.debug("Before getMaxCarousel ");
		Integer nextId = CMSCAROUSEL.getMaxCarouselId(em);
		LOGGER.debug("After getMaxCarousel " + nextId);
		if (nextId != null) {
			nextId++;
		} else {
			nextId = 1;
		}
		LOGGER.debug("After getMaxCarousel 2: " + nextId);
		// Integer nextId = 1;
		boolean error = false;
		while (it.hasNext()) {
			try {
				transaction = em.getTransaction();
				item = it.next();
				transaction.begin();
				LOGGER.debug("Before check exists: " + item.toString());
				if (item.getKey().getId() == -1) {
					LOGGER.debug("Before carouselpk: " + nextId);
					CMSCAROUSELPK ckey = new CMSCAROUSELPK();
					LOGGER.debug("After carouselpk: " + nextId);
					ckey.setId(nextId);
					LOGGER.debug("Before set key: " + nextId);
					item.setKey(ckey);
					LOGGER.debug("Before persist: " + item.toString());
					em.persist(item);
					LOGGER.debug("Before commit: " + item.toString());
					transaction.commit();
					LOGGER.debug("Before nextId: " + nextId);
					nextId++;
					LOGGER.debug("After nextId: " + nextId);
				} else {
					LOGGER.debug("Before get by key: " + item.getKey());
					CMSCAROUSEL exists = CMSCAROUSEL.getCarouselByKey(em, item.getKey());
					LOGGER.debug("After get by key: " + exists);
					if (exists != null) {
						// the entry exists, let's update it
						exists.setPicture(item.getPicture());
						transaction.commit();
					} else {
						// CMSCAROUSELPK ckey = new CMSCAROUSELPK(nextId);
						// item.setKey(ckey);
						em.persist(item);
						transaction.commit();
						nextId++;
					}

				}
			} catch (PersistenceException e) {
				LOGGER.error("Failed to create or update document via REST", e);
				error = true;
			} finally {
				if (transaction != null && transaction.isActive()) {
					transaction.rollback();
				}

			}
		}

		em.close();
		if (error) {
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
					.entity("An error occurred when saving one or more entries").build();
		} else {
			response = Response.status(HttpURLConnection.HTTP_CREATED).build();
		}

		return response;
	}

}
