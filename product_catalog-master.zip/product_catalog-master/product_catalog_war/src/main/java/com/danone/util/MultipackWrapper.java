package com.danone.util;

import java.util.List;

public class MultipackWrapper {
	
	//MAKT
	private String description;
	//ZPRODCAT_HDR
	private String cat_guid;
	private String matnr;
	private String ean_upc_base;
	//ZPRODCAT_ITEM
	private java.sql.Date validity_base;
	
	//PRICAT_K006
	private String code_labelling;
	private String code_output;
	private String lsf;
	private String label_status;
	private String artemis_sku;
	
	//PRICAT_K007
	private Integer quantity_subline;
	
	//NUTBOARD
	private List<NutboardWrapper> nutboard;
	
	private String currentStatus;
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getEan_upc_base() {
		return ean_upc_base;
	}

	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}

	public String getCode_labelling() {
		return code_labelling;
	}

	public void setCode_labelling(String code_labelling) {
		this.code_labelling = code_labelling;
	}

	public String getLsf() {
		return lsf;
	}

	public void setLsf(String lsf) {
		this.lsf = lsf;
	}

	public String getLabel_status() {
		return label_status;
	}

	public void setLabel_status(String label_status) {
		this.label_status = label_status;
	}

	public String getCode_output() {
		return code_output;
	}

	public void setCode_output(String code_output) {
		this.code_output = code_output;
	}

	public java.sql.Date getValidity_base() {
		return validity_base;
	}

	public void setValidity_base(java.sql.Date validity_base) {
		this.validity_base = validity_base;
	}

	public Integer getQuantity_subline() {
		return quantity_subline;
	}

	public void setQuantity_subline(Integer quantity_subline) {
		this.quantity_subline = quantity_subline;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getCat_guid() {
		return cat_guid;
	}

	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}

	public List<NutboardWrapper> getNutboard() {
		return nutboard;
	}

	public void setNutboard(List<NutboardWrapper> nutboard) {
		this.nutboard = nutboard;
	}

	public String getArtemis_sku() {
		return artemis_sku;
	}

	public void setArtemis_sku(String artemis_sku) {
		this.artemis_sku = artemis_sku;
	}
	
}
