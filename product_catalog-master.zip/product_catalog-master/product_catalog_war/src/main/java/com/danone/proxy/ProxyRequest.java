package com.danone.proxy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProxyRequest {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProxyRequest.class);

	private String completeRequestURI;
	private String requestURI;
	private String contextPath;
	private String servletPath;
	private String queryString;
	private String method;
	private Map<String, String> headers;
	private HttpEntity entity;
	private HttpServletRequest request; 

	public ProxyRequest(HttpServletRequest request) throws IOException {
		String completeRequestURI = request.getRequestURI();
		if (request.getQueryString() != null) {
			completeRequestURI += "?" + request.getQueryString();
		}
		this.completeRequestURI = completeRequestURI;

		this.requestURI = request.getRequestURI();
		this.contextPath = request.getContextPath();
		this.servletPath = request.getServletPath();
		this.queryString = request.getQueryString();
		this.method = request.getMethod();
		this.headers = copyAllHeaders(request);
		this.entity = copyRequestPayload(request);
		this.request = request;

	}

	public String getParameter(String parameter) {
		return request.getParameter(parameter);

	}

	private HttpEntity copyRequestPayload(HttpServletRequest request)
			throws IOException {
		if (method.equals("POST") || method.equals("PUT")) {
			LOGGER.debug("Copy request payload for ");
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			if (request.getInputStream() != null) {
				ProxyServlet.pipe(request.getInputStream(), out);
				ByteArrayEntity entity = new ByteArrayEntity(out.toByteArray());
				entity.setContentType(request.getHeader("Content-Type"));
				return entity;
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	private Map<String, String> copyAllHeaders(HttpServletRequest request) {
		Map<String, String> returnMap = new HashMap<String, String>();
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String headerName = headerNames.nextElement();
			String headerValue = request.getHeader(headerName);
			returnMap.put(headerName.toLowerCase(), headerValue);
			LOGGER.debug("Header name " + headerName + " has value = "
					+ headerValue);
		}
		return returnMap;
	}

	public String getCompleteRequestURI() {
		return completeRequestURI;
	}

	public String getRequestURI() {
		return this.requestURI;
	}

	public String getContextPath() {
		return this.contextPath;
	}

	public String getServletPath() {
		return this.servletPath;
	}

	public String getQueryString() {
		return this.queryString;
	}

	public String getMethod() {
		return this.method;
	}

	public Map<String, String> getHeaders() {
		return this.headers;
	}

	public String getHeader(String name) {
		return this.headers.get(name);
	}

	public HttpEntity getEntity() {
		return this.entity;
	}
	public HttpServletRequest getOriginalRequest() {
		return this.request;
	}

}
