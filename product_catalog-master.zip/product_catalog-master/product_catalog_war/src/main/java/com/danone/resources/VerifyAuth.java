package com.danone.resources;

import java.net.HttpURLConnection;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

@Path("/verifyauth")
public class VerifyAuth {
	
	@Context
	private HttpServletRequest servletRequest;
	
	@GET
	public Response getAuthorization() {
		
		if (!servletRequest.isUserInRole(Roles.EUPRODTRANSFERPRICE)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}else {
			return Response.status(HttpURLConnection.HTTP_OK).build();
		}
	}
}
