package com.danone.resources;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.AUTHORIZATION;
import com.danone.entities.MAKT;
import com.danone.entities.MAKTPK;
import com.danone.entities.MVKE;
import com.danone.entities.MVKEPK;
import com.danone.entities.PICTURES;
import com.danone.entities.PICTURESPK;
import com.danone.entities.PRICAT_K005;
import com.danone.entities.PRICAT_K006;
import com.danone.entities.PRICAT_K010_ZPRO_VPRICAT_S;
import com.danone.entities.PRICAT_K010_ZPRO_VPRICAT_SPK;
import com.danone.entities.ZPRODCAT_HDR;
import com.danone.entities.ZPRODCAT_ITEM;
import com.danone.entities.ZPRO_ASSORTMENT;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.ProductDetailWrapper;
import com.danone.util.ProductWrapper;
import com.google.gson.Gson;

public class SearchResource extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1678866505075219877L;
	private final static Logger LOGGER = LoggerFactory.getLogger(SearchResource.class);
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
		Enumeration<String> enumer = request.getParameterNames();
		JSONObject params = null;
		if (enumer.hasMoreElements())
		{
			String jsonString = enumer.nextElement();
			LOGGER.debug("JSON String: " + jsonString);
			params = new JSONObject(jsonString);
		}
		
		response.setCharacterEncoding("UTF-8");
		response.addHeader("Content-type", "application/json; charset=utf-8");
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-cache, no-store");
		PrintWriter responseWriter = response.getWriter();
		
		String jsonObjString = null;
		JSONObject jsonObj = null;
		if (params != null)
		{
			jsonObjString = params.getString("SEARCHSTR");
		}
		
		LOGGER.debug("JSONObjString: " + jsonObjString);
		
		if (jsonObjString != null)
		{
			jsonObj = new JSONObject(jsonObjString);
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		
		/*
		Boolean allowed = filterAuthorizations(jsonObj, request);
		if (!allowed)
		{
			response.setStatus(HttpURLConnection.HTTP_FORBIDDEN);
			responseWriter.write("You do not have the required authorizations");
			return;
		}
		*/
		
		try {
			
			List<ProductWrapper> fullProductList = new ArrayList<ProductWrapper>();
			List<ZPRO_ASSORTMENT> assortList;
			
			//Get all possible assort entrees
			if (jsonObj.has("VTWEG"))
			{
				assortList = new ArrayList<ZPRO_ASSORTMENT>();
				JSONArray ar = jsonObj.getJSONArray("VTWEG");
				
				for (int i = 0; i < ar.length(); i++)
				{
					List<ZPRO_ASSORTMENT> assortListTemp = ZPRO_ASSORTMENT.getZPRO_ASSORTMENTByVkorg(em, jsonObj.get("VKORG").toString());
					ZPRO_ASSORTMENT assort = null;
					
					for (ZPRO_ASSORTMENT zproassort : assortListTemp)
					{
						if (zproassort.getKey().getVtweg().equalsIgnoreCase(ar.getString(i)))
						{
							assort = zproassort;
							break;
						}
					}
					
					if (assort != null)
					{
						assortList.add(assort);
					}
				}
				
			}else {
				assortList = ZPRO_ASSORTMENT.getZPRO_ASSORTMENTByVkorg(em, jsonObj.getString("VKORG"));
			}
			
			if (assortList.size() == 0)
			{
				responseWriter.print(new Gson().toJson(fullProductList));
				return;
			}
			
			List<ZPRODCAT_HDR> productList;
			List<ZPRODCAT_HDR> archivedList = new ArrayList<ZPRODCAT_HDR>();
			List<ZPRODCAT_HDR> deleteList = new ArrayList<ZPRODCAT_HDR>();
			
			Query query = buildQuery(em, jsonObj, assortList);
			
			productList = ZPRODCAT_HDR.getAllProductsWithQuery(em, query);
			
			//Filter out based on search parameters which are not query'able + status authorization
			productList = filterOut(em, jsonObj, productList, request);
			
			//Filter out unwanted archived values (only last archived value is needed)
			for (ZPRODCAT_HDR prod : productList)
			{
				//Check for archived
				if (prod.getStatus().equalsIgnoreCase("8"))
				{
					Boolean add = true;
					List<ZPRODCAT_HDR> delArchList = new ArrayList<ZPRODCAT_HDR>();
					
					for (ZPRODCAT_HDR arch : archivedList)
					{
						if (arch.getMatnr().equalsIgnoreCase(prod.getMatnr()) 
								&& arch.getEan_upc_base().equalsIgnoreCase(prod.getEan_upc_base())
								&& arch.getAsort().equalsIgnoreCase(prod.getAsort())
								&& arch.getVkorg().equalsIgnoreCase(prod.getVkorg())
								&& arch.getVtweg().equalsIgnoreCase(prod.getVtweg())
								&& arch.getProductgroup().equalsIgnoreCase(prod.getProductgroup()))
						{
							//Same
							if (arch.getAedat().after(prod.getAedat()))
							{
								//Keep arch, delete prod
								add = false;
								deleteList.add(prod);
							}else {
								//Keep prod, delete arch
								deleteList.add(arch);
								delArchList.add(arch);
							}
							
							break;
						}
					}
					
					for (ZPRODCAT_HDR del : delArchList)
					{
						archivedList.remove(del);
					}
					
					if (add)
					{
						archivedList.add(prod);
					}
				}
			}
			
			for (ZPRODCAT_HDR del : deleteList)
			{
				productList.remove(del);
			}
			
			// Get list of status the user can manage
			List<String> statusAdmin = getAdminStatusList(em, request);
			
			// Process products query list 
			Iterator<ZPRODCAT_HDR> iterator = productList.iterator();
			
			while (iterator.hasNext()) {
				ZPRODCAT_HDR product = iterator.next();
				ProductWrapper fullProduct = new ProductWrapper();
				
				//Set Dummy's
				fullProduct.setExportexcel(false);
								
				//Set authorizations
				fullProduct.setStatus_allowed(false);
				if (statusAdmin.contains(product.getStatus()))
				{
					fullProduct.setStatus_allowed(true);
				}
				
				//Set ZPRODCAT_HDR data
				fullProduct.setSystem(product.getKey().getSystem());
				fullProduct.setMandt(product.getKey().getMandt());
				fullProduct.setCat_guid(product.getKey().getCat_guid());
				fullProduct.setFullmatnr(product.getMatnr());
				fullProduct.setMatnr(product.getMatnr().replaceFirst("^0+(?!$)", ""));
				fullProduct.setStatus(product.getStatus());
				fullProduct.setVerno(product.getVerno());
				fullProduct.setVkorg(product.getVkorg());
				fullProduct.setVtweg(product.getVtweg());
				fullProduct.setEan_upc_base(product.getEan_upc_base());
				fullProduct.setPrinbr(product.getPrinbr());
				fullProduct.setProductgroup(product.getProductgroup());
				
				//Fetch ZPRODCAT_ITEM
				ZPRODCAT_ITEM itemEntry = ZPRODCAT_ITEM.getItemByGuidAndPostyp(em, product.getKey().getSystem(), product.getKey().getCat_guid(), "P");
				if (itemEntry != null)
				{
					fullProduct.setValidity_base(itemEntry.getValidity_base());
				}
				
				//Fetch and set MAKT data
				MAKTPK maktpk = new MAKTPK(product.getKey().getSystem(), product.getKey().getMandt(), product.getMatnr(), "E");
				MAKT maktentry = MAKT.getMAKTByKey(em, maktpk);
				if (maktentry != null)
				{
					fullProduct.setMaktx(maktentry.getMaktx());
				}
				
				//Fetch and set MVKE data
				MVKEPK mvkepk = new MVKEPK(product.getKey().getSystem(), product.getKey().getMandt(), product.getMatnr(), product.getVkorg(), product.getVtweg());
				MVKE mvkeentry = MVKE.getMVKEByKey(em, mvkepk);
				if (mvkeentry != null)
				{
					fullProduct.setMvgr1(mvkeentry.getMvgr1());
//					fullProduct.setZzlaunchdate(mvkeentry.getZzlaunchdate());
				}
				
				// Fetch and set PRICAT_K005 data (Texts)
				String language = jsonObj.getString("LANG");
				String texttypes[] = { "FS" };
				List<PRICAT_K005> listK005 = PRICAT_K005.getK005With(em,
						product.getKey().getSystem(),
						product.getKey().getMandt(), 
						product.getPrinbr(), 
						product.getProductgroup(),
						product.getEan_upc_base(),
						itemEntry.getValidity_base(),
						language,
						texttypes);

				for (PRICAT_K005 element : listK005) {
					if (element.getKey().getTexttyp() != null && element.getText_line() != null) {
						if (element.getKey().getTexttyp().equalsIgnoreCase("FS")) {
							try {
								if (fullProduct.getStddescription() == null) {
									fullProduct.setStddescription(element.getText_line());
								} else {
									fullProduct.setStddescription(fullProduct.getStddescription() + element.getText_line());
								}
							} catch (Exception e) {
								fullProduct.setStddescription("");
							}
						} 
					}
				}
				
				//Fetch and set PRICAT_K006 data
				ArrayList<String> characteristics = new ArrayList<String>();
				characteristics.add("LABELLING_CODE");
				characteristics.add("ARTEMISCODE");
				characteristics.add("PACKPRINT_LABCODE");
				characteristics.add("LABEL_STATUS");
				List<PRICAT_K006> list = PRICAT_K006.getK006With(em, 
																product.getKey().getSystem(),
																product.getKey().getMandt(), 
																product.getPrinbr(), 
																product.getProductgroup(),
																product.getEan_upc_base(),
																itemEntry.getValidity_base(), 
																characteristics);
				
				for (PRICAT_K006 element : list) {
				    
					if (element.getKey().getCharacteristic().equalsIgnoreCase("LABELLING_CODE"))
					{
						fullProduct.setCode_labelling(element.getKey().getDescription());
					}else if (element.getKey().getCharacteristic().equalsIgnoreCase("ARTEMISCODE"))
					{
						fullProduct.setCode_output(element.getKey().getDescription());
					}else if (element.getKey().getCharacteristic().equalsIgnoreCase("PACKPRINT_LABCODE"))
					{
						fullProduct.setLsf(element.getKey().getDescription());
					}else if (element.getKey().getCharacteristic().equalsIgnoreCase("LABEL_STATUS"))
					{
						fullProduct.setLabel_status(element.getKey().getDescription());
					}
				}
				
				//Fetch and set PRICAT_K010_ZPRO_VPRICAT_S data
				PRICAT_K010_ZPRO_VPRICAT_SPK pricat_k010_zpro_vpricat_spk = new PRICAT_K010_ZPRO_VPRICAT_SPK(product.getKey().getSystem(), product.getKey().getMandt(), 
						product.getPrinbr(), 
						product.getProductgroup(),
						product.getEan_upc_base(),
						itemEntry.getValidity_base());
				PRICAT_K010_ZPRO_VPRICAT_S pricat_k010_zpro_vpricat_sentry = PRICAT_K010_ZPRO_VPRICAT_S.getPRICAT_K010_ZPRO_VPRICAT_SByKey(em, pricat_k010_zpro_vpricat_spk);
				if (pricat_k010_zpro_vpricat_sentry != null)
				{
					fullProduct.setZzpaccod(pricat_k010_zpro_vpricat_sentry.getZzpaccod());
					fullProduct.setVmsta(pricat_k010_zpro_vpricat_sentry.getVmsta());
					fullProduct.setZzlaunchdate(pricat_k010_zpro_vpricat_sentry.getZzlaunchdate());
				}
				
				
				//Fetch picture info
				LOGGER.debug("Before ZPRODCAT_ITEM.getItemsByType");
				List<ZPRODCAT_ITEM> listItems = ZPRODCAT_ITEM.getItemsByType(em, product.getKey().getSystem(), product.getKey().getMandt(), product.getKey().getCat_guid(), "D");				
				LOGGER.debug("After ZPRODCAT_ITEM.getItemsByType : " + listItems.size());
				for (ZPRODCAT_ITEM itemDoc : listItems)					
				{
					if (itemDoc.getThumbnail_ind() != null)
					{
						LOGGER.debug("ItemDocThumbnail Ind : " + itemDoc.getThumbnail_ind().toString());
						if (itemDoc.getThumbnail_ind())
						{
							LOGGER.debug("Before PICTURESPK prepare");
							String dokar = itemDoc.getDokar();				
							String doknr = itemDoc.getDoknr();				
							String dokvr = itemDoc.getDokvr();				
							String doktl = itemDoc.getDoktl();				
							PICTURESPK picturespk = new PICTURESPK(product.getKey().getSystem(), product.getKey().getMandt(), dokar, doknr, dokvr, doktl);			
							PICTURES picturesentry = PICTURES.getPICTURESByKey(em, picturespk);
							if (picturesentry != null)
							{
								LOGGER.debug("picturesentry");
								fullProduct.setThumbnailUrl("/main/ImageRenderer?DmsDocument=true&documentId=" 
										+ picturesentry.getThumbnail_id());
							}
						}	
					}
				}
				
				//Add full product to list
				fullProductList.add(fullProduct);
			}
			
			responseWriter.print(new Gson().toJson(fullProductList));
			return;
		} catch (Exception e)
		{
			LOGGER.debug("Error getting products by search: " + e.toString());
		} finally {
			em.close();
		}
		
		responseWriter.print(new Gson().toJson(Collections.EMPTY_LIST));
		return;
	}
	
	public Boolean filterAuthorizations(JSONObject jsonObj, HttpServletRequest servletRequest)
	{
//		//Check CBU authorization
//		String vkorg = jsonObj.get("VKORG").toString().trim();
//		String rolename = "Prometheus_CBU_" + vkorg;
//		if (!servletRequest.isUserInRole(rolename)) {
//			return false;
//		}
//		
//		if (jsonObj.has("STATUS"))
//		{
//			String status = jsonObj.get("STATUS").toString();
//			
//			EntityManager em = PersistenceAdapter.getEntityManager();
//			List<String> adminReq = AUTHORIZATION.getAuthorizationRequiredByVkorgInNumberStringFormat(em, vkorg);
//			//If status is in adminReq, then admin is required
//			if (adminReq.contains(status))
//			{
//				//Must be admin to view this status
//				if (!servletRequest.isUserInRole("Prometheus_Admin")) {
//					return false;
//				}
//			}
//		}
//		
		return true;
	}
	
	public List<ZPRODCAT_HDR> filterOut(EntityManager em, JSONObject jsonObj, List<ZPRODCAT_HDR> prodlist, HttpServletRequest servletRequest)
	{
	
//		if (!servletRequest.isUserInRole("Prometheus_Admin")) {
//			//User is not admin
//			
//			List<ZPRODCAT_HDR> deleteList = new ArrayList<ZPRODCAT_HDR>();
//			List<String> adminReq = AUTHORIZATION.getAuthorizationRequiredByVkorgInNumberStringFormat(em, jsonObj.get("VKORG").toString().trim());
//			
//			for (ZPRODCAT_HDR hdr : prodlist)
//			{
//				if (adminReq.contains(hdr.getStatus()))
//				{
//					deleteList.add(hdr);
//				}
//			}
//			
//			for (ZPRODCAT_HDR hdrDel : deleteList)
//			{
//				prodlist.remove(hdrDel);
//			}
//		}
		
		// Authority check on statuses
		List<String> statusAllowed = getAllowedStatusList(em, servletRequest, jsonObj.get("VKORG").toString());
		List<ZPRODCAT_HDR> deleteListAuth = new ArrayList<ZPRODCAT_HDR>();
		for (ZPRODCAT_HDR catHdr : prodlist)
		{
			if (!statusAllowed.contains(catHdr.getStatus()))
			{
				deleteListAuth.add(catHdr);
			}
		}

		for (ZPRODCAT_HDR hdrDelAuth : deleteListAuth)
		{
			prodlist.remove(hdrDelAuth);
		}

		
		if (jsonObj.has("ECATDESCR") || jsonObj.has("COMDESCR") || jsonObj.has("ALLERGENSNO") || jsonObj.has("ALLERGENSYES"))
		{
			List<ZPRODCAT_HDR> deleteList = new ArrayList<ZPRODCAT_HDR>();
			
			for (ZPRODCAT_HDR hdr : prodlist)
			{
				ProductDetailResource prodRes = new ProductDetailResource();
				String plant = jsonObj.get("PLANT").toString();
				String langu = jsonObj.getString("LANG");
				String ecatd = jsonObj.get("ECATD").toString();
				ZPRODCAT_ITEM item = ZPRODCAT_ITEM.getItemByGuidAndPostyp(em, hdr.getKey().getSystem(), hdr.getKey().getCat_guid(), "P");
				
				if (item != null)
				{
					Boolean excel = false;
					ProductDetailWrapper prodDetail = prodRes.getDetails(hdr.getKey().getSystem(), hdr.getKey().getMandt(),
							hdr.getKey().getCat_guid(), hdr.getMatnr(), hdr.getVkorg(), hdr.getVtweg(), hdr.getPrinbr(),
							hdr.getProductgroup(), hdr.getEan_upc_base(), item.getValidity_base(), langu, plant, ecatd, excel);
					Boolean delete = false;
					
					if (jsonObj.has("ECATDESCR"))
					{
						String compareValue = jsonObj.getString("ECATDESCR");
						
						if (prodDetail.getEcatdescription() != null)
						{
							if (!prodDetail.getEcatdescription().toLowerCase().contains(compareValue.toLowerCase()))
							{
								delete = true;
							}
						}else {
							delete = true;
						}
					}
					
					if (jsonObj.has("COMDESCR") && !delete)
					{
						String compareValue = jsonObj.getString("COMDESCR");
						
						if (prodDetail.getCommercialDescription() != null)
						{
							if (!prodDetail.getCommercialDescription().toLowerCase().contains(compareValue.toLowerCase()))
							{
								delete = true;
							}
						}else {
							delete = true;
						}
					}
					
					if (jsonObj.has("ALLERGENSYES") && !delete)
					{
						JSONArray ar = jsonObj.getJSONArray("ALLERGENSYES");
						ArrayList<String> characs = new ArrayList<String>();
						characs.add("CONTAIN");
						characs.add("MAY_CONTAIN");
						
						List<PRICAT_K006> list = PRICAT_K006.getK006With(em, hdr.getKey().getSystem(), hdr.getKey().getMandt(), hdr.getPrinbr(), hdr.getProductgroup(), hdr.getEan_upc_base(), item.getValidity_base(), characs);
						
						for (int i = 0; i < ar.length(); i++)
						{
							Boolean found = false;
							
							for (PRICAT_K006 six : list)
							{
								if (ar.getString(i).equalsIgnoreCase(six.getKey().getDescription()))
								{
									found = true;
									break;
								}
							}
							
							if (!found)
							{
								delete = true;
								break;
							}
						}
					}
					
					if (jsonObj.has("ALLERGENSNO") && !delete)
					{
						JSONArray ar = jsonObj.getJSONArray("ALLERGENSNO");
						ArrayList<String> characs = new ArrayList<String>();
						characs.add("CONTAIN");
						characs.add("MAY_CONTAIN");
						
						List<PRICAT_K006> list = PRICAT_K006.getK006With(em, hdr.getKey().getSystem(), hdr.getKey().getMandt(), hdr.getPrinbr(), hdr.getProductgroup(), hdr.getEan_upc_base(), item.getValidity_base(), characs);
						
						mainLoop:
						for (PRICAT_K006 six : list)
						{
							for (int i = 0; i < ar.length(); i++)
							{
								if (ar.getString(i).equalsIgnoreCase(six.getKey().getDescription()))
								{
									delete = true;
									break mainLoop;
								}
							}
						}
					}
					
					if (delete)
					{
						deleteList.add(hdr);
					}
				}else {
					LOGGER.debug("Error, no item for HDR entry in filterOut method");
				}
			}
			
			for (ZPRODCAT_HDR hdrDel : deleteList)
			{
				prodlist.remove(hdrDel);
			}
		}
		
		return prodlist;
	}
	
	public static List<String> getAllowedStatusList(EntityManager em, HttpServletRequest servletRequest, String vkorg)
	{
		// Initialize the allowed status list with the statuses not protected
		List<String> statusList = new ArrayList<String>();
/*		// Published Distributor
		statusList.add("4");*/
		// Published Consumer
		statusList.add("5");
/*		// Archived
		statusList.add("8");*/
		 
		String userSalesorg = new String();
		try {
			userSalesorg = servletRequest.getSession().getAttribute("Usersalesorg").toString();
		} catch (Exception e) {
			userSalesorg = "";
		}		

		Boolean samesorg = false;
		if (userSalesorg .equals(vkorg) )
		{ samesorg = true; }

		if ( samesorg || servletRequest.isUserInRole(Roles.ALLCBU)) {

			// Get all roles defined
			List<AUTHORIZATION> roleList = new ArrayList<AUTHORIZATION>();
			roleList = AUTHORIZATION.getAllAuthorizations(em);

			LOGGER.debug("getAllowedStatusList - roleList size " + roleList.size());

			// Add the status depending on the roles assignment
			for (AUTHORIZATION role : roleList)
			{
				if (servletRequest.isUserInRole(role.getRole())) {
					List<String> statusRoleList = AUTHORIZATION.getAuthorizationRequiredByRoleInNumberStringFormat(em, role.getRole());
					for (String status : statusRoleList){
						if (!statusList.contains(status))
							statusList.add(status);
					}
				}
			}
		}

		LOGGER.debug("getAllowedStatusList - statusList size " + statusList.size());
		return statusList;
	}
	
    public static List<String> getAdminStatusList(EntityManager em, HttpServletRequest servletRequest)
	{
		// Get all admin roles defined
		List<AUTHORIZATION> roleList = new ArrayList<AUTHORIZATION>();
		roleList = AUTHORIZATION.getAllAdminRoles(em);
		
		LOGGER.debug("getAdminStatusList - roleList size" + roleList.size());

		// Initialize the allowed status list with the statuses not protected
		List<String> statusList = new ArrayList<String>();

		// Add the status depending on the roles assignment
		for (AUTHORIZATION role : roleList)
		{
			if (servletRequest.isUserInRole(role.getRole())) {
				List<String> statusRoleList = AUTHORIZATION.getAuthorizationRequiredByRoleInNumberStringFormat(em, role.getRole());
				for (String status : statusRoleList){
					if (!statusList.contains(status))
						statusList.add(status);
				}
			}
		}
		LOGGER.debug("getAdminStatusList - statusList size" + statusList.size());
		return statusList;
	}
	
	public Query buildQuery(EntityManager em, JSONObject jsonObj, List<ZPRO_ASSORTMENT> assortList) throws JSONException, ParseException {
		Query query;
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		
		String queryString = "SELECT distinct p FROM ZPRODCAT_HDR p, ZPRODCAT_ITEM i ";
		
		if (jsonObj.has("ZOVERLAY") || jsonObj.has("ZZPROCESS1") || jsonObj.has("ZZPROCESS2") || jsonObj.has("ZZCAPACITY"))
		{
			queryString = queryString + ", MARA m ";
		}
		
		if (jsonObj.has("VMSTA") || jsonObj.has("MVGR1") || jsonObj.has("ZZLAUNCHDATEFROM") || jsonObj.has("PRODHIER"))
		{
			queryString = queryString + ", MVKE v ";
		}
		
		if (jsonObj.has("LABELLING_CODE") 
				|| jsonObj.has("ARTEMISCODE")
				|| jsonObj.has("LSF")
				|| jsonObj.has("FR8_PROJECT_CODE")
				|| jsonObj.has("ALLERGENSYES")
				|| jsonObj.has("CONSUMPTIONAGE"))
		{
			queryString = queryString + ", PRICAT_K006 k ";
		}
		
		if (jsonObj.has("NTGEW_WEIGHT") )
		{
			queryString = queryString + ", PRICAT_K004 b ";
		}
		
		if (jsonObj.has("DESCRIPTION"))
		{
			queryString = queryString + ", MAKT t ";
		}
		
		if (jsonObj.has("INGREDIENT") )
		{
			queryString = queryString + ", PRICAT_K005 c ";
		}
		
		if (jsonObj.has("CODEPACKAGING"))
		{
			queryString = queryString + ", PRICAT_K010_ZPRO_VPRICAT_S d ";
		}
		
		if (jsonObj.length() > 0)
		{
			queryString = queryString + "WHERE p.key.cat_guid = i.key.cat_guid ";
		}
		
		int count = 0;
		queryString = queryString + "and ( ";
		for (ZPRO_ASSORTMENT as : assortList)
		{
			if (count > 0)
			{
				queryString = queryString + "OR ";
			}
			queryString = queryString + "( p.asort = :assortassort" + count + " and p.prinbr = :assortprinbr" + count + " ) ";
			count++;
		}
		queryString = queryString + ") ";
		
		if (jsonObj.has("NTGEW_WEIGHT") )
		{
			queryString = queryString + "and b.key.prinbr = p.prinbr and b.key.productgroup = p.productgroup and b.validity_base = i.validity_base and b.key.ean_upc_altunit = p.ean_upc_base ";
			queryString = queryString + "and b.net_weight = :ntgew_weight ";
		}
		
		if (jsonObj.has("DESCRIPTION"))
		{
			queryString = queryString + "and t.key.matnr = p.matnr ";
			queryString = queryString + "and UPPER(t.maktx) LIKE UPPER(:description) ";
		}
		
		if (jsonObj.has("VERNO") )
		{
			queryString = queryString + "and p.verno = :verno ";
		}
		
		if (jsonObj.has("INGREDIENT") )
		{
			queryString = queryString + "and c.key.ean_upc_altunit = p.ean_upc_base ";
			queryString = queryString + "and c.key.prinbr = p.prinbr and c.key.productgroup = p.productgroup ";
			queryString = queryString + "and c.key.validity_unit = i.validity_base ";
			queryString = queryString + "and c.key.texttyp = 'ZING' and UPPER(c.text_line) LIKE UPPER(:ingredient) ";
		}
		
		if (jsonObj.has("ZOVERLAY") || jsonObj.has("ZZPROCESS1") || jsonObj.has("ZZPROCESS2") || jsonObj.has("ZZCAPACITY"))
		{
			queryString = queryString + "and p.matnr = m.key.matnr ";
		}
		
		if (jsonObj.has("VMSTA") || jsonObj.has("MVGR1") || jsonObj.has("ZZLAUNCHDATEFROM") || jsonObj.has("PRODHIER"))
		{
			queryString = queryString + "and v.key.vkorg = p.vkorg and v.key.vtweg = p.vtweg and v.key.matnr = p.matnr ";
		}
		
		if (jsonObj.has("LABELLING_CODE") 
				|| jsonObj.has("ARTEMISCODE")
				|| jsonObj.has("LSF")
				|| jsonObj.has("FR8_PROJECT_CODE")
				|| jsonObj.has("ALLERGENSYES")
				|| jsonObj.has("CONSUMPTIONAGE"))
		{
			queryString = queryString + "and k.key.prinbr = p.prinbr ";
			queryString = queryString + "and k.key.validity_base = i.validity_base ";
			queryString = queryString + "and k.key.ean_upc_base = p.ean_upc_base ";
			queryString = queryString + "and k.key.productgroup = p.productgroup ";
		}
		
		if (jsonObj.has("CODEPACKAGING"))
		{
			queryString = queryString + "and d.key.prinbr = p.prinbr ";
			queryString = queryString + "and d.key.validity_base = i.validity_base ";
			queryString = queryString + "and d.key.ean_upc_base = p.ean_upc_base ";
			queryString = queryString + "and d.key.productgroup = p.productgroup ";
			queryString = queryString + "and d.zzpaccod = :CODEPACKAGING ";
		}
		
		if (jsonObj.has("LABELLING_CODE"))
		{
			queryString = queryString + "and (k.key.characteristic = 'LABELLING_CODE' ";
			queryString = queryString + "and UPPER(k.key.description) LIKE UPPER(:LABELLING_CODE)) ";
		}
		if (jsonObj.has("ARTEMISCODE"))
		{
			queryString = queryString + "and (k.key.characteristic = 'ARTEMISCODE' ";
			queryString = queryString + "and UPPER(k.key.description) LIKE UPPER(:ARTEMISCODE)) ";
		}
		if (jsonObj.has("LSF"))
		{
			queryString = queryString + "and ( k.key.characteristic = 'PACKPRINT_LABCODE' ";
			queryString = queryString + "and k.key.description = :LSF ) ";
		}
		if (jsonObj.has("FR8_PROJECT_CODE"))
		{
			queryString = queryString + "and ( k.key.characteristic = 'FR8_PROJECT_CODE' ";
			queryString = queryString + "and UPPER(k.key.description) LIKE UPPER(:FR8_PROJECT_CODE) ) ";
		}
		if (jsonObj.has("CONSUMPTIONAGE"))
		{
			queryString = queryString + "and ( k.key.characteristic = 'FR8_CONSUMPTION_AGE' ";
			
			JSONArray ar = jsonObj.getJSONArray("CONSUMPTIONAGE");
			queryString = queryString + "and ( ";
			
			for (int i = 0; i < ar.length(); i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
				
				queryString = queryString + "k.key.description = :consumptionage" + i + " ";
			}
			
			queryString = queryString + ") ) ";
		}
		if (jsonObj.has("ALLERGENSYES"))
		{
			JSONArray ar = jsonObj.getJSONArray("ALLERGENSYES");
			
			if (ar.length() > 0)
			{
				queryString = queryString + "and ( ( k.key.characteristic = 'CONTAIN' OR k.key.characteristic = 'MAY_CONTAIN' ) AND ";
				queryString = queryString + "k.key.description = :allergen0) ";
			}
		}
		
		if (jsonObj.has("ZZPROCESS1"))
		{
			queryString = queryString + "and m.zzproces1 = :ZZPROCESS1 ";
		}
		if (jsonObj.has("ZZPROCESS2"))
		{
			queryString = queryString + "and m.zzproces2 = :ZZPROCESS2 ";
		}
		if (jsonObj.has("ZZCAPACITY"))
		{
			queryString = queryString + "and m.zzcapacity = :ZZCAPACITY ";
		}
		if (jsonObj.has("VKORG"))
		{
			queryString = queryString + "and p.vkorg = :vkorg ";
		}
		if (jsonObj.has("MATNR"))
		{
			queryString = queryString + "and p.matnr = :matnr ";
		}
		if (jsonObj.has("STATUS"))
		{
			queryString = queryString + "and p.status = :status ";
		}
		if (jsonObj.has("EAN"))
		{
			queryString = queryString + "and p.ean_upc_base = :ean ";
		}
		if (jsonObj.has("ZZLAUNCHDATEFROM"))
		{
			queryString = queryString + "and v.zzlaunchdate >= :datefrom ";
		}
		if (jsonObj.has("ZZLAUNCHDATETO"))
		{
			queryString = queryString + "and v.zzlaunchdate <= :dateto ";
		}
		if (jsonObj.has("STATUSAEDATFROM"))
		{
			queryString = queryString + "and p.status_date >= :statusaedatefrom ";
		}
		if (jsonObj.has("STATUSAEDATTO"))
		{
			queryString = queryString + "and p.status_date <= :statusaedateto ";
		}
		if (jsonObj.has("VTWEG"))
		{
			JSONArray ar = jsonObj.getJSONArray("VTWEG");
			queryString = queryString + "and ( ";
			
			for (int i = 0; i < ar.length(); i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
				
				queryString = queryString + "p.vtweg = :vtweg" + i + " ";
			}
			
			queryString = queryString + ") ";
		}
		
		if (jsonObj.has("PRODHIER"))
		{
			JSONArray ar = jsonObj.getJSONArray("PRODHIER");
			queryString = queryString + "and ( ";
			
			for (int i = 0; i < ar.length(); i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
				
				queryString = queryString + "v.prodh LIKE :prodhier" + i + " ";
			}
			
			queryString = queryString + ") ";
		}
		
		if (jsonObj.has("VMSTA"))
		{
			JSONArray ar = jsonObj.getJSONArray("VMSTA");
			queryString = queryString + "and ( ";
			
			for (int i = 0; i < ar.length(); i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
				
				queryString = queryString + "v.vmsta = :vmsta" + i + " ";
			}
			
			queryString = queryString + ") ";
		}
		
		if (jsonObj.has("MVGR1"))
		{
			JSONArray ar = jsonObj.getJSONArray("MVGR1");
			queryString = queryString + "and ( ";
			
			for (int i = 0; i < ar.length(); i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
				
				queryString = queryString + "v.mvgr1 = :mvgr1" + i + " ";
			}
			
			queryString = queryString + ") ";
		}
		
		if (jsonObj.has("ZOVERLAY"))
		{
			JSONArray ar = jsonObj.getJSONArray("ZOVERLAY");
			queryString = queryString + "and ( ";
			
			for (int i = 0; i < ar.length(); i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
				
				queryString = queryString + "m.zzoverlay = :zoverlay" + i + " ";
			}
			
			queryString = queryString + ") ";
		}
		
		LOGGER.debug(queryString);
		query = em.createQuery(queryString,ZPRODCAT_HDR.class);
		
		//Now that the query exists, we can set the parameters
		int countA = 0;
		for (ZPRO_ASSORTMENT as : assortList)
		{
			query.setParameter("assortassort" + countA, as.getAsort());
			query.setParameter("assortprinbr"+ countA, as.getPrinbr());
			countA++;
		}
		
		if (jsonObj.has("VERNO") )
		{
			query.setParameter("verno", Integer.parseInt(jsonObj.get("VERNO").toString()));
		}
		
		if (jsonObj.has("VKORG"))
		{
			query.setParameter("vkorg", jsonObj.get("VKORG").toString());
		}

		if (jsonObj.has("DESCRIPTION"))
		{
			query.setParameter("description", "%" + jsonObj.get("DESCRIPTION").toString() + "%");
		}
		
		if (jsonObj.has("STATUS"))
		{
			query.setParameter("status", jsonObj.get("STATUS").toString());
		}
		
		if (jsonObj.has("MATNR"))
		{
			String appendedMatnr = StringUtils.leftPad(jsonObj.get("MATNR").toString(), 18, "0");
			query.setParameter("matnr", appendedMatnr);
		}

		if (jsonObj.has("NTGEW_WEIGHT") )
		{
			Double netvalue = Double.parseDouble(jsonObj.get("NTGEW_WEIGHT").toString());
			LOGGER.debug(netvalue.toString());
			query.setParameter("ntgew_weight", netvalue);
		}
		if (jsonObj.has("ZZPROCESS1"))
		{
			query.setParameter("ZZPROCESS1", jsonObj.get("ZZPROCESS1").toString());
		}
		if (jsonObj.has("ZZPROCESS2"))
		{
			query.setParameter("ZZPROCESS2", jsonObj.get("ZZPROCESS2").toString());
		}
		if (jsonObj.has("ZZCAPACITY"))
		{
			query.setParameter("ZZCAPACITY", Integer.parseInt(jsonObj.get("ZZCAPACITY").toString()));
		}
		if (jsonObj.has("EAN"))
		{
			query.setParameter("ean", jsonObj.get("EAN").toString());
		}
		if (jsonObj.has("ZZLAUNCHDATEFROM"))
		{
			java.util.Date utildate = df.parse(jsonObj.get("ZZLAUNCHDATEFROM").toString());
			java.sql.Date date = new java.sql.Date(utildate.getTime());
			query.setParameter("datefrom", date);
		}
		if (jsonObj.has("ZZLAUNCHDATETO"))
		{
			java.util.Date utildate = df.parse(jsonObj.get("ZZLAUNCHDATETO").toString());
			java.sql.Date date = new java.sql.Date(utildate.getTime());
			query.setParameter("dateto", date);
		}
		if (jsonObj.has("STATUSAEDATFROM"))
		{
			java.util.Date utildate = df.parse(jsonObj.get("STATUSAEDATFROM").toString());
			java.sql.Date date = new java.sql.Date(utildate.getTime());
			query.setParameter("statusaedatefrom", date);
		}
		if (jsonObj.has("STATUSAEDATTO"))
		{
			java.util.Date utildate = df.parse(jsonObj.get("STATUSAEDATTO").toString());
			java.sql.Date date = new java.sql.Date(utildate.getTime());
			query.setParameter("statusaedateto", date);
		}
		if (jsonObj.has("VTWEG"))
		{
			JSONArray ar = jsonObj.getJSONArray("VTWEG");
			
			for (int i = 0; i < ar.length(); i++)
			{
				String param = "vtweg" + i;
				query.setParameter(param, ar.getString(i));
			}
		}
		if (jsonObj.has("ZOVERLAY"))
		{
			JSONArray ar = jsonObj.getJSONArray("ZOVERLAY");
			
			for (int i = 0; i < ar.length(); i++)
			{
				String param = "zoverlay" + i;
				query.setParameter(param, ar.getString(i));
			}
		}
		if (jsonObj.has("VMSTA"))
		{
			JSONArray ar = jsonObj.getJSONArray("VMSTA");
			
			for (int i = 0; i < ar.length(); i++)
			{
				String param = "vmsta" + i;
				query.setParameter(param, ar.getString(i));
			}
		}
		if (jsonObj.has("MVGR1"))
		{
			JSONArray ar = jsonObj.getJSONArray("MVGR1");
			
			for (int i = 0; i < ar.length(); i++)
			{
				String param = "mvgr1" + i;
				query.setParameter(param, ar.getString(i));
			}
		}
		if (jsonObj.has("PRODHIER"))
		{
			JSONArray ar = jsonObj.getJSONArray("PRODHIER");
			
			for (int i = 0; i < ar.length(); i++)
			{
				String param = "prodhier" + i;
				query.setParameter(param, ar.getString(i) + "%");
			}
		}
		if (jsonObj.has("CODEPACKAGING"))
		{
			query.setParameter("CODEPACKAGING", jsonObj.get("CODEPACKAGING").toString());
		}
		if (jsonObj.has("LABELLING_CODE"))
		{
			query.setParameter("LABELLING_CODE", "%" + jsonObj.get("LABELLING_CODE").toString().trim() + "%");
		}
		if (jsonObj.has("ARTEMISCODE"))
		{
			query.setParameter("ARTEMISCODE", jsonObj.get("ARTEMISCODE").toString());
		}
		if (jsonObj.has("LSF"))
		{
			query.setParameter("LSF", "%" + jsonObj.get("LSF").toString().trim() + "%");
		}
		if (jsonObj.has("INGREDIENT"))
		{
			query.setParameter("ingredient", "%" + jsonObj.get("INGREDIENT").toString() + "%");
		}
		if (jsonObj.has("FR8_PROJECT_CODE"))
		{
			String par = jsonObj.get("FR8_PROJECT_CODE").toString();
			par.replaceAll(" ", "%");
			LOGGER.debug("FR8_PROJECT_CODE: " + par);
			
			query.setParameter("FR8_PROJECT_CODE", "%" + par + "%");
		}
		if (jsonObj.has("ALLERGENSYES"))
		{
			JSONArray ar = jsonObj.getJSONArray("ALLERGENSYES");
			
			if (ar.length() > 0)
			{
				String param = "allergen0";
				query.setParameter(param, ar.getString(0));
			}
		}
		if (jsonObj.has("CONSUMPTIONAGE"))
		{
			JSONArray ar = jsonObj.getJSONArray("CONSUMPTIONAGE");
			
			for (int i = 0; i < ar.length(); i++)
			{
				String param = "consumptionage" + i;
				query.setParameter(param, ar.getString(i));
			}
		}
		
		return query;
	}
}
