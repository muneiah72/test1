package com.danone.resources;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class SDMXRequestListener implements ServletRequestListener {

    public SDMXRequestListener() {
    }

    public void requestDestroyed(ServletRequestEvent event) {
    }

    public void requestInitialized(ServletRequestEvent event) {
        final ServletRequest request = event.getServletRequest();
        ServletRequestStore.setServletRequest(request);
    }

}