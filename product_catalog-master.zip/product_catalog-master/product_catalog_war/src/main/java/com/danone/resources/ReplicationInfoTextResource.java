package com.danone.resources;

import java.net.HttpURLConnection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.cron.UpdateDBText;
import com.danone.entities.ReplicationInfoText;
import com.danone.persistence.PersistenceAdapter;

@Path("/replicationinfotext")
@Produces({ MediaType.APPLICATION_JSON })
public class ReplicationInfoTextResource {
	
	private final Logger LOGGER = LoggerFactory.getLogger(ReplicationInfoTextResource.class);
	
	@Context
	private HttpServletRequest servletRequest;
	
	@GET
	public Response getAllInfo() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {
			List<ReplicationInfoText> infos = ReplicationInfoText.getAllReplicationInfoText(em);
			return Response.ok(infos).build();
		} finally {
			em.close();
		}
	}
	
	@POST
	public Response startNewReplicationText() {
		Response response;
		
		if (!servletRequest.isUserInRole(Roles.MANTRIGGER)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}
		
		try {
			
			LOGGER.debug("Attempt to start manual text replication");
			UpdateDBText updatedbtext = UpdateDBText.getInstance(false);
			updatedbtext.startManual(servletRequest.getUserPrincipal().getName());
			
		} catch (PersistenceException e) {
			LOGGER.error("Failed to start text replication via REST ", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
			return response;
		} 

		response = Response.status(HttpURLConnection.HTTP_OK).entity("Text Replication started").build();
		return response;
	}
}
