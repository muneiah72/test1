package com.danone.resources;

public class Roles {
	public static final String MANTRIGGER = "Prometheus_ManualTrigger";
	public static final String ADMIN = "Prometheus_Admin";
	public static final String USER = "Prometheus_User";
	public static final String CBU_3000 = "Prometheus_CBU_3000";
	public static final String CBU_0046 = "Prometheus_CBU_0046";
	public static final String SUPERADMIN = "Prometheus_SuperAdmin";
	public static final String ALLCBU = "Prometheus_ALLCBU";
	public static final String EUPRODTRANSFERPRICE = "EuProdCat_TransferPrice";

}
