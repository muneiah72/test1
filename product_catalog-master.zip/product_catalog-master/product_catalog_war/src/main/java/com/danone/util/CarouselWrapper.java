package com.danone.util;

public class CarouselWrapper {
	
	private Integer id;
	private String title;
	private String pictureUrl;
	private String documentUrl;
	
	private String language;
	private Integer validFrom;
	private Integer validTo;
	private String pictureName;
	private String documentName;	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPictureUrl() {
		return pictureUrl;
	}
	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}
	public String getDocumentUrl() {
		return documentUrl;
	}
	public void setDocumentUrl(String documentUrl) {
		this.documentUrl = documentUrl;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Integer getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(Integer validFrom) {
		this.validFrom = validFrom;
	}
	public Integer getValidTo() {
		return validTo;
	}
	public void setValidTo(Integer validTo) {
		this.validTo = validTo;
	}
	public String getPictureName() {
		return pictureName;
	}
	public void setPictureName(String pictureName) {
		this.pictureName = pictureName;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	
}
