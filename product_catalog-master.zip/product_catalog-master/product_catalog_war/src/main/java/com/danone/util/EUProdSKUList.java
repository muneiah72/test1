package com.danone.util;

public class EUProdSKUList implements Comparable<EUProdSKUList>{
	private String matnr;
	private String maktx;
	private double weight;
	private String flavour;
	private String format;
	private String factory;
	private String sellingcountry;
	private String artemisref;
	private double skutray;
	
	public String getMatnr() {
		return matnr;
	}
	
	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	
	public String getMaktx() {
		return maktx;
	}
	
	public void setMaktx(String maktx) {
		this.maktx = maktx;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getFlavour() {
		return flavour;
	}

	public void setFlavour(String flavour) {
		this.flavour = flavour;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getSellingcountry() {
		return sellingcountry;
	}

	public void setSellingcountry(String sellingcountry) {
		this.sellingcountry = sellingcountry;
	}

	public String getArtemisref() {
		return artemisref;
	}

	public void setArtemisref(String artemisref) {
		this.artemisref = artemisref;
	}

	public String getFactory() {
		return factory;
	}

	public void setFactory(String factory) {
		this.factory = factory;
	}

	public double getSkutray() {
		return skutray;
	}

	public void setSkutray(double skutray) {
		this.skutray = skutray;
	}

	@Override
	public int compareTo(EUProdSKUList skulist) {
		return format.compareTo(skulist.getFormat());
	}
	
	public int compare(EUProdSKUList c1, EUProdSKUList c2)
    {
        return c1.getFormat().compareTo(c2.getFormat());
    }
}

