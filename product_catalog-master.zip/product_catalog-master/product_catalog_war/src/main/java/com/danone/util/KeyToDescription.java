package com.danone.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.codehaus.plexus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.CMSCAROUSEL;
import com.danone.entities.ZPPFLAV;
import com.danone.persistence.PersistenceAdapter;

public class KeyToDescription {
	
	private static KeyToDescription instance = null;
	private static Map<String, String> mapFat = null;
	private static Map<String, String> mapBrand = null;
	private static Map<String, String> mapBrandCat = null;
	private static Map<String, String> mapSubrange = null;
	private static Map<String, String> mapProcessTech = null;
	private static Map<String, String> mapCupDiam = null;
	private static Map<String, String> mapMultilayer = null;
	private static Map<String, String> mapTopper = null;
	private static Map<String, String> mapPlant = null;
	private static Map<String, String> mapCountry = null;
	private static Map<String, String> mapFlavor = null;
	private final Logger LOGGER = LoggerFactory.getLogger(KeyToDescription.class);
	
	protected KeyToDescription() {
		
	}
	
	public static KeyToDescription getInstance() {
		if(instance == null) {
			instance = new KeyToDescription();
	    }
	    
		return instance;
	}
	
	@SuppressWarnings("rawtypes")
	public String getSearchBrandTechnologyFlavorKey(String fullValue){
		if (mapFlavor == null)
		{
			fillMapFlavor();
		}
		if (mapBrand == null || mapProcessTech == null )
		{
			fillMaps();
		}
		String result = "";
		LOGGER.debug("Search string: " + fullValue);
		String[] splited = StringUtils.split(fullValue, " ");
		LOGGER.debug("After split length: " + splited.length);
		Iterator<?> it;
		
		for (String value : splited)
		{
			String tempResult = "";
			LOGGER.debug("Search value: " + value.toLowerCase());
			
			it = mapBrand.entrySet().iterator();
			while (it.hasNext()) {
		        Map.Entry pair = (Map.Entry)it.next();
		        if (pair.getValue().toString().toLowerCase().contains(value.toLowerCase()))
				{
		        	tempResult = pair.getKey().toString();
					break;
				}
		    }
			
			if (tempResult.equalsIgnoreCase(""))
			{
				it = mapProcessTech.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        if (pair.getValue().toString().toLowerCase().contains(value.toLowerCase()))
					{
			        	tempResult = pair.getKey().toString();
						break;
					}
			    }
			}
			if (tempResult.equalsIgnoreCase(""))
			{
				it = mapFlavor.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
//			        LOGGER.debug("Flavor: " + pair.getValue().toString().toLowerCase());
			        if (pair.getValue().toString().toLowerCase().contains(value.toLowerCase()))
					{
			        	if (tempResult.length() > 0)
						{
			        		tempResult = tempResult + " ";
						}						
			        	tempResult = tempResult + pair.getKey().toString();			        	
					}
			    }
			}
			
			if (!tempResult.equalsIgnoreCase(""))
			{
				if (result.length() > 0)
				{
					result = result + " ";
				}
				
				result = result + tempResult;
			}
		}
		
		if (result.equalsIgnoreCase(""))
		{
			//Return original value
			LOGGER.debug("After KeyToDescription: " + fullValue);
			return fullValue;
		}else {
			LOGGER.debug("After KeyToDescription: " + result);
			return result;
		}
	}
	
	public String getFatText(String key)
	{
		if (mapFat == null)
		{
			fillMaps();
		}
		String value = mapFat.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value fat for key: " + key);
		}
		return value;
	}
	
	public String getBrandText(String key)
	{
		if (mapBrand == null)
		{
			fillMaps();
		}
		String value = mapBrand.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value brand for key: " + key);
		}
		return value;
	}
	
	public String getBrandCatText(String key)
	{
		if (mapBrandCat == null)
		{
			fillMaps();
		}
		String value = mapBrandCat.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value brand category for key: " + key);
		}
		return value;
	}
	
	public String getSubrangeText(String key)
	{
		if (mapSubrange == null)
		{
			fillMaps();
		}
		String value = mapSubrange.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value subrange for key: " + key);
		}
		return value;
	}
	
	public String getProcessTechText(String key)
	{
		if (mapProcessTech == null)
		{
			fillMaps();
		}
		String value = mapProcessTech.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value processtech for key: " + key);
		}
		return value;
	}
	
	public String getCupDiamText(String key)
	{
		if (mapCupDiam == null)
		{
			fillMaps();
		}
		String value = mapCupDiam.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value cupdiam for key: " + key);
		}
		return value;
	}
	
	public String getMultilayerText(String key)
	{
		if (mapMultilayer == null)
		{
			fillMaps();
		}
		String value = mapMultilayer.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value multilayer for key: " + key);
		}
		return value;
	}
	
	public String getTopperText(String key)
	{
		if (mapTopper == null)
		{
			fillMaps();
		}
		String value = mapTopper.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value topper for key: " + key);
		}
		return value;
	}
	
	public String getPlantText(String key)
	{
		if (mapPlant == null)
		{
			fillMaps();
		}
		String value = mapPlant.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value plant for key: " + key);
		}
		return value;
	}
	
	public String getCountryText(String key)
	{
		if (mapCountry == null)
		{
			fillMaps();
		}
		String value = mapCountry.get(key);
		if (value == null)
		{
			value = key;
			LOGGER.debug("No value country for key: " + key);
		}
		return value;
	}
	
	public void fillMaps()
	{
		mapFat = new HashMap<String, String>();
		mapFat.put("0001", "FULL FAT");
		mapFat.put("0002", "LOW FAT");
		mapFat.put("0003", "FULL FAT LACTOSE FREE");
		mapFat.put("0004", "LOW FAT LACTOSE FREE");
/*		mapFat.put("7089", "Full Fat");
		mapFat.put("7090", "Low Fat");		*/
		
		mapBrand = new HashMap<String, String>();
		mapBrand.put("001", "ACTIMEL");
		mapBrand.put("002", "LIGHT & FREE");
		mapBrand.put("009", "DANETTE");
		mapBrand.put("035", "OTHERS BRANDS");
		mapBrand.put("058", "VITALINEA");
		mapBrand.put("080", "ACTIVIA");
		mapBrand.put("207", "DANACOL");
		mapBrand.put("312", "DANONE");
		mapBrand.put("313", "DANONINO");
		mapBrand.put("568", "LICENSING");
		mapBrand.put("727", "OKIO INDULGENCE");
		mapBrand.put("730", "LES 2 VACHES");
//		mapBrand.put("016", "FANTASIA");
//		mapBrand.put("032", "LOCAL CORE");
//		mapBrand.put("081", "BABY");
//		mapBrand.put("088", "DAN'UP");
//		mapBrand.put("089", "FJORD");
//		mapBrand.put("094", "GERVITA");
//		mapBrand.put("101", "VELOUTE");
//		mapBrand.put("144", "JOCKEY");
//		mapBrand.put("146", "RECETTE CREMEUSE");
//		mapBrand.put("415", "CASA BUNA");
//		mapBrand.put("566", "DENSIA");
//		mapBrand.put("625", "GRATKA");
//		mapBrand.put("676", "CO-BRANDING");
//		mapBrand.put("722", "PETIT SUISSE NATURE");
//		mapBrand.put("725", "DANIO STRAINED");
//		mapBrand.put("726", "DANONE CORE");
//		mapBrand.put("728", "DANONE & FRUIT");
//		mapBrand.put("729", "LOCAL DESSERTS");
//		mapBrand.put("731", "VEGETAL");
//		mapBrand.put("732", "DANIO CHEESE");

		
		mapBrandCat = new HashMap<String, String>();
		mapBrandCat.put("0001", "1919");
		mapBrandCat.put("0002", "ATLAS");
		mapBrandCat.put("0003", "CASA BUNA");
		mapBrandCat.put("0004", "CREMOSSO");
		mapBrandCat.put("0005", "CUAJADA");
		mapBrandCat.put("0006", "DANIO CHEESE");
		mapBrandCat.put("0007", "DANIO INDULGENCE");
		mapBrandCat.put("0008", "DAN'UP");
		mapBrandCat.put("0009", "DANY SAHNE");
		mapBrandCat.put("0010", "DENSIA");
		mapBrandCat.put("0011", "DISNEY");
		mapBrandCat.put("0012", "DZP");
		mapBrandCat.put("0013", "FANTASIA");
		mapBrandCat.put("0014", "FJORD");
		mapBrandCat.put("0015", "FLAN");
		mapBrandCat.put("0016", "GERVAIS");
		mapBrandCat.put("0017", "GERVITA");
		mapBrandCat.put("0018", "GRATKA");
		mapBrandCat.put("0019", "JOCKEY");
		mapBrandCat.put("0020", "KIDS");
		mapBrandCat.put("0021", "LA COPA");
		mapBrandCat.put("0022", "LIEGEOIS");
		mapBrandCat.put("0023", "LOCAL");
		mapBrandCat.put("0024", "MARS");
		mapBrandCat.put("0025", "NA BABA");
		mapBrandCat.put("0026", "NAP MINT NAP");
		mapBrandCat.put("0027", "NUTRIDAY");
		mapBrandCat.put("0028", "OBSTGARTEN");
		mapBrandCat.put("0029", "OIKOS - DANIO HUNGER");
		mapBrandCat.put("0031", "PETIT SUISSE NATURE");
		mapBrandCat.put("0032", "PRIVATE LABELS AND FIRST PRICE");
		mapBrandCat.put("0033", "PROVITAL");
		mapBrandCat.put("0034", "RECETTE CREMEUSE");
		mapBrandCat.put("0035", "RICE MILK");
		mapBrandCat.put("0036", "SOY / VEGETAL");
		mapBrandCat.put("0037", "STANDARD");
		mapBrandCat.put("0038", "VELOUTE");
		mapBrandCat.put("0039", "ORGANIC");

		
		mapSubrange = new HashMap<String, String>();
		mapSubrange.put("0001", "CEREALS");
		mapSubrange.put("0002", "FLAVOURED");
		mapSubrange.put("0003", "FRUITS");
		mapSubrange.put("0004", "PLAIN");
		
		mapProcessTech = new HashMap<String, String>();
		mapProcessTech.put("01", "ACTIMEL");
		mapProcessTech.put("02", "AYRAN");
		mapProcessTech.put("03", "CHEESE");
		mapProcessTech.put("04", "DESSERT");
		mapProcessTech.put("05", "DESSERT WITH WHIPPED CREAM");
		mapProcessTech.put("06", "DRINKS");
		mapProcessTech.put("07", "KEFIR");
		mapProcessTech.put("08", "LABAN");
		mapProcessTech.put("09", "LASSI");
		mapProcessTech.put("10", "MILK");
		mapProcessTech.put("11", "MOUSSE");
		mapProcessTech.put("12", "SET YOGHURT");
		mapProcessTech.put("13", "SKYR");
		mapProcessTech.put("14", "SOUR CREAM");
		mapProcessTech.put("15", "STIRRED YOGHURT");
		mapProcessTech.put("16", "STRAINED YOGHURT");
/*		mapProcessTech.put("D01", "SET YOGHURT");
		mapProcessTech.put("D02", "STIRRED YOGHURT");
		mapProcessTech.put("D03", "DESSERT");
		mapProcessTech.put("D04", "CHEESE");
		mapProcessTech.put("D05", "DRINKS");
		mapProcessTech.put("D06", "OTHERS");
		mapProcessTech.put("D07", "FRESH CHEESE");
		mapProcessTech.put("D08", "IMPORT");
		mapProcessTech.put("D09", "SMETANA");
		mapProcessTech.put("D10", "DESSERT WITH WHIPPED CREAM");
		mapProcessTech.put("D11", "JUICE");
		mapProcessTech.put("D12", "KEFIR");
		mapProcessTech.put("D13", "MOUSSE");
		mapProcessTech.put("D14", "MILK");
		mapProcessTech.put("D15", "SOUR CREAM");
		mapProcessTech.put("D16", "STRAINED YOGHURT");*/
		
		mapCupDiam = new HashMap<String, String>();
		mapCupDiam.put("D01", "B>400ML");
		mapCupDiam.put("D02", "B100ML");
		mapCupDiam.put("D03", "B200ML");
		mapCupDiam.put("D04", "B300ML");
		mapCupDiam.put("D05", "F>93");
		mapCupDiam.put("D06", "F12673");
		mapCupDiam.put("D07", "F48");
		mapCupDiam.put("D08", "F57OM");
		mapCupDiam.put("D09", "F63 - ERCA");
		mapCupDiam.put("D10", "F63 - KISS");
		mapCupDiam.put("D11", "F63 - OTHERS");
		mapCupDiam.put("D12", "F6372");
		mapCupDiam.put("D13", "F73");
		mapCupDiam.put("D14", "F7480");
		mapCupDiam.put("D15", "F8163");
		mapCupDiam.put("D16", "F9270");
		mapCupDiam.put("D17", "F93");
		mapCupDiam.put("D18", "F95");
		mapCupDiam.put("D19", "GLASS CUP");
		mapCupDiam.put("D20", "P>118");
		mapCupDiam.put("D21", "P57");
		mapCupDiam.put("D22", "P65");
		mapCupDiam.put("D23", "P75");
		mapCupDiam.put("D24", "P93");
		mapCupDiam.put("D25", "POU<=0,5L");
		mapCupDiam.put("D26", "POU>0,5L");
		mapCupDiam.put("D27", "TT");
		mapCupDiam.put("D28", "TR");
		
		mapMultilayer = new HashMap<String, String>();
		mapMultilayer.put("D01", "Multilayer");
		
		mapTopper = new HashMap<String, String>();
		mapTopper.put("D01", "CEREALS");
		mapTopper.put("D02", "CHOCOLATE");
		mapTopper.put("D03", "FRUITS");
		mapTopper.put("D04", "OTHER");
		
		mapPlant = new HashMap<String, String>();
		/*
		mapPlant.put("23","0029 PL DANONE Plant Warszawa");
		mapPlant.put("24","0029 PL DANONE DC Blonie");
		mapPlant.put("25","0029 PL DANONE Plant Bierun");
		mapPlant.put("26","0026 PL DANONE Copacker 01");
		mapPlant.put("28","0029 PL DANONE Virtual skimmed");
		mapPlant.put("29","0029 PL DANONE Headquarters Po");
		mapPlant.put("30","0006 DE HAUPTVERWALTUNG");
		mapPlant.put("31","0006 DE WERK ROSENHEIM");
		mapPlant.put("32","0006 DE WERK OCHSENFURT");
		mapPlant.put("33","0006 DE WERK HAGENOW");
		mapPlant.put("34","0006 DE ZENTRALLAGER");
		mapPlant.put("42","0006 DE HAMBURG");
		mapPlant.put("63","0021 BE ROTSELAAR (FACTORY)");
		mapPlant.put("64","0021 BE ROTSELAAR (DC)");
		mapPlant.put("65","0021 BE BRUXELLES (HQ)");
		mapPlant.put("71","0024 FR BAILLEUL (PL)");
		mapPlant.put("72","0024 FR FERRIERES (PL)");
		mapPlant.put("73","0024 FR NEUFCHATEL (PL)");
		mapPlant.put("74","0024 FR ST JUST (PL)");
		mapPlant.put("75","0024 FR VILLECOMTAL (PL)");
		mapPlant.put("76","0024 FR MOLAY (PL)");
		mapPlant.put("77","0024 FR LESQUIN (DC)");
		mapPlant.put("78","0024 FR PARIS NORD (DC)");
		mapPlant.put("79","0024 FR PARIS SUD (DC)");
		mapPlant.put("80","0024 FR METZ (DC)");
		mapPlant.put("81","0024 FR TOURS (DC)");
		mapPlant.put("82","0024 FR VALLET (DC)");
		mapPlant.put("83","0024 FR CHAPONNAY (DC)");
		mapPlant.put("84","0024 FR AIX (DC)");
		mapPlant.put("85","0024 FR TOULOUSE (DC)");
		mapPlant.put("86","0024 FR PL CFE3");
		mapPlant.put("87","0024 FR CHAPONNAY (CE)");
		mapPlant.put("88","0024 FR LESQUIN (CE)");
		mapPlant.put("89","0024 FR LACAPELLE (DC)");
		mapPlant.put("90","0024 FR LOUHANS (DC)");
		mapPlant.put("91","0024 FR LEVALLOIS (DIR LAIT)");
		mapPlant.put("92","0024 FR LEVALLOIS (DIR DFR)");
		mapPlant.put("165","0036 ES PL Fábrica PARETS");
		mapPlant.put("166","0036 ES PL Fábrica TRES CANTOS");
		mapPlant.put("167","0036 ES PL Fábrica SALAS");
		mapPlant.put("168","0036 ES PL Fábrica ALDAYA");
		mapPlant.put("169","0036 ES PL Fábrica SEVILLA");
		mapPlant.put("170","0036 ES DC Base Sant Cugat");
		mapPlant.put("171","0036 ES DC Base Getafe");
		mapPlant.put("172","0036 ES DC Base Oviedo");
		mapPlant.put("173","0036 ES DC Base Vigo");
		mapPlant.put("174","0036 ES DC Base Aldaya");
		mapPlant.put("175","0036 ES DC Base Pamplona");
		mapPlant.put("176","0036 ES DC Base Sevilla");
		mapPlant.put("177","0036 ES DC Base Málaga");
		mapPlant.put("178","0036 ES DC C.R.L. Ulzama");
		mapPlant.put("179","CRL Galicia");
		mapPlant.put("180","0036 ES DC OOCC Buenos Aires");
		mapPlant.put("181","0036 ES DC DPT Córcega");
		mapPlant.put("182","0036 EUROSERUM");
		mapPlant.put("183","0036 ES DC Converty");
		mapPlant.put("216","0006 DE KITZINGEN");
		mapPlant.put("217","0036 ES Base Murcia");
		mapPlant.put("218","0036 ES Base Tres Cantos");
		mapPlant.put("478","SITEX TRES CANTOS");
		mapPlant.put("512","0024 FR TOULOUSE (CE)");
		mapPlant.put("513","0024 FR LSDH (PL)");
		mapPlant.put("514","0024 FR YEO (PL)");
		mapPlant.put("515","0024 FR PL CFE1");
		mapPlant.put("516","0024 FR PL CFE2");
		mapPlant.put("540","0024 FR BLEDINA MILK (VIRTUAL)");
		mapPlant.put("693","0029 PL DANONE DC Żabia Wola");
		mapPlant.put("694","0029 PL DANONE DC Chorzow");
		mapPlant.put("870","0006 DE Danone GmbH DHL");
		mapPlant.put("993","0029 PL DANONE DC Copacker 02");
		mapPlant.put("994","0029 PL DANONE DC Swiecice");
		mapPlant.put("995","0029 PL DANONE DC Copacker 03");
		mapPlant.put("1021","0074 NL NUTRICIA FACTORY");
		mapPlant.put("3701","3700 NUTRICIA ZAKLADY PR_OPOLE");
		mapPlant.put("3702","3700 NUTRICIA ZAKLAD_KROTOSZYN");
		mapPlant.put("8701","8700 Bucharest Factory");
		mapPlant.put("8702","8700 Bucharest DC");
		mapPlant.put("8703","8700 Cluj DC");
		mapPlant.put("8704","8700 Virtual Poland");
		mapPlant.put("8705","8700 Virtual Bulgaria");
		*/
		mapPlant.put("0002","Praha 3");
		mapPlant.put("0023","Warszawa");
		mapPlant.put("0024","Blonie");
		mapPlant.put("0025","Bierun");
		mapPlant.put("0026","Pszczyna");
		mapPlant.put("0028","Warszawa");
		mapPlant.put("0029","Warszawa");
		mapPlant.put("0030","Haar");
		mapPlant.put("0031","Rosenheim");
		mapPlant.put("0032","Ochsenfurt");
		mapPlant.put("0033","Hagenow");
		mapPlant.put("0034","Ochsenfurt-Goßmannsdorf");
		mapPlant.put("0042","Hamburg");
		mapPlant.put("0063","Rotselaar");
		mapPlant.put("0064","Rotselaar");
		mapPlant.put("0065","Bruxelles");
		mapPlant.put("0071","Bailleul");
		mapPlant.put("0072","Ferrieres-En-Bray");
		mapPlant.put("0073","Neufchatel-En-Bray");
		mapPlant.put("0074","Saint-Just-Chaleyssin");
		mapPlant.put("0075","Villecomtal-Sur-Arros");
		mapPlant.put("0076","Le Molay-Littry");
		mapPlant.put("0077","Lesquin Cedex");
		mapPlant.put("0078","Tremblay en France");
		mapPlant.put("0079","Rungis Cedex");
		mapPlant.put("0080","Marly");
		mapPlant.put("0081","Chambray Les Tours");
		mapPlant.put("0082","Vallet");
		mapPlant.put("0083","Chaponnay");
		mapPlant.put("0084","Aix En Provence");
		mapPlant.put("0085","Eurocentre Cedex");
		mapPlant.put("0086","Grand Quevilly");
		mapPlant.put("0087","Chaponnay");
		mapPlant.put("0088","Lesquin Cedex");
		mapPlant.put("0089","Lacapelle-Marival");
		mapPlant.put("0090","Louhans");
		mapPlant.put("0091","Saint Ouen Cedex");
		mapPlant.put("0092","Saint Ouen Cedex");
		mapPlant.put("0165","Parets Del Valles (BCN)");
		mapPlant.put("0166","Tres Cantos - Madrid");
		mapPlant.put("0167","Salas");
		mapPlant.put("0168","Aldaya");
		mapPlant.put("0169","Sevilla");
		mapPlant.put("0170","S. Cugat Del Valles (BCN)");
		mapPlant.put("0171","Getafe (Madrid)");
		mapPlant.put("0172","Viella-Siero (Asturias)");
		mapPlant.put("0173","S.Pedro De Sardoma (Vigo)");
		mapPlant.put("0174","Aldaya");
		mapPlant.put("0175","Berriosuso (Navarra)");
		mapPlant.put("0176","Sevilla");
		mapPlant.put("0177","Malaga");
		mapPlant.put("0178","Iraizoz - Ulzama (Navarra");
		mapPlant.put("0179","Monforte De Lemos (Lugo)");
		mapPlant.put("0180","Barcelona");
		mapPlant.put("0181","Barcelona");
		mapPlant.put("0182","Monforte De Lemos");
		mapPlant.put("0183","Tres Cantos - Madrid");
		mapPlant.put("0216","Kitzingen");
		mapPlant.put("0217","Sangorena La Seca (Murcia");
		mapPlant.put("0218","Tres Cantos");
		mapPlant.put("0471","Castelo Branco");
		mapPlant.put("0478","Tres Cantos");
		mapPlant.put("0512","Eurocentre");
		mapPlant.put("0513","Saint Denis de l'Hotel");
		mapPlant.put("0514","Toulouse");
		mapPlant.put("0515","Saint Laurent Blangy");
		mapPlant.put("0516","La Meauffe");
		mapPlant.put("0540","Steenvoorde");
		mapPlant.put("0693","Żabia Wola");
		mapPlant.put("0694","Chorzow");
		mapPlant.put("0870","Krefeld");
		mapPlant.put("0993","Wolka Kosowska");
		mapPlant.put("0994","Plochocin");
		mapPlant.put("0995","Bierun");
		mapPlant.put("1021","Zoetermeer");
		mapPlant.put("3701","Opole");
		mapPlant.put("3702","Krotoszyn");
		mapPlant.put("8701","Bucharest");
		mapPlant.put("8702","Bucharest");
		mapPlant.put("8703","Cluj");
		mapPlant.put("8704","Bucharest");
		mapPlant.put("8705","Bucharest");
		mapPlant.put("8802","Sofia");
		
		mapCountry = new HashMap<String, String>();
		mapCountry.put("AB", "Abkhazia");
		mapCountry.put("AD", "Andorra");
		mapCountry.put("AE", "Utd.Arab Emir.");
		mapCountry.put("AF", "Afghanistan");
		mapCountry.put("AG", "Antigua/Barbuda");
		mapCountry.put("AI", "Anguilla");
		mapCountry.put("AL", "Albania");
		mapCountry.put("AM", "Armenia");
		mapCountry.put("AN", "Dutch Antilles");
		mapCountry.put("AO", "Angola");
		mapCountry.put("AQ", "Antarctica");
		mapCountry.put("AR", "Argentina");
		mapCountry.put("AS", "Samoa, American");
		mapCountry.put("AT", "Austria");
		mapCountry.put("AU", "Australia");
		mapCountry.put("AW", "Aruba");
		mapCountry.put("AZ", "Azerbaijan");
		mapCountry.put("BA", "Bosnia-Herz.");
		mapCountry.put("BB", "Barbados");
		mapCountry.put("BD", "Bangladesh");
		mapCountry.put("BE", "Belgium");
		mapCountry.put("BF", "Burkina-Faso");
		mapCountry.put("BG", "Bulgaria");
		mapCountry.put("BH", "Bahrain");
		mapCountry.put("BI", "Burundi");
		mapCountry.put("BJ", "Benin");
		mapCountry.put("BL", "St Barthelemy");
		mapCountry.put("BM", "Bermuda");
		mapCountry.put("BN", "Brunei Dar-es-S");
		mapCountry.put("BO", "Bolivia");
		mapCountry.put("BQ", "Bonaire, Saba");
		mapCountry.put("BR", "Brazil");
		mapCountry.put("BS", "Bahamas");
		mapCountry.put("BT", "Bhutan");
		mapCountry.put("BV", "Bouvet Island");
		mapCountry.put("BW", "Botswana");
		mapCountry.put("BY", "Belarus");
		mapCountry.put("BZ", "Belize");
		mapCountry.put("CA", "Canada");
		mapCountry.put("CC", "Coconut Islands");
		mapCountry.put("CD", "Congo-Kinshasa");
		mapCountry.put("CF", "Central Afr.Rep");
		mapCountry.put("CG", "Congo-Brazavill");
		mapCountry.put("CH", "Switzerland");
		mapCountry.put("CI", "Ivory Coast");
		mapCountry.put("CK", "Cook Islands");
		mapCountry.put("CL", "Chile");
		mapCountry.put("CM", "Cameroon");
		mapCountry.put("CN", "China");
		mapCountry.put("CO", "Colombia");
		mapCountry.put("CR", "Costa Rica");
		mapCountry.put("CS", "DO NOT USE");
		mapCountry.put("CU", "Cuba");
		mapCountry.put("CV", "Cape Verde");
		mapCountry.put("CW", "Curaçao");
		mapCountry.put("CX", "Christmas Islnd");
		mapCountry.put("CY", "Cyprus");
		mapCountry.put("CZ", "Czech Republic");
		mapCountry.put("DE", "Germany");
		mapCountry.put("DJ", "Djibouti");
		mapCountry.put("DK", "Denmark");
		mapCountry.put("DM", "Dominica");
		mapCountry.put("DO", "Dominican Rep.");
		mapCountry.put("DZ", "Algeria");
		mapCountry.put("EC", "Ecuador");
		mapCountry.put("EE", "Estonia");
		mapCountry.put("EG", "Egypt");
		mapCountry.put("EH", "West Sahara");
		mapCountry.put("ER", "Eritrea");
		mapCountry.put("ES", "Spain");
		mapCountry.put("ET", "Ethiopia");
		mapCountry.put("EU", "European Union");
		mapCountry.put("FI", "Finland");
		mapCountry.put("FJ", "Fiji");
		mapCountry.put("FK", "Falkland Islnds");
		mapCountry.put("FM", "Micronesia");
		mapCountry.put("FO", "Faroe Islands");
		mapCountry.put("FR", "France");
		mapCountry.put("GA", "Gabon");
		mapCountry.put("GB", "United Kingdom");
		mapCountry.put("GD", "Grenada");
		mapCountry.put("GE", "Georgia");
		mapCountry.put("GF", "French Guayana");
		mapCountry.put("GH", "Ghana");
		mapCountry.put("GI", "Gibraltar");
		mapCountry.put("GL", "Greenland");
		mapCountry.put("GM", "Gambia");
		mapCountry.put("GN", "Guinea");
		mapCountry.put("GP", "Guadeloupe");
		mapCountry.put("GQ", "Equatorial Gui.");	
		mapCountry.put("GR", "Greece");
		mapCountry.put("GS", "S. Sandwich Ins");
		mapCountry.put("GT", "Guatemala");
		mapCountry.put("GU", "Guam");
		mapCountry.put("GW", "Guinea-Bissau");
		mapCountry.put("GY", "Guyana");
		mapCountry.put("HK", "Hong Kong");
		mapCountry.put("HM", "Heard/McDon.Isl");
		mapCountry.put("HN", "Honduras");
		mapCountry.put("HR", "Croatia");
		mapCountry.put("HT", "Haiti");
		mapCountry.put("HU", "Hungaria");
		mapCountry.put("ID", "Indonesia");
		mapCountry.put("IE", "Ireland");
		mapCountry.put("IL", "Israel");
		mapCountry.put("IN", "India");
		mapCountry.put("IO", "Brit.Ind.Oc.Ter");
		mapCountry.put("IQ", "Iraq");
		mapCountry.put("IR", "Iran");
		mapCountry.put("IS", "Iceland");
		mapCountry.put("IT", "Italy");
		mapCountry.put("JM", "Jamaica");
		mapCountry.put("JO", "Jordan");
		mapCountry.put("JP", "Japan");
		mapCountry.put("KE", "Kenya");
		mapCountry.put("KG", "Kyrgyzstan");
		mapCountry.put("KH", "Cambodia");
		mapCountry.put("KI", "Kiribati");
		mapCountry.put("KM", "Comoros");
		mapCountry.put("KN", "St Kitts&Nevis");
		mapCountry.put("KO", "Curacao");
		mapCountry.put("KP", "North Korea");
		mapCountry.put("KR", "South Korea");
		mapCountry.put("KW", "Kuwait");
		mapCountry.put("KY", "Cayman Islands");
		mapCountry.put("KZ", "Kazakhstan");
		mapCountry.put("LA", "Laos");
		mapCountry.put("LB", "Lebanon");
		mapCountry.put("LC", "St. Lucia");
		mapCountry.put("LB", "Lebanon");
		mapCountry.put("LI", "Liechtenstein");
		mapCountry.put("LK", "Sri Lanka");
		mapCountry.put("LR", "Liberia");
		mapCountry.put("LS", "Lesotho");
		mapCountry.put("LT", "Lithuania");
		mapCountry.put("LU", "Luxembourg");
		mapCountry.put("LV", "Latvia");
		mapCountry.put("LY", "Libya");
		mapCountry.put("MA", "Morocco");
		mapCountry.put("MC", "Monaco");
		mapCountry.put("MD", "Moldavia");
		mapCountry.put("ME", "Montenegro");
		mapCountry.put("MF", "St Martin Dutch");
		mapCountry.put("MG", "Madagascar");
		mapCountry.put("MH", "Marshall Islnds");
		mapCountry.put("MK", "Macedonia");
		mapCountry.put("ML", "Mali");
		mapCountry.put("MM", "Myanmar");
		mapCountry.put("MN", "Mongolia");
		mapCountry.put("MO", "Macau");
		mapCountry.put("MP", "N.Mariana Islnd");
		mapCountry.put("MQ", "Martinique");
		mapCountry.put("MR", "Mauretania");
		mapCountry.put("MS", "Montserrat");
		mapCountry.put("MT", "Malta");
		mapCountry.put("MU", "Mauritius");
		mapCountry.put("MV", "Maldives");
		mapCountry.put("MW", "Malawi");
		mapCountry.put("MX", "Mexico");
		mapCountry.put("MY", "Malaysia");
		mapCountry.put("MZ", "Mozambique");
		mapCountry.put("NA", "Namibia");
		mapCountry.put("NC", "New Caledonia");
		mapCountry.put("NE", "Niger");
		mapCountry.put("NF", "Norfolk Island");
		mapCountry.put("NG", "Nigeria");
		mapCountry.put("NI", "Nicaragua");
		mapCountry.put("NL", "Netherlands");
		mapCountry.put("NO", "Norway");
		mapCountry.put("NP", "Nepal");
		mapCountry.put("NR", "Nauru");
		mapCountry.put("NT", "NATO");
		mapCountry.put("NU", "Niue Islands");
		mapCountry.put("NZ", "New Zealand");
		mapCountry.put("OM", "Oman");
		mapCountry.put("OR", "Orange");
		mapCountry.put("PA", "Panama");
		mapCountry.put("PE", "Peru");
		mapCountry.put("PF", "Frenc.Polynesia");
		mapCountry.put("PG", "Papua Nw Guinea");
		mapCountry.put("PH", "Philippines");
		mapCountry.put("PK", "Pakistan");
		mapCountry.put("PL", "Poland");
		mapCountry.put("PM", "St.Pier,Miquel.");
		mapCountry.put("PN", "Pitcairn Islnds");
		mapCountry.put("PR", "Puerto Rico");
		mapCountry.put("PS", "Palestine");
		mapCountry.put("PT", "Portugal");
		mapCountry.put("PW", "Palau");
		mapCountry.put("PY", "Paraguay");
		mapCountry.put("QA", "Qatar");
		mapCountry.put("RE", "Reunion");
		mapCountry.put("RO", "Romania");
		mapCountry.put("RS", "Serbia");
		mapCountry.put("RU", "Russian Fed.");
		mapCountry.put("RW", "Ruanda");
		mapCountry.put("SA", "Saudi Arabia");
		mapCountry.put("SB", "Solomon Islands");
		mapCountry.put("SC", "Seychelles");
		mapCountry.put("SD", "Sudan");		
		mapCountry.put("SE", "Sweden");
		mapCountry.put("SG", "Singapore");
		mapCountry.put("SH", "St. Helena");
		mapCountry.put("SI", "Slovenia");
		mapCountry.put("SJ", "Svalbard");
		mapCountry.put("SK", "Slovakia");
		mapCountry.put("SL", "Sierra Leone");
		mapCountry.put("SM", "San Marino");
		mapCountry.put("SN", "Senegal");
		mapCountry.put("SO", "Somalia");
		mapCountry.put("SR", "Suriname");
		mapCountry.put("SS", "South Sudan");
		mapCountry.put("ST", "S.Tome,Principe");
		mapCountry.put("SV", "El Salvador");
		mapCountry.put("SX", "Sint Maarten");
		mapCountry.put("SY", "Syria");
		mapCountry.put("SZ", "Swaziland");
		mapCountry.put("TC", "Turksh Caicosin");
		mapCountry.put("TD", "Chad");
		mapCountry.put("TF", "French S.Territ");
		mapCountry.put("TG", "Togo");
		mapCountry.put("TH", "Thailand");
		mapCountry.put("TJ", "Tajikstan");
		mapCountry.put("TK", "Tokelau Islands");
		mapCountry.put("TL", "East Timor");
		mapCountry.put("TM", "Turkmenistan");
		mapCountry.put("TN", "Tunisia");
		mapCountry.put("TO", "Tonga");
		mapCountry.put("TP", "East Timor");
		mapCountry.put("TR", "Turkey");
		mapCountry.put("TT", "Trinidad,Tobago");
		mapCountry.put("TV", "Tuvalu");
		mapCountry.put("TW", "Taiwan");
		mapCountry.put("TZ", "Tanzania");
		mapCountry.put("UA", "Ukraine");
		mapCountry.put("UG", "Uganda");
		mapCountry.put("UM", "Minor Outl.Ins.");
		mapCountry.put("UN", "United Nations");
		mapCountry.put("US", "USA");
		mapCountry.put("UY", "Uruguay");
		mapCountry.put("UZ", "Uzbekistan");
		mapCountry.put("VA", "Vatican City");
		mapCountry.put("VC", "St. Vincent");
		mapCountry.put("VE", "Venezuela");
		mapCountry.put("VG", "Brit.Virgin Is.");
		mapCountry.put("VI", "Amer.Virgin Is.");
		mapCountry.put("VN", "Vietnam");
		mapCountry.put("VU", "Vanuatu");
		mapCountry.put("WF", "Wallis,Futuna");
		mapCountry.put("WS", "Western Samoa");
		mapCountry.put("XK", "Kosovo");
		mapCountry.put("YE", "Yemen");
		mapCountry.put("YT", "Mayotte");
		mapCountry.put("YU", "Yugoslavia");
		mapCountry.put("ZA", "South Africa");
		mapCountry.put("ZM", "Zambia");
		mapCountry.put("ZW", "Zimbabwe");		
	}	
	
	public void fillMapFlavor()
	{
		EntityManager em = PersistenceAdapter.getEntityManager();
		mapFlavor = new HashMap<String, String>();
		try {
			LOGGER.debug("fillMapFlavor");
			List<Object[]> allFlavors = ZPPFLAV.getFlavorList(em);
			LOGGER.debug("fillMapFlavor list:" + allFlavors.size());
			for (Object[] flavor : allFlavors)
			{
				String flavorId = (String)flavor[0];
				String flavorDesc = (String)flavor[1];
				mapFlavor.put(flavorId, flavorDesc);
			}
	
		} finally {
			em.close();
		}
		
	}
}
