package com.danone.resources;

import java.net.HttpURLConnection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.COMPANYSORG;
import com.danone.entities.COMPANYSORGPK;
import com.danone.persistence.PersistenceAdapter;

@Path("/companysorg")
public class CompanySorgResource {
	
	private final Logger LOGGER = LoggerFactory.getLogger(CompanySorgResource.class);
	
	@Context
	private HttpServletRequest servletRequest;
	
	@GET
	public Response getCompanysorg() {
		LOGGER.debug("In fetch authorization");
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		List<COMPANYSORG> compList = COMPANYSORG.getAllCompanysorgs(em);
		
		if (compList.isEmpty()) {
			return Response.ok().build();
		}
		
		return Response.ok(compList).build();
	}
	
	@POST
	@Path("{company}/")
	public Response deleteCompanysorg(@PathParam("company") String company){
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		if (company == null)
		{
			return Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("An error occured while deleting this company name").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		try {
			transaction.begin();
			COMPANYSORGPK companysorgpk = new COMPANYSORGPK(company);
			COMPANYSORG toBeRemoved = COMPANYSORG.getCOMPANYSORGByKey(em, companysorgpk);
			em.remove(toBeRemoved);
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to delete CompanySorg via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		
		response = Response.ok().build();
		
		return response;
	}
	
	@PUT
	public Response modifyCompanysorg(COMPANYSORG comp) {
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		if (comp == null)
		{
			return Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("An error occured while modifying this company name").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		transaction.begin();
		try {
			COMPANYSORGPK companysorgpk = new COMPANYSORGPK(comp.getKey().getCompany());
			COMPANYSORG exists = COMPANYSORG.getCOMPANYSORGByKey(em, companysorgpk);
			exists.setVkorg(comp.getVkorg());
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to update CompanySorg via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		response = Response.ok().build();
		return response;
	}

	@POST
	public Response createCompanysorg(COMPANYSORG comp) {
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		if (comp == null)
		{
			return Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("An error occured while creating this company name").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		try {
			COMPANYSORGPK companysorgpk = new COMPANYSORGPK(comp.getKey().getCompany());
			COMPANYSORG exists = COMPANYSORG.getCOMPANYSORGByKey(em, companysorgpk);
			
			if (exists != null) {
				LOGGER.error("Company name exists already");
				response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("Company name exists already")
						.build();
				return response;
			}
			transaction.begin();
			em.persist(comp);
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to create Company name via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		
		response = Response.ok().build();
		return response;
	}
}
