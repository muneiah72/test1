package com.danone.proxy;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class LRUCache<K, V> {

	private final Map<K, V> cacheMap;

	public LRUCache(final int cacheSize) {
		this.cacheMap = new LinkedHashMap<K, V>(cacheSize, 0.75f, true) {
			private static final long serialVersionUID = 4594966176806564986L;

			@Override
			protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
				return size() > cacheSize;
			}
		};
	}

	public synchronized void put(K key, V elem) {
		cacheMap.put(key, elem);
	}

	public synchronized V get(K key) {
		return cacheMap.get(key);
	}

	public synchronized V remove(K key) {
		return cacheMap.remove(key);
	}

	public synchronized Set<Entry<K, V>> entrySet() {
		return cacheMap.entrySet();
	}

	public synchronized void clearCache() {
		cacheMap.clear();
	}
}