package com.danone.resources;

import java.net.HttpURLConnection;
import java.security.Principal;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.COMPANYSORG;
import com.danone.entities.COMPANYSORGPK;
import com.danone.entities.MARA;
import com.danone.entities.MVKE;
import com.danone.entities.PRICAT_K006;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.ConfigWrapper;
import com.sap.security.um.service.UserManagementAccessor;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;

@Path("/config")
@Produces({ MediaType.APPLICATION_JSON })
public class ConfigResource {
	private final Logger LOGGER = LoggerFactory.getLogger(ConfigResource.class);
	
	@Context
	private HttpServletRequest servletRequest;
	
	@GET
	@Path("{config}")
	public Response getConfig(@PathParam("config") String config) throws Exception {
		
		LOGGER.debug("In fetch config");
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		ConfigWrapper configWrapper = new ConfigWrapper();
		
		LOGGER.debug("In fetch user config");

		final HttpServletRequest request = (HttpServletRequest) ServletRequestStore.getServletRequest();			

		UserProvider userProvider = UserManagementAccessor.getUserProvider();
		Principal principal = request.getUserPrincipal();
		if (principal == null) {
			// user not authenticated
			LOGGER.debug("No user is authenticated");
			return Response.status(HttpURLConnection.HTTP_NOT_FOUND)
					.entity("No authenticated user").build();
		}
		User user = userProvider.getUser(principal.getName());	
		configWrapper.setUserid(principal.getName());
		configWrapper.setUsercompany(user.getAttribute("company"));
		
		HttpSession session = request.getSession();
		session.setAttribute("Userid", principal.getName());
		session.setAttribute("Usercompany", user.getAttribute("company"));
		LOGGER.debug("company parameter found:"+ user.getAttribute("company"));
		
		try {
			String company = new String(user.getAttribute("company"));
//			COMPANYSORG companysorg = COMPANYSORG.getCOMPANYSORGByCompany(em, company);
			COMPANYSORGPK companysorgpk = new COMPANYSORGPK(company);
			COMPANYSORG companysorg = COMPANYSORG.getCOMPANYSORGByKey(em, companysorgpk);
			if (companysorg != null) {
				configWrapper.setUsersalesorg(companysorg.getVkorg());
				session.setAttribute("Usersalesorg", companysorg.getVkorg());
				servletRequest.getSession().setAttribute("Usersalesorg", companysorg.getVkorg());
				LOGGER.debug("Usersalesorg found:"+ companysorg.getVkorg());
			}		
		} catch (Exception e) {
			LOGGER.debug("No user attributes found: " + user.getName());
		}

		LOGGER.debug("In fetch data config");
		
		List<String> zzoverlayList = MARA.getSBrandValues(em);
		zzoverlayList.removeAll(Collections.singleton(null));
		if (zzoverlayList.size() > 0)
		{
			configWrapper.setZzoverlay(zzoverlayList);
		}
		
		List<String> zzsignatureList = MARA.getBrandValues(em);
		zzsignatureList.removeAll(Collections.singleton(null));
		if (zzsignatureList.size() > 0)
		{
			configWrapper.setZzsignature(zzsignatureList);
		}
		
		List<String> consumationfrom = PRICAT_K006.getConsumationFrom(em);
		consumationfrom.removeAll(Collections.singleton(null));
		if (consumationfrom.size() > 0)
		{
			configWrapper.setConsumationfrom(consumationfrom);
		}
		
		List<String> allergens = PRICAT_K006.getAllergens(em);
		allergens.removeAll(Collections.singleton(null));
		if (allergens.size() > 0)
		{
			configWrapper.setAllergens(allergens);
		}
		
		List<String> mvgr1list = MVKE.getMvgr1(em);
		mvgr1list.removeAll(Collections.singleton(null));
		if (mvgr1list.size() > 0)
		{
			configWrapper.setMvgr1(mvgr1list);
		}
		
		List<String> vmstalist = MVKE.getVmsta(em);
		vmstalist.removeAll(Collections.singleton(null));
		if (vmstalist.size() > 0)
		{
			configWrapper.setVmsta(vmstalist);
		}
		
		List<String> zzproductvarlist = MVKE.getZzproductvar(em);
		zzproductvarlist.removeAll(Collections.singleton(null));
		if (zzproductvarlist.size() > 0)
		{
			configWrapper.setZzproductvar(zzproductvarlist);
		}
		
		List<String> zzforcastunitlist = MVKE.getZzforcastunit(em);
		zzforcastunitlist.removeAll(Collections.singleton(null));
		if (zzforcastunitlist.size() > 0)
		{
			configWrapper.setZzforcastunit(zzforcastunitlist);
		}
		
		List<String> zzproces1 = MARA.getZzproces1(em);
		zzproces1.removeAll(Collections.singleton(null));
		if (zzproces1.size() > 0)
		{
			configWrapper.setZzproces1(zzproces1);
		}
		
		List<String> zzproces2 = MARA.getZzproces2(em);
		zzproces2.removeAll(Collections.singleton(null));
		if (zzproces2.size() > 0)
		{
			configWrapper.setZzproces2(zzproces2);
		}
		
		return Response.ok(configWrapper).build();
	}
}
