package com.danone.util;

public class CMSConfigWrapper {
	
	private String language;
	private String type;
	private Integer validFrom;
	private Integer validTo;
	private String documentName;	
	
		
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public Integer getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(Integer validFrom) {
		this.validFrom = validFrom;
	}
	public Integer getValidTo() {
		return validTo;
	}
	public void setValidTo(Integer validTo) {
		this.validTo = validTo;
	}	
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
