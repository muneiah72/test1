package com.danone.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.olingo.commons.api.edm.EdmPrimitiveTypeKind;
import org.apache.olingo.commons.api.edm.FullQualifiedName;
import org.apache.olingo.commons.api.edm.provider.CsdlAbstractEdmProvider;
import org.apache.olingo.commons.api.edm.provider.CsdlComplexType;
import org.apache.olingo.commons.api.edm.provider.CsdlEntityContainer;
import org.apache.olingo.commons.api.edm.provider.CsdlEntityContainerInfo;
import org.apache.olingo.commons.api.edm.provider.CsdlEntitySet;
import org.apache.olingo.commons.api.edm.provider.CsdlEntityType;
import org.apache.olingo.commons.api.edm.provider.CsdlNavigationProperty;
import org.apache.olingo.commons.api.edm.provider.CsdlNavigationPropertyBinding;
import org.apache.olingo.commons.api.edm.provider.CsdlProperty;
import org.apache.olingo.commons.api.edm.provider.CsdlPropertyRef;
import org.apache.olingo.commons.api.edm.provider.CsdlSchema;
import org.apache.olingo.server.api.uri.UriParameter;

public class ProductEdmProvider extends CsdlAbstractEdmProvider {
	
	  // Service Namespace
	  public static final String NAMESPACE = "OData.Product";

	  // EDM Container
	  public static final String CONTAINER_NAME = "Container";
	  public static final FullQualifiedName CONTAINER = new FullQualifiedName(NAMESPACE, CONTAINER_NAME);

	  // Entity Types Names
	  public static final String ET_PRODUCT_NAME = "Product";
	  public static final FullQualifiedName ET_PRODUCT_FQN = new FullQualifiedName(NAMESPACE, ET_PRODUCT_NAME);

	  public static final String ET_SALESORG_NAME = "SalesOrg";
	  public static final FullQualifiedName ET_SALESORG_FQN = new FullQualifiedName(NAMESPACE, ET_SALESORG_NAME);
	  
	  // Complex Type Names
	  public static final String CT_ALLERGENC_NAME = "AllergensContain";
	  public static final FullQualifiedName CT_ALLERGENC_FQN = new FullQualifiedName(NAMESPACE, CT_ALLERGENC_NAME);
	  public static final String CT_ALLERGENMC_NAME = "AllergensMayContain";
	  public static final FullQualifiedName CT_ALLERGENMC_FQN = new FullQualifiedName(NAMESPACE, CT_ALLERGENMC_NAME);
	  public static final String CT_ALLERGENNP_NAME = "AllergensNotPresent";
	  public static final FullQualifiedName CT_ALLERGENNP_FQN = new FullQualifiedName(NAMESPACE, CT_ALLERGENNP_NAME);
	  public static final String CT_NUTBOARD_NAME = "NutritionalValues";
	  public static final FullQualifiedName CT_NUTBOARD_FQN = new FullQualifiedName(NAMESPACE, CT_NUTBOARD_NAME);
	    
	  // Entity Set Names
	  public static final String ES_PRODUCTS_NAME = "Products";
	  public static final String ES_SALESORGS_NAME = "SalesOrgs";

	  @Override
	  public CsdlEntityType getEntityType(FullQualifiedName entityTypeName) {

	    // this method is called for each EntityType that are configured in the Schema
	    CsdlEntityType entityType = null;

	    if (entityTypeName.equals(ET_PRODUCT_FQN)) {
	      // create EntityType properties
	      List<CsdlProperty> propertyList = new ArrayList<CsdlProperty>();
	      // Code
	      propertyList.add(Util.defStringProperty("InternalCode"));
	      propertyList.add(Util.defStringProperty("EANCode"));
	      // Grouping
	      propertyList.add(Util.defStringProperty("LanguageISO"));
	      propertyList.add(Util.defDateProperty("LastUpdated"));
	      propertyList.add(Util.defStringProperty("Brand"));
	      propertyList.add(Util.defStringProperty("SubBrand"));
	      propertyList.add(Util.defStringProperty("Flavor"));
	      propertyList.add(Util.defIntegerProperty("By"));
	      propertyList.add(Util.defStringProperty("Promo"));
	      propertyList.add(Util.defStringProperty("Process1"));
	      propertyList.add(Util.defStringProperty("Process2"));
	      propertyList.add(Util.defStringProperty("PotDiameter"));
	      propertyList.add(Util.defStringProperty("Range"));
	      propertyList.add(Util.defStringProperty("Subrange"));
	      propertyList.add(Util.defStringProperty("MkgGroupI"));
	      propertyList.add(Util.defStringProperty("MkgGroupII"));
	      propertyList.add(Util.defStringProperty("MkgGroupIII"));
	      propertyList.add(Util.defStringProperty("MkgGroupIV"));
	      propertyList.add(Util.defStringProperty("ProdHier_L1"));
	      propertyList.add(Util.defStringProperty("ProdHier_L1_Desc"));
	      propertyList.add(Util.defStringProperty("ProdHier_L2"));
	      propertyList.add(Util.defStringProperty("ProdHier_L2_Desc"));
	      propertyList.add(Util.defStringProperty("ProdHier_L3"));
	      propertyList.add(Util.defStringProperty("ProdHier_L3_Desc"));
	      propertyList.add(Util.defStringProperty("ProdHier_L4"));
	      propertyList.add(Util.defStringProperty("ProdHier_L4_Desc"));
	      propertyList.add(Util.defStringProperty("ProdHier_L5"));
	      propertyList.add(Util.defStringProperty("ProdHier_L5_Desc"));
	      propertyList.add(Util.defStringProperty("ProdHier_L6"));
	      propertyList.add(Util.defStringProperty("ProdHier_L6_Desc"));
	      // Dimensions
	      propertyList.add(Util.defDoubleProperty("NetWeight_UC"));
	      propertyList.add(Util.defStringProperty("NetWeightUnit_UC"));
	      propertyList.add(Util.defDoubleProperty("NetWeight_UL"));
	      propertyList.add(Util.defStringProperty("NetWeightUnit_UL"));
	      propertyList.add(Util.defDoubleProperty("NetWeight_PAL"));
	      propertyList.add(Util.defStringProperty("NetWeightUnit_PAL"));
	      propertyList.add(Util.defDoubleProperty("GrossWeight_UC"));
	      propertyList.add(Util.defStringProperty("GrossWeightUnit_UC"));
	      propertyList.add(Util.defDoubleProperty("GrossWeight_UL"));
	      propertyList.add(Util.defStringProperty("GrossWeightUnit_UL"));
	      propertyList.add(Util.defDoubleProperty("GrossWeight_PAL"));
	      propertyList.add(Util.defStringProperty("GrossWeightUnit_PAL"));
	      propertyList.add(Util.defDoubleProperty("Volume_UC"));
	      propertyList.add(Util.defStringProperty("VolumeUnit_UC"));
	      propertyList.add(Util.defDoubleProperty("Volume_UL"));
	      propertyList.add(Util.defStringProperty("VolumeUnit_UL"));
	      propertyList.add(Util.defDoubleProperty("Volume_PAL"));
	      propertyList.add(Util.defStringProperty("VolumeUnit_PAL"));
	      propertyList.add(Util.defDoubleProperty("Length_UC"));
	      propertyList.add(Util.defStringProperty("LengthUnit_UC"));
	      propertyList.add(Util.defDoubleProperty("Length_UL"));
	      propertyList.add(Util.defStringProperty("LengthUnit_UL"));
	      propertyList.add(Util.defDoubleProperty("Length_PAL"));
	      propertyList.add(Util.defStringProperty("LengthUnit_PAL"));
	      propertyList.add(Util.defDoubleProperty("Width_UC"));
	      propertyList.add(Util.defStringProperty("WidthUnit_UC"));
	      propertyList.add(Util.defDoubleProperty("Width_UL"));
	      propertyList.add(Util.defStringProperty("WidthUnit_UL"));
	      propertyList.add(Util.defDoubleProperty("Width_PAL"));
	      propertyList.add(Util.defStringProperty("WidthUnit_PAL"));
	      propertyList.add(Util.defDoubleProperty("Height_UC"));
	      propertyList.add(Util.defStringProperty("HeightUnit_UC"));
	      propertyList.add(Util.defDoubleProperty("Height_UL"));
	      propertyList.add(Util.defStringProperty("HeightUnit_UL"));
	      propertyList.add(Util.defDoubleProperty("Height_PAL"));
	      propertyList.add(Util.defStringProperty("HeightUnit_PAL"));
//	      propertyList.add(Util.defDoubleProperty("NbOfUC"));
	      propertyList.add(Util.defDoubleProperty("NbOfUCPerUL"));
	      propertyList.add(Util.defDoubleProperty("NbOfUCPerPAL"));
	      propertyList.add(Util.defDoubleProperty("NbOfULPerPAL"));
	      propertyList.add(Util.defDoubleProperty("NbOfLayer"));
	      propertyList.add(Util.defDoubleProperty("NbPerLayer"));
	      // Descriptions
	      propertyList.add(Util.defStringProperty("ShortDescription"));
	      propertyList.add(Util.defStringProperty("DescriptionLong"));
	      propertyList.add(Util.defStringProperty("IngredientList"));	      
	      propertyList.add(Util.defStringProperty("ConsumptionAge"));	      
	      propertyList.add(Util.defStringProperty("LegalDenomination"));	      
	      propertyList.add(Util.defStringProperty("MentionConsBefore"));	      
	      propertyList.add(Util.defStringProperty("MentionConsAfter"));	      
	      propertyList.add(Util.defStringProperty("RegulatoryMentions"));	      
	      propertyList.add(Util.defStringProperty("AdviseOfUse"));	      
	      propertyList.add(Util.defStringProperty("NoticeMilk"));	      
	      propertyList.add(Util.defStringProperty("Indication"));	      
	      propertyList.add(Util.defStringProperty("InstructionsUse"));	      
	      propertyList.add(Util.defStringProperty("InstructionsUseLight"));	      
	      // Allergens
//	      propertyList.add(Util.defComplexProperty("AllergensContain", CT_ALLERGENC_FQN, false));
	      propertyList.add(Util.defComplexProperty("AllergensContainColl", CT_ALLERGENC_FQN, true));
//	      propertyList.add(Util.defComplexProperty("AllergensMayContain", CT_ALLERGENMC_FQN, false));
	      propertyList.add(Util.defComplexProperty("AllergensMayContainColl", CT_ALLERGENMC_FQN, true));
//	      propertyList.add(Util.defComplexProperty("AllergensNotPresent", CT_ALLERGENNP_FQN, false));
	      propertyList.add(Util.defComplexProperty("AllergensNotPresentColl", CT_ALLERGENNP_FQN, true));

	      // Nutritional values
//	      propertyList.add(Util.defComplexProperty("NutritionalValues", CT_NUTBOARD_FQN, false));
	      propertyList.add(Util.defComplexProperty("NutritionalValuesColl", CT_NUTBOARD_FQN, true));
	      // General
	      propertyList.add(Util.defStringProperty("DescriptionComm"));
	      propertyList.add(Util.defStringProperty("DescriptionWeb"));	      
	      propertyList.add(Util.defStringProperty("MkgFormat"));	      
	      propertyList.add(Util.defStringProperty("ConsumptionTime"));
	      propertyList.add(Util.defStringProperty("Click2Buy"));
	      propertyList.add(Util.defStringProperty("Texture"));	      
	      propertyList.add(Util.defStringProperty("AdditionalIngredients"));	      
	      propertyList.add(Util.defStringProperty("Benefits"));	      
	      propertyList.add(Util.defStringProperty("MkgOther"));	      
	      propertyList.add(Util.defStringProperty("CountryOfOrigin"));	      
	      propertyList.add(Util.defStringProperty("GoodSupplierAgreement"));	      
	      propertyList.add(Util.defStringProperty("CEEGoodSupplierAgreement"));	      
	      propertyList.add(Util.defStringProperty("MilkyProducts"));	      
	      propertyList.add(Util.defStringProperty("GMO"));	      
	      propertyList.add(Util.defStringProperty("OrganicBio"));	      
	      propertyList.add(Util.defStringProperty("Brick"));	      
	      propertyList.add(Util.defStringProperty("CustomsList"));	      
	      propertyList.add(Util.defStringProperty("ShelfLifeDelivery"));
	      propertyList.add(Util.defStringProperty("ShelfLifeProduction"));	      
	      // create PropertyRef for Key element
	      CsdlPropertyRef propertyRef = new CsdlPropertyRef();
	      propertyRef.setName("InternalCode");

	      // navigation property: many-to-one, null not allowed (product must have a SalesOrg)
	      CsdlNavigationProperty navProp = new CsdlNavigationProperty().setName("SalesOrg")
	          .setType(ET_SALESORG_FQN).setNullable(false).setPartner("Products");
	      List<CsdlNavigationProperty> navPropList = new ArrayList<CsdlNavigationProperty>();
	      navPropList.add(navProp);

	      // configure EntityType
	      entityType = new CsdlEntityType();
	      entityType.setName(ET_PRODUCT_NAME);
	      entityType.setProperties(propertyList);
	      entityType.setKey(Arrays.asList(propertyRef));
	      entityType.setNavigationProperties(navPropList);

	    } else if (entityTypeName.equals(ET_SALESORG_FQN)) {
	      // create EntityType properties
	      CsdlProperty vkorg = new CsdlProperty().setName("SalesOrg")
	          .setType(EdmPrimitiveTypeKind.String.getFullQualifiedName());
	      CsdlProperty vtweg = new CsdlProperty().setName("DistCh")
		      .setType(EdmPrimitiveTypeKind.String.getFullQualifiedName());
	      CsdlProperty vkorgDescr = new CsdlProperty().setName("SalesOrgDescr")
	          .setType(EdmPrimitiveTypeKind.String.getFullQualifiedName());
		  CsdlProperty vtwegDescr = new CsdlProperty().setName("DistChDescr")
	          .setType(EdmPrimitiveTypeKind.String.getFullQualifiedName());
	      // create PropertyRef for Key element
	      CsdlPropertyRef salesOrgRef = new CsdlPropertyRef();
	      salesOrgRef.setName("SalesOrg");
	      CsdlPropertyRef distChRef = new CsdlPropertyRef();
	      distChRef.setName("DistCh");
	      
	      // navigation property: one-to-many
	      CsdlNavigationProperty navProp2 = new CsdlNavigationProperty().setName("Products")
	          .setType(ET_PRODUCT_FQN).setCollection(true).setPartner("SalesOrg");
	      List<CsdlNavigationProperty> navPropList2 = new ArrayList<CsdlNavigationProperty>();
	      navPropList2.add(navProp2);

	      // configure EntityType
	      entityType = new CsdlEntityType();
	      entityType.setName(ET_SALESORG_NAME);
	      entityType.setProperties(Arrays.asList(vkorg, vtweg, vkorgDescr, vtwegDescr));
	      entityType.setKey(Arrays.asList(salesOrgRef, distChRef));
	      entityType.setNavigationProperties(navPropList2);
	    }

	    return entityType;

	  }

	  @Override
	  public CsdlComplexType getComplexType(FullQualifiedName complexTypeName) {

	    // this method is called for each EntityType that are configured in the Schema
	    CsdlComplexType complexType = null;

	    if (complexTypeName.equals(CT_ALLERGENC_FQN)) {
	    	// create EntityType properties
	    	List<CsdlProperty> propertyList = new ArrayList<CsdlProperty>();
	    	propertyList.add(Util.defStringProperty("AllergensContainCode"));
	    	propertyList.add(Util.defStringProperty("AllergensContainCodeDesc"));
	    	// configure ComplexType
	    	complexType = new CsdlComplexType();
	    	complexType.setName(CT_ALLERGENC_NAME);
	    	complexType.setProperties(propertyList);
	    } else if (complexTypeName.equals(CT_ALLERGENMC_FQN)) {
	    	// create EntityType properties
	    	List<CsdlProperty> propertyList = new ArrayList<CsdlProperty>();
	    	propertyList.add(Util.defStringProperty("AllergensMayContainCode"));
	    	propertyList.add(Util.defStringProperty("AllergensMayContainCodeDesc"));
	    	// configure ComplexType
	    	complexType = new CsdlComplexType();
	    	complexType.setName(CT_ALLERGENMC_NAME);
	    	complexType.setProperties(propertyList);
	    } else if (complexTypeName.equals(CT_ALLERGENNP_FQN)) {
	    	// create EntityType properties
	    	List<CsdlProperty> propertyList = new ArrayList<CsdlProperty>();
	    	propertyList.add(Util.defStringProperty("AllergensNotPresentCode"));
	    	propertyList.add(Util.defStringProperty("AllergensNotPresentCodeDesc"));
	    	// configure ComplexType
	    	complexType = new CsdlComplexType();
	    	complexType.setName(CT_ALLERGENNP_NAME);
	    	complexType.setProperties(propertyList);
	  } else if (complexTypeName.equals(CT_NUTBOARD_FQN)) {
	    	// create EntityType properties
	    	List<CsdlProperty> propertyList = new ArrayList<CsdlProperty>();
	    	propertyList.add(Util.defStringProperty("ServingSize"));
	    	propertyList.add(Util.defStringProperty("UnitServingSize"));
	    	propertyList.add(Util.defStringProperty("ServingSizeDesc"));
	    	propertyList.add(Util.defIntegerProperty("RankNutrients"));
	    	propertyList.add(Util.defStringProperty("NutrientCode"));
	    	propertyList.add(Util.defStringProperty("NutrientCodeDesc"));
	    	propertyList.add(Util.defDoubleProperty("ValueNutrient"));
	    	propertyList.add(Util.defDoubleProperty("ValueRoundedNutrient"));
	    	propertyList.add(Util.defStringProperty("UnitValueNutrient"));
	    	propertyList.add(Util.defDoubleProperty("AJRC"));
	    	propertyList.add(Util.defStringProperty("AJRCUnit"));
	    	propertyList.add(Util.defStringProperty("SignNutrient"));
	    	// configure ComplexType
	    	complexType = new CsdlComplexType();
	    	complexType.setName(CT_NUTBOARD_NAME);
	    	complexType.setProperties(propertyList);
	    }
		return complexType;
	  }
	  
	  @Override
	  public CsdlEntitySet getEntitySet(FullQualifiedName entityContainer, String entitySetName) {

	    CsdlEntitySet entitySet = null;

	    if (entityContainer.equals(CONTAINER)) {

	      if (entitySetName.equals(ES_PRODUCTS_NAME)) {

	        entitySet = new CsdlEntitySet();
	        entitySet.setName(ES_PRODUCTS_NAME);
	        entitySet.setType(ET_PRODUCT_FQN);

	        // navigation
	        CsdlNavigationPropertyBinding navPropBinding = new CsdlNavigationPropertyBinding();
	        navPropBinding.setTarget("SalesOrgs"); // the target entity set, where the navigation property points to
	        navPropBinding.setPath("SalesOrgs"); // the path from entity type to navigation property
	        List<CsdlNavigationPropertyBinding> navPropBindingList = new ArrayList<CsdlNavigationPropertyBinding>();
	        navPropBindingList.add(navPropBinding);
	        entitySet.setNavigationPropertyBindings(navPropBindingList);

	      } else if (entitySetName.equals(ES_SALESORGS_NAME)) {

	        entitySet = new CsdlEntitySet();
	        entitySet.setName(ES_SALESORGS_NAME);
	        entitySet.setType(ET_SALESORG_FQN);

	        // navigation
	        CsdlNavigationPropertyBinding navPropBinding = new CsdlNavigationPropertyBinding();
	        navPropBinding.setTarget("Products"); // the target entity set, where the navigation property points to
	        navPropBinding.setPath("Products"); // the path from entity type to navigation property
	        List<CsdlNavigationPropertyBinding> navPropBindingList = new ArrayList<CsdlNavigationPropertyBinding>();
	        navPropBindingList.add(navPropBinding);
	        entitySet.setNavigationPropertyBindings(navPropBindingList);
	      }
	    }

	    return entitySet;
	  }

	  @Override
	  public CsdlEntityContainerInfo getEntityContainerInfo(FullQualifiedName entityContainerName) {

	    // This method is invoked when displaying the service document at
	    // e.g. http://localhost:8080/DemoService/DemoService.svc
	    if (entityContainerName == null || entityContainerName.equals(CONTAINER)) {
	      CsdlEntityContainerInfo entityContainerInfo = new CsdlEntityContainerInfo();
	      entityContainerInfo.setContainerName(CONTAINER);
	      return entityContainerInfo;
	    }

	    return null;
	  }

	  @Override
	  public List<CsdlSchema> getSchemas() {
	    // create Schema
	    CsdlSchema schema = new CsdlSchema();
	    schema.setNamespace(NAMESPACE);

	    // add EntityTypes
	    List<CsdlEntityType> entityTypes = new ArrayList<CsdlEntityType>();
	    entityTypes.add(getEntityType(ET_PRODUCT_FQN));
	    entityTypes.add(getEntityType(ET_SALESORG_FQN));
	    schema.setEntityTypes(entityTypes);
	    
	    // ComplexTypes
	    List<CsdlComplexType> complexTypes = new ArrayList<CsdlComplexType>();
	    complexTypes.add(getComplexType(CT_ALLERGENC_FQN));
	    complexTypes.add(getComplexType(CT_ALLERGENMC_FQN));
	    complexTypes.add(getComplexType(CT_ALLERGENNP_FQN));
	    complexTypes.add(getComplexType(CT_NUTBOARD_FQN));
	    schema.setComplexTypes(complexTypes);
	    
	    // add EntityContainer
	    schema.setEntityContainer(getEntityContainer());

	    // finally
	    List<CsdlSchema> schemas = new ArrayList<CsdlSchema>();
	    schemas.add(schema);

	    return schemas;
	  }

	  @Override
	  public CsdlEntityContainer getEntityContainer() {

	    // create EntitySets
	    List<CsdlEntitySet> entitySets = new ArrayList<CsdlEntitySet>();
	    entitySets.add(getEntitySet(CONTAINER, ES_PRODUCTS_NAME));
	    entitySets.add(getEntitySet(CONTAINER, ES_SALESORGS_NAME));

	    // create EntityContainer
	    CsdlEntityContainer entityContainer = new CsdlEntityContainer();
	    entityContainer.setName(CONTAINER_NAME);
	    entityContainer.setEntitySets(entitySets);

	    return entityContainer;
	  }
	
	
}
