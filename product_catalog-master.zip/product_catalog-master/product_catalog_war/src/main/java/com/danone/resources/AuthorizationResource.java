package com.danone.resources;

import java.net.HttpURLConnection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.AUTHORIZATION;
import com.danone.persistence.PersistenceAdapter;

@Path("/authorization")
public class AuthorizationResource {
	
	private final Logger LOGGER = LoggerFactory.getLogger(AuthorizationResource.class);
	
	@Context
	private HttpServletRequest servletRequest;
	
	@GET
	public Response getAuthorization() {
		LOGGER.debug("In fetch authorization");
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		List<AUTHORIZATION> authList = AUTHORIZATION.getAllAuthorizations(em);
		
		if (authList.isEmpty()) {
			return Response.ok().build();
		}
		
		return Response.ok(authList).build();
	}
	
	@POST
	@Path("{role}/")
	public Response deleteAuthorization(@PathParam("role") String role){
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		if (role == null)
		{
			return Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("An error occured while deleting this authorization").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		try {
			transaction.begin();
			AUTHORIZATION toBeRemoved = AUTHORIZATION.getAuthorizationByRole(em, role);
			em.remove(toBeRemoved);
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to delete Authorization via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		
		response = Response.ok().build();
		
		return response;
	}
	
	@PUT
	public Response modifyAuthorization(AUTHORIZATION auth) {
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		if (auth == null)
		{
			return Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("An error occured while modifying this authorization").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		transaction.begin();
		try {
			AUTHORIZATION exists = AUTHORIZATION.getAuthorizationByRole(em, auth.getRole());
			exists.setArchived(auth.getArchived());
			exists.setDraft(auth.getDraft());
			exists.setPublished_consommateur(auth.getPublished_consommateur());
			exists.setPublished_distributeur(auth.getPublished_distributeur());
			exists.setValidated(auth.getValidated());
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to update Authorization via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		response = Response.ok().build();
		return response;
	}

	@POST
	public Response createAuthorization(AUTHORIZATION auth) {
		
		if (!servletRequest.isUserInRole(Roles.SUPERADMIN)) {
			return Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the required authorizations").build();
		}
		
		if (auth == null)
		{
			return Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("An error occured while creating this authorization").build();
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		try {
			AUTHORIZATION exists = AUTHORIZATION.getAuthorizationByRole(em, auth.getRole());
			
			if (exists != null) {
				LOGGER.error("Authorization exists already");
				response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("Authorization exists already")
						.build();
				return response;
			}
			transaction.begin();
			em.persist(auth);
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to create Authorization via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		
		response = Response.ok().build();
		return response;
	}
}
