package com.danone.rest;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.danone.resources.AuthorizationResource;
import com.danone.resources.CompanySorgResource;
import com.danone.resources.CMSCarouselResource;
import com.danone.resources.CMSDocumentResource;
import com.danone.resources.ConfigResource;
import com.danone.resources.PictureResource;
import com.danone.resources.ReplicationInfoResource;
import com.danone.resources.ReplicationInfoTextResource;
import com.danone.resources.SearchResource;
import com.danone.resources.ProductDetailResource;
import com.danone.resources.VerifyAuth;
//import com.danone.resources.UserSorgResource;

/**
 * This class is used for declaring the restful services that are being offered.
 */
public class RestRegistry extends Application {

	private Set<Object> singletons = new HashSet<Object>();
	
	public RestRegistry() {
		
		singletons.add(new GsonMessageBodyHandler<Object>());
		singletons.add(new SearchResource());
		singletons.add(new ConfigResource());
		singletons.add(new ProductDetailResource());
		singletons.add(new ReplicationInfoResource());
		singletons.add(new ReplicationInfoTextResource());
		singletons.add(new PictureResource());
		singletons.add(new AuthorizationResource());
		singletons.add(new CompanySorgResource());
		singletons.add(new CMSDocumentResource());
		singletons.add(new CMSCarouselResource());
		singletons.add(new VerifyAuth());
//		singletons.add(new UserSorgResource());
	}
	
	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}
}
