package com.danone.proxy;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.util.EntityUtils;

public class CacheAdmin extends HttpServlet {
	private static final long serialVersionUID = 7818779874272330669L;
	private static final Map<Integer, String> requestIDs = new HashMap<Integer, String>();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.addHeader("Content-type", "text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		//response.setContentType("text/html");
		printHTMLStart(out);
		handleAction(request, response, out);
		out.write("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		this.doGet(request, response);
	}

	private void handleAction(HttpServletRequest request, HttpServletResponse response, PrintWriter out)
			throws IOException {
		String action = request.getParameter("action");
		LRUCache<String, CacheEntry2> cache = ProxyServlet.getCache();
		if (cache == null) {
			out.write("No cache instanciated, you must first call the proxy servlet once, before you can access Cache Admin");
			return;
		}
		printMenue(out, request, cache);
		if (action == null) {
			return;
		} else if (action.equals("showCache")) {
			printCache(out, cache, request);
		} else if (action.equals("clear")) {
			ProxyUtil.writeClearCacheCommand();
			out.write("Cache will be cleared. This can take up to 1 min.<br><a href=\"/product_catalog_war/CacheAdmin\">Back to cache view</a>");
			return;
		} else if (action.equals("delete")) {
			String requestID = request.getParameter("requestID");
			if (requestID != null) {
				String requestURI = requestIDs.get(Integer.parseInt(requestID));
				if (requestURI != null) {
					ProxyUtil.writeDeleteEntryCommand(requestURI);
					out.write("Cache entry will be deleted. This can take up to 1 min.<br><a href=\"/product_catalog_war/CacheAdmin\">Back to cache view</a>");
				} else {
					out.write("Error, cache entry not found <br><a href=\"/product_catalog_war/CacheAdmin\">Back to cache view</a>");
				}
			}
			return;
		} else if (action.equals("activate")) {
			ProxyUtil.writeActivateCacheCommand("true");
			out.write("Cache will be activated. This can take up to 1 min.<br><a href=\"/product_catalog_war/CacheAdmin\">Back to cache view</a>");
			return;
		} else if (action.equals("deactivate")) {
			ProxyUtil.writeActivateCacheCommand("false");
			out.write("Cache deactivated. This can take up to 1 min.<br><a href=\"/product_catalog_war/CacheAdmin\">Back to cache view</a>");
			return;
		} else {
			out.write("Action parameter " + action + " does not exist");
			return;
		}

	}

	private void printHTMLStart(PrintWriter out) {
		out.write("<!DOCTYPE HTML>\n");
		out.write("<html><head><title>Cache Administration</title></head><body>\n");
	}

	private void printMenue(PrintWriter out, HttpServletRequest request, LRUCache<String, CacheEntry2> cache) {
		out.write("Server node: " + getServerCookie(request) + "<br>");
		out.write("Current Cache Size: " + cache.entrySet().size() + " (least recently used entry is on top)<br>");
		out.write("Cache status: " + (ProxyServlet.cacheActive() ? "active" : "not active") + "<br>");
		if (ProxyServlet.cacheActive()) {
			out.write(" * <a href=\"?action=deactivate\"> Deactivate cache</a><br>");
		} else {
			out.write(" * <a href=\"?action=activate\"> Activate cache</a><br>");
		}

		out.write(" * <a href=\"?action=showCache\"> Show complete cache</a><br>");

		out.write(" * <a href=\"?action=clear\"> Clear complete cache</a><br>");

		out.write("<form action=\"?action=delete\" method=\"POST\" accept-charset=\"UTF-8\">\n");
		out.write(" * Clear single entry: <input type=\"text\" name=\"requestID\" size=3>");
		out.write("<input type=\"submit\" value=\"Delete\">");
		out.write("</form><br><br>\n");
	}

	private void printCache(PrintWriter out, LRUCache<String, CacheEntry2> cache, HttpServletRequest request)
			throws IOException {
		requestIDs.clear();
		out.write("\n<table width=\"100%\" border=\"1\" style=\"table-layout:fixed; border-spacing: 0px\">\n");
		out.write("<colgroup><col width=\"50px\"><col width=\"600px\"><col width=\"600px\"></colgroup>\n");
		out.write("<tr><th>Nr.</th><th>Client Request</th><th>Backend Response</th></tr>\n");
		int i = 0;
		synchronized (cache) {
			for (Map.Entry<String, CacheEntry2> entry : cache.entrySet()) {
				i++;
				CacheEntry2 cacheEntry = entry.getValue();
				out.write("<tr><td>" + i + "</td>\n<td><div style=\"height:250px; overflow:scroll\">"
						+ requestToHTMLString(cacheEntry.getClientRequest())
						+ "</div></td>\n<td><div style=\"height:250px; overflow:scroll\">"
						//+ responseToHTMLString(cacheEntry.getBackendResponse()) + "</div></td>\n</tr>\n");
				        + cacheEntry.getBackendResponse() + "</div></td>\n</tr>\n");
				requestIDs.put(Integer.valueOf(i), cacheEntry.getClientRequest().getCompleteRequestURI());
			}
		}
		out.write("</table>");
	}

	private String requestToHTMLString(ProxyRequest request) throws IOException {
		StringBuffer sb = new StringBuffer();
		sb.append(request.getMethod()).append(" ").append(request.getCompleteRequestURI())
				.append("<br>------------------------------------------------------------------------<br>");
		for (Map.Entry<String, String> header : request.getHeaders().entrySet()) {
			sb.append("<b>").append(header.getKey()).append("</b>").append(" : ").append(header.getValue())
					.append("<br>");
		}
		sb.append("------------------------------------------------------------------------<br>");
		if (request.getEntity() != null) {
			sb.append(EntityUtils.toString(request.getEntity(), "UTF-8")).append("<br>");
		}
		return sb.toString();
	}

	private String responseToHTMLString(HttpResponse response) throws IOException {
		StringBuffer sb = new StringBuffer();
		sb.append("Status: ").append(response.getStatusLine().getStatusCode())
				.append("<br>------------------------------------------------------------------------<br>");
		for (Header header : response.getAllHeaders()) {
			sb.append("<b>").append(header.getName()).append("</b>").append(" : ").append(header.getValue())
					.append("<br>");
		}
		sb.append("------------------------------------------------------------------------<br>");
		HttpEntity entity = response.getEntity();
		if (entity != null) {
			Header header = entity.getContentEncoding();
			if (header != null && header.getValue().contains("gzip")) {
				entity = new GzipDecompressingEntity(entity);
			}
			sb.append(EntityUtils.toString(entity, "UTF-8")).append("<br>");
		}
		return sb.toString();
	}

	private String getServerCookie(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().startsWith("BIGipServer")) {
					return cookie.getValue();
				}
			}
		}
		return "";
	}
}
