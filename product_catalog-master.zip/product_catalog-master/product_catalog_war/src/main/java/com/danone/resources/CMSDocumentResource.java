package com.danone.resources;

import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.CMSCAROUSEL;
import com.danone.entities.CMSCONFIG;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.CMSConfigWrapper;
import com.danone.util.CarouselWrapper;

@Path("/cmsdocument")
@Produces({ MediaType.APPLICATION_JSON })
public class CMSDocumentResource {
	private final Logger logger = LoggerFactory.getLogger(CMSDocumentResource.class);

	@Context
	private HttpServletRequest servletRequest;

	@GET
	public Response getAllDocuments() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {
			List<CMSCONFIG> allDocuments = CMSCONFIG.getAllDocuments(em);
			List<CMSConfigWrapper> allCMSDocuments = new ArrayList<CMSConfigWrapper>();
			for (CMSCONFIG document : allDocuments) {
				CMSConfigWrapper doc = new CMSConfigWrapper();
				doc.setType(document.getKey().getType());
				doc.setValidFrom(document.getKey().getValidFrom());
				doc.setValidTo(document.getKey().getValidTo());
				doc.setLanguage(document.getKey().getLanguage());
				doc.setDocumentName(document.getDocumentName());				
				allCMSDocuments.add(doc);				
			}	
			return Response.ok(allCMSDocuments).build();
		} finally {
			em.close();
		}
	}
	
	@DELETE
	public Response deleteDocument(CMSCONFIG item) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;
		
		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}		

		boolean error = false;
		try {
			CMSCONFIG itemToDelete = CMSCONFIG.getDocumentByKey(em, item.getKey());
			if (itemToDelete != null) {
				transaction.begin();
				em.remove(itemToDelete);
				transaction.commit();
			}

		} catch (PersistenceException e) {
			logger.error("Failed to delete Webshop document via REST", e);
			error = true;
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}

		if (error) {
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
					.entity("An error occurred when deleting one or more resource").build();
		} else {
			response = Response.status(HttpURLConnection.HTTP_OK).build();
		}

		return response;
	}

	@Path("multipledelete")
	@PUT
	public Response deleteDocuments(List<CMSCONFIG> list) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = null;
		Response response;

		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}
		
		boolean error = false;	
		logger.debug("number of entrees to delete: " + list.size());
		logger.debug("before for");
		for (CMSCONFIG item : list)
		{
			logger.debug("in for");
			
			try {
				transaction = em.getTransaction();
				logger.debug("getDocumentByKey: " + item.getKey().toString());
				CMSCONFIG itemToDelete = CMSCONFIG.getDocumentByKey(em, item.getKey());
				logger.debug("before itemToDelete check ");
				if (itemToDelete != null) {
					transaction.begin();
					em.remove(itemToDelete);
					transaction.commit();
				} else {
					error = true;
				}

			} catch (PersistenceException e) {
				logger.error("Failed to delete document via REST", e);
				error = true;
			} finally {
				if (transaction != null && transaction.isActive()) {
					transaction.rollback();
				}
			}
		}
		
		
//		try {
//			logger.debug("before iterator");
//			Iterator<CMSCONFIG> it = list.iterator();
//			CMSCONFIG item;
//			logger.debug("before while");		
//			while (it.hasNext()) {
//				item = it.next();
//				try {
//					transaction = em.getTransaction();
//					logger.debug("getDocumentByKey: " + item.getKey().toString());
//					CMSCONFIG itemToDelete = CMSCONFIG.getDocumentByKey(em, item.getKey());
//					logger.debug("before itemToDelete check ");
//					if (itemToDelete != null) {
//						transaction.begin();
//						em.remove(itemToDelete);
//						transaction.commit();
//					} else {
//						error = true;
//					}
//
//				} catch (PersistenceException e) {
//					logger.error("Failed to delete Webshop document via REST", e);
//					error = true;
//				} finally {
//					if (transaction != null && transaction.isActive()) {
//						transaction.rollback();
//					}
//
//				}
//			}
//
//		} catch (PersistenceException e) {
//			logger.error("Failed to delete Webshop document", e);
//			error = true;
//		}
				
		em.close();
		if (error) {
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
					.entity("An error occurred when deleting one or more resource").build();
		} else {
			response = Response.status(HttpURLConnection.HTTP_OK).build();
		}

		return response;
	}

	@Path("single")
	@POST
	public Response createDocument(CMSCONFIG webshopDocument) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}

		try {
			CMSCONFIG exists = CMSCONFIG.getDocumentByKey(em, webshopDocument.getKey());
			if (exists != null) {
				logger.error("The entry exists already");
				response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).entity("The entry exists already")
						.build();
				return response;
			}

			transaction.begin();
			em.persist(webshopDocument);
			transaction.commit();
		} catch (PersistenceException e) {
			logger.error("Failed to create document via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		response = Response.created(UriBuilder.fromPath("/webshopdocument/{id}").build(webshopDocument.getKey()))
				.entity(webshopDocument).build();
		return response;
	}

	@Path("multiple")
	@POST
	public Response createDocuments(List<CMSCONFIG> list) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = null;
		Response response;

		if (!servletRequest.isUserInRole(Roles.ADMIN)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}
		
		Iterator<CMSCONFIG> it = list.iterator();
		CMSCONFIG item;
		boolean error = false;
		while (it.hasNext()) {
			try {
				transaction = em.getTransaction();
				item = it.next();
				CMSCONFIG exists = CMSCONFIG.getDocumentByKey(em, item.getKey());
				transaction.begin();
				if (exists != null) {
					// the entry exists, let's update it
					exists.setDocument(item.getDocument());
					exists.setDocumentName(item.getDocumentName());
					transaction.commit();
				} else {
					em.persist(item);
					transaction.commit();
				}
			} catch (PersistenceException e) {
				logger.error("Failed to create or update document via REST", e);
				error = true;
			} finally {
				if (transaction != null && transaction.isActive()) {
					transaction.rollback();
				}

			}
		}

		em.close();
		if (error) {
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR)
					.entity("An error occurred when saving one or more entries").build();
		} else {
			response = Response.status(HttpURLConnection.HTTP_CREATED).build();
		}

		return response;
	}
}
