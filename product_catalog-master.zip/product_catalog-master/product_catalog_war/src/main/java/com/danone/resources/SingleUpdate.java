package com.danone.resources;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.cron.UpdateDB;
import com.danone.persistence.PersistenceAdapter;

public class SingleUpdate extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 579835700808255163L;
	private final Logger LOGGER = LoggerFactory.getLogger(SingleUpdate.class);
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
		Enumeration<String> enumer = request.getParameterNames();
		JSONObject params = null;
		if (enumer.hasMoreElements())
		{
			String jsonString = enumer.nextElement();
			LOGGER.debug("JSON String: " + jsonString);
			params = new JSONObject(jsonString);
		}
		
		response.setCharacterEncoding("UTF-8");
		response.addHeader("Content-type", "application/json; charset=utf-8");
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-cache, no-store");
		
		String guid = null;
		String system = null;
		if (params != null)
		{
			guid = params.getString("GUID");
			system = params.getString("SYSTEM");
		}
		
		LOGGER.debug("GUID: " + guid);
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		
		try {
			UpdateDB db = UpdateDB.getInstance();
			db.startSingle(guid, system);
		} catch (Exception e)
		{
			LOGGER.debug("Error updating single entry: " + e.toString());
		} finally {
			em.close();
		}
		
		response.setStatus(HttpServletResponse.SC_OK);
		
		PrintWriter responseWriter = response.getWriter();
		responseWriter.print("Success");
		return;
	}
}
