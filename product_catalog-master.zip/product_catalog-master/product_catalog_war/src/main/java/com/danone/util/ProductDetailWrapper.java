package com.danone.util;

import java.util.List;

public class ProductDetailWrapper {
		
	//ZPRODCAT_HDR
	private String system;
	private Integer mandt;
	private String cat_guid;
	private String vkorg;
	private String vtweg;
	private String prinbr;
	private String status;
	private String productgroup;
	private java.sql.Date last_update;
	
	//ZPRODCAT_ITEM
	private String ean_upc_base;
	private java.sql.Date validity_base;
	
	//Versions
	private List<VersionWrapper> versionList;
	
	//Pictures
	private List<PictureWrapper> pictureList;
	
	//Documents
	private List<PictureWrapper> documentList;
	
	//MARA
	private String matnr;
	private String zzsignature;
	private String zzoverlay;
	private Integer zzcapacity;
	private Integer zzby;
	private double mhdhb;
	private String zzprocess1;
	private String zzprocess2;	
	private Integer stfak;
	private String brand;
	private String subbrand;
	private String flavor;
	private String process1;
	private String process2;
	private String potdiameter;
	private String range;
	private String subrange;

	//MARC
	private String herkl;
	
	//MAKT
	private String maktx;

	//MVKE
	private String zzproductvar;
	private String zzforcastunit;
	private String mvgr1;
	private String prodh;
	private String promo;
	private String prodhl1desc;
	private String prodhl2desc;
	private String prodhl3desc;
	private String prodhl4desc;
	private String prodhl5desc;
	private String prodhl6desc;
	private String zzmarki;
	private String zzmarkii;
	private String zzmarkiii;
	private String zzmarkiv;

	// private java.sql.Date zzlaunchdate;
	
	//PRICAT_K003Z
	private String comm_code;
	
	//PRICAT_K004
	private List<UoMWrapper> uomlist;
	
	//PRICAT_K005
	private String ingredientlist;
	private String beforeopening;
	private String afteropening;
	private String storagecond;
	private String zcmetext;
	private String claim1;
	private String claim2;
	private String claim3;
	private String claim4;
	private String claim5;
	private String consumptionmoment;
	private String ecatdescription;
	private String internetdescription;
	private String marketingtexts;
	private String commercialDescription;
	private String instructionsuse;
	private String instructionsuselight;
	private String format;
	private String mktexture;
	private String mkingredient;
	private String mkbenefits;
	private String mkother;
	private String stddescription;
	
	//PRICAT_K006
	private String code_labelling;
	private String mentions;
	private String project_code;
	private String legaldeno;
	private String agreement;
	private String tradename;
	private String regulatory;
	private String adviseuse;
	private String noticemilk;
	private String specificindic;
	private String regulcce;
	private List<AllergenWrapper> allergenList;
	private List<AllergenDetailWrapper> allergensContainList;
	private List<AllergenDetailWrapper> allergensMayContainList;
	private List<AllergenDetailWrapper> allergensNotPresentList;
	private String allergen_contain;
	private String allergen_may_contain;
	private String cross_contamination;
	private String consumptionage;
	private String consumptiontime;
	private String lifetime_day;
	private String dlsc;
	private String consigne;
	private String palettisation;
	private String artemis_sku;
	private String goodsupplier;
	private String milkyproduct;
	private String gmo;
	private String organic;
	private String brick;
	private String click2buy;
	
	//Multipacks
	private List<MultipackWrapper> multiList;
	
	//Nutritional data
	private List<NutboardWrapper> nutboard;
	
	public String getMaktx() {
		if (maktx != null)
		{
			return maktx;	
		}else {
			return "";
		}
	}

	public void setMaktx(String maktx) {
		this.maktx = maktx;
	}

	public String getZzsignature() {
		if (zzsignature != null)
		{
			return zzsignature;	
		}else {
			return "";
		}
	}

	public void setZzsignature(String zzsignature) {
		this.zzsignature = zzsignature;
	}

	public String getZzoverlay() {
		if (zzoverlay != null)
		{
			return zzoverlay;	
		}else {
			return "";
		}
	}

	public void setZzoverlay(String zzoverlay) {
		this.zzoverlay = zzoverlay;
	}

	public Integer getZzcapacity() {
		if (zzcapacity != null)
		{
			return zzcapacity;	
		}else {
			return 0;
		}
	}

	public void setZzcapacity(Integer zzcapacity) {
		this.zzcapacity = zzcapacity;
	}

	public Integer getZzby() {
		if (zzby != null)
		{
			return zzby;	
		}else {
			return 0;
		}
	}

	public void setZzby(Integer zzby) {
		this.zzby = zzby;
	}

	public double getMhdhb() {
		return mhdhb;	
	}

	public void setMhdhb(double mhdhb) {
		this.mhdhb = mhdhb;
	}

	public String getZzprocess1() {
		if (zzprocess1 != null)
		{
			return zzprocess1;	
		}else {
			return "";
		}
	}

	public void setZzprocess1(String zzprocess1) {
		this.zzprocess1 = zzprocess1;
	}

	public String getZzprocess2() {
		if (zzprocess2 != null)
		{
			return zzprocess2;	
		}else {
			return "";
		}
	}

	public void setZzprocess2(String zzprocess2) {
		this.zzprocess2 = zzprocess2;
	}

	public String getHerkl() {
		if (herkl != null)
		{
			return herkl;	
		}else {
			return "";
		}
	}

	public void setHerkl(String herkl) {
		this.herkl = herkl;
	}

	public String getZzproductvar() {
		if (zzproductvar != null)
		{
			return zzproductvar;	
		}else {
			return "";
		}
	}

	public void setZzproductvar(String zzproductvar) {
		this.zzproductvar = zzproductvar;
	}

	public String getZzforcastunit() {
		if (zzforcastunit != null)
		{
			return zzforcastunit;	
		}else {
			return "";
		}
	}

	public void setZzforcastunit(String zzforcastunit) {
		this.zzforcastunit = zzforcastunit;
	}

	public String getMvgr1() {
		if (mvgr1 != null)
		{
			return mvgr1;	
		}else {
			return "";
		}
	}

	public void setMvgr1(String mvgr1) {
		this.mvgr1 = mvgr1;
	}

	public String getComm_code() {
		if (comm_code != null)
		{
			return comm_code;	
		}else {
			return "";
		}
	}

	public void setComm_code(String comm_code) {
		this.comm_code = comm_code;
	}

	public String getMentions() {
		if (mentions != null)
		{
			return mentions;	
		}else {
			return "";
		}
	}

	public void setMentions(String mentions) {
		this.mentions = mentions;
	}

	public String getProject_code() {
		if (project_code != null)
		{
			return project_code;	
		}else {
			return "";
		}
	}

	public void setProject_code(String project_code) {
		this.project_code = project_code;
	}

	public String getIngredientlist() {
		if (ingredientlist != null)
		{
			return ingredientlist;	
		}else {
			return "";
		}
	}

	public void setIngredientlist(String ingredientlist) {
		this.ingredientlist = ingredientlist;
	}

	public String getBeforeopening() {
		if (beforeopening != null)
		{
			return beforeopening;	
		}else {
			return "";
		}
	}

	public void setBeforeopening(String beforeopening) {
		this.beforeopening = beforeopening;
	}

	public String getAfteropening() {
		if (afteropening != null)
		{
			return afteropening;	
		}else {
			return "";
		}
	}

	public void setAfteropening(String afteropening) {
		this.afteropening = afteropening;
	}

	public String getStoragecond() {
		if (storagecond != null)
		{
			return storagecond;	
		}else {
			return "";
		}
	}

	public void setStoragecond(String storagecond) {
		this.storagecond = storagecond;
	}

	public String getClaim2() {
		if (claim2 != null)
		{
			return claim2;	
		}else {
			return "";
		}
	}

	public void setClaim2(String claim2) {
		this.claim2 = claim2;
	}

	public String getClaim1() {
		if (claim1 != null)
		{
			return claim1;	
		}else {
			return "";
		}
	}

	public void setClaim1(String claim1) {
		this.claim1 = claim1;
	}

	public String getClaim3() {
		if (claim3 != null)
		{
			return claim3;	
		}else {
			return "";
		}
	}

	public void setClaim3(String claim3) {
		this.claim3 = claim3;
	}

	public String getClaim4() {
		if (claim4 != null)
		{
			return claim4;	
		}else {
			return "";
		}
	}

	public void setClaim4(String claim4) {
		this.claim4 = claim4;
	}

	public String getConsumptionmoment() {
		if (consumptionmoment != null)
		{
			return consumptionmoment;	
		}else {
			return "";
		}
	}

	public void setConsumptionmoment(String consumptionmoment) {
		this.consumptionmoment = consumptionmoment;
	}

	public String getEcatdescription() {
		if (ecatdescription != null)
		{
			return ecatdescription;	
		}else {
			return "";
		}
	}

	public void setEcatdescription(String ecatdescription) {
		this.ecatdescription = ecatdescription;
	}

	public String getInternetdescription() {
		if (internetdescription != null)
		{
			return internetdescription;	
		}else {
			return "";
		}
	}

	public void setInternetdescription(String internetdescription) {
		this.internetdescription = internetdescription;
	}

	public String getClaim5() {
		if (claim5 != null)
		{
			return claim5;	
		}else {
			return "";
		}
	}

	public void setClaim5(String claim5) {
		this.claim5 = claim5;
	}

	public String getLegaldeno() {
		if (legaldeno != null)
		{
			return legaldeno;	
		}else {
			return "";
		}
	}

	public void setLegaldeno(String legaldeno) {
		this.legaldeno = legaldeno;
	}

	public String getAgreement() {
		if (agreement != null)
		{
			return agreement;	
		}else {
			return "";
		}
	}

	public void setAgreement(String agreement) {
		this.agreement = agreement;
	}

	public String getTradename() {
		if (tradename != null)
		{
			return tradename;	
		}else {
			return "";
		}
	}

	public void setTradename(String tradename) {
		this.tradename = tradename;
	}

	public String getRegulatory() {
		if (regulatory != null)
		{
			return regulatory;	
		}else {
			return "";
		}
	}

	public void setRegulatory(String regulatory) {
		this.regulatory = regulatory;
	}

	public String getAdviseuse() {
		if (adviseuse != null)
		{
			return adviseuse;	
		}else {
			return "";
		}
	}

	public void setAdviseuse(String adviseuse) {
		this.adviseuse = adviseuse;
	}

	public String getInstructionsuse() {
		if (instructionsuse != null)
		{
			return instructionsuse;	
		}else {
			return "";
		}
	}

	public void setInstructionsuse(String instructionsuse) {
		this.instructionsuse = instructionsuse;
	}

	public String getNoticemilk() {
		if (noticemilk != null)
		{
			return noticemilk;	
		}else {
			return "";
		}
	}

	public void setNoticemilk(String noticemilk) {
		this.noticemilk = noticemilk;
	}

	public String getSpecificindic() {
		if (specificindic != null)
		{
			return specificindic;	
		}else {
			return "";
		}
	}

	public void setSpecificindic(String specificindic) {
		this.specificindic = specificindic;
	}

	public String getRegulcce() {
		if (regulcce != null)
		{
			return regulcce;	
		}else {
			return "";
		}
	}

	public void setRegulcce(String regulcce) {
		this.regulcce = regulcce;
	}

	public String getProdh() {
		if (prodh != null)
		{
			return prodh;	
		}else {
			return "";
		}
	}

	public void setProdh(String prodh) {
		this.prodh = prodh;
	}
	
	public List<MultipackWrapper> getMultiList() {
		return multiList;
	}

	public void setMultiList(List<MultipackWrapper> multiList) {
		this.multiList = multiList;
	}

	public List<NutboardWrapper> getNutboard() {
		return nutboard;
	}

	public void setNutboard(List<NutboardWrapper> nutboard) {
		this.nutboard = nutboard;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getZcmetext() {
		if (zcmetext != null)
		{
			return zcmetext;	
		}else {
			return "";
		}
	}

	public void setZcmetext(String zcmetext) {
		this.zcmetext = zcmetext;
	}

	public String getCommercialDescription() {
		if (commercialDescription != null)
		{
			return commercialDescription;	
		}else {
			return "";
		}
	}

	public void setCommercialDescription(String commercialDescription) {
		this.commercialDescription = commercialDescription;
	}

	public String getInstructionsuselight() {
		if (instructionsuselight != null)
		{
			return instructionsuselight;	
		}else {
			return "";
		}
	}

	public void setInstructionsuselight(String instructionsuselight) {
		this.instructionsuselight = instructionsuselight;
	}
	
	public List<VersionWrapper> getVersionList() {
		return versionList;
	}

	public void setVersionList(List<VersionWrapper> versionList) {
		this.versionList = versionList;
	}
	
	public String getAllergen_contain() {
		if (allergen_contain != null)
		{
			return allergen_contain;	
		}else {
			return "";
		}
	}

	public void setAllergen_contain(String allergen_contain) {
		this.allergen_contain = allergen_contain;
	}

	public String getAllergen_may_contain() {
		if (allergen_may_contain != null)
		{
			return allergen_may_contain;	
		}else {
			return "";
		}
	}

	public void setAllergen_may_contain(String allergen_may_contain) {
		this.allergen_may_contain = allergen_may_contain;
	}

	public String getCross_contamination() {
		if (cross_contamination != null)
		{
			return cross_contamination;	
		}else {
			return "";
		}
	}

	public void setCross_contamination(String cross_contamination) {
		this.cross_contamination = cross_contamination;
	}

	public String getConsumptionage() {
		if (consumptionage != null)
		{
			return consumptionage;	
		}else {
			return "";
		}
	}

	public void setConsumptionage(String consumptionage) {
		this.consumptionage = consumptionage;
	}

	public String getMarketingtexts() {
		if (marketingtexts != null)
		{
			return marketingtexts;	
		}else {
			return "";
		}
	}

	public void setMarketingtexts(String marketingtexts) {
		this.marketingtexts = marketingtexts;
	}

	public String getLifetime_day() {
		if (lifetime_day != null)
		{
			return lifetime_day;	
		}else {
			return "";
		}
	}

	public void setLifetime_day(String lifetime_day) {
		this.lifetime_day = lifetime_day;
	}
	
	public List<AllergenWrapper> getAllergenList() {
		return allergenList;
	}

	public void setAllergenList(List<AllergenWrapper> allergenList) {
		this.allergenList = allergenList;
	}
	
	public Integer getStfak() {
		if (stfak != null)
		{
			return stfak;	
		}else {
			return 0;
		}
	}

	public void setStfak(Integer stfak) {
		this.stfak = stfak;
	}

	public List<UoMWrapper> getUomlist() {
		return uomlist;
	}

	public void setUomlist(List<UoMWrapper> uomlist) {
		this.uomlist = uomlist;
	}

	public String getCode_labelling() {
		if (code_labelling != null)
		{
			return code_labelling;	
		}else {
			return "";
		}
	}

	public void setCode_labelling(String code_labelling) {
		this.code_labelling = code_labelling;
	}

	public String getConsigne() {
		if (consigne != null)
		{
			return consigne;	
		}else {
			return "";
		}
	}

	public void setConsigne(String consigne) {
		this.consigne = consigne;
	}

	public String getPalettisation() {
		if (palettisation != null)
		{
			return palettisation;	
		}else {
			return "";
		}
	}

	public void setPalettisation(String palettisation) {
		this.palettisation = palettisation;
	}

	public String getDlsc() {
		if (dlsc != null)
		{
			return dlsc;	
		}else {
			return "";
		}
	}

	public void setDlsc(String dlsc) {
		this.dlsc = dlsc;
	}

	public String getFormat() {
		if (format != null)
		{
			return format;	
		}else {
			return "";
		}
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getMktexture() {
		if (mktexture != null)
		{
			return mktexture;	
		}else {
			return "";
		}
	}

	public void setMktexture(String mktexture) {
		this.mktexture = mktexture;
	}

	public String getMkingredient() {
		if (mkingredient != null)
		{
			return mkingredient;	
		}else {
			return "";
		}
	}

	public void setMkingredient(String mkingredient) {
		this.mkingredient = mkingredient;
	}

	public String getMkbenefits() {
		if (mkbenefits != null)
		{
			return mkbenefits;	
		}else {
			return "";
		}
	}

	public void setMkbenefits(String mkbenefits) {
		this.mkbenefits = mkbenefits;
	}

	public String getMkother() {
		if (mkother != null)
		{
			return mkother;	
		}else {
			return "";
		}
	}

	public void setMkother(String mkother) {
		this.mkother = mkother;
	}

	public List<PictureWrapper> getPictureList() {
		return pictureList;
	}

	public void setPictureList(List<PictureWrapper> pictureList) {
		this.pictureList = pictureList;
	}

	public List<PictureWrapper> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<PictureWrapper> documentList) {
		this.documentList = documentList;
	}	

	public String getArtemis_sku() {
		if (artemis_sku != null)
		{
			return artemis_sku;	
		}else {
			return "";
		}
	}

	public void setArtemis_sku(String artemis_sku) {
		this.artemis_sku = artemis_sku;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getCat_guid() {
		return cat_guid;
	}

	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}

	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

	public String getPrinbr() {
		return prinbr;
	}

	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}

	public String getProductgroup() {
		return productgroup;
	}

	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}

	public String getEan_upc_base() {
		return ean_upc_base;
	}

	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}

	public java.sql.Date getValidity_base() {
		return validity_base;
	}

	public void setValidity_base(java.sql.Date validity_base) {
		this.validity_base = validity_base;
	}

	public java.sql.Date getLast_update() {
		return last_update;
	}

	public void setLast_update(java.sql.Date last_update) {
		this.last_update = last_update;
	}

	public String getBrand() {
		if (brand != null)
		{
			return brand;	
		}else {
			return "";
		}
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getSubbrand() {
		if (subbrand != null)
		{
			return subbrand;	
		}else {
			return "";
		}
	}

	public void setSubbrand(String subbrand) {
		this.subbrand = subbrand;
	}

	public String getFlavor() {
		if (flavor != null)
		{
			return flavor;	
		}else {
			return "";
		}
	}

	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}

	public String getPromo() {
		if (promo != null)
		{
			return promo;	
		}else {
			return "";
		}
	}

	public void setPromo(String promo) {
		this.promo = promo;
	}

	public String getProcess2() {
		if (process2 != null)
		{
			return process2;	
		}else {
			return "";
		}
	}

	public void setProcess2(String process2) {
		this.process2 = process2;
	}

	public String getProcess1() {
		if (process1 != null)
		{
			return process1;	
		}else {
			return "";
		}
	}

	public void setProcess1(String process1) {
		this.process1 = process1;
	}

	public String getPotdiameter() {
		if (potdiameter != null)
		{
			return potdiameter;	
		}else {
			return "";
		}
	}

	public void setPotdiameter(String potdiameter) {
		this.potdiameter = potdiameter;
	}

	public String getRange() {
		if (range != null)
		{
			return range;	
		}else {
			return "";
		}
	}

	public void setRange(String range) {
		this.range = range;
	}

	public String getSubrange() {
		if (subrange != null)
		{
			return subrange;	
		}else {
			return "";
		}
	}

	public void setSubrange(String subrange) {
		this.subrange = subrange;
	}

	public String getProdhl1desc() {
		if (prodhl1desc != null)
		{
			return prodhl1desc;	
		}else {
			return "";
		}
	}

	public void setProdhl1desc(String prodhl1desc) {
		this.prodhl1desc = prodhl1desc;
	}

	public String getProdhl2desc() {
		if (prodhl2desc != null)
		{
			return prodhl2desc;	
		}else {
			return "";
		}
	}

	public void setProdhl2desc(String prodhl2desc) {
		this.prodhl2desc = prodhl2desc;
	}

	public String getProdhl4desc() {
		if (prodhl4desc != null)
		{
			return prodhl4desc;	
		}else {
			return "";
		}
	}

	public void setProdhl4desc(String prodhl4desc) {
		this.prodhl4desc = prodhl4desc;
	}

	public String getProdhl3desc() {
		if (prodhl3desc != null)
		{
			return prodhl3desc;	
		}else {
			return "";
		}
	}

	public void setProdhl3desc(String prodhl3desc) {
		this.prodhl3desc = prodhl3desc;
	}

	public String getProdhl5desc() {
		if (prodhl5desc != null)
		{
			return prodhl5desc;	
		}else {
			return "";
		}
	}

	public void setProdhl5desc(String prodhl5desc) {
		this.prodhl5desc = prodhl5desc;
	}

	public String getProdhl6desc() {
		if (prodhl6desc != null)
		{
			return prodhl6desc;	
		}else {
			return "";
		}
	}

	public void setProdhl6desc(String prodhl6desc) {
		this.prodhl6desc = prodhl6desc;
	}

	public List<AllergenDetailWrapper> getAllergensContainList() {
		return allergensContainList;
	}

	public void setAllergensContainList(List<AllergenDetailWrapper> allergensContainList) {
		this.allergensContainList = allergensContainList;
	}

	public List<AllergenDetailWrapper> getAllergensMayContainList() {
		return allergensMayContainList;
	}

	public void setAllergensMayContainList(List<AllergenDetailWrapper> allergensMayContainList) {
		this.allergensMayContainList = allergensMayContainList;
	}

	public List<AllergenDetailWrapper> getAllergensNotPresentList() {
		return allergensNotPresentList;
	}

	public void setAllergensNotPresentList(List<AllergenDetailWrapper> allergensNotPresentList) {
		this.allergensNotPresentList = allergensNotPresentList;
	}

	public String getGoodsupplier() {
		if (goodsupplier != null)
		{
			return goodsupplier;	
		}else {
			return "";
		}
	}

	public void setGoodsupplier(String goodsupplier) {
		this.goodsupplier = goodsupplier;
	}

	public String getMilkyproduct() {
		if (milkyproduct != null)
		{
			return milkyproduct;	
		}else {
			return "";
		}
	}

	public void setMilkyproduct(String milkyproduct) {
		this.milkyproduct = milkyproduct;
	}

	public String getGmo() {
		if (gmo != null)
		{
			return gmo;	
		}else {
			return "";
		}
	}

	public void setGmo(String gmo) {
		this.gmo = gmo;
	}

	public String getOrganic() {
		if (organic != null)
		{
			return organic;	
		}else {
			return "";
		}
	}

	public void setOrganic(String organic) {
		this.organic = organic;
	}

	public String getBrick() {
		if (brick != null)
		{
			return brick;	
		}else {
			return "";
		}
	}

	public void setBrick(String brick) {
		this.brick = brick;
	}

	public String getZzmarki() {
		if (zzmarki != null)
		{
			return zzmarki;	
		}else {
			return "";
		}
	}

	public void setZzmarki(String zzmarki) {
		this.zzmarki = zzmarki;
	}

	public String getZzmarkii() {
		if (zzmarkii != null)
		{
			return zzmarkii;	
		}else {
			return "";
		}
	}

	public void setZzmarkii(String zzmarkii) {
		this.zzmarkii = zzmarkii;
	}

	public String getZzmarkiii() {
		if (zzmarkiii != null)
		{
			return zzmarkiii;	
		}else {
			return "";
		}
	}

	public void setZzmarkiii(String zzmarkiii) {
		this.zzmarkiii = zzmarkiii;
	}

	public String getZzmarkiv() {
		if (zzmarkiv != null)
		{
			return zzmarkiv;	
		}else {
			return "";
		}
	}

	public void setZzmarkiv(String zzmarkiv) {
		this.zzmarkiv = zzmarkiv;
	}

	public String getConsumptiontime() {
		if (consumptiontime != null)
		{
			return consumptiontime;	
		}else {
			return "";
		}
	}

	public void setConsumptiontime(String consumptiontime) {
		this.consumptiontime = consumptiontime;
	}

	public String getClick2buy() {
		if (click2buy != null)
		{
			return click2buy;	
		}else {
			return "";
		}
	}

	public void setClick2buy(String click2buy) {
		this.click2buy = click2buy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getStddescription() {
		if (stddescription != null)
		{
			return stddescription;	
		}else {
			return "";
		}
	}

	public void setStddescription(String stddescription) {
		this.stddescription = stddescription;
	}
	
}
