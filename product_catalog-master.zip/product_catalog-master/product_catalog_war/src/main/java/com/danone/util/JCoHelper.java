package com.danone.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

public class JCoHelper {

	//private static final Logger LOGGER = LoggerFactory.getLogger(JCoHelper.class);
	
	/** ABAP TABLE TYPE export parsing **/
	   public static JSONArray parseTable(JCoTable outputTable){
	       
	       JSONArray  jsonArray  = new JSONArray();

	       for (int i = 0; i < outputTable.getNumRows(); i++) {
	       	
	       	   JSONObject jsonRecord = new JSONObject();
	       	
	       	   outputTable.setRow(i);
	       	   JCoFieldIterator it = outputTable.getFieldIterator();
	       	   // get fields of current record
	       	   while(it.hasNextField()){
	       		  JCoField oComponent = it.nextField();
	       	      String paramName = (String)oComponent.getName();
	       	      String paramType = oComponent.getTypeAsString();
	       	      
	       	      // do what you need to do with the field and value
	       	      try {
	       	    	  
	       	          // parse table output
	       	    	  if(paramType.equals("TABLE")){
	       	    		JCoTable jcoTable=oComponent.getTable();
		      	        jsonRecord.put(paramName, parseTable(jcoTable));
		     
		      	      // parse structure output
		      	      }else if(paramType.equals("STRUCTURE")){
		      	        JCoStructure jcoStructure = oComponent.getStructure();
		      	        jsonRecord.put(paramName, parseStructure(jcoStructure));
		      	      }else{
		      	    	jsonRecord.put(paramName, oComponent.getValue());
		      	        
		      	      }

	       	      } catch(JSONException e) {
	       	    	    e.getCause();
	       	      }
	       	      
	       	   }
	       	   
	       	   jsonArray.put(jsonRecord);
	       }
	       
	       return jsonArray;
	   }
		
	   public static JSONObject parseStructure(JCoStructure outputStructure){
		   
		   JSONObject jsonRecord = new JSONObject();
		   
		   JCoFieldIterator it = outputStructure.getFieldIterator();
	   	   // get fields of current record
	   	   while(it.hasNextField()){
	   		  JCoField oComponent = it.nextField();
	 	      String paramName = (String)oComponent.getName();
	 	      String paramType = oComponent.getTypeAsString();
	   	      
	   	      // do what you need to do with the field and value
	   	      try {
	   	          // parse table output
	   	    	  if(paramType.equals("TABLE")){
	   	    		JCoTable jcoTable=oComponent.getTable();
	      	        jsonRecord.put(paramName, parseTable(jcoTable));
	     
	      	      // parse structure output
	      	      }else if(paramType.equals("STRUCTURE")){
	      	        JCoStructure jcoStructure = oComponent.getStructure();
	      	        jsonRecord.put(paramName, parseStructure(jcoStructure));
	      	      }else{
	      	        jsonRecord.put(paramName, oComponent.getValue());
	      	      }
	   	      } catch(JSONException e) {
	   	    	    e.getCause();
	   	      }
	   	      
	   	   }
		   
		   return jsonRecord;
	   }
	
}
