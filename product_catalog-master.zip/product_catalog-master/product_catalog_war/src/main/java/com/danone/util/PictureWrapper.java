package com.danone.util;

public class PictureWrapper {
	private String imageId;
	private String thumbnailId;
	private String thumbnailUrl;
	private String documentNr;
	private String documentVr;
	private String pictureName;
	private String productType;
	private String contentType;
	private String mainFace;
	private String horizontalAngle;
	private String fileNature;
	private String validFrom;
	private String validTo;
	private String shootingDate;
	private java.sql.Date creationDate;
	private Boolean selected;
	private String downloadUrl;
	

	public Boolean getSelected() {
		return selected;
	}

	public void setSelected(Boolean selected) {
		this.selected = selected;
	}

	public String getDocumentNr() {
		return documentNr;
	}

	public void setDocumentNr(String documentNr) {
		this.documentNr = documentNr;
	}

	public String getDocumentVr() {
		return documentVr;
	}

	public void setDocumentVr(String documentVr) {
		this.documentVr = documentVr;
	}

	public String getPictureName() {
		return pictureName;
	}

	public void setPictureName(String pictureName) {
		this.pictureName = pictureName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getHorizontalAngle() {
		return horizontalAngle;
	}

	public void setHorizontalAngle(String horizontalAngle) {
		this.horizontalAngle = horizontalAngle;
	}

	public String getMainFace() {
		return mainFace;
	}

	public void setMainFace(String mainFace) {
		this.mainFace = mainFace;
	}

	public String getFileNature() {
		return fileNature;
	}

	public void setFileNature(String fileNature) {
		this.fileNature = fileNature;
	}

	public java.sql.Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}

	public String getShootingDate() {
		return shootingDate;
	}

	public void setShootingDate(String shootingDate) {
		this.shootingDate = shootingDate;
	}

	public String getValidTo() {
		return validTo;
	}

	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}

	public String getThumbnailId() {
		return thumbnailId;
	}

	public void setThumbnailId(String thumbnailId) {
		this.thumbnailId = thumbnailId;
	}

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public void setThumbnailUrl(String thumbnailUrl) {
		this.thumbnailUrl = thumbnailUrl;
	}

	public String getDownloadUrl() {
		return downloadUrl;
	}

	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}
}
