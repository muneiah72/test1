package com.danone.util;

public class NutboardWrapper {

	//ZPRO_NUTBOARD
	private String porid;
	private String nutid;
	private String poridun;
	private String poridtext;
	private Integer rank;
	private double poridva;
	private double poridvaro;
	private String valueun;
	private double ajrc;
	private String ajrcun;
	private String display;
	private String poridsign;
	
	private String nutidtext;
	
	public String getNutid() {
		if (nutid != null)
		{
			return nutid;	
		}else {
			return "";
		}
	}

	public void setNutid(String nutid) {
		this.nutid = nutid;
	}

	public String getPoridun() {
		if (poridun != null)
		{
			return poridun;	
		}else {
			return "";
		}
	}

	public void setPoridun(String poridun) {
		this.poridun = poridun;
	}

	public String getPoridtext() {
		if (poridtext != null)
		{
			return poridtext;	
		}else {
			return "";
		}
	}

	public void setPoridtext(String poridtext) {
		this.poridtext = poridtext;
	}

	public double getPoridva() {
		return poridva;
	}

	public void setPoridva(double poridva) {
		this.poridva = poridva;
	}

	public double getPoridvaro() {
		return poridvaro;
	}

	public void setPoridvaro(double poridvaro) {
		this.poridvaro = poridvaro;
	}

	public String getValueun() {
		if (valueun != null)
		{
			return valueun;	
		}else {
			return "";
		}
	}

	public void setValueun(String valueun) {
		this.valueun = valueun;
	}

	public String getAjrcun() {
		if (ajrcun != null)
		{
			return ajrcun;	
		}else {
			return "";
		}
	}

	public void setAjrcun(String ajrcun) {
		this.ajrcun = ajrcun;
	}

	public double getAjrc() {
		return ajrc;
	}

	public void setAjrc(double ajrc) {
		this.ajrc = ajrc;
	}

	public String getDisplay() {
		if (display != null)
		{
			return display;	
		}else {
			return "";
		}
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	public String getNutidtext() {
		if (nutidtext != null)
		{
			return nutidtext;	
		}else {
			return "";
		}
	}

	public void setNutidtext(String nutidtext) {
		this.nutidtext = nutidtext;
	}

	public String getPoridsign() {
		if (poridsign != null)
		{
			return poridsign;	
		}else {
			return "";
		}
	}

	public void setPoridsign(String poridsign) {
		this.poridsign = poridsign;
	}

	public String getPorid() {
		if (porid != null)
		{
			return porid;	
		}else {
			return "";
		}
	}

	public void setPorid(String porid) {
		this.porid = porid;
	}

	public Integer getRank() {
		if (rank != null)
		{
			return rank;	
		}else {
			return 0;
		} 
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

}
