package com.danone.util;

public class AllergenDetailWrapper {
	
	private String code;
	private String description;
	
	public String getCode() {
		if (code != null)
		{
			return code;	
		}else {
			return "";
		}
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		if (description != null)
		{
			return description;	
		}else {
			return "";
		}
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
