package com.danone.cron;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimerTask;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.ReplicationInfo;
import com.danone.entities.ZPOTDIAM;
import com.danone.entities.ZPOTDIAMPK;
import com.danone.entities.ZPPFLAV;
import com.danone.entities.ZPPFLAVPK;
import com.danone.entities.ZPPPRO1;
import com.danone.entities.ZPPPRO1PK;
import com.danone.entities.ZPROEU_GRP_PROD;
import com.danone.entities.ZPROEU_GRP_PRODPK;
import com.danone.entities.ZPROEU_QTY;
import com.danone.entities.ZPROEU_QTYPK;
import com.danone.entities.ZPROEU_PLANT;
import com.danone.entities.ZPROEU_PLANTPK;
import com.danone.entities.ZPRO_ALLERGEN;
import com.danone.entities.ZPRO_ALLERGENPK;
import com.danone.entities.ZPRO_MENTION;
import com.danone.entities.ZPRO_MENTIONPK;
import com.danone.entities.ZPRO_NUTRIENT;
import com.danone.entities.ZPRO_NUTRIENTPK;
import com.danone.entities.ZRANGE;
import com.danone.entities.ZRANGEPK;
import com.danone.entities.ZSUBRANGE;
import com.danone.entities.ZSUBRANGEPK;
import com.danone.entities.ZPROWS_ORG;
import com.danone.entities.ZPROWS_ORGPK;
import com.danone.entities.ZPPSIGN;
import com.danone.entities.ZPPSIGNPK;
import com.danone.entities.ZPPOVER;
import com.danone.entities.ZPPOVERPK;
import com.danone.entities.TVM1T;
import com.danone.entities.TVM1TPK;
import com.danone.entities.ZPPPRO2;
import com.danone.entities.ZPPPRO2PK;
import com.danone.entities.T179T;
import com.danone.entities.T179TPK;
import com.danone.entities.ZPROCHARVALTXT;
import com.danone.entities.ZPROCHARVALTXTPK;
import com.danone.entities.T002;
import com.danone.entities.T002PK;
import com.danone.entities.ZPPMAR1;
import com.danone.entities.ZPPMAR1PK;
import com.danone.entities.ZPPMAR2;
import com.danone.entities.ZPPMAR2PK;
import com.danone.entities.ZPPMAR3;
import com.danone.entities.ZPPMAR3PK;
import com.danone.entities.ZPPMAR4;
import com.danone.entities.ZPPMAR4PK;
import com.danone.entities.ReplicationInfoText;
import com.danone.persistence.PersistenceAdapter;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoListMetaData;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

public class UpdateDBText extends TimerTask {

	private static Logger LOGGER = LoggerFactory.getLogger(UpdateDBText.class);
	// private static String destinationName = "PRODCATALOG-SAP";
	private static List<String> destinations = null;
	private String currentDestination = null;
	private JCoRepository repo = null;
	private JCoDestination destination = null;
	private static UpdateDBText instance = null;

	protected UpdateDBText() {
		// Exists only to defeat instantiation.
	}

	public static UpdateDBText getInstance(Boolean newinstance) {
		if (instance == null || newinstance == true) {
			instance = new UpdateDBText();
			destinations = new ArrayList<String>();
			destinations.add("PRODCATALOG-SAP");
			destinations.add("PRODCATALOG-SAP1");
			destinations.add("PRODCATALOG-SAP2");
			destinations.add("PRODCATALOG-SAP3");
			// destinations.add("PRODCATALOG-SAP4");
			// destinations.add("PRODCATALOG-SAP5");
			// destinations.add("PRODCATALOG-SAP6");
			// destinations.add("PRODCATALOG-SAP7");
			// destinations.add("PRODCATALOG-SAP8");
			// destinations.add("PRODCATALOG-SAP9");
		}

		return instance;
	}
	
	public void startManual(String username) {

		LOGGER.debug("Start manual text synchronisation");

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();

			ReplicationInfoText infotext = new ReplicationInfoText();
			infotext.setIsManual(true);

			Calendar calendar = Calendar.getInstance();
			java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
			infotext.setStartDate(ourJavaDateObject);
			infotext.setUser(username);
			infotext.setTime(new java.sql.Time(calendar.getTime().getTime()));

			em.merge(infotext);
			transaction.commit();

		} catch (Exception e) {
			LOGGER.error("Exception while creating ReplicationInfoText " + e.toString());
		} finally {
			em.close();
		}

		// Automatic start
		start();
	}

	@Override
	public void run() {

		LOGGER.debug("Start automatic text synchronisation");

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();

			ReplicationInfoText infotext = new ReplicationInfoText();
			infotext.setIsManual(false);

			Calendar calendar = Calendar.getInstance();
			java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
			infotext.setStartDate(ourJavaDateObject);
			infotext.setUser("BATCH");
			infotext.setTime(new java.sql.Time(calendar.getTime().getTime()));

			em.merge(infotext);
			transaction.commit();

		} catch (Exception e) {
			LOGGER.error("Exception while creating ReplicationInfoText " + e.toString());
		} finally {
			em.close();
		}

		// Automatic start
		start();
	}

	public void start() {

		for (String dest : destinations) {
			repo = null;
			currentDestination = dest;
			doProcessing();
		}
	}

	private void doProcessing() {
		LOGGER.debug("UpdateDBText is running on system: " + currentDestination);

		try {
			LOGGER.debug("Initializing Repository....");
			destination = JCoDestinationManager
					.getDestination(currentDestination);

			repo = destination.getRepository();
			// JCo.setProperty("jco.use_repository_roundtrip_optimization",
			// "1");
			List<String> functions = new ArrayList<String>();
			functions.add("ZSHCP_PROM_FETCH_TEXT");
			// JCo.queryMetaDataSet(repo, functions, null, null);
			LOGGER.debug("Initializing Finished....");

		} catch (JCoException e) {
			LOGGER.debug("Exception during Repository Initiliazation: "
					+ e.getLocalizedMessage());
			e.printStackTrace();
		}

		if (repo != null) {
			try {
				LOGGER.debug("Access RFC");
				// access the RFC Destination via Cloud Connector
				// JCoDestination destination =
				// JCoDestinationManager.getDestination(currentDestination);
				// JCoRepository repo = destination.getRepository();

				// make an invocation of FUNCTION in the back-end
				JCoFunction stfcConnection = repo
						.getFunction("ZSHCP_PROM_FETCH_TEXT");

				// Run the Function module
				LOGGER.debug("Before execute");
				stfcConnection.execute(destination);
				LOGGER.debug("After execute");

				// Get results
				JCoParameterList exports = stfcConnection
						.getExportParameterList();
				JCoListMetaData exportParameters = exports.getListMetaData();

				LOGGER.debug("start loop over export");
				for (int i = 0; i < exportParameters.getFieldCount(); i++) {
					String paramName = exportParameters.getName(i);

					if (paramName.equalsIgnoreCase("ES_EXPORT_STRUCTURE")) {
						LOGGER.debug("ES_EXPORT_STRUCTURE");
						JCoStructure structure = exports
								.getStructure(paramName);
						fillZPRO_MENTION(structure.getTable("ZPRO_MENTION"));
						fillZPRO_ALLERGEN(structure.getTable("ZPRO_ALLERGEN"));
						fillZPRO_NUTRIENT(structure.getTable("ZPRO_NUTRIENT"));
						fillZPPFLAV(structure.getTable("ZPPFLAV"));
						fillZPPPRO1(structure.getTable("ZPPPRO1"));
						fillZPOTDIAM(structure.getTable("ZPOTDIAM"));
						fillZRANGE(structure.getTable("ZRANGE"));
						fillZSUBRANGE(structure.getTable("ZSUBRANGE"));
						fillZPROEU_GRP_PROD(structure.getTable("ZPROEU_GRP_PROD"));
						fillZPROEU_QTY(structure.getTable("ZPROEU_QTY"));
						fillZPROEU_PLANT(structure.getTable("ZPROEU_PLANT"));
						fillZPROWS_ORG(structure.getTable("ZPROWS_ORG"));
						fillZPPSIGN(structure.getTable("ZPPSIGN"));
						fillZPPOVER(structure.getTable("ZPPOVER"));
						fillTVM1T(structure.getTable("TVM1T"));
						fillZPPPRO2(structure.getTable("ZPPPRO2"));
						fillT179T(structure.getTable("T179T"));
						fillZPROCHARVALTXT(structure.getTable("ZPROCHARVALTXT"));
						fillT002(structure.getTable("T002"));
						fillZPPMAR1(structure.getTable("ZPPMAR1"));
						fillZPPMAR2(structure.getTable("ZPPMAR2"));
						fillZPPMAR3(structure.getTable("ZPPMAR3"));
						fillZPPMAR4(structure.getTable("ZPPMAR4"));
						// fillPricatK010_ZPRO_VPRICAT_S(structure.getTable("PRICAT_K010_ZPRO_VPRICAT_S"));
						// fillZPRO_NUTBOARD(structure.getTable("ZPRO_NUTBOARD"));
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				LOGGER.error("Error during RFC " + e.toString());
			}
		}
	}

	private void fillZPRO_MENTION(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPRO_MENTION " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPRO_MENTION s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPRO_MENTION " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPRO_MENTION mention = new ZPRO_MENTION();
				ZPRO_MENTIONPK mentionpk = new ZPRO_MENTIONPK();
				mentionpk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(mention, mentionpk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPRO_MENTION field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				mention.setKey(mentionpk);
				em.merge(mention);
			}		
			
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPRO_MENTION "
					+ e.toString());
		} finally {
			em.close();
		}
	}

	private void fillZPRO_ALLERGEN(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPRO_ALLERGEN " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPRO_ALLERGEN s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPRO_ALLERGEN " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {

				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPRO_ALLERGEN proallergen = new ZPRO_ALLERGEN();
				ZPRO_ALLERGENPK proallergenpk = new ZPRO_ALLERGENPK();
				proallergenpk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(proallergen, proallergenpk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPRO_ALLERGEN field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				proallergen.setKey(proallergenpk);
				em.merge(proallergen);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPRO_ALLERGEN "
					+ e.toString());
		} finally {
			em.close();
		}
	}

	private void fillZPRO_NUTRIENT(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPRO_NUTRIENT " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPRO_NUTRIENT s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPRO_NUTRIENT " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPRO_NUTRIENT nutrient = new ZPRO_NUTRIENT();
				ZPRO_NUTRIENTPK nutrientpk = new ZPRO_NUTRIENTPK();
				nutrientpk.setObject(" ");
				nutrientpk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(nutrient, nutrientpk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPRO_NUTRIENT field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				nutrient.setKey(nutrientpk);
				em.merge(nutrient);
			}	
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPRO_NUTRIENT "
					+ e.toString());
		} finally {
			em.close();
		}

	}

	private void fillZPPFLAV(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPFLAV " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPFLAV s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPFLAV " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPFLAV flavor = new ZPPFLAV();
				ZPPFLAVPK flavorpk = new ZPPFLAVPK();
				flavorpk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(flavor, flavorpk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPFLAV field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				if (flavorpk.getZflavor()!= null) {
					flavor.setKey(flavorpk);
					em.merge(flavor);	
				}else {
					LOGGER.debug("Null key while replicating ZPPFLAV " );
				}
			}	
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPFLAV " + e.toString());
		} finally {
			em.close();
		}		
	}

	private void fillZPPPRO1(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPPRO1 " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPPRO1 s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPPRO1 " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPPRO1 process1 = new ZPPPRO1();
				ZPPPRO1PK process1pk = new ZPPPRO1PK();
				process1pk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPPRO1 field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPPRO1 " + e.toString());
		} finally {
			em.close();
		}
	}

	private void fillZPOTDIAM(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPOTDIAM " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPOTDIAM s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPOTDIAM " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPOTDIAM potdiam = new ZPOTDIAM();
				ZPOTDIAMPK potdiampk = new ZPOTDIAMPK();
				potdiampk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(potdiam, potdiampk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPOTDIAM field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				potdiam.setKey(potdiampk);
				em.merge(potdiam);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPOTDIAM " + e.toString());
		} finally {
			em.close();
		}		
	}

	private void fillZRANGE(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZRANGE " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZRANGE s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZRANGE " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZRANGE range = new ZRANGE();
				ZRANGEPK rangepk = new ZRANGEPK();
				rangepk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(range, rangepk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZRANGE field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				range.setKey(rangepk);
				em.merge(range);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZRANGE " + e.toString());
		} finally {
			em.close();
		}
	}

	private void fillZSUBRANGE(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZSUBRANGE " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZSUBRANGE s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZSUBRANGE " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZSUBRANGE subrange = new ZSUBRANGE();
				ZSUBRANGEPK subrangepk = new ZSUBRANGEPK();
				subrangepk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(subrange, subrangepk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZSUBRANGE field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				subrange.setKey(subrangepk);
				em.merge(subrange);
			}	
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZSUBRANGE "
					+ e.toString());
		} finally {
			em.close();
		}
	}

	private void fillZPROEU_GRP_PROD(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPROEU_GRP_PROD " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPROEU_GRP_PROD s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPROEU_GRP_PROD " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPROEU_GRP_PROD proeugrp = new ZPROEU_GRP_PROD();
				ZPROEU_GRP_PRODPK proeugrppk = new ZPROEU_GRP_PRODPK();
				proeugrppk.setSystem(currentDestination);
				proeugrp.setGroup1("");
				proeugrp.setGroup2("");
				proeugrp.setGroup3("");
				proeugrp.setGroup4("");
				proeugrp.setGroup5("");
				proeugrp.setGroup6("");
				proeugrp.setGroup7("");
				proeugrp.setGroup8("");
				proeugrp.setGroup9("");
				proeugrp.setGroup10(""); 
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(proeugrp, proeugrppk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPROEU_GRP_PROD field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				proeugrp.setKey(proeugrppk);
				em.merge(proeugrp);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPROEU_GRP_PROD "
					+ e.toString());
		} finally {
			em.close();
		}		
	}

	private void deleteZPROEU_GRP_PRODContent() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		try {
			transaction.begin();

			Query query = em.createNativeQuery("DELETE FROM ZPROEU_GRP_PROD");
			query.executeUpdate();
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while deleting ZPROEU_GRP_PROD "
					+ e.toString());
		} finally {
			em.close();
		}
	}	
	
	private void fillZPROEU_QTY(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPROEU_QTY " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPROEU_QTY s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPROEU_QTY " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPROEU_QTY proeuqty = new ZPROEU_QTY();
				ZPROEU_QTYPK proeuqtypk = new ZPROEU_QTYPK();
				proeuqtypk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");

						try {
							// Attempt to fill the field
							setFieldDynamically(proeuqty, proeuqtypk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPROEU_QTY field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				proeuqty.setKey(proeuqtypk);
				em.merge(proeuqty);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPROEU_QTY "
					+ e.toString());
		} finally {
			em.close();
		}	
	}

	private void deleteZPROEU_QTYContent() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();

			Query query = em.createNativeQuery("DELETE FROM ZPROEU_QTY");
			query.executeUpdate();
			transaction.commit(); 
		} catch (Exception e) {
			LOGGER.debug("Exception while deleting ZPROEU_QTY "
					+ e.toString());
		} finally {
			em.close();
		}
	}

	private void fillZPROEU_PLANT(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPROEU_PLANT " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPROEU_PLANT s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPROEU_PLANT " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPROEU_PLANT proeuplant = new ZPROEU_PLANT();
				ZPROEU_PLANTPK proeuplantpk = new ZPROEU_PLANTPK();
				proeuplantpk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(proeuplant, proeuplantpk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPROEU_PLANT field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				proeuplant.setKey(proeuplantpk);
				em.merge(proeuplant);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPROEU_PLANT "
					+ e.toString());
		} finally {
			em.close();
		}		
	}

	private void deleteZPROEU_PLANTContent() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();

			Query query = em.createNativeQuery("DELETE FROM ZPROEU_PLANT");
			query.executeUpdate();
			transaction.commit(); 
		} catch (Exception e) {
			LOGGER.debug("Exception while deleting ZPROEU_PLANT "
					+ e.toString());
		} finally {
			em.close();
		}
	}

	private void fillZPROWS_ORG(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPROWS_ORG");
			Query query = em.createQuery("DELETE FROM ZPROWS_ORG");
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPROWS_ORG " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPROWS_ORG prowsorg = new ZPROWS_ORG();
				ZPROWS_ORGPK prowsorgpk = new ZPROWS_ORGPK();
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(prowsorg, prowsorgpk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPROWS_ORG field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				prowsorg.setKey(prowsorgpk);
				em.merge(prowsorg);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPROWS_ORG "
					+ e.toString());
		} finally {
			em.close();
		}		
	}

	private void deleteZPROWS_ORGContent() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();

			Query query = em.createNativeQuery("DELETE FROM ZPROWS_ORG");
			query.executeUpdate();
			transaction.commit(); 
		} catch (Exception e) {
			LOGGER.debug("Exception while deleting ZPROWS_ORG "
					+ e.toString());
		} finally {
			em.close();
		}
	}
	
	private void fillZPPSIGN(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPSIGN " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPSIGN s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPSIGN " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPSIGN process1 = new ZPPSIGN();
				ZPPSIGNPK process1pk = new ZPPSIGNPK();
				process1pk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPSIGN field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPSIGN " + e.toString());
		} finally {
			em.close();
		}
	}
	private void fillZPPOVER(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPOVER " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPOVER s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPOVER " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPOVER process1 = new ZPPOVER();
				ZPPOVERPK process1pk = new ZPPOVERPK();
				process1pk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPOVER field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPOVER " + e.toString());
		} finally {
			em.close();
		}
	}
	private void fillTVM1T(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting TVM1T " + currentDestination);
			Query query = em.createQuery("DELETE FROM TVM1T s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating TVM1T " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				TVM1T process1 = new TVM1T();
				TVM1TPK process1pk = new TVM1TPK();
				process1pk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling TVM1T field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating TVM1T " + e.toString());
		} finally {
			em.close();
		}
	}
	private void fillZPPPRO2(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPPRO2 " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPPRO2 s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPPRO2 " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPPRO2 process1 = new ZPPPRO2();
				ZPPPRO2PK process1pk = new ZPPPRO2PK();
				process1pk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPPRO2 field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPPRO2 " + e.toString());
		} finally {
			em.close();
		}
	}
	private void fillT179T(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting T179T " + currentDestination);
			Query query = em.createQuery("DELETE FROM T179T s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating T179T " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				T179T process1 = new T179T();
				T179TPK process1pk = new T179TPK();
				process1pk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling T179T field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating T179T " + e.toString());
		} finally {
			em.close();
		}
	}
	private void fillZPROCHARVALTXT(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPROCHARVALTXT " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPROCHARVALTXT s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPROCHARVALTXT " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPROCHARVALTXT process1 = new ZPROCHARVALTXT();
				ZPROCHARVALTXTPK process1pk = new ZPROCHARVALTXTPK();
				process1pk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPROCHARVALTXT field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPROCHARVALTXT " + e.toString());
		} finally {
			em.close();
		}
	}
	
	private void fillT002(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting T002 " + currentDestination);
			Query query = em.createQuery("DELETE FROM T002");
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating T002 " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				T002 process1 = new T002();
				T002PK process1pk = new T002PK();
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(process1, process1pk,
									paramName, oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling T002 field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				process1.setKey(process1pk);
				em.merge(process1);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating T002 " + e.toString());
		} finally {
			em.close();
		}
	}
	

	private void fillZPPMAR1(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPMAR1 " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPMAR1 s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPMAR1 " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPMAR1 zmarki = new ZPPMAR1();
				ZPPMAR1PK zmarkipk = new ZPPMAR1PK();
				zmarkipk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(zmarki, zmarkipk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPMAR1 field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				zmarki.setKey(zmarkipk);
				em.merge(zmarki);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPMAR1 " + e.toString());
		} finally {
			em.close();
		}		
	}
	
	private void fillZPPMAR2(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPMAR2 " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPMAR2 s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPMAR2 " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPMAR2 zmarkii = new ZPPMAR2();
				ZPPMAR2PK zmarkiipk = new ZPPMAR2PK();
				zmarkiipk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(zmarkii, zmarkiipk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPMAR2 field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				zmarkii.setKey(zmarkiipk);
				em.merge(zmarkii);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPMAR2 " + e.toString());
		} finally {
			em.close();
		}		
	}	

	private void fillZPPMAR3(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPMAR3 " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPMAR3 s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPMAR3 " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPMAR3 zmarkiii = new ZPPMAR3();
				ZPPMAR3PK zmarkiiipk = new ZPPMAR3PK();
				zmarkiiipk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(zmarkiii, zmarkiiipk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPMAR3 field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				zmarkiii.setKey(zmarkiiipk);
				em.merge(zmarkiii);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPMAR3 " + e.toString());
		} finally {
			em.close();
		}		
	}
	
	private void fillZPPMAR4(JCoTable outputTable) {

		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();

		try {
			transaction.begin();
			// Delete all entries for the current destination
			LOGGER.debug("Start deleting ZPPMAR4 " + currentDestination);
			Query query = em.createQuery("DELETE FROM ZPPMAR4 s WHERE s.key.system = :destination");
			query.setParameter("destination", currentDestination);
			query.executeUpdate();
			transaction.commit();

			transaction.begin();
			LOGGER.debug("Start replicating ZPPMAR4 " + currentDestination);
			for (int i = 0; i < outputTable.getNumRows(); i++) {
				outputTable.setRow(i);
				JCoFieldIterator it = outputTable.getFieldIterator();
				ZPPMAR4 zmarkiv = new ZPPMAR4();
				ZPPMAR4PK zmarkivpk = new ZPPMAR4PK();
				zmarkivpk.setSystem(currentDestination);
				// get fields of current record
				while (it.hasNextField()) {
					JCoField oComponent = it.nextField();
					if (oComponent.getValue() != ""
							&& oComponent.getValue() != null) {
						String paramName = (String) oComponent.getName();
						paramName = paramName.replace("/", "");
						try {
							// Attempt to fill the field
							setFieldDynamically(zmarkiv, zmarkivpk, paramName,
									oComponent.getValue());
						} catch (Exception ex) {
							LOGGER.debug("Error while filling ZPPMAR4 field "
									+ paramName + " " + ex.toString());
						}
					}
				}
				zmarkiv.setKey(zmarkivpk);
				em.merge(zmarkiv);
			}
			transaction.commit();
		} catch (Exception e) {
			LOGGER.debug("Exception while replicating ZPPMAR4 " + e.toString());
		} finally {
			em.close();
		}		
	}	
	
	// Set dynamically
	public static boolean setFieldDynamically(Object object, Object pk,
			String fieldName, Object fieldValue) throws NoSuchFieldException,
			SecurityException {
		Class<?> clazz = object.getClass();

		try {
			Field field = clazz.getDeclaredField(fieldName.toLowerCase());
			field.setAccessible(true);

			setOnObject(field, object, fieldValue);

			return true;
		} catch (NoSuchFieldException e) {

			// No such field on the object, must be on the PK
			Class<?> pkclazz = pk.getClass();
			Field field = pkclazz.getDeclaredField(fieldName.toLowerCase());
			field.setAccessible(true);
			setOnPkObject(field, pk, fieldValue);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

		return false;
	}

	@SuppressWarnings("unused")
	public static void setOnPkObject(Field field, Object object,
			Object fieldValue) {

		// PK cannot contain null in JPA
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

		try {
			if (fieldValue.toString() != null) {
				if (field.getType().getName()
						.equalsIgnoreCase("java.lang.Integer")) {
					Integer value = Integer.parseInt(fieldValue.toString());
					if (value == null) {
						value = 0;
					}

					field.set(object, value);
				} else if (field.getType().getName()
						.equalsIgnoreCase("java.lang.Long")) {
					Long value = Long.parseLong(fieldValue.toString());
					if (value == null) {
						value = new Integer(0).longValue();
					}

					field.set(object, value);
				} else if (field.getType().getName()
						.equalsIgnoreCase("java.lang.String")) {

					String value = fieldValue.toString();
					if (value == null) {
						value = "";
					}
					field.set(object, value);

				} else if (field.getType().getName()
						.equalsIgnoreCase("java.sql.Date")) {

					java.sql.Date sqlDate;

					if (fieldValue == null) {
						sqlDate = (java.sql.Date) df.parse("00/00/0000");
					} else {
						java.util.Date utilDate = (java.util.Date) fieldValue;
						sqlDate = new java.sql.Date(utilDate.getTime());
					}

					field.set(object, sqlDate);

				} else if (field.getType().getName()
						.equalsIgnoreCase("java.lang.Float")) {

					Float value = Float.parseFloat(fieldValue.toString());

					if (value == null) {
						value = new Float("0.0");
					}

					field.set(object, value);
				} else {
					LOGGER.debug(field.getType().getName());
				}
			}
		} catch (Exception ex) {
			LOGGER.debug("Error setOnObject" + ex.toString());
		}
	}

	public static void setOnObject(Field field, Object object, Object fieldValue) {

		try {
			if (fieldValue.toString() != null) {
				if (field.getType().getName()
						.equalsIgnoreCase("java.lang.Integer")) {
					field.set(object, Integer.parseInt(fieldValue.toString()));
				} else if (field.getType().getName()
						.equalsIgnoreCase("java.lang.Long")) {
					field.set(object, Long.parseLong(fieldValue.toString()));
				} else if (field.getType().getName()
						.equalsIgnoreCase("java.lang.String")) {
					field.set(object, (String) fieldValue);
				} else if (field.getType().getName()
						.equalsIgnoreCase("java.sql.Date")) {

					java.util.Date utilDate = (java.util.Date) fieldValue;
					java.sql.Date sqlDate = new java.sql.Date(
							utilDate.getTime());
					field.set(object, sqlDate);

				} else if (field.getType().getName()
						.equalsIgnoreCase("java.lang.Float")) {
					field.set(object, Float.parseFloat(fieldValue.toString()));
				} else if (field.getType().getName().equalsIgnoreCase("double")) {
					field.set(object, Double.parseDouble(fieldValue.toString()));
				} else {
					LOGGER.debug(field.getType().getName());
				}
			}
		} catch (Exception ex) {
			LOGGER.debug("Error setOnObject" + ex.toString());
		}
	}
}