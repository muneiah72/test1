package com.danone.resources;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.ZPROEU_GRP_PROD;
import com.danone.entities.ZPROEU_QTY;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.EUProdFilterResult;
import com.google.gson.Gson;

public class EUProdFilters extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8937713741573172792L;
	private final Logger LOGGER = LoggerFactory.getLogger(EUProdFilters.class);
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
		
		response.setCharacterEncoding("UTF-8");
		response.addHeader("Content-type", "application/json; charset=utf-8");
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-cache, no-store");
		PrintWriter responseWriter = response.getWriter();
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		EUProdFilterResult result = new EUProdFilterResult();
		
		List<String> EUBrandsConfiguredInWeb = new ArrayList<String>();
		EUBrandsConfiguredInWeb.add("001");
		EUBrandsConfiguredInWeb.add("080");
//		EUBrandsConfiguredInWeb.add("676");
		EUBrandsConfiguredInWeb.add("207");
		EUBrandsConfiguredInWeb.add("009");
//		EUBrandsConfiguredInWeb.add("725");
//		EUBrandsConfiguredInWeb.add("726");
		EUBrandsConfiguredInWeb.add("312");		
		EUBrandsConfiguredInWeb.add("313");
//		EUBrandsConfiguredInWeb.add("566");
		EUBrandsConfiguredInWeb.add("730");
		EUBrandsConfiguredInWeb.add("568");
//		EUBrandsConfiguredInWeb.add("058");
		EUBrandsConfiguredInWeb.add("727");
		EUBrandsConfiguredInWeb.add("035");
		EUBrandsConfiguredInWeb.add("058");
		EUBrandsConfiguredInWeb.add("002");
/*		List<String> LocalBrandsConfiguredInWeb = new ArrayList<String>();
		LocalBrandsConfiguredInWeb.add("081");
		LocalBrandsConfiguredInWeb.add("415");
		LocalBrandsConfiguredInWeb.add("088");
		LocalBrandsConfiguredInWeb.add("732");
		LocalBrandsConfiguredInWeb.add("728");
		LocalBrandsConfiguredInWeb.add("016");
		LocalBrandsConfiguredInWeb.add("089");
		LocalBrandsConfiguredInWeb.add("094");
		LocalBrandsConfiguredInWeb.add("625");
		LocalBrandsConfiguredInWeb.add("144");
		LocalBrandsConfiguredInWeb.add("032");
		LocalBrandsConfiguredInWeb.add("729");
		LocalBrandsConfiguredInWeb.add("730");
		LocalBrandsConfiguredInWeb.add("035");
		LocalBrandsConfiguredInWeb.add("722");
		LocalBrandsConfiguredInWeb.add("146");
		LocalBrandsConfiguredInWeb.add("731");
		LocalBrandsConfiguredInWeb.add("101");*/
		
		try {
			
			List<String> allBrands = ZPROEU_GRP_PROD.getUniqueBrands(em);
			allBrands.removeAll(Collections.singleton(null));
			
			List<String> euBrands = new ArrayList<String>();
//			List<String> localBrands = new ArrayList<String>();
			for (String str : allBrands)
			{
				if (EUBrandsConfiguredInWeb.contains(str))
				{
					euBrands.add(str);
/*				}else if (LocalBrandsConfiguredInWeb.contains(str))
				{
					localBrands.add(str);*/
				}
			}
			result.setEubrands(euBrands);
//			result.setLocalbrands(localBrands);
			
			List<String> brandCat = ZPROEU_GRP_PROD.getUniqueBrandCat(em);
			brandCat.removeAll(Collections.singleton(null));
			result.setBrandcat(brandCat);
			
	  		List<String> countries = ZPROEU_QTY.getUniqueCountries(em);
			countries.removeAll(Collections.singleton(null));
			result.setCountries(countries);
			List<String> potdiam = ZPROEU_GRP_PROD.getUniquePotdiams(em);
			potdiam.removeAll(Collections.singleton(null));
			result.setCuptypes(potdiam);
			List<String> processTech = ZPROEU_GRP_PROD.getUniqueProcessTechnology(em);
			processTech.removeAll(Collections.singleton(null));
			result.setProcesstech(processTech);
			List<String> fatContent = ZPROEU_GRP_PROD.getUniqueFatcontent(em);
			fatContent.removeAll(Collections.singleton(null));
			result.setFatcontent(fatContent);
			List<String> subrange = ZPROEU_GRP_PROD.getUniqueSubrange(em);
			subrange.removeAll(Collections.singleton(null));
			result.setSubrange(subrange);
			List<String> multilayer = ZPROEU_GRP_PROD.getUniqueMultilayer(em);
			multilayer.removeAll(Collections.singleton(null));
			result.setMultilayer(multilayer);
			List<String> topper = ZPROEU_GRP_PROD.getUniqueTopper(em);
			topper.removeAll(Collections.singleton(null));
			result.setTopper(topper);
			
		}catch (Exception e)
		{
			LOGGER.debug("Error getting EUProdFilters: " + e.toString());
		} finally {
			em.close();
		}
		
		responseWriter.print(new Gson().toJson(result));
		
		return;
	}
}
