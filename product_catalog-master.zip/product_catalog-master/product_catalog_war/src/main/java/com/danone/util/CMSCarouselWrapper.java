package com.danone.util;

public class CMSCarouselWrapper {
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
