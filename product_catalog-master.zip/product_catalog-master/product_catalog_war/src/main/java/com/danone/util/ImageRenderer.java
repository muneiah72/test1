package com.danone.util;

import java.io.IOException;
import java.io.InputStream;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.commons.io.IOUtils;
import org.apache.tika.Tika;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.CMSCAROUSEL;
import com.danone.entities.CMSCAROUSELPK;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.CmisHelper;

/**
 * Servlet implementation class ImageRenderer
 */
public class ImageRenderer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(ImageRenderer.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ImageRenderer() {
		super();
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		LOGGER.debug("In ImageRenderer service servlet");
		EntityManager em = PersistenceAdapter.getEntityManager();

		byte[] aBlob = null;
		long imageUploadTime = 0;
		boolean imageNotFound = false;
		String imageKey = "";
		String fileName = null;

		// Webshop document file
		// String webshopDocumentId = request.getParameter("webshopDocument");
		// if (webshopDocumentId != null) {
		//
		// String language = request.getParameter("language");
		// String type = request.getParameter("type");
		//
		// Integer validFrom =
		// Integer.parseInt(request.getParameter("validFrom"));
		// Integer validTo = Integer.parseInt(request.getParameter("validTo"));
		//
		// CMSCONFIG document = CMSCONFIG.getDocumentByKey(em, new
		// CMSCONFIGPK(language, type, validFrom, validTo));
		// if (document != null) {
		// aBlob = document.getDocument();
		// imageUploadTime = 0;
		// imageNotFound = false;
		// } else {
		// imageNotFound = true;
		// }
		// }

		// CMS Carousel Image
		String webshopImageId = request.getParameter("webshopImage");
		if (webshopImageId != null) {
			Integer id = Integer.parseInt(request.getParameter("id"));

			CMSCAROUSEL image = CMSCAROUSEL.getCarouselByKey(em, new CMSCAROUSELPK(id));
			if (image != null) {
				aBlob = image.getPicture();
				imageUploadTime = 0;
				imageNotFound = false;
			} else {
				imageNotFound = true;
			}
		}

		// Webshop document Document
		// String webshopDocId = request.getParameter("webshopDoc");
		// if (webshopDocId != null) {
		// Integer id = Integer.getInteger(request.getParameter("id")) ;
		//
		// CMSCAROUSEL doc = CMSCAROUSEL.getCarouselByKey(em, new
		// CMSCAROUSELPK(id));
		// if (doc != null) {
		// aBlob = doc.getDocument();
		// imageUploadTime = 0;
		// imageNotFound = false;
		// } else {
		// imageNotFound = true;
		// }
		// }

		// DMS Image
		String DmsDocumentId = request.getParameter("DmsDocument");
		if (DmsDocumentId != null) {
			String documentId = request.getParameter("documentId");
			CmisHelper cmis = new CmisHelper();
			ContentStream contentStream = cmis.getDocumentStreamById(documentId);
			fileName = request.getParameter("fileName");
			if (fileName == null) {
				fileName = cmis.getDocumentNameById(documentId);
			}

			if (contentStream != null) {
				InputStream inputStream = contentStream.getStream();
				aBlob = IOUtils.toByteArray(inputStream);
				imageUploadTime = 0;
				imageNotFound = false;
			} else {
				imageNotFound = true;
			}
		}


		String fileFormat =   new Tika().detect(aBlob); 
		// Image rendering
		if (!imageNotFound) {
			if (imageUploadTime <= 0) {
				imageUploadTime = System.currentTimeMillis();
			}
			long ifModifiedSince = request.getDateHeader("If-Modified-Since");
			if (ifModifiedSince < (imageUploadTime / 1000 * 1000)) {
				maybeSetLastModified(response, imageUploadTime);

				if (aBlob != null && aBlob.length > 0) {
					response.setContentLength(aBlob.length);
					response.setContentType(fileFormat);
					String fileExtension = Utils.getFormat(fileFormat);
					fileName = fileName + "." + fileExtension;
					String download = request.getParameter("Download");
					if (download != null) {
						if (download.equalsIgnoreCase("X")) {
							response.addHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
						}
					}
					response.getOutputStream().write(aBlob, 0, aBlob.length);
					// /* Cache Handling */
					final int CACHE_DURATION_IN_SECOND = 60 * 60 * 24 * 1; // 1
					// day
					// final
					long CACHE_DURATION_IN_MS = CACHE_DURATION_IN_SECOND * 1000;
					long now = System.currentTimeMillis();
					response.addHeader("Cache-Control", "max-age=" + CACHE_DURATION_IN_SECOND);
					response.setDateHeader("Last-Modified", imageUploadTime);
					response.setDateHeader("Expires", now + CACHE_DURATION_IN_MS);
				} else {
					response.setContentType(fileFormat);
					response.setStatus(HttpServletResponse.SC_NOT_FOUND);
				}
			} else {
				response.setContentType(fileFormat);
				response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
			}
		} else {
			response.getOutputStream().print("No Image found for key " + imageKey);
			response.setContentType("text/html");
		}
		em.close();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	public long getLastModified(HttpServletRequest req) {
		return -1;
	}

	private void maybeSetLastModified(HttpServletResponse resp, long lastModified) {
		if (resp.containsHeader("Last-Modified"))
			return;
		if (lastModified >= 0)
			resp.setDateHeader("Last-Modified", lastModified);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}