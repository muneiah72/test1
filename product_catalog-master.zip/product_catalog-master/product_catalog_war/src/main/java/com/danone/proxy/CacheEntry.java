package com.danone.proxy;

import org.apache.http.HttpResponse;

public class CacheEntry {

	private ProxyRequest request;
	private HttpResponse response;

	public CacheEntry(ProxyRequest request, HttpResponse response) {
		this.request = request;
		this.response = response;
	}

	public ProxyRequest getClientRequest() {
		return request;
	}

	public void setClientRequest(ProxyRequest request) {
		this.request = request;
	}

	public HttpResponse getBackendResponse() {
		return response;
	}

	public void setBackendResponse(HttpResponse response) {
		this.response = response;
	}

}
