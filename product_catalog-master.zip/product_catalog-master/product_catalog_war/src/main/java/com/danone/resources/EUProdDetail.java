package com.danone.resources;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.MAKT;
import com.danone.entities.MAKTPK;
import com.danone.entities.PICTURES;
import com.danone.entities.PICTURESPK;
import com.danone.entities.PRICAT_K004;
import com.danone.entities.PRICAT_K005;
import com.danone.entities.PRICAT_K006;
import com.danone.entities.ZPPFLAV;
import com.danone.entities.ZPRODCAT_HDR;
import com.danone.entities.ZPRODCAT_ITEM;
import com.danone.entities.ZPROEU_GRP_PROD;
import com.danone.entities.ZPROEU_PLANT;
import com.danone.entities.ZPROEU_QTY;
import com.danone.entities.ZPRO_NUTBOARD;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.EUProdFull;
import com.danone.util.EUProdSKUList;
import com.danone.util.EUProdSKUListComparator;
import com.danone.util.KeyToDescription;
import com.google.gson.Gson;

public class EUProdDetail extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1596502395604000071L;
	private final Logger LOGGER = LoggerFactory.getLogger(EUProdDetail.class);

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		Enumeration<String> enumer = request.getParameterNames();
		JSONObject params = null;
		if (enumer.hasMoreElements()) {
			String jsonString = enumer.nextElement();
			LOGGER.debug("JSON String: " + jsonString);
			params = new JSONObject(jsonString);
		}

		response.setCharacterEncoding("UTF-8");
		response.addHeader("Content-type", "application/json; charset=utf-8");
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-cache, no-store");
		PrintWriter responseWriter = response.getWriter();

		String mandt = "";
		String system = "";
		String guid = "";
		if (params != null) {
			mandt = params.getString("MANDT");
			system = params.getString("SYSTEM");
			guid = params.getString("CATGUID");
		}

		EntityManager em = PersistenceAdapter.getEntityManager();
		EUProdFull result = new EUProdFull();
		result.setPictureId("");
		KeyToDescription keyToDesc = KeyToDescription.getInstance();

		if (mandt == "" || guid == "" || system == "") {
			responseWriter.print(new Gson().toJson(result));
			return;
		}

		try {

			ZPROEU_GRP_PROD product = ZPROEU_GRP_PROD
					.getZPROEU_GRP_PRODByMandtAndGuid(em, system,
							Integer.parseInt(mandt), guid);

			// Check if there is grouping for this product
			List<ZPROEU_GRP_PROD> listGrouping = ZPROEU_GRP_PROD
					.getZPROEU_GRP_PRODByMandt(em,
							product.getKey().getSystem(), product.getKey()
									.getMandt(), product.getKey().getVkorg(),
							product.getKey().getSpart(), product.getGroup1(),
							product.getGroup2(), product.getGroup3(), product
									.getGroup4(), product.getGroup5(), product
									.getGroup6(), product.getGroup7(), product
									.getGroup8(), product.getGroup9(), product
									.getGroup10());
			LOGGER.debug("Number of entrees in listGrouping: "
					+ listGrouping.size());

			ZPRODCAT_HDR prodcatheader = ZPRODCAT_HDR.getHeaderByCatGuid(em,
					system, guid);
			LOGGER.debug("prodcatheader");
			if (prodcatheader == null) {
				LOGGER.error("No prodcatheader for system: " + system
						+ " and guid: " + guid);
				responseWriter.print(new Gson().toJson(result));
				return;
			}
			ZPRODCAT_ITEM prodcatitem = ZPRODCAT_ITEM.getItemByGuidAndPostyp(
					em, system, guid, "P");
			LOGGER.debug("prodcatitem");
			if (prodcatitem == null) {
				LOGGER.error("No prodcatitem for system: " + system
						+ " and guid: " + guid);
				responseWriter.print(new Gson().toJson(result));
				return;
			}

			result.setMandt(product.getKey().getMandt());
			result.setCat_guid(product.getUuid());

			/*
			 * MAKT entry = MAKT.getMAKTByKey(em, new
			 * MAKTPK(product.getKey().getSystem(), product.getKey().getMandt(),
			 * product.getKey().getMatnr(), "E")); if (entry != null) {
			 * result.setTitle(entry.getMaktx()); }
			 */

			LOGGER.debug("Fetch picture");
			// Fetch picture info
			List<ZPRODCAT_ITEM> listItems = new ArrayList<ZPRODCAT_ITEM>();
			for (ZPROEU_GRP_PROD pr : listGrouping) {
				List<ZPRODCAT_ITEM> listItemsPr = ZPRODCAT_ITEM.getItemsByType(
						em, pr.getKey().getSystem(), pr.getKey().getMandt(),
						pr.getUuid(), "D");
				LOGGER.debug("List items pr: " + listItemsPr.size());
				if (listItemsPr.size() > 0) {
					listItems.addAll(listItemsPr);
				}
			}

			LOGGER.debug("Found document items: " + listItems.size());
			for (ZPRODCAT_ITEM itemDoc : listItems) {
				LOGGER.debug("Searching for picture for: "
						+ itemDoc.getKey().getSystem() + " "
						+ itemDoc.getKey().getMandt() + " "
						+ itemDoc.getDokar() + " " + itemDoc.getDoknr() + " "
						+ itemDoc.getDokvr() + " " + itemDoc.getDoktl());
				PICTURESPK picturespk = new PICTURESPK(itemDoc.getKey()
						.getSystem(), itemDoc.getKey().getMandt(),
						itemDoc.getDokar(), itemDoc.getDoknr(),
						itemDoc.getDokvr(), itemDoc.getDoktl());
				PICTURES picturesentry = PICTURES.getPICTURESByKey(em,
						picturespk);
				if (picturesentry != null) {
					result.setPictureId("/main/ImageRenderer?DmsDocument=true&documentId="
							+ picturesentry.getImage_id());
					break;
				} else {
					LOGGER.debug("No pictures entry for this key");
				}
			}

			LOGGER.debug("After picture");
			String brand = "";
			String level4 = "";
			String zzproces = "";
			String subbrand = "";
			String potdiam = "";
			String topper = "";
			String multilayer = "";
			if (product.getBrand() != null) {
				brand = product.getBrand();
			}
			if (product.getLevel4() != null) {
				level4 = product.getLevel4();
			}
			if (product.getZzproces1() != null) {
				zzproces = product.getZzproces1();
			}
			if (product.getSubbrand() != null) {
				subbrand = product.getSubbrand();
			}
			if (product.getZzpot_diam() != null) {
				potdiam = product.getZzpot_diam();
			}
			if (product.getZzrange() != null) {
				topper = product.getZzrange();
			}
			if (product.getZzsub_range() != null) {
				multilayer = product.getZzsub_range();
			}

			/* Title */
			String title = keyToDesc.getBrandText(brand) + " "
					+ keyToDesc.getFatText(subbrand) + " "
					+ keyToDesc.getSubrangeText(level4);
			result.setTitle(title);

			/* Description */
			String description = "";
			if (!keyToDesc.getProcessTechText(zzproces).equalsIgnoreCase("")) {
				if (description.length() > 0) {
					description = description + " • ";
				}
				description = description
						+ keyToDesc.getProcessTechText(zzproces);
			}
			if (!keyToDesc.getCupDiamText(potdiam).equalsIgnoreCase("")) {
				if (description.length() > 0) {
					description = description + " • ";
				}
				description = description + keyToDesc.getCupDiamText(potdiam);
			}
			if (!keyToDesc.getTopperText(topper).equalsIgnoreCase("")) {
				if (description.length() > 0) {
					description = description + " • ";
				}
				description = description + "TOPPER "
						+ keyToDesc.getTopperText(topper);
			}
			if (!keyToDesc.getMultilayerText(multilayer).equalsIgnoreCase("")) {
				if (description.length() > 0) {
					description = description + " • ";
				}
				description = description
						+ keyToDesc.getMultilayerText(multilayer);
			}

			result.setDescription(description);

			// First block of info in EU ProdCatalog product detail page
			result.setBrandCode(brand);
			result.setBrand(keyToDesc.getBrandText(brand));
			result.setProcessTechnology(keyToDesc.getProcessTechText(zzproces));
			result.setCupDiameter(keyToDesc.getCupDiamText(potdiam));
			Double minWeight = null;
			Double maxWeight = null;
			for (ZPROEU_GRP_PROD pr : listGrouping) {
				if (minWeight == null & maxWeight == null) {
					minWeight = pr.getNtgew();
					maxWeight = pr.getNtgew();
				} else {
					if (pr.getNtgew() < minWeight) {
						minWeight = pr.getNtgew();
					}
					if (pr.getNtgew() > maxWeight) {
						maxWeight = pr.getNtgew();
					}
				}
			}
			if (minWeight.intValue() == maxWeight.intValue()) {
				result.setWeight(String.valueOf(minWeight.intValue()));
			} else {
				result.setWeight(String.valueOf(minWeight.intValue()) + " - "
						+ String.valueOf(maxWeight.intValue()));
			}

			result.setShelflife(product.getMhdhb());
			if (topper.equalsIgnoreCase("")) {
				result.setTopper(" - ");
			} else {
				result.setTopper(keyToDesc.getTopperText(topper));
			}
			if (multilayer.equalsIgnoreCase("")) {
				result.setMultilayer(" - ");
			} else {
				result.setMultilayer(keyToDesc.getMultilayerText(multilayer));
			}

			// Second block of info in EU ProdCatalog product detail page
			LOGGER.debug("Second block of info");
			result.setFormat("");
			List<String> formats = new ArrayList<String>();
			for (ZPROEU_GRP_PROD pr : listGrouping) {
				if (!formats.contains("x" + pr.getZzby().toString())) {
					formats.add("x" + pr.getZzby().toString());
				}
			}
			if (formats.size() > 0) {
				Collections.sort(formats);
			}

			for (String format : formats) {
				if (result.getFormat().length() > 0) {
					result.setFormat(result.getFormat() + ", ");
				}
				result.setFormat(result.getFormat() + format);
			}

			result.setFlavors("");
			List<String> flavNames = new ArrayList<String>();
			for (ZPROEU_GRP_PROD pr : listGrouping) {
				ZPPFLAV flav = ZPPFLAV.getZPPFLAVByKey(em, product.getKey()
						.getSystem(), product.getKey().getMandt(), pr
						.getZzflavor());
				if (flav != null) {
					if (!flavNames.contains(flav.getZdescription())) {
						flavNames.add(flav.getZdescription());
					}
				} else {
					LOGGER.debug("Flav null for: " + pr.getZzflavor());
				}
			}
			// Sort the flavour names
			if (flavNames.size() > 0) {
				Collections.sort(flavNames);
			}

			for (String flav : flavNames) {
				if (result.getFlavors().length() > 0) {
					result.setFlavors(result.getFlavors() + ", ");
				}
				result.setFlavors(result.getFlavors() + flav);
			}

			// Third block of info in EU ProdCatalog product detail page
			LOGGER.debug("Third block of info");
			ArrayList<String> characterist = new ArrayList<String>();
			characterist.add("LABELLING_CODE");

			List<PRICAT_K006> listMulti = PRICAT_K006.getK006With(em,
					prodcatheader.getKey().getSystem(), prodcatheader.getKey()
							.getMandt(), prodcatheader.getPrinbr(),
					prodcatheader.getProductgroup(), prodcatheader
							.getEan_upc_base(), prodcatitem.getValidity_base(),
					characterist);

			String codeLabelling = "";
			for (PRICAT_K006 element : listMulti) {

				if (element.getKey().getCharacteristic()
						.equalsIgnoreCase("LABELLING_CODE")) {
					codeLabelling = element.getKey().getDescription();
				}
			}

			List<ZPRO_NUTBOARD> nutboard = ZPRO_NUTBOARD
					.getNutboardByMatnrAndValidityAndLabelcod(em, prodcatheader
							.getKey().getSystem(), prodcatheader.getMatnr(),
							codeLabelling);
			result.setNutritionalvaluesCol1("");
			result.setNutritionalvaluesCol2("");
			for (ZPRO_NUTBOARD nutentry : nutboard) {
				if (result.getNutritionalvaluesCol1().length() > 0) {
					result.setNutritionalvaluesCol1(result
							.getNutritionalvaluesCol1() + "\n");
				}
				result.setNutritionalvaluesCol1(result
						.getNutritionalvaluesCol1()
						+ nutentry.getKey().getNutid());

				if (result.getNutritionalvaluesCol2().length() > 0) {
					result.setNutritionalvaluesCol2(result
							.getNutritionalvaluesCol2() + "\n");
				}
				result.setNutritionalvaluesCol2(result
						.getNutritionalvaluesCol2()
						+ nutentry.getAjrc()
						+ nutentry.getValueun().toLowerCase());
			}

			// Fetch and set PRICAT_K005 data (Texts)
			String texttypes[] = { "ZING" };
			LOGGER.debug("Fetch K005 with system: "
					+ prodcatheader.getKey().getSystem());
			List<PRICAT_K005> listK005 = PRICAT_K005.getK005With(em,
					prodcatheader.getKey().getSystem(), prodcatheader.getKey()
							.getMandt(), prodcatheader.getPrinbr(),
					prodcatheader.getProductgroup(), prodcatheader
							.getEan_upc_base(), prodcatitem.getValidity_base(),
					"E", texttypes);

			for (PRICAT_K005 element : listK005) {
				if (element.getKey().getTexttyp() != null
						&& element.getText_line() != null) {
					if (element.getKey().getTexttyp().equalsIgnoreCase("ZING")) {
						try {
							if (result.getIngredientslist() == null) {
								result.setIngredientslist(element
										.getText_line());
							} else {
								result.setIngredientslist(result
										.getIngredientslist()
										+ element.getText_line());
							}
						} catch (Exception e) {
							result.setIngredientslist("");
							LOGGER.debug("Error with ZING text setting ingredientlist: "
									+ e.toString());
						}
					}
				}
			}

			// Fourth block of info in EU ProdCatalog product detail page
			result.setSellingcountries("");
			result.setSellingcountriesCapacity("");
			List<ZPROEU_QTY> qtyList = new ArrayList<ZPROEU_QTY>();
			for (ZPROEU_GRP_PROD pr : listGrouping) {
				List<ZPROEU_QTY> qtyListPr = ZPROEU_QTY.getZPROEU_QTYBySearch(
						em, pr.getKey().getSystem(), pr.getKey().getMandt(), pr
								.getKey().getMatnr());
				if (qtyListPr.size() > 0) {
					qtyList.addAll(qtyListPr);
				}
			}

			LOGGER.debug("ZPROEU_QTY length: " + qtyList.size());
			HashMap<String, Double> map = new HashMap<String, Double>();
			for (ZPROEU_QTY qtyEntry : qtyList) {

				if (qtyEntry.getNtgew() > 0) {
					String key = qtyEntry.getKey().getCtrydest();

					if (map.containsKey(key)) {
						Double oldQuantity = (Double) map.get(key);
						map.put(key,
								Double.valueOf(qtyEntry.getNtgew()
										+ oldQuantity.doubleValue()));

					} else {
						map.put(key, Double.valueOf(qtyEntry.getNtgew()));
					}
					// if
					// (!result.getSellingcountries().contains(keyToDesc.getCountryText(qtyEntry.getKey().getCtrydest())))
					// {
					// if (result.getSellingcountries().length() > 0)
					// {
					// result.setSellingcountries(result.getSellingcountries() +
					// "\n");
					// }
					// result.setSellingcountries(result.getSellingcountries() +
					// keyToDesc.getCountryText(qtyEntry.getKey().getCtrydest()));
					//
					// if (result.getSellingcountriesCapacity().length() > 0)
					// {
					// result.setSellingcountriesCapacity(result.getSellingcountriesCapacity()
					// + "\n");
					// }
					//
					// Double qty = (qtyEntry.getFklmg() / 6);
					// result.setSellingcountriesCapacity(result.getSellingcountriesCapacity()
					// + qty.intValue());
					// }
				}
			}

			for (Map.Entry<String, Double> entry : map.entrySet()) {
				double capacity = entry.getValue().doubleValue() / 4;
				int capacityrnd = (int) Math.round(capacity);
				if (capacityrnd > 0)
				{
					if (result.getSellingcountries().length() > 0)
					{
						result.setSellingcountries(result.getSellingcountries() + "\n");
					}
					result.setSellingcountries(result.getSellingcountries() +
							keyToDesc.getCountryText(entry.getKey()));
					//				result.setSellingcountries(keyToDesc.getCountryText(entry
					//						.getKey()) + "\n");

					if (result.getSellingcountriesCapacity().length() > 0)
					{
						result.setSellingcountriesCapacity(result.getSellingcountriesCapacity() + "\n");
					}
					result.setSellingcountriesCapacity(result.getSellingcountriesCapacity()
							+ String.valueOf(capacityrnd));
					//				result.setSellingcountriesCapacity(String.valueOf(capacity)
					//						+ "\n");
				}
			}

			List<ZPROEU_PLANT> plantlist = new ArrayList<ZPROEU_PLANT>();
			result.setFactories("");
			for (ZPROEU_GRP_PROD pr : listGrouping) {
				List<ZPROEU_PLANT> plantlistPr = ZPROEU_PLANT
						.getZPROEU_PLANTByMandtAndGuid(em, pr.getKey()
								.getSystem(), pr.getKey().getMandt(), pr
								.getKey().getMatnr());
				if (plantlistPr.size() > 0) {
					plantlist.addAll(plantlistPr);
				}
			}
			for (ZPROEU_PLANT plantEntry : plantlist) {
				if (!result.getFactories().contains(
						keyToDesc.getPlantText(plantEntry.getKey().getwerks()))) {
					if (result.getFactories().length() > 0) {
						result.setFactories(result.getFactories() + "\n");
					}
					result.setFactories(result.getFactories()
							+ keyToDesc.getPlantText(plantEntry.getKey()
									.getwerks()));
				}
			}

			if (request.isUserInRole(Roles.EUPRODTRANSFERPRICE)) {
				result.setTransferprice(String.valueOf(product.getStprs()));
				result.setCapacity(""); // LATER
			} else {
				result.setTransferprice("Unauthorized");
				result.setCapacity("Unauthorized");
			}

			// SKU List
			List<EUProdSKUList> skulist = new ArrayList<EUProdSKUList>();
			for (ZPROEU_GRP_PROD pr : listGrouping) {
				EUProdSKUList entry = new EUProdSKUList();
				entry.setFactory("");
				entry.setFlavour("");
				entry.setSellingcountry("");
				entry.setMaktx("");
				entry.setFormat("");
				entry.setMatnr(pr.getKey().getMatnr()
						.replaceFirst("^0+(?!$)", ""));
				entry.setWeight(pr.getNtgew());

				MAKT makt = MAKT.getMAKTByKey(em, new MAKTPK(pr.getKey()
						.getSystem(), pr.getKey().getMandt(), pr.getKey()
						.getMatnr(), "E"));
				if (makt != null) {
					entry.setMaktx(makt.getMaktx());
				} else {
					entry.setMaktx("");
				}

				List<ZPROEU_PLANT> plantlistSku = ZPROEU_PLANT
						.getZPROEU_PLANTByMandtAndGuid(em, pr.getKey()
								.getSystem(), pr.getKey().getMandt(), pr
								.getKey().getMatnr());
				if (plantlistSku.size() > 0) {
					for (ZPROEU_PLANT plantEntry : plantlistSku) {
						if (!entry.getFactory().contains(
								keyToDesc.getPlantText(plantEntry.getKey()
										.getwerks()))) {
							if (entry.getFactory().length() > 0) {
								entry.setFactory(entry.getFactory() + ", ");
							}
							entry.setFactory(entry.getFactory()
									+ keyToDesc.getPlantText(plantEntry
											.getKey().getwerks()));
						}
					}
				}
				ZPRODCAT_HDR hdr = ZPRODCAT_HDR.getHeaderByCatGuid(em, pr
						.getKey().getSystem(), pr.getUuid());
				if (hdr != null) {
					ZPRODCAT_ITEM it = ZPRODCAT_ITEM.getItemByGuidAndPostyp(em,
							hdr.getKey().getSystem(), hdr.getKey()
									.getCat_guid(), "P");
					if (it != null) {
						List<PRICAT_K004> k004List = PRICAT_K004.getK004With(
								em, hdr.getKey().getSystem(), hdr.getKey()
										.getMandt(), hdr.getPrinbr(), hdr
										.getProductgroup(), hdr
										.getEan_upc_base(), it
										.getValidity_base());
						for (PRICAT_K004 k004 : k004List) {
							if (k004.getAlt_unit_iso().equalsIgnoreCase("CT")) {
								entry.setSkutray(k004.getNumerator());
								break;
							}
						}
					}
				}

				ZPPFLAV flav = ZPPFLAV.getZPPFLAVByKey(em, pr.getKey()
						.getSystem(), pr.getKey().getMandt(), pr.getZzflavor());
				if (flav != null) {
					entry.setFlavour(flav.getZdescription());
				} else {
					entry.setFlavour("");
				}
				entry.setFormat("x" + pr.getZzby());
				entry.setArtemisref(pr.getLabel_code());

				List<ZPROEU_QTY> qtyListPr = ZPROEU_QTY.getZPROEU_QTYBySearch(
						em, pr.getKey().getSystem(), pr.getKey().getMandt(), pr
								.getKey().getMatnr());
				for (ZPROEU_QTY qty : qtyListPr) {
					entry.setSellingcountry(keyToDesc.getCountryText(qty
							.getKey().getCtrydest()));
				}

				skulist.add(entry);
			}

			Collections.sort(skulist, new EUProdSKUListComparator());
			// Collections.sort(skulist);
			result.setSkuList(skulist);

			responseWriter.print(new Gson().toJson(result));
			return;

		} catch (Exception e) {
			LOGGER.debug("Error getting EUProdDetail: " + e.toString());
		} finally {
			em.close();
		}

		responseWriter.print(new Gson().toJson(Collections.EMPTY_LIST));

		return;
	}
}
