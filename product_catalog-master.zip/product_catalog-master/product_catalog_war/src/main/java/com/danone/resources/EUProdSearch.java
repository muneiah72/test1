package com.danone.resources;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.PICTURES;
import com.danone.entities.PICTURESPK;
import com.danone.entities.ZPRODCAT_ITEM;
import com.danone.entities.ZPROEU_GRP_PROD;
import com.danone.entities.ZPROEU_QTY;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.EUProdSearchResult;
import com.danone.util.KeyToDescription;
import com.google.gson.Gson;

public class EUProdSearch extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8714801497023307278L;
	private final Logger LOGGER = LoggerFactory.getLogger(EUProdSearch.class);
	
	
	@Override
	public void init() {
		// load properties from disk, do be used by subsequent doGet() calls
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
		Enumeration<String> enumer = request.getParameterNames();
		JSONObject params = null;
		if (enumer.hasMoreElements())
		{
			String jsonString = enumer.nextElement();
			LOGGER.debug("JSON String: " + jsonString);
			params = new JSONObject(jsonString);
		}
		
		response.setCharacterEncoding("UTF-8");
		response.addHeader("Content-type", "application/json; charset=utf-8");
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-cache, no-store");
		PrintWriter responseWriter = response.getWriter();
		
		String searchString = "";
		JSONObject searchFilters = null;
		
		List<List<EUProdSearchResult>> fullProductList = new ArrayList<List<EUProdSearchResult>>();
		List<EUProdSearchResult> smallList = new ArrayList<EUProdSearchResult>();
		
		if (params != null)
		{
			searchString = params.getString("SEARCHSTR");
			searchFilters = params.getJSONObject("SEARCHFILTERS");
		}else {
			LOGGER.debug("No params");
			responseWriter.print(new Gson().toJson(fullProductList));
		}
		
		EntityManager em = PersistenceAdapter.getEntityManager();
		
		if (searchString.length() > 0)
		{
			KeyToDescription keyToDesc = KeyToDescription.getInstance();
			searchString = keyToDesc.getSearchBrandTechnologyFlavorKey(searchString);
		}
		
		try {
			LOGGER.debug("Searching with " + searchString);
			LOGGER.debug("Searching with filters: " + searchFilters);
			JSONArray brandArray = searchFilters.getJSONArray("eubrands");
//		    JSONArray locBrandArray = searchFilters.getJSONArray("localbrands");
			JSONArray brandCatArray = searchFilters.getJSONArray("brandcat");
			JSONArray fatcontentArray = searchFilters.getJSONArray("fatcontent");
			JSONArray subrangeArray = searchFilters.getJSONArray("subrange");
			JSONArray processTechArray = searchFilters.getJSONArray("processtechnology");
			JSONArray cuptypeArray = searchFilters.getJSONArray("cuptype");
			JSONArray multilayerArray = searchFilters.getJSONArray("multilayer");
			JSONArray topperArray = searchFilters.getJSONArray("topper");
			JSONArray weightArray = searchFilters.getJSONArray("weightButtons");
			JSONArray countryArray = searchFilters.getJSONArray("country");
			JSONObject weight = searchFilters.getJSONObject("cupweight");
			JSONObject price = searchFilters.getJSONObject("price");
			
			//For security reasons, the price might be filled by debugging, always clear it if user doesn't have the necessary role assigned
			if (!request.isUserInRole(Roles.EUPRODTRANSFERPRICE)) {
				price = new JSONObject();
			}
			
/*			for (int i=0; i<locBrandArray.length(); i++)
			{
				String brand = locBrandArray.getString(i);
				Boolean found = false;
				for (int j=0; j<brandArray.length(); j++)
				{
					if (brand.equalsIgnoreCase(brandArray.getString(j)))
					{
						found = true;
					}
				}
				if (!found)
				{
					brandArray.put(brand);
				}
			}*/
			
			LOGGER.debug("Before getZPROEU_GRP_PRODBySearch ");
			List<ZPROEU_GRP_PROD> grpProdList = ZPROEU_GRP_PROD.getZPROEU_GRP_PRODBySearch(em, searchString, brandArray, brandCatArray, fatcontentArray, subrangeArray, processTechArray, cuptypeArray, multilayerArray, weight, price, topperArray, weightArray);
			LOGGER.debug("ZPROEU_GRP_PRODBySearch " + grpProdList.size());
			List<ZPROEU_GRP_PROD> deleteEntries = new ArrayList<ZPROEU_GRP_PROD>();
			
			//Filter out based on selling country
			if (countryArray.length() > 0)
			{
				LOGGER.debug("Filter out based on selling countries");
				deleteEntries.clear();
				
				for (ZPROEU_GRP_PROD entry : grpProdList)
				{
					List<ZPROEU_QTY> qtyListPr = ZPROEU_QTY.getZPROEU_QTYBySearch(em, entry.getKey().getSystem(), entry.getKey().getMandt(), entry.getKey().getMatnr());
					Boolean found = false;
					for (ZPROEU_QTY qty : qtyListPr)
					{
						String country = qty.getKey().getCtrydest();
						for(int i=0; i < countryArray.length(); i++)
				        {
							String countryKey = countryArray.getString(i);
				            if (country.equalsIgnoreCase(countryKey))
				            {
				            	found = true;
				            	break;
				            }
				        }
						if (found)
						{
							break;
						}
					}
					
					if (!found)
					{
						deleteEntries.add(entry);
					}
				}
				
				for (ZPROEU_GRP_PROD entry : deleteEntries)
				{
					grpProdList.remove(entry);
				}
				LOGGER.debug("Still " + grpProdList.size() + "entrees");
			}			
			
			//Aggregate on groups values			
			deleteEntries.clear();
			ZPROEU_GRP_PROD previousEntry = null;
			LOGGER.debug("Loop over " + grpProdList.size());
			for (ZPROEU_GRP_PROD entry : grpProdList)
			{
				if (previousEntry != null)
				{
					if (entry.getGroup1().equalsIgnoreCase(previousEntry.getGroup1()) &&
							entry.getGroup2().equalsIgnoreCase(previousEntry.getGroup2()) &&
							entry.getGroup3().equalsIgnoreCase(previousEntry.getGroup3()) &&
							entry.getGroup4().equalsIgnoreCase(previousEntry.getGroup4()) &&
							entry.getGroup5().equalsIgnoreCase(previousEntry.getGroup5()) &&
							entry.getGroup6().equalsIgnoreCase(previousEntry.getGroup6()) &&
							entry.getGroup7().equalsIgnoreCase(previousEntry.getGroup7()) &&
							entry.getGroup8().equalsIgnoreCase(previousEntry.getGroup8()) &&
							entry.getGroup9().equalsIgnoreCase(previousEntry.getGroup9()) &&
							entry.getGroup10().equalsIgnoreCase(previousEntry.getGroup10()) )
					{
						deleteEntries.add(previousEntry);
					}
				}
				
				previousEntry = entry;
			}
			
			LOGGER.debug("Delete entries: " + deleteEntries.size());
			
			for (ZPROEU_GRP_PROD entry : deleteEntries)
			{
				grpProdList.remove(entry);
			}
			
			//Delete empty group1's
			deleteEntries.clear();
			LOGGER.debug("Still " + grpProdList.size() + "entrees");
			for (ZPROEU_GRP_PROD entry : grpProdList)
			{
				if (entry.getGroup1() == null)
				{
					deleteEntries.add(entry);
				}else if (entry.getGroup1().equalsIgnoreCase("")) {
					deleteEntries.add(entry);
				}
				if (entry.getGroup1().isEmpty())
				{
					LOGGER.debug("Add to delete");
					
				}else {
					LOGGER.debug("Don't add to delete");
				}
			}
			LOGGER.debug("Delete: " + deleteEntries.size());
			for (ZPROEU_GRP_PROD entry : deleteEntries)
			{
				grpProdList.remove(entry);
			}
			

			
			LOGGER.debug("Number of product pages: " + grpProdList.size());
			Iterator<ZPROEU_GRP_PROD> iterator = grpProdList.iterator();
			while (iterator.hasNext()) {
				ZPROEU_GRP_PROD product = iterator.next();
				EUProdSearchResult resultProduct = new EUProdSearchResult();
				resultProduct.setMandt(product.getKey().getMandt());
				resultProduct.setCat_guid(product.getUuid());
				resultProduct.setSystem(product.getKey().getSystem());
				
				/*
				MAKT entry = MAKT.getMAKTByKey(em, new MAKTPK(product.getKey().getSystem(), product.getKey().getMandt(), product.getKey().getMatnr(), "E"));
				if (entry != null)
				{
					resultProduct.setTitle(entry.getMaktx());
				}
				*/
				
				//Fetch picture info	
				List<ZPROEU_GRP_PROD> listGrouping = ZPROEU_GRP_PROD.getZPROEU_GRP_PRODByMandt(em, product.getKey().getSystem(), product.getKey().getMandt(), 
						product.getKey().getVkorg(), product.getKey().getSpart(), product.getGroup1(), product.getGroup2(), 
						product.getGroup3(), product.getGroup4(), product.getGroup5(), product.getGroup6(), product.getGroup7(), 
						product.getGroup8(), product.getGroup9(), product.getGroup10());
				LOGGER.debug("Number of entrees in listGrouping: " + listGrouping.size());
				
				List<ZPRODCAT_ITEM> listItems = new ArrayList<ZPRODCAT_ITEM>();
				LOGGER.debug("Start loop over all listGrouping items for pictures: " + listGrouping.size());
				for (ZPROEU_GRP_PROD pr : listGrouping)
				{
					List<ZPRODCAT_ITEM> listItemsPr = ZPRODCAT_ITEM.getItemsByType(em, pr.getKey().getSystem(), pr.getKey().getMandt(), pr.getUuid(), "D");			
					listItems.addAll(listItemsPr);
					LOGGER.debug("Added " + listItemsPr.size() + " to listItems for pictures");
				}
				LOGGER.debug("Loop over  " + listItems.size() + " entrees in listItems for pictures");
				for (ZPRODCAT_ITEM itemDoc : listItems)
				{
					PICTURESPK picturespk = new PICTURESPK(itemDoc.getKey().getSystem(), itemDoc.getKey().getMandt(), itemDoc.getDokar(), itemDoc.getDoknr(), itemDoc.getDokvr(), itemDoc.getDoktl());			
					PICTURES picturesentry = PICTURES.getPICTURESByKey(em, picturespk);
					if (picturesentry != null)
					{
						LOGGER.debug("Picture found!");
						resultProduct.setPictureId("/main/ImageRenderer?DmsDocument=true&documentId=" + picturesentry.getImage_id());
						break;
					}
				}
				if (resultProduct.getPictureId() == null)
				{
					resultProduct.setPictureId("/images/nopicture.png");
					LOGGER.debug("No picture found!");
				}
				
				String brand = "";
				String level4 = "";
				String zzproces = "";
				String subbrand = "";
				String potdiam = "";
				String topper = "";
				String multilayer = "";
				if (product.getBrand() != null)
				{
					brand = product.getBrand();
				}
				if (product.getLevel4() != null)
				{
					level4 = product.getLevel4();
				}
				if (product.getZzproces1() != null)
				{
					zzproces = product.getZzproces1();
				}
				if (product.getSubbrand() != null)
				{
					subbrand = product.getSubbrand();
				}
				if (product.getZzpot_diam() != null)
				{
					potdiam = product.getZzpot_diam();
				}
				if (product.getZzrange() != null)
				{
					topper = product.getZzrange();
				}
				if (product.getZzsub_range() != null)
				{
					multilayer = product.getZzsub_range();
				}
				
				KeyToDescription keyToDesc = KeyToDescription.getInstance();
				/* Title */
				String title = keyToDesc.getBrandText(brand) + " " + keyToDesc.getFatText(subbrand) + " " + keyToDesc.getSubrangeText(level4);
				resultProduct.setTitle(title);
				
				/* Description */
				String description = "";
				//String description = keyToDesc.getProcessTechText(zzproces) + " • " + keyToDesc.getCupDiamText(potdiam)  + " • " + keyToDesc.getTopperText(topper) + " • " + keyToDesc.getMultilayerText(multilayer);
				if (!keyToDesc.getProcessTechText(zzproces).equalsIgnoreCase(""))
				{
					if (description.length() > 0)
					{
						description = description + " • ";
					}
					description = description + keyToDesc.getProcessTechText(zzproces);
				}
				if (!keyToDesc.getCupDiamText(potdiam).equalsIgnoreCase(""))
				{
					if (description.length() > 0)
					{
						description = description + " • ";
					}
					description = description + keyToDesc.getCupDiamText(potdiam);
				}
				if (!keyToDesc.getTopperText(topper).equalsIgnoreCase(""))
				{
					if (description.length() > 0)
					{
						description = description + " • ";
					}
					description = description + "TOPPER " + keyToDesc.getTopperText(topper);
				}
				if (!keyToDesc.getMultilayerText(multilayer).equalsIgnoreCase(""))
				{
					if (description.length() > 0)
					{
						description = description + " • ";
					}
					description = description + keyToDesc.getMultilayerText(multilayer);
				}
				
				resultProduct.setDescription(description);
				
				if (smallList.size() == 5)
				{
					fullProductList.add(smallList);
					smallList = new ArrayList<EUProdSearchResult>();
				}
				
				smallList.add(resultProduct);
			}
			
			if (smallList.size() > 0)
			{
				fullProductList.add(smallList);
			}
			
			responseWriter.print(new Gson().toJson(fullProductList));
			return;
			
		}catch (Exception e)
		{
			LOGGER.debug("Error getting EUProdCatalog products by search: " + e.toString());
		} finally {
			em.close();
		}
		
		responseWriter.print(new Gson().toJson(Collections.EMPTY_LIST));
		
		return;
	}
}
