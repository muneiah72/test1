package com.danone.util;

public class AllergenWrapper {
	
	private String allergen;
	private String presence;
	
	public String getAllergen() {
		return allergen;
	}
	
	public void setAllergen(String allergen) {
		this.allergen = allergen;
	}
	
	public String getPresence() {
		return presence;
	}
	
	public void setPresence(String presence) {
		this.presence = presence;
	}
}
