package com.danone.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;

import com.danone.entities.AUTHORIZATION;

public class Utils {

	public static final String[] FORMAT_NAMES = { "jpeg", "gif", "png", "bmp", "pcx", "iff", "ras", "pbm", "pgm", "ppm",
			"psd", "swf", "pdf" };

	public static final String[] MIME_TYPE_STRINGS = { "image/jpeg", "image/gif", "image/png", "image/bmp", "image/pcx",
			"image/iff", "image/ras", "image/x-portable-bitmap", "image/x-portable-graymap", "image/x-portable-pixmap",
			"image/psd", "application/x-shockwave-flash", "application/pdf" };

	static Map<String, String> map;

	static {
		map = new HashMap<String, String>();
		for (int i = 0; i < MIME_TYPE_STRINGS.length; i++) {
			map.put(MIME_TYPE_STRINGS[i], FORMAT_NAMES[i]);
		}
		map = Collections.unmodifiableMap(map);
	}

	public static String getFormat(String mimeType) {

		return map.get(mimeType);
	}
	
}
