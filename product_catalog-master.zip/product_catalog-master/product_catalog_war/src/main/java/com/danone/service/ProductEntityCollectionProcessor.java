/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.danone.service;

import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.olingo.commons.api.data.ContextURL;
import org.apache.olingo.commons.api.data.Entity;
import org.apache.olingo.commons.api.data.EntityCollection;
import org.apache.olingo.commons.api.edm.EdmEntitySet;
import org.apache.olingo.commons.api.edm.EdmEntityType;
import org.apache.olingo.commons.api.edm.EdmNavigationProperty;
import org.apache.olingo.commons.api.format.ContentType;
import org.apache.olingo.commons.api.http.HttpHeader;
import org.apache.olingo.commons.api.http.HttpStatusCode;
import org.apache.olingo.server.api.OData;
import org.apache.olingo.server.api.ODataApplicationException;
import org.apache.olingo.server.api.ODataRequest;
import org.apache.olingo.server.api.ODataResponse;
import org.apache.olingo.server.api.ServiceMetadata;
import org.apache.olingo.server.api.processor.EntityCollectionProcessor;
import org.apache.olingo.server.api.serializer.EntityCollectionSerializerOptions;
import org.apache.olingo.server.api.serializer.ODataSerializer;
import org.apache.olingo.server.api.serializer.SerializerException;
import org.apache.olingo.server.api.serializer.SerializerResult;
import org.apache.olingo.server.api.uri.UriInfo;
import org.apache.olingo.server.api.uri.UriParameter;
import org.apache.olingo.server.api.uri.UriResource;
import org.apache.olingo.server.api.uri.UriResourceEntitySet;
import org.apache.olingo.server.api.uri.UriResourceNavigation;
import org.apache.olingo.server.api.uri.queryoption.FilterOption;
import org.apache.olingo.server.api.uri.queryoption.expression.Expression;
import org.apache.olingo.server.api.uri.queryoption.expression.ExpressionVisitException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.danone.service.ProductFilterExpressionVisitor;

public class ProductEntityCollectionProcessor implements EntityCollectionProcessor {

	private final Logger LOGGER = LoggerFactory.getLogger(ProductEntityCollectionProcessor.class);
	
  private OData odata;
  private ServiceMetadata srvMetadata;
  // our database-mock
  private ProductStorage storage;

  public ProductEntityCollectionProcessor(ProductStorage storage) {
    this.storage = storage;
  }

  public void init(OData odata, ServiceMetadata serviceMetadata) {
    this.odata = odata;
    this.srvMetadata = serviceMetadata;
  }

  /*
   * This method is invoked when a collection of entities has to be read.
   * In our example, this can be either a "normal" read operation, or a navigation:
   * 
   * Example for "normal" read entity set operation:
   * http://localhost:8080/DemoService/DemoService.svc/Categories
   * 
   * Example for navigation
   * http://localhost:8080/DemoService/DemoService.svc/Categories(3)/Products
   */
  public void readEntityCollection(ODataRequest request, ODataResponse response,
      UriInfo uriInfo, ContentType responseFormat)
      throws ODataApplicationException, SerializerException {

    EdmEntitySet responseEdmEntitySet = null; // we'll need this to build the ContextURL
    EntityCollection responseEntityCollection = null; // we'll need this to set the response body

    // 1st retrieve the requested EntitySet from the uriInfo (representation of the parsed URI)
    List<UriResource> resourceParts = uriInfo.getUriResourceParts();
    int segmentCount = resourceParts.size();

    UriResource uriResource = resourceParts.get(0); // in our example, the first segment is the EntitySet
    if (!(uriResource instanceof UriResourceEntitySet)) {
      throw new ODataApplicationException("Only EntitySet is supported",
          HttpStatusCode.NOT_IMPLEMENTED.getStatusCode(), Locale.ROOT);
    }

    UriResourceEntitySet uriResourceEntitySet = (UriResourceEntitySet) uriResource;
    EdmEntitySet startEdmEntitySet = uriResourceEntitySet.getEntitySet();

    if (segmentCount == 1) { // this is the case for: DemoService/DemoService.svc/Categories
      responseEdmEntitySet = startEdmEntitySet; // the response body is built from the first (and only) entitySet

      // 2nd: fetch the data from backend for this requested EntitySetName and deliver as EntitySet
      responseEntityCollection = storage.readEntitySetData(startEdmEntitySet);
    } else if (segmentCount == 2) { // in case of navigation: DemoService.svc/Categories(3)/Products

      UriResource lastSegment = resourceParts.get(1); // in our example we don't support more complex URIs
      if (lastSegment instanceof UriResourceNavigation) {
        UriResourceNavigation uriResourceNavigation = (UriResourceNavigation) lastSegment;
        EdmNavigationProperty edmNavigationProperty = uriResourceNavigation.getProperty();
        EdmEntityType targetEntityType = edmNavigationProperty.getType();
        // from Categories(1) to Products
        responseEdmEntitySet = Util.getNavigationTargetEntitySet(startEdmEntitySet, edmNavigationProperty);

        // 2nd: fetch the data from backend
        // first fetch the entity where the first segment of the URI points to
        List<UriParameter> keyPredicates = uriResourceEntitySet.getKeyPredicates();
        // e.g. for Categories(3)/Products we have to find the single entity: Category with ID 3
        Entity sourceEntity = storage.readEntityData(startEdmEntitySet, keyPredicates);
        // error handling for e.g. DemoService.svc/Categories(99)/Products
        if (sourceEntity == null) {
          throw new ODataApplicationException("Entity not found.",
              HttpStatusCode.NOT_FOUND.getStatusCode(), Locale.ROOT);
        }
        // then fetch the entity collection where the entity navigates to
        // note: we don't need to check uriResourceNavigation.isCollection(),
        // because we are the EntityCollectionProcessor
        LOGGER.debug("before getRelatedEntityCollection - source: " + sourceEntity.getType());
        LOGGER.debug("before getRelatedEntityCollection - target: " + targetEntityType.getName());
        responseEntityCollection = storage.getRelatedEntityCollection(sourceEntity, targetEntityType);
        if (responseEntityCollection == null) {
            throw new ODataApplicationException("Collection empty.",
                HttpStatusCode.NOT_FOUND.getStatusCode(), Locale.ROOT);
          }
        LOGGER.debug("after getRelatedEntityCollection - count: " + responseEntityCollection.getCount());
      }
    } else { // this would be the case for e.g. Products(1)/Category/Products
      throw new ODataApplicationException("Not supported",
          HttpStatusCode.NOT_IMPLEMENTED.getStatusCode(), Locale.ROOT);
    }

 // 3rd: Check if filter system query option is provided and apply the expression if necessary
 		FilterOption filterOption = uriInfo.getFilterOption();
 		if(filterOption != null) {
 			// Apply $filter system query option
 			try {
 			      List<Entity> entityList = responseEntityCollection.getEntities();
 			      Iterator<Entity> entityIterator = entityList.iterator();
 			      
 			      // Evaluate the expression for each entity
 			      // If the expression is evaluated to "true", keep the entity otherwise remove it from the entityList
 			      while (entityIterator.hasNext()) {
 			    	  // To evaluate the the expression, create an instance of the Filter Expression Visitor and pass
 			    	  // the current entity to the constructor
 			    	  Entity currentEntity = entityIterator.next();
 			    	  Expression filterExpression = filterOption.getExpression();
 			    	  ProductFilterExpressionVisitor expressionVisitor = new ProductFilterExpressionVisitor(currentEntity);
 			    	  
 			    	  // Start evaluating the expression
 			    	  Object visitorResult = filterExpression.accept(expressionVisitor);
 			    	  
 			    	  // The result of the filter expression must be of type Edm.Boolean
 			    	  if(visitorResult instanceof Boolean) {
 			    		  if(!Boolean.TRUE.equals(visitorResult)) {
 			    		    // The expression evaluated to false (or null), so we have to remove the currentEntity from entityList
 			    		    entityIterator.remove();
 			    		  }
 			    	  } else {
 			    		  throw new ODataApplicationException("A filter expression must evaulate to type Edm.Boolean", 
 			    		      HttpStatusCode.BAD_REQUEST.getStatusCode(), Locale.ENGLISH);
 			    	  }
 			      }

 			    } catch (ExpressionVisitException e) {
 			      throw new ODataApplicationException("Exception in filter evaluation",
 			          HttpStatusCode.INTERNAL_SERVER_ERROR.getStatusCode(), Locale.ENGLISH);
 			    }
 		}
    
    // 4th: create and configure a serializer
    try {
        ContextURL contextUrl = ContextURL.with().entitySet(responseEdmEntitySet).build();
        final String id = request.getRawBaseUri() + "/" + responseEdmEntitySet.getName();
        EntityCollectionSerializerOptions opts = EntityCollectionSerializerOptions.with()
            .contextURL(contextUrl).id(id).build();
        EdmEntityType edmEntityType = responseEdmEntitySet.getEntityType();
        ODataSerializer serializer = odata.createSerializer(responseFormat);
    	SerializerResult serializerResult = serializer.entityCollection(this.srvMetadata, edmEntityType,
    			responseEntityCollection, opts);
    	LOGGER.debug("serializerResult - string: " + serializerResult.toString());
    	InputStream serializedContent = serializerResult.getContent();
    	LOGGER.debug("serializedContent - string: " + serializedContent.toString());

    	// 5th: configure the response object: set the body, headers and status code
    	response.setContent(serializedContent);
    	response.setStatusCode(HttpStatusCode.OK.getStatusCode());
    	response.setHeader(HttpHeader.CONTENT_TYPE, responseFormat.toContentTypeString());
    } catch (Exception e) {
    	LOGGER.debug("SerializerException : " + e);
    	LOGGER.debug("SerializerException - Message: " + e.getCause().getMessage());
    	throw new ODataApplicationException("Exception in serialization: " + e.getCause().getMessage(),
    			HttpStatusCode.INTERNAL_SERVER_ERROR.getStatusCode(), Locale.ENGLISH);
    }
  }

}
