package com.danone.util;

public class EUProdSearchResult {
	
	private Integer mandt;
	private String cat_guid;
	private String title;
	private String pictureId;
	private String description;
	private String system;
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getCat_guid() {
		return cat_guid;
	}

	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPictureId() {
		return pictureId;
	}

	public void setPictureId(String pictureId) {
		this.pictureId = pictureId;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
}
