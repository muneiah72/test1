package com.danone.monitoring;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.proxy.ProxyServlet;
import com.danone.util.JCoHelper;
import com.sap.conn.jco.JCo;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoListMetaData;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
import com.sap.core.connectivity.api.http.HttpDestination;

/**
 * This servlet is NOT protected. It will be called by monitoring infrastructure
 * to check if the application is available. To prevent misuse of this servlet
 * the destination and URL is hardcoded.
 */

public class Heartbeat extends ProxyServlet {
	private static final long serialVersionUID = -403495745275252525L;
	private static Logger LOGGER = LoggerFactory.getLogger(Heartbeat.class);

	protected void service2(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int contextPathLength = request.getContextPath().length();
		int servletPathLength = request.getServletPath().length();

		String pathInfo = request.getRequestURI().substring(contextPathLength + servletPathLength + 1);
		LOGGER.info("PATHINFO: " + pathInfo);
		String queryString = request.getQueryString();
		String destinationName = getDestinationFromUrl(request.getServletPath());
		LOGGER.info("Destination Name: " + destinationName);
		String urlToService = getRelativePathFromUrl(pathInfo, queryString);
		LOGGER.info("URL to service: " + urlToService);

		HttpDestination dest = getDestination(destinationName);
		HttpClient httpClient = null;
		try {
			httpClient = dest.createHttpClient();
			HttpGet get = new HttpGet(urlToService);
			HttpResponse backendResponse = httpClient.execute(get);
			int status = backendResponse.getStatusLine().getStatusCode();
			response.setContentType("text/html");
			response.setStatus(status);
			PrintWriter out = response.getWriter();
			out.write("<!DOCTYPE HTML>\n");
			out.write("<html><head><title>Heartbeat</title></head><body>\n");
			out.write("Retrun code from Backend: " + status);
			out.write("</body></html>");
		} catch (Exception e) {
			throw new ServletException(e);
		} finally {
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// String destinationName = "CRM_HCP-SAP";
		//String destinationName = request.getParameter("destination");
		//String portalDestinationName = request.getParameter("portalDestination");
		//String functionName = request.getParameter("function");
		String functionName = "ZSHCP_PROM_FETCH_CONFIG";
		
		// DESTINATION: make an invocation of FUNCTION in the back-end
		JCoFunction stfcConnection;
		String globalStatusMessage = "OK";
		String destinationStatusMessage = "OK";
		int globalStatusNumber = 200;
		int destinationStatusNumber = 200;
		List<String> destinations = new ArrayList<String>();
		//destinations.add("PRODCATALOG-SAP");
		destinations.add("PRODCATALOG-SAP1");
		//destinations.add("PRODCATALOG-SAP2");
		//destinations.add("PRODCATALOG-SAP3");
		
		for (String destinationName : destinations)
		{
			try {
				JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
				JCoRepository repo = destination.getRepository();
				JCo.setProperty("jco.use_repository_roundtrip_optimization", "1");
				stfcConnection = repo.getFunction(functionName);
				stfcConnection.execute(destination);
				// Get results
				JCoParameterList exports = stfcConnection.getExportParameterList();
				if (exports != null) {
					JCoListMetaData exportParameters = exports.getListMetaData();

					JSONObject jsonData = new JSONObject();

					for (int i = 0; i < exportParameters.getFieldCount(); i++) {
						String paramName = exportParameters.getName(i);
						String paramType = exportParameters.getTypeAsString(i);

						// do what you need to do with the field and value
						try {

							// parse table output
							if (paramType.equals("TABLE")) {
								JCoTable jcoTable = exports.getTable(paramName);
								jsonData.put(paramName, JCoHelper.parseTable(jcoTable));

								// parse structure output
							} else if (paramType.equals("STRUCTURE")) {
								JCoStructure jcoStructure = exports.getStructure(paramName);
								jsonData.put(paramName, JCoHelper.parseStructure(jcoStructure));
							} else {
								jsonData.put(paramName, exports.getValue(paramName));
							}
						} catch (JSONException e) {
							e.getCause();
						}
					}
				}
			} catch (JCoException ex) {
				globalStatusNumber = 501;
				destinationStatusNumber = 501;
				globalStatusMessage = " DESTINATION " + destinationName + ": " + ex.getLocalizedMessage();
				destinationStatusMessage = ex.getLocalizedMessage();
			} catch (Exception ex) {
				globalStatusNumber = 502;
				destinationStatusNumber = 502;
				globalStatusMessage = " DESTINATION " + destinationName + ": " + ex.getLocalizedMessage();
				destinationStatusMessage = ex.getLocalizedMessage();
			}
		}
		

		// URL TO Service
		/*
		HttpClient httpClient = null;
		HttpDestination dest = getDestination(portalDestinationName);
		int portalDestinationStatusNumber = 201;
		String portalDestinationStatusMessage = "OK";
		try {
			httpClient = dest.createHttpClient();
			HttpGet get = new HttpGet();
			HttpResponse httpResponse = httpClient.execute(get);
			portalDestinationStatusNumber = httpResponse.getStatusLine().getStatusCode();
			if (isCodeValid(portalDestinationStatusNumber) && isCodeValid(globalStatusNumber)) {
				globalStatusNumber = 210;
			} else {
				if (!isCodeValid(portalDestinationStatusNumber) && isCodeValid(globalStatusNumber)) {
					globalStatusNumber = 501;
					portalDestinationStatusMessage = "ERROR " + httpResponse.getStatusLine().getReasonPhrase();
					globalStatusMessage = "Destination " + destinationName + ": OK -------- PORTAL URL:  ERROR ";
				} else if (isCodeValid(portalDestinationStatusNumber) && !isCodeValid(globalStatusNumber)) {
					globalStatusNumber = 502;
					globalStatusMessage = "Destination " + destinationName + ": ERROR -------- PORTAL URL:  OK ";
				} else if (!isCodeValid(portalDestinationStatusNumber) && !isCodeValid(globalStatusNumber)) {
					globalStatusNumber = 503;
					portalDestinationStatusMessage = "ERROR " + httpResponse.getStatusLine().getReasonPhrase();
					globalStatusMessage = "Destination " + destinationName + ": ERROR -------- PORTAL URL:  ERROR ";
				}

			}
		} catch (Exception ex) {
			// globalStatusNumber = globalStatusNumber * 1000 + 603;
			portalDestinationStatusNumber = 503;
			// globalStatusMessage = globalStatusMessage + " URL TO SERVICE " +
			// dest.getName() + " : " + ex.getLocalizedMessage();
			portalDestinationStatusMessage = ex.getLocalizedMessage();

			if (isCodeValid(globalStatusNumber)) {
				globalStatusNumber = 501;
				globalStatusMessage = "Destination " + destinationName + ": OK -------- PORTAL URL:  ERROR with exception :" + ex.getLocalizedMessage();
			}
			if (!isCodeValid(globalStatusNumber)) {
				globalStatusNumber = 503;
				globalStatusMessage = "Destination " + destinationName + ": ERROR -------- PORTAL URL:  ERROR with exception :" + ex.getLocalizedMessage();
			}

			// throw new ServletException(ex);
		} finally {
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
			}
		}

		LOGGER.debug("Heartbeat status. Destination " + destinationName + " has status " + destinationStatusNumber + " and response from backend is " + destinationStatusMessage);
		LOGGER.debug("Portal Destination Name is " + dest.getName() + " and response from backend is " + portalDestinationStatusNumber);
		*/
		
		try {
			response.setContentType("text/html");
			response.setStatus(globalStatusNumber);
			PrintWriter out = response.getWriter();
			out.write("<!DOCTYPE HTML>\n");
			out.write("<html><head><title>Heartbeat</title></head><body>\n");
			out.write("Destination    return code: " + destinationStatusNumber + " and message: " + destinationStatusMessage + "<br>");
			//out.write("URL To Service return code: " + portalDestinationStatusNumber + " and message: " + portalDestinationStatusMessage + "<br>");
			out.write("Global Status Number is: " + globalStatusNumber + " and global message: " + globalStatusMessage + "<br>");
			out.write("</body></html>");
		} catch (Exception e) {
			throw new ServletException(e);
		} finally {
		}
	}

	protected boolean isCodeValid(int code) {
		if (code >= 200 && code <= 299) {
			return true;
		} else {
			return false;
		}
	}

}
