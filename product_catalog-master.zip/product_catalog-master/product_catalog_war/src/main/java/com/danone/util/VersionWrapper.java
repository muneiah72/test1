package com.danone.util;

public class VersionWrapper {
	private String catalogNo;
	private Integer versionNo;
	private String currentStatus;
	private String previousStatus;
	private java.sql.Date creationDate;
	private java.sql.Date modifDate;
	private String changedBy;
	private Boolean selected;
	private String system;
	private Integer mandt;
	private String cat_guid;
	private String vkorg;
	private String vtweg;
	private String prinbr;
	private String productgroup;
	private String ean_upc_base;
	private java.sql.Date validity_base;
	
	public String getCatalogNo() {
		return catalogNo;
	}
	
	public void setCatalogNo(String catalogNo) {
		this.catalogNo = catalogNo;
	}
	
	public Integer getVersionNo() {
		return versionNo;
	}
	
	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getPreviousStatus() {
		return previousStatus;
	}

	public void setPreviousStatus(String previousStatus) {
		this.previousStatus = previousStatus;
	}

	public java.sql.Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(java.sql.Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getChangedBy() {
		return changedBy;
	}

	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}

	public java.sql.Date getModifDate() {
		return modifDate;
	}

	public void setModifDate(java.sql.Date modifDate) {
		this.modifDate = modifDate;
	}

	public Boolean getSelected() {
		return selected;
	}

	public void setSelected(Boolean selected) {
		this.selected = selected;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getCat_guid() {
		return cat_guid;
	}

	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}

	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

	public String getPrinbr() {
		return prinbr;
	}

	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}

	public String getProductgroup() {
		return productgroup;
	}

	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}

	public String getEan_upc_base() {
		return ean_upc_base;
	}

	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}

	public java.sql.Date getValidity_base() {
		return validity_base;
	}

	public void setValidity_base(java.sql.Date validity_base) {
		this.validity_base = validity_base;
	}
}
