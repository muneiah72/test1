package com.danone.resources;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.COMPANYSORG;
import com.danone.entities.COMPANYSORGPK;
import com.danone.persistence.PersistenceAdapter;

@Path("/usersorg")
@Produces({ MediaType.APPLICATION_JSON })
public class UserSorgResource {
	private final Logger LOGGER = LoggerFactory.getLogger(UserSorgResource.class);

	@Context
	private HttpServletRequest servletRequest;

	@GET
	@Path("{company}")
	public Response getUserSorg(@PathParam("company") String company) {
		LOGGER.debug("In fetch usersorg");
		
		LOGGER.debug("In fetch usersorg" + company);

		EntityManager em = PersistenceAdapter.getEntityManager();
		
		COMPANYSORGPK companysorgpk = new COMPANYSORGPK(company);
		COMPANYSORG companysorgentry = COMPANYSORG.getCOMPANYSORGByKey(em, companysorgpk);
		if (companysorgentry != null)
		{
			String userSorg = new String(companysorgentry.getVkorg());
			return Response.ok(userSorg).build();
		}
		return null;
	}
}
