package com.danone.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.commons.io.IOUtils;
import org.apache.tika.Tika;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.CMSCAROUSEL;
import com.danone.entities.CMSCAROUSELPK;
import com.danone.entities.CMSCONFIG;
import com.danone.entities.CMSCONFIGPK;
import com.danone.persistence.PersistenceAdapter;

/**
 * Servlet implementation class PDF Renderer
 */
public class PdfRenderer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(PdfRenderer.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PdfRenderer() {
		super();
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		LOGGER.debug("In PDF Renderer service servlet");
		EntityManager em = PersistenceAdapter.getEntityManager();
		
		byte[] aBlob = null;
		long documentUploadTime = 0;
		boolean documentNotFound = false;
		String documentKey = "";
		String fileName = null;
			
		// DMS PDF document
		String DmsDocPdfId = request.getParameter("DmsDocPdf");		
		if (DmsDocPdfId != null) {
			String documentId = request.getParameter("documentId");
			CmisHelper cmis = new CmisHelper();
			ContentStream contentStream = cmis.getDocumentStreamById(documentId);
			fileName = request.getParameter("fileName");
			if (fileName == null) {
				fileName = cmis.getDocumentNameById(documentId);
			}
			
			if (contentStream != null) {
				InputStream inputStream = contentStream.getStream();
				aBlob = IOUtils.toByteArray(inputStream);
				documentUploadTime = 0;
				documentNotFound = false;
			} else {
				documentNotFound = true;
			}
		}				
		
		
		// CMS Carousel PDF document
		String webshopDocId = request.getParameter("webshopDoc");
		if (webshopDocId != null) {
			Integer id = Integer.parseInt(request.getParameter("id")) ;

			CMSCAROUSEL doc = CMSCAROUSEL.getCarouselByKey(em, new CMSCAROUSELPK(id));		
			if (doc != null) {
				aBlob = doc.getDocument();
				fileName = doc.getDocumentName();
				documentUploadTime = 0;
				documentNotFound = false;
			} else {
				documentNotFound = true;
			}
		}
		
		// CMS Document PDF document
		String webshopDocumentId = request.getParameter("webshopDocument");
		if (webshopDocumentId != null) {
			LOGGER.debug("webshopDocument");
			String type = request.getParameter("type");
			String language = request.getParameter("language");
			if (language != null) {
			} else { 
				language = "EN";
			}
			CMSCONFIG document = null;

			String fullkey = request.getParameter("fullkey");
			if (fullkey != null) {			
				LOGGER.debug("fullkey");
				Integer validFrom = Integer.parseInt(request.getParameter("validFrom"));
				Integer validTo = Integer.parseInt(request.getParameter("validTo"));

				document = CMSCONFIG.getDocumentByKey(em, new CMSCONFIGPK(language, type, validFrom, validTo));
			} else {
				java.util.Calendar calendar = java.util.Calendar.getInstance();
//				java.sql.Date currentDate = new java.sql.Date(calendar.getTime().getTime());
				LOGGER.debug("document by date");
		//		Calendar now = Calendar.getInstance();
				int iyear = calendar.get(java.util.Calendar.YEAR);
				int imonth = calendar.get(java.util.Calendar.MONTH) + 1; // Note: zero based!
				int iday = calendar.get(java.util.Calendar.DAY_OF_MONTH);
				String yyyy = Integer.toString(iyear);
				String mm = Integer.toString(imonth);
				String dd = Integer.toString(iday);
				String strDate = yyyy + (imonth < 10 ? "0" + mm : mm) + (iday < 10 ? "0" + dd : dd);
				LOGGER.debug("document by date:" + strDate);
		//		String strDate = currentDate.toString();
				LOGGER.debug("document by date:" + strDate);
//				String year = strDate.substring(0, 4);
//				String month = strDate.substring(5, 2);
//				String day = strDate.substring(8, 2);
//				String date = year + month + day;
				Integer intDate = Integer.parseInt(strDate);
				LOGGER.debug("document by date:" + intDate);
				List<CMSCONFIG> listCmsconfig = CMSCONFIG.getDocumentByDate(em, language, type, intDate);					
				LOGGER.debug("listCmsconfig:" + listCmsconfig.size());
				for (CMSCONFIG itemCmsconfig : listCmsconfig)
				{
					document = itemCmsconfig;				
				}
			}

			if (document != null) {
				aBlob = document.getDocument();
				fileName = document.getDocumentName();
				documentUploadTime = 0;
				documentNotFound = false;
			} else {
				documentNotFound = true;
			}
		}
		String fileFormat = new Tika().detect(aBlob);
		String fileExtension = Utils.getFormat(fileFormat);
		if (!documentNotFound) {
			if (documentUploadTime <= 0) {
				documentUploadTime = System.currentTimeMillis();
			}
			long ifModifiedSince = request.getDateHeader("If-Modified-Since");
			if (ifModifiedSince < (documentUploadTime / 1000 * 1000)) {
				maybeSetLastModified(response, documentUploadTime);
				if (aBlob != null && aBlob.length > 0) {
					response.setContentType("application/pdf");
					response.setContentLength(aBlob.length);
					
					String download = request.getParameter("Download");
				
					fileName = fileName + "." + fileExtension;
					if (download != null) {
						if (download.equalsIgnoreCase("X")) {	
							response.addHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"" );
						} }
					
					response.getOutputStream().write(aBlob, 0, aBlob.length);
					// /* Cache Handling */
					final int CACHE_DURATION_IN_SECOND = 60 * 60 * 24 * 1; // 1
																			// day
					// final
					long CACHE_DURATION_IN_MS = CACHE_DURATION_IN_SECOND * 1000;
					long now = System.currentTimeMillis();
					response.addHeader("Cache-Control", "max-age=" + CACHE_DURATION_IN_SECOND);
					response.setDateHeader("Last-Modified", documentUploadTime);
					response.setDateHeader("Expires", now + CACHE_DURATION_IN_MS);
				} else {
					response.setContentType(fileFormat);
					response.setStatus(HttpServletResponse.SC_NOT_FOUND);

				}

			} else {
				response.setContentType(fileFormat);
				response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
			}
		} else {
			response.getOutputStream().print("No Document found for key " + documentKey);
			response.setContentType("text/html");
		}
		em.close();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	public long getLastModified(HttpServletRequest req) {
		return -1;
	}

	private void maybeSetLastModified(HttpServletResponse resp, long lastModified) {
		if (resp.containsHeader("Last-Modified"))
			return;
		if (lastModified >= 0)
			resp.setDateHeader("Last-Modified", lastModified);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
	}

}