package com.danone.resources;

import java.net.HttpURLConnection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.cron.UpdateDB;
import com.danone.entities.ReplicationInfo;
import com.danone.persistence.PersistenceAdapter;

@Path("/replicationinfo")
@Produces({ MediaType.APPLICATION_JSON })
public class ReplicationInfoResource {
	
	private final Logger LOGGER = LoggerFactory.getLogger(ReplicationInfoResource.class);
	
	@Context
	private HttpServletRequest servletRequest;
	
	@GET
	public Response getAllInfo() {
		EntityManager em = PersistenceAdapter.getEntityManager();
		try {
			List<ReplicationInfo> infos = ReplicationInfo.getAllReplicationInfo(em);
			return Response.ok(infos).build();
		} finally {
			em.close();
		}
	}
	
	@POST
	public Response startNewReplication() {
		Response response;
		
		if (!servletRequest.isUserInRole(Roles.MANTRIGGER)) {
			response = Response.status(HttpURLConnection.HTTP_FORBIDDEN).entity("You do not have the right to do so")
					.build();
			return response;
		}
		
		try {
			
			LOGGER.debug("Attempt to start manual replication");
			UpdateDB updatedb = UpdateDB.getInstance();
			updatedb.startManual(servletRequest.getUserPrincipal().getName());
			
		} catch (PersistenceException e) {
			LOGGER.error("Failed to start replication via REST ", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
			return response;
		} 

		response = Response.status(HttpURLConnection.HTTP_OK).entity("Replication started").build();
		return response;
	}
}
