package com.danone.resources;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFCreationHelper;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.entities.ZPRODCAT_HDR;
import com.danone.persistence.PersistenceAdapter;
import com.danone.util.KeyToDescription;
import com.danone.util.MultipackWrapper;
import com.danone.util.NutboardWrapper;
import com.danone.util.ProductDetailWrapper;
import com.danone.util.ProductWrapper;
import com.danone.util.UoMWrapper;
import com.sap.conn.jco.JCo;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFieldIterator;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;

public class ExcelRenderer extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2721213250087843923L;
	private static final Logger LOGGER = LoggerFactory.getLogger(ExcelRenderer.class);
	private static String destinationName = "PRODCATALOG-SAP";
	// private List<String> allExistList;

	private JCoRepository repo = null;
	JCoDestination destination = null;
	JSONArray consumpDesc = null;
	JSONArray brandDesc = null;
	JSONArray subbrandDesc = null;
	JSONArray prodvarDesc = null;
	JSONArray forcastuDesc = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			/*
			 * allExistList = new ArrayList<String>();
			 * allExistList.add("ALMOND"); allExistList.add("BRAZILNUT");
			 * allExistList.add("CASHEWNUT"); allExistList.add("CELERY");
			 * allExistList.add("CRUSTACEA"); allExistList.add("EGG");
			 * allExistList.add("FISH"); allExistList.add("GLUTEN");
			 * allExistList.add("HAZELNUT"); allExistList.add("LUPIN");
			 * allExistList.add("MILK"); allExistList.add("MOLLUSC");
			 * allExistList.add("MUSTARD"); allExistList.add("NUT");
			 * allExistList.add("PEANUT"); allExistList.add("PECANNUT");
			 * allExistList.add("PISTACHIOS"); allExistList.add("QUEENSLAND");
			 * allExistList.add("SESAME"); allExistList.add("SOYA");
			 * allExistList.add("SULFITES"); allExistList.add("WALNUT");
			 */

			List<ProductWrapper> prodList = new ArrayList<ProductWrapper>();
			LOGGER.debug("In get excel file");

			Enumeration<String> enumer = request.getParameterNames();
			String plant = null;
			String ecatd = null;

			JSONObject params = null;

			if (enumer.hasMoreElements()) {
				String jsonString = enumer.nextElement();

				if (jsonString.equalsIgnoreCase("data")) {
					String value = URLDecoder.decode(request.getParameter(jsonString), "UTF-8");
					// String value = request.getParameter(jsonString);
					// value = value.replace("\\\"", "\"");
					LOGGER.info("Parsing request parameter data, value is: " + value);
					try {
						params = new JSONObject(value);
					} catch (JSONException ex) {
						LOGGER.debug("Exception raised while parsing the request parameter data "
								+ ex.getLocalizedMessage());
					}
				}
			}

			String filename = "";
			String langu = "";
			String salesorg = "";
			JSONArray requiredArray = null;
			JSONArray recordsArray = null;
			Boolean excel = true;

			if (params != null) {
				LOGGER.debug("In params");
				requiredArray = params.getJSONArray("REQUIRED");
				plant = params.getString("PLANT");
				recordsArray = params.getJSONArray("RECORDS");
				filename = params.getString("FILENAME");
				langu = params.getString("LANG");
				salesorg = params.getString("SALESORG");
				consumpDesc = params.getJSONArray("CONSUMPDESC");
				brandDesc = params.getJSONArray("BRANDDESC");
				subbrandDesc = params.getJSONArray("SUBBRANDDESC");
				prodvarDesc = params.getJSONArray("PRODVARDESC");
				forcastuDesc = params.getJSONArray("FORCASTUDESC");
				try {
					ecatd = params.getString("ECATD");
				} catch (Exception e) {
					ecatd = "";
				}

				/*
				 * Boolean allowed = filterAuthorizations(salesorg, request); if
				 * (!allowed) {
				 * response.setStatus(HttpURLConnection.HTTP_FORBIDDEN);
				 * PrintWriter responseWriter = response.getWriter();
				 * responseWriter.write(
				 * "You do not have the required authorizations"); return; }
				 */
			}

			String contentdisp;
			if (filename.length() > 0) {
				contentdisp = "attachment; filename=\"" + filename + ".xls\"";
			} else {
				contentdisp = "attachment; filename=\"excelExport.xls\"";
				filename = "excelExport.xls";
			}
			response.setHeader("Content-Disposition", contentdisp);
			response.setContentType("application/vnd.ms-excel");
			// response.setContentType("application/ms-excel");
			// response.setHeader("Content-Disposition", "attachment; filename="
			// + filename);

			if (request.getParameter("required") != null) {
				String requiredString = request.getParameter("required");
				requiredArray = new JSONArray(requiredString);
			}
			if (request.getParameter("records") != null) {
				String recordsString = request.getParameter("records");
				recordsArray = new JSONArray(recordsString);
			}
			if (request.getParameter("plant") != null) {
				plant = request.getParameter("plant");
			}
			
			if (requiredArray != null && recordsArray != null & plant != null) {
				for (int n = 0; n < recordsArray.length(); n++) {
					JSONObject entry = recordsArray.getJSONObject(n);
					LOGGER.debug("Record entry: " + entry.toString());
					ProductWrapper p = null;
					try {
						p = ProductWrapper.convertFromJSONToMyClass(entry);
					} catch (Exception e) {
						LOGGER.debug("Error converting JSONObj to ProductWrapper: " + e.toString());
						e.printStackTrace();
					}

					if (p != null) {
						prodList.add(p);	
					}
				}

				// Prepare Product details data
				HashMap<String, ProductDetailWrapper> prodDetailHm = new HashMap<String, ProductDetailWrapper>();
//				List<ProductDetailWrapper> prodDetailList = new ArrayList<ProductDetailWrapper>();
				for (ProductWrapper prodw : prodList) {
					ProductDetailResource prodRes = new ProductDetailResource();
					ProductDetailWrapper prodDetail = null;
					prodDetail = prodRes.getDetails(prodw.getSystem(), prodw.getMandt(), prodw.getCat_guid(),
							prodw.getMatnr(), prodw.getVkorg(), prodw.getVtweg(), prodw.getPrinbr(),
							prodw.getProductgroup(), prodw.getEan_upc_base(), prodw.getValidity_base(), langu, plant,
							ecatd, excel);

					if (prodDetail != null) {
//						prodDetailList.add(prodDetail);
						prodDetailHm.put(prodw.getSystem() + "_" + prodw.getMandt() + "_" + prodw.getCat_guid(),
								prodDetail);
					}
				}

				final HSSFWorkbook wb = new HSSFWorkbook();

				// Create header style
				HSSFCellStyle headerCellStyle = wb.createCellStyle();
				HSSFFont headerCellFont = wb.createFont();
				headerCellFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerCellFont.setFontName("Calibri-Regular");
				headerCellStyle.setFont(headerCellFont);

				for (int n = 0; n < requiredArray.length(); n++) {
					String entry = requiredArray.getString(n);
					LOGGER.debug("Required entry: " + entry);

					if (entry.equalsIgnoreCase("product")) {
						JCoTable prodhier = getProdHier(salesorg);
						HSSFSheet sheetProduct = wb.createSheet("EXTRACT file - PRODUCT");
						List<String> objTitles = createTitlesTabOne();
						fillExcelSheet(objTitles, prodList, prodDetailHm, sheetProduct, headerCellStyle,
								entry, plant, langu, prodhier, ecatd);
						for (int x = 0; x < sheetProduct.getRow(0).getPhysicalNumberOfCells(); x++) {
							sheetProduct.autoSizeColumn(x);
						}
					} else if (entry.equalsIgnoreCase("logistics")) {
						HSSFSheet sheetLogistics = wb.createSheet("EXTRACT file - LOGISTICS");
						List<String> objTitles = createTitlesTabTwo();
						fillExcelSheet(objTitles, prodList, prodDetailHm, sheetLogistics, headerCellStyle,
								entry, plant, langu, null, ecatd);
						for (int x = 0; x < sheetLogistics.getRow(0).getPhysicalNumberOfCells(); x++) {
							sheetLogistics.autoSizeColumn(x);
						}
					} else if (entry.equalsIgnoreCase("pack")) {
						HSSFSheet sheetPack = wb.createSheet("EXTRACT file - PACK");
						List<String> objTitles = createTitlesTabThree();
						fillExcelSheetPack(objTitles, prodList, prodDetailHm, sheetPack, headerCellStyle,
								entry, plant, langu, null, ecatd, excel);
						for (int x = 0; x < sheetPack.getRow(0).getPhysicalNumberOfCells(); x++) {
							sheetPack.autoSizeColumn(x);
						}
					} else if (entry.equalsIgnoreCase("nutrition")) {
						HSSFSheet sheetNutritional = wb.createSheet("EXTRACT file - NUTRITION");
						List<String> objTitles = createTitlesTabFour();
						fillExcelSheetNutrition(objTitles, prodList, prodDetailHm, sheetNutritional, headerCellStyle,
								entry, plant, langu, null, ecatd);
						for (int x = 0; x < sheetNutritional.getRow(0).getPhysicalNumberOfCells(); x++) {
							sheetNutritional.autoSizeColumn(x);
						}
					}
				}

				LOGGER.debug("Excel output");
				OutputStream outStream = response.getOutputStream();
				LOGGER.debug("Excel write");
				wb.write(outStream);
				LOGGER.debug("Excel end");

				// ByteArrayOutputStream outByteStream = new
				// ByteArrayOutputStream();
				// wb.write(outByteStream);
				// byte[] outArray = outByteStream.toByteArray();
				// response.setContentType("application/ms-excel");
				// response.setContentLength(outArray.length);
				// response.setHeader("Expires:", "0");
				// response.setHeader("Content-Disposition", "attachment;
				// filename=testxls.xls");
				//
				// OutputStream outStream2 = response.getOutputStream();
				// outStream2.write(outArray);
				// outStream2.flush();

			} else {
				// LOGGER.debug("sleep for 60 seconds");
				// Thread.sleep(60000); //sleep for 60 seconds
				return;
			}
		} catch (Exception e) {
			response.getWriter().println(
					"An exception occurred and further details are stored into the Log File (Please check with the administrator)");
			LOGGER.debug("Error in Excel service" + e.toString());
			return;
		}
	}

	public Boolean filterAuthorizations(String vkorg, HttpServletRequest servletRequest) {
		// Check CBU authorization
		String rolename = "Prometheus_CBU_" + vkorg;
		if (!servletRequest.isUserInRole(rolename)) {
			return false;
		}

		return true;
	}

	private JCoTable getProdHier(String salesorg) {
		try {
			destination = JCoDestinationManager.getDestination(destinationName);
			repo = destination.getRepository();
			JCo.setProperty("jco.use_repository_roundtrip_optimization", "1");
			List<String> functions = new ArrayList<String>();
			functions.add("ZSHCP_PROM_FETCH_CONFIG");
			JCo.queryMetaDataSet(repo, functions, null, null);

			// Get prodhier
			// make an invocation of FUNCTION in the back-end
			JCoFunction stfcConnection = repo.getFunction("ZSHCP_PROM_FETCH_CONFIG");

			// Set import parameters
			JCoParameterList imports = stfcConnection.getImportParameterList();
			imports.setValue("IV_SALESORG", salesorg);

			// Run the Function module
			stfcConnection.execute(destination);

			// Get results
			JCoParameterList tables = stfcConnection.getTableParameterList();
			JCoTable jcoTable = tables.getTable("ET_NODELIST");
			return jcoTable;
		} catch (Exception e) {
			LOGGER.debug("Error while fetching product hierarchy: " + e.toString());
		}

		return null;
	}

	private void fillExcelSheet(List<String> objTitles, List<ProductWrapper> prodList,
			HashMap<String, ProductDetailWrapper> prodDetailHm, HSSFSheet sheet,
			HSSFCellStyle headerStyle, String type, String plant, String langu, JCoTable prodhier, String ecatd) {
		HSSFCellStyle style = sheet.getWorkbook().createCellStyle();
		style.setWrapText(true);
		HSSFFont my_font = sheet.getWorkbook().createFont();
		my_font.setFontName("Calibri-Regular");
		style.setFont(my_font);

		HSSFCellStyle datestyle = sheet.getWorkbook().createCellStyle();
		HSSFCreationHelper createHelper = sheet.getWorkbook().getCreationHelper();
		datestyle.setFont(my_font);
		datestyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));

		try {
			// Create titles
			Row rowTitle = sheet.createRow(0);
			int cellnum = 0;
			for (String title : objTitles) {
				Cell cell = rowTitle.createCell(cellnum++);
				cell.setCellStyle(headerStyle);
				cell.setCellValue(title);
			}

			int rownum = 1;
			int count = 1;
			for (ProductWrapper prodw : prodList) {
				cellnum = 0;
				LOGGER.debug("Add entry: " + count);
				count++;
				ProductDetailWrapper prodDetail =
						prodDetailHm.get(prodw.getSystem() + "_" + prodw.getMandt() + "_" + prodw.getCat_guid());				
				List<Object> objRecords = createRecord(type, prodw, prodDetail, plant, langu, prodhier, ecatd);
				Row row = sheet.createRow(rownum++);
				if (objRecords != null) {
					if (prodw != null) {
						for (Object obj : objRecords) {
							Cell cell = row.createCell(cellnum++);
							cell.setCellStyle(style);
							if (obj != null) {
								if (obj instanceof String) {
									cell.setCellValue((String) obj);
								} else if (obj instanceof Integer) {
									cell.setCellValue((Integer) obj);
								} else if (obj instanceof Double) {
									cell.setCellValue((Double) obj);
								} else if (obj instanceof Date) {
									cell.setCellValue((Date) obj);
									cell.setCellStyle(datestyle);
								} else {
									if (obj != null) {
										cell.setCellValue(obj.toString());
										LOGGER.debug("UNSUPPORTED TYPE: " + obj.getClass());
									}
								}
							} else {
								cell.setCellValue("");
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Error in fillExcelSheet" + e.toString());
		}
	}

	private List<String> createTitlesTabOne() // Product
	{
		List<String> objTitles = new ArrayList<String>();
		objTitles.add("CBU");
		objTitles.add("Channel");
		objTitles.add("EAN");
		objTitles.add("Material Code");
		objTitles.add("Material Description");
		objTitles.add("Version status");
		objTitles.add("Version #");
		objTitles.add("Launchdate");
		objTitles.add("Packaging Code");
		objTitles.add("Labelling Code");
		objTitles.add("Output Code");
		objTitles.add("Code Bassine");
		objTitles.add("LSF");
		objTitles.add("Artemis SKU");
		objTitles.add("Dchain Material status");
		objTitles.add("Standard description");
		objTitles.add("Commercial description");
		objTitles.add("E CAT description");
		objTitles.add("Internet description");
		objTitles.add("Brand");
		objTitles.add("Sub-Brand");
		objTitles.add("Product variant");
		objTitles.add("Forecast unit");
		objTitles.add("Format");
		objTitles.add("Consumption Time");
		objTitles.add("Regulations CCE, conformity");
		objTitles.add("Customs list");
		objTitles.add("Durée de vie (en mois)");
		objTitles.add("Durée de vie (en JOURS)");
		objTitles.add("DLSC");
		objTitles.add("Consigne support");
		objTitles.add("Palettisation");
		objTitles.add("Country of origin");
		objTitles.add("By(Regroupement)");
		objTitles.add("Flag Std/Promo");
		objTitles.add("Factory of Production");
		objTitles.add("Factory of conditioning");
		objTitles.add("Carbon footprint");
		objTitles.add("Project code");
		objTitles.add("Product Hierarchy Level 1");
		objTitles.add("Product Hierarchy Level 2");
		objTitles.add("Product Hierarchy Level 3");
		objTitles.add("Product Hierarchy Level 4");
		objTitles.add("Product Hierarchy Level 5");
		objTitles.add("Product Hierarchy Level 6");
		objTitles.add("Range");
		objTitles.add("Sub Range");
		objTitles.add("Marketing Group I");
		objTitles.add("Marketing Group II");
		objTitles.add("Marketing Group III");
		objTitles.add("Marketing Group IV");
		objTitles.add("Click 2 buy");

		/*
		 * for (String str : allExistList) { objTitles.add("ALLERGEN - " + str);
		 * }
		 */

		return objTitles;
	}

	private List<String> createTitlesTabTwo() // Logistic
	{
		List<String> objTitles = new ArrayList<String>();
		objTitles.add("CBU");
		objTitles.add("Channel");
		objTitles.add("EAN");
		objTitles.add("Material Code");
		objTitles.add("Material Description");
		objTitles.add("Version status");
		objTitles.add("Version #");
		objTitles.add("Launchdate");
		objTitles.add("Packaging Code");
		objTitles.add("Labelling Code");
		objTitles.add("Output Code");
		objTitles.add("Code Bassine");
		objTitles.add("LSF");
		objTitles.add("Artemis SKU");

		// PC
		objTitles.add("EAN PC");
		objTitles.add("Net Weight PC");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight PC");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume PC");
		objTitles.add("Unit volume");
		objTitles.add("Length PC");
		objTitles.add("Length unit");
		objTitles.add("Width PC");
		objTitles.add("With unit");
		objTitles.add("Height PC");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// BAG
		objTitles.add("EAN BAG");
		objTitles.add("Net Weight BAG");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight BAG");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume BAG");
		objTitles.add("Unit volume");
		objTitles.add("Length BAG");
		objTitles.add("Length unit");
		objTitles.add("Width BAG");
		objTitles.add("With unit");
		objTitles.add("Height BAG");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// BT
		objTitles.add("EAN BT");
		objTitles.add("Net Weight BT");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight BT");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume BT");
		objTitles.add("Unit volume");
		objTitles.add("Length BT");
		objTitles.add("Length unit");
		objTitles.add("Width BT");
		objTitles.add("With unit");
		objTitles.add("Height BT");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// BOX
		objTitles.add("EAN BOX");
		objTitles.add("Net Weight BOX");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight BOX");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume BOX");
		objTitles.add("Unit volume");
		objTitles.add("Length BOX");
		objTitles.add("Length unit");
		objTitles.add("Width BOX");
		objTitles.add("With unit");
		objTitles.add("Height BOX");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// BRQ
		objTitles.add("EAN BRQ");
		objTitles.add("Net Weight BRQ");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight BRQ");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume BRQ");
		objTitles.add("Unit volume");
		objTitles.add("Length BRQ");
		objTitles.add("Length unit");
		objTitles.add("Width BRQ");
		objTitles.add("With unit");
		objTitles.add("Height BRQ");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// CAS
		objTitles.add("EAN CAS");
		objTitles.add("Net Weight CAS");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight CAS");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume CAS");
		objTitles.add("Unit volume");
		objTitles.add("Length CAS");
		objTitles.add("Length unit");
		objTitles.add("Width CAS");
		objTitles.add("With unit");
		objTitles.add("Height CAS");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// DIS
		objTitles.add("EAN DIS");
		objTitles.add("Net Weight DIS");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight DIS");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume DIS");
		objTitles.add("Unit volume");
		objTitles.add("Length DIS");
		objTitles.add("Length unit");
		objTitles.add("Width DIS");
		objTitles.add("With unit");
		objTitles.add("Height DIS");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// CAR
		objTitles.add("EAN CAR");
		objTitles.add("Net Weight CAR");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight CAR");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume CAR");
		objTitles.add("Unit volume");
		objTitles.add("Length CAR");
		objTitles.add("Length unit");
		objTitles.add("Width CAR");
		objTitles.add("With unit");
		objTitles.add("Height CAR");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// MIP
		objTitles.add("EAN MIP");
		objTitles.add("Net Weight MIP");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight MIP");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume MIP");
		objTitles.add("Unit volume");
		objTitles.add("Length MIP");
		objTitles.add("Length unit");
		objTitles.add("Width MIP");
		objTitles.add("With unit");
		objTitles.add("Height MIP");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// PAC
		objTitles.add("EAN PAC");
		objTitles.add("Net Weight PAC");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight PAC");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume PAC");
		objTitles.add("Unit volume");
		objTitles.add("Length PAC");
		objTitles.add("Length unit");
		objTitles.add("Width PAC");
		objTitles.add("With unit");
		objTitles.add("Height PAC");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// PAL
		objTitles.add("EAN PAL");
		objTitles.add("Net Weight PAL");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight PAL");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume PAL");
		objTitles.add("Unit volume");
		objTitles.add("Length PAL");
		objTitles.add("Length unit");
		objTitles.add("Width PAL");
		objTitles.add("With unit");
		objTitles.add("Height PAL");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		// LAY
		objTitles.add("EAN LAY");
		objTitles.add("Net Weight LAY");
		objTitles.add("Unit net weight");
		objTitles.add("Gross Weight LAY");
		objTitles.add("Unit gross weight");
		objTitles.add("Volume LAY");
		objTitles.add("Unit volume");
		objTitles.add("Length LAY");
		objTitles.add("Length unit");
		objTitles.add("Width LAY");
		objTitles.add("With unit");
		objTitles.add("Height LAY");
		objTitles.add("Height unit");
		objTitles.add("Number of layer");
		objTitles.add("Number per layer");

		objTitles.add("Stackability factor");

		return objTitles;
	}

	private List<String> createTitlesTabThree() // Pack
	{
		List<String> objTitles = new ArrayList<String>();
		objTitles.add("CBU");
		objTitles.add("Channel");
		objTitles.add("EAN");
		objTitles.add("Material Code");
		objTitles.add("Material Description");
		objTitles.add("Version status");
		objTitles.add("Version #");
		objTitles.add("Launchdate");
		objTitles.add("Packaging Code");
		objTitles.add("Number of component");
		objTitles.add("Component");
		objTitles.add("Description component");
		objTitles.add("Labelling Code");
		objTitles.add("Output Code");
		objTitles.add("Code Bassine");
		objTitles.add("LSF");
		objTitles.add("Artemis SKU");
		objTitles.add("Legal denomination");
		objTitles.add("Good supplier agreement");
		objTitles.add("Trade name of the operator");
		objTitles.add("Ingredient list");
		objTitles.add("Allergens - Contain");
		objTitles.add("Allergens - May Contain");
		objTitles.add("Allergens - Cross Contamination");
		// objTitles.add("Mentions");
		objTitles.add("Mentions of preservation BEFORE opening");
		objTitles.add("Mentions of preservation AFTER opening");
		objTitles.add("Regulatory mentions");
		objTitles.add("Advises of use and preservation");
		objTitles.add("Instructions for use");
		objTitles.add("Consumption age");
		objTitles.add("Storage condition");
		objTitles.add("Important notice for Milk");
		objTitles.add("Specific indication");
		objTitles.add("Texte Claim 1");
		objTitles.add("Texte Claim 2");
		objTitles.add("Texte Claim 3");
		objTitles.add("Texte Claim 4");
		objTitles.add("Texte Claim 5");
		objTitles.add("Marketing Claims 1");
		objTitles.add("Marketing Claims 2");
		objTitles.add("Marketing Claims 3");
		objTitles.add("Marketing Claims 4");
		// objTitles.add("Valeurs Nutritionelle");
		// objTitles.add("Pour 100g/100ml");
		// objTitles.add("125 g");
		// objTitles.add("%VRE");

		return objTitles;
	}

	private List<String> createTitlesTabFour() // Nutru=itional
	{
		List<String> objTitles = new ArrayList<String>();
		objTitles.add("CBU");
		objTitles.add("Channel");
		objTitles.add("EAN");
		objTitles.add("Material Code");
		objTitles.add("Material Description");
		objTitles.add("Version status");
		objTitles.add("Version #");
		objTitles.add("Launchdate");
		objTitles.add("Packaging Code");
		objTitles.add("Number of component");
		objTitles.add("Component");
		objTitles.add("Description component");
		objTitles.add("Labelling Code");
		objTitles.add("Output Code");
		objTitles.add("Code Bassine");
		objTitles.add("LSF");
		objTitles.add("Artemis SKU");
		objTitles.add("Serving Size");
		objTitles.add("Nutrient Code");
		objTitles.add("Unit of Serving Size");
		objTitles.add("Description of serving size");
		objTitles.add("Rank");
		objTitles.add("Sign description of serving size");
		objTitles.add("Value of nutrient");
		objTitles.add("Value rounded of nutrient");
		objTitles.add("Unit value of nutrient");
		objTitles.add("RI = AJRC");
		objTitles.add("Unit of RI");
		objTitles.add("Display");

		return objTitles;
	}

	private List<Object> createRecord(String type, ProductWrapper product, ProductDetailWrapper prodDetail,
			String plant, String langu, JCoTable prodhier, String ecatd) {
		try {
			KeyToDescription keyToDesc = KeyToDescription.getInstance();
			
/*			ProductDetailResource prodRes = new ProductDetailResource();
			ProductDetailWrapper prodDetail = prodRes.getDetails(product.getSystem(), product.getMandt(),
					product.getCat_guid(), product.getMatnr(), product.getVkorg(), product.getVtweg(),
					product.getPrinbr(), product.getProductgroup(), product.getEan_upc_base(),
					product.getValidity_base(), langu, plant, ecatd, true);*/

			List<Object> objRecord = new ArrayList<Object>();
			objRecord.add(product.getVkorg());
			objRecord.add(product.getVtweg());
			objRecord.add(product.getEan_upc_base());
			objRecord.add(product.getMatnr());
			objRecord.add(product.getMaktx());
			objRecord.add(product.getStatustext());
			objRecord.add(product.getVerno());
			objRecord.add(product.getZzlaunchdate());
			objRecord.add(product.getZzpaccod());
			objRecord.add(product.getCode_labelling());
			objRecord.add(product.getCode_output());
			objRecord.add("");
			objRecord.add(product.getLsf());
			objRecord.add(prodDetail.getArtemis_sku());

			if (prodDetail != null) {
				if (type.equalsIgnoreCase("product")) {
					// Determine prodhier
					String prodh1 = "";
					String prodh2 = "";
					String prodh3 = "";
					String prodh4 = "";
					String prodh5 = "";
					String prodh6 = "";

					if (prodhier != null && prodDetail.getProdh().length() > 0) {
						String fullProdHier = prodDetail.getProdh();

						for (int i = 0; i < prodhier.getNumRows(); i++) {

							prodhier.setRow(i);
							JCoFieldIterator it = prodhier.getFieldIterator();

							Boolean correctEntry = false;
							String nodelvl = "";

							// get fields of current record
							while (it.hasNextField()) {
								JCoField oComponent = it.nextField();
								String paramName = (String) oComponent.getName();

								if (paramName.equalsIgnoreCase("PROD_HIER")) {
									String prodhiervalue = oComponent.getValue().toString();
									if (fullProdHier.substring(0, prodhiervalue.length())
											.equalsIgnoreCase(prodhiervalue)) {
										correctEntry = true;
									} else {
										correctEntry = false;
									}
								}

								if (paramName.equalsIgnoreCase("NODE_LEVEL") && correctEntry) {
									nodelvl = oComponent.getValue().toString();
								}

								if (paramName.equalsIgnoreCase("NODE_TEXT") && !nodelvl.equalsIgnoreCase("")) {
									if (nodelvl.equalsIgnoreCase("1")) {
										prodh1 = oComponent.getValue().toString();
									} else if (nodelvl.equalsIgnoreCase("2")) {
										prodh2 = oComponent.getValue().toString();
									} else if (nodelvl.equalsIgnoreCase("3")) {
										prodh3 = oComponent.getValue().toString();
									} else if (nodelvl.equalsIgnoreCase("4")) {
										prodh4 = oComponent.getValue().toString();
									} else if (nodelvl.equalsIgnoreCase("5")) {
										prodh5 = oComponent.getValue().toString();
									} else if (nodelvl.equalsIgnoreCase("6")) {
										prodh6 = oComponent.getValue().toString();
										break;
									}
								}
							}
						}
					}

					objRecord.add(product.getVmsta());
					objRecord.add(product.getMaktx());
					objRecord.add(prodDetail.getCommercialDescription());
					objRecord.add(prodDetail.getEcatdescription());
					objRecord.add(prodDetail.getInternetdescription());
					// objRecord.add(prodDetail.getZzsignature());
					// objRecord.add(prodDetail.getZzoverlay());
					// objRecord.add(prodDetail.getZzproductvar());
					// objRecord.add(prodDetail.getZzforcastunit());
					objRecord.add(getBrandText(prodDetail.getZzsignature()));
					objRecord.add(getSubbrandText(prodDetail.getZzoverlay()));
					objRecord.add(getProdvarText(prodDetail.getZzproductvar()));
					objRecord.add(getForcastuText(prodDetail.getZzforcastunit()));
					objRecord.add(prodDetail.getFormat());
					// objRecord.add(prodDetail.getConsumptionmoment());
					objRecord.add(prodDetail.getConsumptiontime());
					// objRecord.add(getConsumptionText(prodDetail.getConsumptionage()));
					objRecord.add(prodDetail.getRegulcce());
					objRecord.add(prodDetail.getComm_code());

					if (prodDetail.getLifetime_day().length() > 0) {
						Integer valueInt = Integer.parseInt(prodDetail.getLifetime_day());
						if (valueInt != null) {
							double calcMonth = valueInt / 30;
							objRecord.add((int) calcMonth);
						} else {
							objRecord.add("");
						}
					} else {
						objRecord.add("");
					}

					objRecord.add(prodDetail.getLifetime_day());
					objRecord.add(prodDetail.getDlsc());
					objRecord.add(prodDetail.getConsigne());
					objRecord.add(prodDetail.getPalettisation());
					objRecord.add(prodDetail.getHerkl());
					objRecord.add(prodDetail.getZzby());
					objRecord.add(prodDetail.getMvgr1());
					String factory = "";
					if (prodDetail.getZzprocess1() != null && prodDetail.getZzprocess2() != null) {
						factory = prodDetail.getZzprocess1() + " " + prodDetail.getZzprocess2();
					} else if (prodDetail.getZzprocess1() != null) {
						factory = prodDetail.getZzprocess1();
					} else if (prodDetail.getZzprocess2() != null) {
						factory = prodDetail.getZzprocess2();
					}
					objRecord.add(factory.trim());
					objRecord.add(""); // Factory of conditioning
					objRecord.add(""); // Carbon footprint
					objRecord.add(prodDetail.getProject_code());
					objRecord.add(prodh1);
					objRecord.add(prodh2);
					objRecord.add(prodh3);
					objRecord.add(prodh4);
					objRecord.add(prodh5);
					objRecord.add(prodh6);
					objRecord.add(prodDetail.getRange());
					objRecord.add(prodDetail.getSubrange());
					objRecord.add(prodDetail.getZzmarki());
					objRecord.add(prodDetail.getZzmarkii());
					objRecord.add(prodDetail.getZzmarkiii());
					objRecord.add(prodDetail.getZzmarkiv());
					objRecord.add(prodDetail.getClick2buy());
					/*
					 * List<AllergenWrapper> allergenList =
					 * prodDetail.getAllergenList();
					 * Collections.sort(allergenList, new
					 * Comparator<AllergenWrapper>(){ public int
					 * compare(AllergenWrapper a1, AllergenWrapper a2) { return
					 * a1.getAllergen().compareToIgnoreCase(a2.getAllergen()); }
					 * });
					 * 
					 * for (String str : allExistList) { Boolean found = false;
					 * 
					 * for (AllergenWrapper al : allergenList) { if
					 * (str.equalsIgnoreCase(al.getAllergen()) &&
					 * al.getPresence().equalsIgnoreCase("yes")) { found = true;
					 * objRecord.add("Yes"); } }
					 * 
					 * if (found == false) { objRecord.add("No"); } }
					 */
				} else if (type.equalsIgnoreCase("logistics")) {
					// STUPID Code, should see if we can't make this dynamic...
					// Challenge is that this is different based on the product
					List<UoMWrapper> uomlist = prodDetail.getUomlist();
					UoMWrapper uomkar = new UoMWrapper();
					UoMWrapper uompal = new UoMWrapper();
					UoMWrapper uomst = new UoMWrapper();
					UoMWrapper uombag = new UoMWrapper();
					UoMWrapper uombt = new UoMWrapper();
					UoMWrapper uombox = new UoMWrapper();
					UoMWrapper uombrq = new UoMWrapper();
					UoMWrapper uomcas = new UoMWrapper();
					UoMWrapper uomdis = new UoMWrapper();
					UoMWrapper uommip = new UoMWrapper();
					UoMWrapper uompac = new UoMWrapper();
					UoMWrapper uomlay = new UoMWrapper();

					for (UoMWrapper wrap : uomlist) {
						if (wrap.getAlt_unit().equalsIgnoreCase("ST")) {
							uomst = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("BAG")) {
							uombag = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("BOT")) {
							uombt = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("BOX")) {
							uombox = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("BRQ")) {
							uombrq = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("CAS")) {
							uomcas = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("DIS")) {
							uomdis = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("KAR")) {
							uomkar = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("MIP")) {
							uommip = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("PAK")) {
							uompac = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("PAL")) {
							uompal = wrap;
						} else if (wrap.getAlt_unit().equalsIgnoreCase("LAY")) {
							uomlay = wrap;
						}
					}

					objRecord.add(uomst.getEan_upc_altunit());
					objRecord.add(uomst.getNet_weight());
					objRecord.add(uomst.getUnit_of_net());
					objRecord.add(uomst.getGross_wt());
					objRecord.add(uomst.getUnit_of_wt());
					objRecord.add(uomst.getVolume());
					objRecord.add(uomst.getVolumeunit());
					objRecord.add(uomst.getLength());
					objRecord.add(uomst.getUnit_length());
					objRecord.add(uomst.getWidth());
					objRecord.add(uomst.getUnit_width());
					objRecord.add(uomst.getHeight());
					objRecord.add(uomst.getUnit_height());
					objRecord.add(uomst.getNb_of_lay());
					objRecord.add(uomst.getNb_per_lay());

					objRecord.add(uombag.getEan_upc_altunit());
					objRecord.add(uombag.getNet_weight());
					objRecord.add(uombag.getUnit_of_net());
					objRecord.add(uombag.getGross_wt());
					objRecord.add(uombag.getUnit_of_wt());
					objRecord.add(uombag.getVolume());
					objRecord.add(uombag.getVolumeunit());
					objRecord.add(uombag.getLength());
					objRecord.add(uombag.getUnit_length());
					objRecord.add(uombag.getWidth());
					objRecord.add(uombag.getUnit_width());
					objRecord.add(uombag.getHeight());
					objRecord.add(uombag.getUnit_height());
					objRecord.add(uombag.getNb_of_lay());
					objRecord.add(uombag.getNb_per_lay());

					objRecord.add(uombt.getEan_upc_altunit());
					objRecord.add(uombt.getNet_weight());
					objRecord.add(uombt.getUnit_of_net());
					objRecord.add(uombt.getGross_wt());
					objRecord.add(uombt.getUnit_of_wt());
					objRecord.add(uombt.getVolume());
					objRecord.add(uombt.getVolumeunit());
					objRecord.add(uombt.getLength());
					objRecord.add(uombt.getUnit_length());
					objRecord.add(uombt.getWidth());
					objRecord.add(uombt.getUnit_width());
					objRecord.add(uombt.getHeight());
					objRecord.add(uombt.getUnit_height());
					objRecord.add(uombt.getNb_of_lay());
					objRecord.add(uombt.getNb_per_lay());

					objRecord.add(uombox.getEan_upc_altunit());
					objRecord.add(uombox.getNet_weight());
					objRecord.add(uombox.getUnit_of_net());
					objRecord.add(uombox.getGross_wt());
					objRecord.add(uombox.getUnit_of_wt());
					objRecord.add(uombox.getVolume());
					objRecord.add(uombox.getVolumeunit());
					objRecord.add(uombox.getLength());
					objRecord.add(uombox.getUnit_length());
					objRecord.add(uombox.getWidth());
					objRecord.add(uombox.getUnit_width());
					objRecord.add(uombox.getHeight());
					objRecord.add(uombox.getUnit_height());
					objRecord.add(uombox.getNb_of_lay());
					objRecord.add(uombox.getNb_per_lay());

					objRecord.add(uombrq.getEan_upc_altunit());
					objRecord.add(uombrq.getNet_weight());
					objRecord.add(uombrq.getUnit_of_net());
					objRecord.add(uombrq.getGross_wt());
					objRecord.add(uombrq.getUnit_of_wt());
					objRecord.add(uombrq.getVolume());
					objRecord.add(uombrq.getVolumeunit());
					objRecord.add(uombrq.getLength());
					objRecord.add(uombrq.getUnit_length());
					objRecord.add(uombrq.getWidth());
					objRecord.add(uombrq.getUnit_width());
					objRecord.add(uombrq.getHeight());
					objRecord.add(uombrq.getUnit_height());
					objRecord.add(uombrq.getNb_of_lay());
					objRecord.add(uombrq.getNb_per_lay());

					objRecord.add(uomcas.getEan_upc_altunit());
					objRecord.add(uomcas.getNet_weight());
					objRecord.add(uomcas.getUnit_of_net());
					objRecord.add(uomcas.getGross_wt());
					objRecord.add(uomcas.getUnit_of_wt());
					objRecord.add(uomcas.getVolume());
					objRecord.add(uomcas.getVolumeunit());
					objRecord.add(uomcas.getLength());
					objRecord.add(uomcas.getUnit_length());
					objRecord.add(uomcas.getWidth());
					objRecord.add(uomcas.getUnit_width());
					objRecord.add(uomcas.getHeight());
					objRecord.add(uomcas.getUnit_height());
					objRecord.add(uomcas.getNb_of_lay());
					objRecord.add(uomcas.getNb_per_lay());

					objRecord.add(uomdis.getEan_upc_altunit());
					objRecord.add(uomdis.getNet_weight());
					objRecord.add(uomdis.getUnit_of_net());
					objRecord.add(uomdis.getGross_wt());
					objRecord.add(uomdis.getUnit_of_wt());
					objRecord.add(uomdis.getVolume());
					objRecord.add(uomdis.getVolumeunit());
					objRecord.add(uomdis.getLength());
					objRecord.add(uomdis.getUnit_length());
					objRecord.add(uomdis.getWidth());
					objRecord.add(uomdis.getUnit_width());
					objRecord.add(uomdis.getHeight());
					objRecord.add(uomdis.getUnit_height());
					objRecord.add(uomdis.getNb_of_lay());
					objRecord.add(uomdis.getNb_per_lay());

					objRecord.add(uomkar.getEan_upc_altunit());
					objRecord.add(uomkar.getNet_weight());
					objRecord.add(uomkar.getUnit_of_net());
					objRecord.add(uomkar.getGross_wt());
					objRecord.add(uomkar.getUnit_of_wt());
					objRecord.add(uomkar.getVolume());
					objRecord.add(uomkar.getVolumeunit());
					objRecord.add(uomkar.getLength());
					objRecord.add(uomkar.getUnit_length());
					objRecord.add(uomkar.getWidth());
					objRecord.add(uomkar.getUnit_width());
					objRecord.add(uomkar.getHeight());
					objRecord.add(uomkar.getUnit_height());
					objRecord.add(uomkar.getNb_of_lay());
					objRecord.add(uomkar.getNb_per_lay());

					objRecord.add(uommip.getEan_upc_altunit());
					objRecord.add(uommip.getNet_weight());
					objRecord.add(uommip.getUnit_of_net());
					objRecord.add(uommip.getGross_wt());
					objRecord.add(uommip.getUnit_of_wt());
					objRecord.add(uommip.getVolume());
					objRecord.add(uommip.getVolumeunit());
					objRecord.add(uommip.getLength());
					objRecord.add(uommip.getUnit_length());
					objRecord.add(uommip.getWidth());
					objRecord.add(uommip.getUnit_width());
					objRecord.add(uommip.getHeight());
					objRecord.add(uommip.getUnit_height());
					objRecord.add(uommip.getNb_of_lay());
					objRecord.add(uommip.getNb_per_lay());

					objRecord.add(uompac.getEan_upc_altunit());
					objRecord.add(uompac.getNet_weight());
					objRecord.add(uompac.getUnit_of_net());
					objRecord.add(uompac.getGross_wt());
					objRecord.add(uompac.getUnit_of_wt());
					objRecord.add(uompac.getVolume());
					objRecord.add(uompac.getVolumeunit());
					objRecord.add(uompac.getLength());
					objRecord.add(uompac.getUnit_length());
					objRecord.add(uompac.getWidth());
					objRecord.add(uompac.getUnit_width());
					objRecord.add(uompac.getHeight());
					objRecord.add(uompac.getUnit_height());
					objRecord.add(uompac.getNb_of_lay());
					objRecord.add(uompac.getNb_per_lay());

					objRecord.add(uompal.getEan_upc_altunit());
					objRecord.add(uompal.getNet_weight());
					objRecord.add(uompal.getUnit_of_net());
					objRecord.add(uompal.getGross_wt());
					objRecord.add(uompal.getUnit_of_wt());
					objRecord.add(uompal.getVolume());
					objRecord.add(uompal.getVolumeunit());
					objRecord.add(uompal.getLength());
					objRecord.add(uompal.getUnit_length());
					objRecord.add(uompal.getWidth());
					objRecord.add(uompal.getUnit_width());
					objRecord.add(uompal.getHeight());
					objRecord.add(uompal.getUnit_height());
					objRecord.add(uompal.getNb_of_lay());
					objRecord.add(uompal.getNb_per_lay());

					objRecord.add(uomlay.getEan_upc_altunit());
					objRecord.add(uomlay.getNet_weight());
					objRecord.add(uomlay.getUnit_of_net());
					objRecord.add(uomlay.getGross_wt());
					objRecord.add(uomlay.getUnit_of_wt());
					objRecord.add(uomlay.getVolume());
					objRecord.add(uomlay.getVolumeunit());
					objRecord.add(uomlay.getLength());
					objRecord.add(uomlay.getUnit_length());
					objRecord.add(uomlay.getWidth());
					objRecord.add(uomlay.getUnit_width());
					objRecord.add(uomlay.getHeight());
					objRecord.add(uomlay.getUnit_height());
					objRecord.add(uomlay.getNb_of_lay());
					objRecord.add(uomlay.getNb_per_lay());

					objRecord.add(prodDetail.getStfak());

				}
			} else {
				LOGGER.debug("Error fetching product detail wrapper");
			}

			return objRecord;
		} catch (Exception e) {
			LOGGER.debug(
					"Exception while creating object record: " + type + " " + product.getMatnr() + " " + e.toString());
			return null;
		}
	}

	private String getConsumptionText(String key) {
		for (int i = 0; i < consumpDesc.length(); i++) {
			JSONObject obj = consumpDesc.getJSONObject(i);

			if (obj.get("ZPRICHARTERIST").toString().equalsIgnoreCase(key)) {
				return obj.getString("ZDESCRIPTION").toString();
			}
		}
		return key;
	}

	private String getBrandText(String key) {
		for (int i = 0; i < brandDesc.length(); i++) {
			JSONObject obj = brandDesc.getJSONObject(i);

			if (obj.get("ZSIGNATURE").toString().equalsIgnoreCase(key)) {
				return obj.getString("ZDESCRIPTION").toString();
			}
		}
		return key;
	}

	private String getSubbrandText(String key) {
		for (int i = 0; i < subbrandDesc.length(); i++) {
			JSONObject obj = subbrandDesc.getJSONObject(i);

			if (obj.get("ZOVERLAY").toString().equalsIgnoreCase(key)) {
				return obj.getString("ZDESCRIPTION").toString();
			}
		}
		return key;
	}

	private String getProdvarText(String key) {
		for (int i = 0; i < prodvarDesc.length(); i++) {
			JSONObject obj = prodvarDesc.getJSONObject(i);

			if (obj.get("ZPRODUCT_VAR").toString().equalsIgnoreCase(key)) {
				return obj.getString("ZPROD_DESCRIP").toString();
			}
		}

		return key;
	}

	private String getForcastuText(String key) {
		for (int i = 0; i < forcastuDesc.length(); i++) {
			JSONObject obj = forcastuDesc.getJSONObject(i);

			if (obj.get("Z_FORCAST_UNIT").toString().equalsIgnoreCase(key)) {
				return obj.getString("ZUNIT_DESCIP").toString();
			}
		}

		return key;
	}

	private void fillExcelSheetPack(List<String> objTitles, List<ProductWrapper> prodList,
			HashMap<String, ProductDetailWrapper> prodDetailHm, HSSFSheet sheet,
			HSSFCellStyle headerStyle, String type, String plant, String langu, JCoTable prodhier, String ecatd,
			Boolean excel) {
		HSSFCellStyle style = sheet.getWorkbook().createCellStyle();
		style.setWrapText(true);
		HSSFFont my_font = sheet.getWorkbook().createFont();
		my_font.setFontName("Calibri-Regular");
		style.setFont(my_font);

		HSSFCellStyle datestyle = sheet.getWorkbook().createCellStyle();
		HSSFCreationHelper createHelper = sheet.getWorkbook().getCreationHelper();
		datestyle.setFont(my_font);
		datestyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));

		try {
			// Create titles
			Row rowTitle = sheet.createRow(0);
			int cellnum = 0;
			for (String title : objTitles) {
				Cell cell = rowTitle.createCell(cellnum++);
				cell.setCellStyle(headerStyle);
				cell.setCellValue(title);
			}

			int rownum = 1;
			for (ProductWrapper product : prodList) {
				try {
/*					ProductDetailResource prodRes = new ProductDetailResource();
					ProductDetailWrapper prodDetail = prodRes.getDetails(product.getSystem(), product.getMandt(),
							product.getCat_guid(), product.getMatnr(), product.getVkorg(), product.getVtweg(),
							product.getPrinbr(), product.getProductgroup(), product.getEan_upc_base(),
							product.getValidity_base(), langu, plant, ecatd, true);*/
					ProductDetailWrapper prodDetail =
						prodDetailHm.get(product.getSystem() + "_" + product.getMandt() + "_" + product.getCat_guid());
					if (prodDetail != null) {
						if (prodDetail.getMultiList().size() > 0) {
							List<MultipackWrapper> multiPack = prodDetail.getMultiList();
							for (MultipackWrapper multi : multiPack) {
								List<Object> objRecord = new ArrayList<Object>();
								objRecord.add(product.getVkorg());
								objRecord.add(product.getVtweg());
								objRecord.add(product.getEan_upc_base());
								objRecord.add(product.getMatnr());
								objRecord.add(product.getMaktx());
								objRecord.add(product.getStatustext());
								objRecord.add(product.getVerno());
								objRecord.add(product.getZzlaunchdate());
								objRecord.add(product.getZzpaccod());
								objRecord.add(multi.getEan_upc_base());
								objRecord.add(multi.getMatnr());
								objRecord.add(multi.getDescription());
								objRecord.add(multi.getCode_labelling());
								objRecord.add(multi.getCode_output());
								objRecord.add("");
								objRecord.add(multi.getLsf());
								objRecord.add(multi.getArtemis_sku());

								// read details of multi component
								EntityManager em = PersistenceAdapter.getEntityManager();
								ZPRODCAT_HDR compCathdr = ZPRODCAT_HDR.getHeaderByCatGuid(em, product.getSystem(),
										multi.getCat_guid());

								ProductDetailResource compRes = new ProductDetailResource();
								ProductDetailWrapper compDetail = compRes.getDetails(compCathdr.getKey().getSystem(),
										compCathdr.getKey().getMandt(), compCathdr.getKey().getCat_guid(),
										compCathdr.getMatnr(), compCathdr.getVkorg(), compCathdr.getVtweg(),
										compCathdr.getPrinbr(), compCathdr.getProductgroup(),
										compCathdr.getEan_upc_base(), multi.getValidity_base(), langu, plant, ecatd,
										excel);

								if (compDetail != null) {
									objRecord.add(compDetail.getLegaldeno());
									objRecord.add(compDetail.getAgreement());
									objRecord.add(compDetail.getTradename());
									objRecord.add(compDetail.getIngredientlist());
									// objRecord.add(compDetail.getMentions());
									String allergContain = compDetail.getAllergen_contain().replaceAll(", ", "\n");
									objRecord.add(allergContain);
									String allergMayContain = compDetail.getAllergen_may_contain().replaceAll(", ",
											"\n");
									objRecord.add(allergMayContain);
									String allergCrossConta = compDetail.getCross_contamination().replaceAll(", ",
											"\n");
									objRecord.add(allergCrossConta);
									objRecord.add(compDetail.getBeforeopening());
									objRecord.add(compDetail.getAfteropening());
									objRecord.add(compDetail.getRegulatory());
									objRecord.add(compDetail.getAdviseuse());
									objRecord.add(compDetail.getInstructionsuse());
									//objRecord.add(getConsumptionText(compDetail.getConsumptionage()));
									objRecord.add(compDetail.getConsumptionage());
									objRecord.add(compDetail.getStoragecond());
									objRecord.add(compDetail.getNoticemilk());
									objRecord.add(compDetail.getSpecificindic());
									objRecord.add(compDetail.getClaim1());
									objRecord.add(compDetail.getClaim2());
									objRecord.add(compDetail.getClaim3());
									objRecord.add(compDetail.getClaim4());
									objRecord.add(compDetail.getClaim5());
									objRecord.add(compDetail.getMktexture());
									objRecord.add(compDetail.getMkingredient());
									objRecord.add(compDetail.getMkbenefits());
									objRecord.add(compDetail.getMkother());
								}

								cellnum = 0;
								LOGGER.debug("Add entry");
								Row row = sheet.createRow(rownum++);
								for (Object obj : objRecord) {
									Cell cell = row.createCell(cellnum++);
									cell.setCellStyle(style);
									if (obj != null) {
										if (obj instanceof String) {
											cell.setCellValue((String) obj);
										} else if (obj instanceof Integer) {
											cell.setCellValue((Integer) obj);
										} else if (obj instanceof Double) {
											cell.setCellValue((Double) obj);
										} else if (obj instanceof Date) {
											cell.setCellValue((Date) obj);
											cell.setCellStyle(datestyle);
										} else {
											if (obj != null) {
												cell.setCellValue(obj.toString());
												LOGGER.debug("UNSUPPORTED TYPE: " + obj.getClass());
											}
										}
									} else {
										cell.setCellValue("");
									}
								}
							}

						} else {
							List<Object> objRecord = new ArrayList<Object>();
							objRecord.add(product.getVkorg());
							objRecord.add(product.getVtweg());
							objRecord.add(product.getEan_upc_base());
							objRecord.add(product.getMatnr());
							objRecord.add(product.getMaktx());
							objRecord.add(product.getStatustext());
							objRecord.add(product.getVerno());
							objRecord.add(product.getZzlaunchdate());
							objRecord.add(product.getZzpaccod());
							objRecord.add("");
							objRecord.add("");
							objRecord.add("");
							objRecord.add(product.getCode_labelling());
							objRecord.add(product.getCode_output());
							objRecord.add("");
							objRecord.add(product.getLsf());
							objRecord.add(prodDetail.getArtemis_sku());

							objRecord.add(prodDetail.getLegaldeno());
							objRecord.add(prodDetail.getAgreement());
							objRecord.add(prodDetail.getTradename());
							objRecord.add(prodDetail.getIngredientlist());
							// objRecord.add(prodDetail.getMentions());
							String allergContain = prodDetail.getAllergen_contain().replaceAll(", ", "\n");
							objRecord.add(allergContain);
							String allergMayContain = prodDetail.getAllergen_may_contain().replaceAll(", ", "\n");
							objRecord.add(allergMayContain);
							String allergCrossConta = prodDetail.getCross_contamination().replaceAll(", ", "\n");
							objRecord.add(allergCrossConta);
							objRecord.add(prodDetail.getBeforeopening());
							objRecord.add(prodDetail.getAfteropening());
							objRecord.add(prodDetail.getRegulatory());
							objRecord.add(prodDetail.getAdviseuse());
							objRecord.add(prodDetail.getInstructionsuse());
							//objRecord.add(getConsumptionText(prodDetail.getConsumptionage()));
							objRecord.add(prodDetail.getConsumptionage());
							objRecord.add(prodDetail.getStoragecond());
							objRecord.add(prodDetail.getNoticemilk());
							objRecord.add(prodDetail.getSpecificindic());
							objRecord.add(prodDetail.getClaim1());
							objRecord.add(prodDetail.getClaim2());
							objRecord.add(prodDetail.getClaim3());
							objRecord.add(prodDetail.getClaim4());
							objRecord.add(prodDetail.getClaim5());
							objRecord.add(prodDetail.getMktexture());
							objRecord.add(prodDetail.getMkingredient());
							objRecord.add(prodDetail.getMkbenefits());
							objRecord.add(prodDetail.getMkother());

							cellnum = 0;
							LOGGER.debug("Add entry");
							Row row = sheet.createRow(rownum++);
							for (Object obj : objRecord) {
								Cell cell = row.createCell(cellnum++);
								cell.setCellStyle(style);
								if (obj != null) {
									if (obj instanceof String) {
										cell.setCellValue((String) obj);
									} else if (obj instanceof Integer) {
										cell.setCellValue((Integer) obj);
									} else if (obj instanceof Double) {
										cell.setCellValue((Double) obj);
									} else if (obj instanceof Date) {
										cell.setCellValue((Date) obj);
										cell.setCellStyle(datestyle);
									} else {
										if (obj != null) {
											cell.setCellValue(obj.toString());
											LOGGER.debug("UNSUPPORTED TYPE: " + obj.getClass());
										}
									}
								} else {
									cell.setCellValue("");
								}
							}
						}

					} else {
						LOGGER.debug("Error fetching product detail wrapper");
					}
				} catch (Exception e) {
					LOGGER.debug("Exception while creating object record: " + type + " " + product.getMatnr() + " "
							+ e.toString());
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Error in fillExcelSheetNutrition" + e.toString());
		}
	}

	private void fillExcelSheetNutrition(List<String> objTitles, List<ProductWrapper> prodList, 
			HashMap<String, ProductDetailWrapper> prodDetailHm,
			HSSFSheet sheet, HSSFCellStyle headerStyle, String type, String plant, String langu, JCoTable prodhier,
			String ecatd) {
		HSSFCellStyle style = sheet.getWorkbook().createCellStyle();
		style.setWrapText(true);
		HSSFFont my_font = sheet.getWorkbook().createFont();
		my_font.setFontName("Calibri-Regular");
		style.setFont(my_font);

		HSSFCellStyle datestyle = sheet.getWorkbook().createCellStyle();
		HSSFCreationHelper createHelper = sheet.getWorkbook().getCreationHelper();
		datestyle.setFont(my_font);
		datestyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));

		try {
			// Create titles
			Row rowTitle = sheet.createRow(0);
			int cellnum = 0;
			for (String title : objTitles) {
				Cell cell = rowTitle.createCell(cellnum++);
				cell.setCellStyle(headerStyle);
				cell.setCellValue(title);
			}

			int rownum = 1;
			for (ProductWrapper product : prodList) {
				try {
/*					ProductDetailResource prodRes = new ProductDetailResource();
					ProductDetailWrapper prodDetail = prodRes.getDetails(product.getSystem(), product.getMandt(),
							product.getCat_guid(), product.getMatnr(), product.getVkorg(), product.getVtweg(),
							product.getPrinbr(), product.getProductgroup(), product.getEan_upc_base(),
							product.getValidity_base(), langu, plant, ecatd, true);*/
//					Set es = hm.entrySet();
//					hm.get("fkljqlksdfjk");
					
					ProductDetailWrapper prodDetail =
							prodDetailHm.get(product.getSystem() + "_" + product.getMandt() + "_" + product.getCat_guid()); 										
					if (prodDetail != null) {
						if (prodDetail.getMultiList().size() > 0) {
							List<MultipackWrapper> multiPack = prodDetail.getMultiList();
							for (MultipackWrapper multi : multiPack) {
								List<NutboardWrapper> nutboardWrap = multi.getNutboard();
								for (NutboardWrapper nut : nutboardWrap) {
									List<Object> objRecord = new ArrayList<Object>();
									objRecord.add(product.getVkorg());
									objRecord.add(product.getVtweg());
									objRecord.add(product.getEan_upc_base());
									objRecord.add(product.getMatnr());
									objRecord.add(product.getMaktx());
									objRecord.add(product.getStatustext());
									objRecord.add(product.getVerno());
									objRecord.add(product.getZzlaunchdate());
									objRecord.add(product.getZzpaccod());
									// TODO
									objRecord.add(multi.getEan_upc_base());
									objRecord.add(multi.getMatnr());
									objRecord.add(multi.getDescription());
									objRecord.add(multi.getCode_labelling());
									objRecord.add(multi.getCode_output());
									objRecord.add("");
									objRecord.add(multi.getLsf());
									objRecord.add(multi.getArtemis_sku());

									objRecord.add(nut.getPoridtext());
									objRecord.add(nut.getNutid());
									objRecord.add(nut.getPoridun());
									objRecord.add(nut.getPoridtext());
									objRecord.add(nut.getRank());
									objRecord.add(nut.getPoridsign());
									objRecord.add(nut.getPoridva());
									objRecord.add(nut.getPoridvaro());
									objRecord.add(nut.getValueun());
									objRecord.add(nut.getAjrc());
									objRecord.add(nut.getAjrcun());
									objRecord.add(nut.getDisplay());

									cellnum = 0;
									LOGGER.debug("Add entry");
									Row row = sheet.createRow(rownum++);
									for (Object obj : objRecord) {
										Cell cell = row.createCell(cellnum++);
										cell.setCellStyle(style);
										if (obj != null) {
											if (obj instanceof String) {
												cell.setCellValue((String) obj);
											} else if (obj instanceof Integer) {
												cell.setCellValue((Integer) obj);
											} else if (obj instanceof Double) {
												cell.setCellValue((Double) obj);
											} else if (obj instanceof Date) {
												cell.setCellValue((Date) obj);
												cell.setCellStyle(datestyle);
											} else {
												if (obj != null) {
													cell.setCellValue(obj.toString());
													LOGGER.debug("UNSUPPORTED TYPE: " + obj.getClass());
												}
											}
										} else {
											cell.setCellValue("");
										}
									}
								}
							}

						} else {
							List<NutboardWrapper> nutboardWrap = prodDetail.getNutboard();
							for (NutboardWrapper nut : nutboardWrap) {
								List<Object> objRecord = new ArrayList<Object>();
								objRecord.add(product.getVkorg());
								objRecord.add(product.getVtweg());
								objRecord.add(product.getEan_upc_base());
								objRecord.add(product.getMatnr());
								objRecord.add(product.getMaktx());
								objRecord.add(product.getStatustext());
								objRecord.add(product.getVerno());
								objRecord.add(product.getZzlaunchdate());
								objRecord.add(product.getZzpaccod());
								objRecord.add("");
								objRecord.add("");
								objRecord.add("");
								objRecord.add(prodDetail.getCode_labelling());
								objRecord.add(product.getCode_output());
								objRecord.add("");
								objRecord.add(product.getLsf());
								objRecord.add(prodDetail.getArtemis_sku());

								objRecord.add(nut.getPoridtext());
								objRecord.add(nut.getNutid());
								objRecord.add(nut.getPoridun());
								objRecord.add(nut.getPoridtext());
								objRecord.add(nut.getRank());
								objRecord.add(nut.getPoridsign());
								objRecord.add(nut.getPoridva());
								objRecord.add(nut.getPoridvaro());
								objRecord.add(nut.getValueun());
								objRecord.add(nut.getAjrc());
								objRecord.add(nut.getAjrcun());
								objRecord.add(nut.getDisplay());

								cellnum = 0;
								LOGGER.debug("Add entry");
								Row row = sheet.createRow(rownum++);
								for (Object obj : objRecord) {
									Cell cell = row.createCell(cellnum++);
									cell.setCellStyle(style);
									if (obj != null) {
										if (obj instanceof String) {
											cell.setCellValue((String) obj);
										} else if (obj instanceof Integer) {
											cell.setCellValue((Integer) obj);
										} else if (obj instanceof Double) {
											cell.setCellValue((Double) obj);
										} else if (obj instanceof Date) {
											cell.setCellValue((Date) obj);
											cell.setCellStyle(datestyle);
										} else {
											if (obj != null) {
												cell.setCellValue(obj.toString());
												LOGGER.debug("UNSUPPORTED TYPE: " + obj.getClass());
											}
										}
									} else {
										cell.setCellValue("");
									}
								}
							}
						}

					} else {
						LOGGER.debug("Error fetching prodDetail detail wrapper");
					}
				} catch (Exception e) {
					LOGGER.debug("Exception while creating object record: " + type + " " + product.getMatnr() + " "
							+ e.toString());
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Error in fillExcelSheetNutrition" + e.toString());
		}
	}

}
