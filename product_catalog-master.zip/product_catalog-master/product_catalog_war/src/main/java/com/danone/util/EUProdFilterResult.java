package com.danone.util;

import java.util.List;

public class EUProdFilterResult {
	
	private List<String> eubrands;
//	private List<String> localbrands;
	private List<String> brandcat;
	private List<String> cuptypes;
	private List<String> processtech;
	private List<String> fatcontent;
	private List<String> subrange;
	private List<String> countries;
	private List<String> multilayer;
	private List<String> topper;
	
	public List<String> getCuptypes() {
		return cuptypes;
	}

	public void setCuptypes(List<String> cuptypes) {
		this.cuptypes = cuptypes;
	}

	public List<String> getProcesstech() {
		return processtech;
	}

	public void setProcesstech(List<String> processtech) {
		this.processtech = processtech;
	}

	public List<String> getFatcontent() {
		return fatcontent;
	}

	public void setFatcontent(List<String> fatcontent) {
		this.fatcontent = fatcontent;
	}

	public List<String> getSubrange() {
		return subrange;
	}

	public void setSubrange(List<String> subrange) {
		this.subrange = subrange;
	}

	public List<String> getEubrands() {
		return eubrands;
	}

	public void setEubrands(List<String> eubrands) {
		this.eubrands = eubrands;
	}
/*
	public List<String> getLocalbrands() {
		return localbrands;
	}

	public void setLocalbrands(List<String> localbrands) {
		this.localbrands = localbrands;
	}*/

	public List<String> getCountries() {
		return countries;
	}

	public void setCountries(List<String> countries) {
		this.countries = countries;
	}

	public List<String> getMultilayer() {
		return multilayer;
	}

	public void setMultilayer(List<String> multilayer) {
		this.multilayer = multilayer;
	}

	public List<String> getTopper() {
		return topper;
	}

	public void setTopper(List<String> topper) {
		this.topper = topper;
	}

	public List<String> getBrandcat() {
		return brandcat;
	}

	public void setBrandcat(List<String> brandcat) {
		this.brandcat = brandcat;
	}
}
