package com.danone.resources;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.conn.jco.JCo;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;

@Path("/picture")
@Produces({ MediaType.APPLICATION_JSON })
public class PictureResource {
	private final Logger LOGGER = LoggerFactory.getLogger(PictureResource.class);
	private JCoRepository repo = null;
	JCoDestination destination = null;
	private static String destinationName = "PRODCATALOG-SAP";

	@Context
	private HttpServletRequest servletRequest;
	
	@POST
/*	public Response createPicture(PICTURES picture) {
		EntityManager em = PersistenceAdapter.getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		Response response;

		try {
			try {
				CmisHelper cmis = new CmisHelper();
				File fileToWriteTo = new File(picture.getFileName());
				FileUtils.writeByteArrayToFile(fileToWriteTo, picture.getPicture());
				cmis.addDocument(fileToWriteTo);
				JCoTable returnMsgTable = this.createPictureInSAPDMS(fileToWriteTo, picture.getType());
				fileToWriteTo.delete();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				LOGGER.error("Failed to create picture from byte array", e);
				response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
			}
			
			transaction.begin();
			
			em.merge(picture);
			
			transaction.commit();
		} catch (PersistenceException e) {
			LOGGER.error("Failed to create Picture via REST", e);
			response = Response.status(HttpURLConnection.HTTP_INTERNAL_ERROR).build();
		} finally {
			if (transaction.isActive()) {
				transaction.rollback();
			}
			em.close();
		}
		
		response = Response.created(UriBuilder.fromPath("/picture/{fileName}").build(picture.getFileName()))
				.entity(picture).build();
		return response;
	}*/
	
	public JCoTable createPictureInSAPDMS(File image, String mimetype) {
		
        try {
			destination = JCoDestinationManager.getDestination(destinationName);
			repo = destination.getRepository();
			JCo.setProperty("jco.use_repository_roundtrip_optimization", "1");
			List<String> functions = new ArrayList<String>();
			functions.add("ZSHCP_DOCUMENT_UPLOAD");
			JCo.queryMetaDataSet(repo, functions, null, null);
			
			JCoFunction stfcConnection = repo.getFunction("ZSHCP_DOCUMENT_UPLOAD");
			JCoParameterList imports = stfcConnection.getImportParameterList();
			
			imports.setValue("IV_DOCUMENT_BUFFER", FileUtils.readFileToByteArray(image));
			imports.setValue("IV_MIME_TYPE", mimetype);
			
			// Run the Function module
			stfcConnection.execute(destination);
			
			// Get results
			JCoParameterList tables = stfcConnection.getTableParameterList();
			JCoTable jcoTable = tables.getTable("ET_RETURN");
			return jcoTable;
			
		}catch (Exception e) {
			LOGGER.debug("Error while attempting to create picture in SAP DMS: " + e.toString());
			return null;
		}
	}
}
