package com.danone.util;

import java.util.Comparator;

public class EUProdSKUListComparator implements Comparator<EUProdSKUList>
{
    public int compare(EUProdSKUList c1, EUProdSKUList c2)
    {
        return c1.getFormat().compareTo(c2.getFormat());
    }
}
