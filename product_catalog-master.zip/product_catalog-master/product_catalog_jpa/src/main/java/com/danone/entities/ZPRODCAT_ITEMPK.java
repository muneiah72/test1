package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPRODCAT_ITEMPK implements java.io.Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7513050866217571716L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	private String cat_guid;
	private Integer cat_posnr;
	
	public ZPRODCAT_ITEMPK() {}

	public ZPRODCAT_ITEMPK(String system, Integer mandt, String cat_guid) {
		this.system = system;
		this.mandt = mandt;
		this.cat_guid = cat_guid;
	}
	
	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getCat_guid() {
		return cat_guid;
	}

	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}

	public Integer getCat_posnr() {
		return cat_posnr;
	}

	public void setCat_posnr(Integer cat_posnr) {
		this.cat_posnr = cat_posnr;
	}

	public boolean equals(Object o) { 
        return ((o instanceof ZPRODCAT_ITEMPK) && 
        		system.equals(((ZPRODCAT_ITEMPK)o).getSystem()) &&
        		mandt.equals(((ZPRODCAT_ITEMPK)o).getMandt()) &&
        		cat_guid.equals(((ZPRODCAT_ITEMPK)o).getCat_guid()) &&
        		cat_posnr.equals(((ZPRODCAT_ITEMPK)o).getCat_posnr()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ cat_guid.hashCode() 
        		+ cat_posnr.hashCode(); 
    }
}
