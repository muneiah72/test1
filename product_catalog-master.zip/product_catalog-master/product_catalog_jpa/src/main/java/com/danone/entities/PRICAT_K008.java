package com.danone.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K008")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K008 {
	
	@EmbeddedId
	private PRICAT_K008PK key;
	
	public PRICAT_K008PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K008PK key) {
		this.key = key;
	}
}
