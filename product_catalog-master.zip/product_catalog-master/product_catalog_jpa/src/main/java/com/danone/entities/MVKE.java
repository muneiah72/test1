package com.danone.entities;

import java.sql.Date;
import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="MVKE")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class MVKE {
	
	@EmbeddedId
	private MVKEPK key;
	private String mvgr1;
	private String prodh;
	private String vmsta;
	private java.sql.Date zzlaunchdate;
	private Integer zzhlfnr1;
	private Integer zzhlfnr2;
	private Integer zzhlfnr3;
	private Integer zzhlfnr4;
	private double aumng;
	private double lfmax;
	private double scmng;
	private double efmng;
	private Integer pvmso;
	private double lfmng;
	private Integer bev1emdrckspl;
	private String zzmarki;
	private String zzmarkii;
	private String zzmarkiii;
	private String zzmarkiv;
	private String zzproductvar;
	private String zzforcastunit;
	private String zzpaccod;
	
	public MVKEPK getKey() {
		return key;
	}
	
	public void setKey(MVKEPK key){
		this.key = key;
	}
	
	public String getMvgr1() {
		return mvgr1;
	}
	
	public void setMvgr1(String mvgr1) {
		this.mvgr1 = mvgr1;
	}
	
	public String getProdh() {
		return prodh;
	}
	
	public void setProdh(String prodh) {
		this.prodh = prodh;
	}
	
	public String getVmsta() {
		return vmsta;
	}
	
	public void setVmsta(String vmsta) {
		this.vmsta = vmsta;
	}

	public Date getZzlaunchdate() {
		return zzlaunchdate;
	}

	public void setZzlaunchdate(Date zzlaunchdate) {
		this.zzlaunchdate = zzlaunchdate;
	}
	
	public Integer getZzhlfnr4() {
		return zzhlfnr4;
	}

	public void setZzhlfnr4(Integer zzhlfnr4) {
		this.zzhlfnr4 = zzhlfnr4;
	}

	public Integer getZzhlfnr1() {
		return zzhlfnr1;
	}

	public void setZzhlfnr1(Integer zzhlfnr1) {
		this.zzhlfnr1 = zzhlfnr1;
	}

	public Integer getZzhlfnr2() {
		return zzhlfnr2;
	}

	public void setZzhlfnr2(Integer zzhlfnr2) {
		this.zzhlfnr2 = zzhlfnr2;
	}

	public Integer getZzhlfnr3() {
		return zzhlfnr3;
	}

	public void setZzhlfnr3(Integer zzhlfnr3) {
		this.zzhlfnr3 = zzhlfnr3;
	}

	public double getAumng() {
		return aumng;
	}

	public void setAumng(double aumng) {
		this.aumng = aumng;
	}

	public double getLfmax() {
		return lfmax;
	}

	public void setLfmax(double lfmax) {
		this.lfmax = lfmax;
	}

	public double getScmng() {
		return scmng;
	}

	public void setScmng(double scmng) {
		this.scmng = scmng;
	}

	public double getEfmng() {
		return efmng;
	}

	public void setEfmng(double efmng) {
		this.efmng = efmng;
	}

	public Integer getPvmso() {
		return pvmso;
	}

	public void setPvmso(Integer pvmso) {
		this.pvmso = pvmso;
	}

	public double getLfmng() {
		return lfmng;
	}

	public void setLfmng(double lfmng) {
		this.lfmng = lfmng;
	}

	public Integer getBev1emdrckspl() {
		return bev1emdrckspl;
	}

	public void setBev1emdrckspl(Integer bev1emdrckspl) {
		this.bev1emdrckspl = bev1emdrckspl;
	}
	
	public String getZzproductvar() {
		return zzproductvar;
	}

	public void setZzproductvar(String zzproductvar) {
		this.zzproductvar = zzproductvar;
	}
	
	public String getZzforcastunit() {
		return zzforcastunit;
	}

	public void setZzforcastunit(String zzforcastunit) {
		this.zzforcastunit = zzforcastunit;
	}
	
	public static MVKE getMVKEByKey(EntityManager em, MVKEPK mvkepk) {
		return em.find(MVKE.class, mvkepk);
	}
	
	public String getZzpaccod() {
		return zzpaccod;
	}

	public void setZzpaccod(String zzpaccod) {
		this.zzpaccod = zzpaccod;
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getMvgr1(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.mvgr1) FROM MVKE m";
		Query query = em.createQuery(queryString, MVKE.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getVmsta(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.vmsta) FROM MVKE m";
		Query query = em.createQuery(queryString, MVKE.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getZzproductvar(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.zzproductvar) FROM MVKE m";
		Query query = em.createQuery(queryString, MVKE.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getZzforcastunit(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.zzforcastunit) FROM MVKE m";
		Query query = em.createQuery(queryString, MVKE.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}

	public String getZzmarkiii() {
		return zzmarkiii;
	}

	public void setZzmarkiii(String zzmarkiii) {
		this.zzmarkiii = zzmarkiii;
	}

	public String getZzmarkiv() {
		return zzmarkiv;
	}

	public void setZzmarkiv(String zzmarkiv) {
		this.zzmarkiv = zzmarkiv;
	}

	public String getZzmarki() {
		return zzmarki;
	}

	public void setZzmarki(String zzmarki) {
		this.zzmarki = zzmarki;
	}

	public String getZzmarkii() {
		return zzmarkii;
	}

	public void setZzmarkii(String zzmarkii) {
		this.zzmarkii = zzmarkii;
	}
}
