package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPRO_NUTRIENT")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPRO_NUTRIENT {
	
	@EmbeddedId
	private ZPRO_NUTRIENTPK key;
	@Column(length = 255)
	private String content;
	
	public ZPRO_NUTRIENTPK getKey() {
		return key;
	}
	
	public void setKey(ZPRO_NUTRIENTPK key) {
		this.key = key;
	}
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	public static ZPRO_NUTRIENT getZPRO_NUTRIENTBySubid(EntityManager em, String system, Integer mandt, String subid, String laiso)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZPRO_NUTRIENT p where p.key.system = :system and p.key.mandt = :mandt and p.key.subid = :subid and p.key.laiso = :laiso",
						ZPRO_NUTRIENT.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("subid", subid);
		query.setParameter("laiso", laiso);

		try {
			List<ZPRO_NUTRIENT> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZPRO_NUTRIENT)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}	
}
