package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K003")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K003 {
	
	@EmbeddedId
	private PRICAT_K003PK key;
	private String ean_upc_type;
	private String bearb_status;
	private String material_group;
	private String mat_id_sender;
	private String matnr;
	private String matl_type;
	private String matl_group;
	private Integer stack_fact;
	private double shelf_life;
	private String countryori;
	private String countryori_iso;
	private String regionorig;
	private String comm_code;
	private double fill_level;
	private double allwd_vol;
	private double allowed_wt;
	private double stor_pct;
	private double net_cont;
	private double compprunit;
	private double minremlife;
	private double gross_cont;
	
	public PRICAT_K003PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K003PK key) {
		this.key = key;
	}
	
	public String getEan_upc_type() {
		return ean_upc_type;
	}
	
	public void setEan_upc_type(String ean_upc_type) {
		this.ean_upc_type = ean_upc_type;
	}

	public String getBearb_status() {
		return bearb_status;
	}

	public void setBearb_status(String bearb_status) {
		this.bearb_status = bearb_status;
	}

	public String getMaterial_group() {
		return material_group;
	}

	public void setMaterial_group(String material_group) {
		this.material_group = material_group;
	}

	public String getMat_id_sender() {
		return mat_id_sender;
	}

	public void setMat_id_sender(String mat_id_sender) {
		this.mat_id_sender = mat_id_sender;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getMatl_type() {
		return matl_type;
	}

	public void setMatl_type(String matl_type) {
		this.matl_type = matl_type;
	}

	public String getMatl_group() {
		return matl_group;
	}

	public void setMatl_group(String matl_group) {
		this.matl_group = matl_group;
	}

	public Integer getStack_fact() {
		return stack_fact;
	}

	public void setStack_fact(Integer stack_fact) {
		this.stack_fact = stack_fact;
	}

	public double getShelf_life() {
		return shelf_life;
	}

	public void setShelf_life(double shelf_life) {
		this.shelf_life = shelf_life;
	}

	public String getCountryori() {
		return countryori;
	}

	public void setCountryori(String countryori) {
		this.countryori = countryori;
	}

	public String getRegionorig() {
		return regionorig;
	}

	public void setRegionorig(String regionorig) {
		this.regionorig = regionorig;
	}

	public String getCountryori_iso() {
		return countryori_iso;
	}

	public void setCountryori_iso(String countryori_iso) {
		this.countryori_iso = countryori_iso;
	}

	public String getComm_code() {
		return comm_code;
	}

	public void setComm_code(String comm_code) {
		this.comm_code = comm_code;
	}

	public double getFill_level() {
		return fill_level;
	}

	public void setFill_level(double fill_level) {
		this.fill_level = fill_level;
	}

	public double getAllwd_vol() {
		return allwd_vol;
	}

	public void setAllwd_vol(double allwd_vol) {
		this.allwd_vol = allwd_vol;
	}

	public double getAllowed_wt() {
		return allowed_wt;
	}

	public void setAllowed_wt(double allowed_wt) {
		this.allowed_wt = allowed_wt;
	}

	public double getStor_pct() {
		return stor_pct;
	}

	public void setStor_pct(double stor_pct) {
		this.stor_pct = stor_pct;
	}

	public double getNet_cont() {
		return net_cont;
	}

	public void setNet_cont(double net_cont) {
		this.net_cont = net_cont;
	}

	public double getCompprunit() {
		return compprunit;
	}

	public void setCompprunit(double compprunit) {
		this.compprunit = compprunit;
	}

	public double getMinremlife() {
		return minremlife;
	}

	public void setMinremlife(double minremlife) {
		this.minremlife = minremlife;
	}

	public double getGross_cont() {
		return gross_cont;
	}

	public void setGross_cont(double gross_cont) {
		this.gross_cont = gross_cont;
	}
	
	public static PRICAT_K003 getPRICAT_K003ByKey(EntityManager em, PRICAT_K003PK key) {
		return em.find(PRICAT_K003.class, key);
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K003> getK003With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup,
						String ean_upc_base, java.sql.Date validity_base) {
		
		String queryString = "SELECT p FROM PRICAT_K003 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_base = :ean_upc_base and p.key.validity_base = :validity_base";
		
		Query query = em.createQuery(queryString, PRICAT_K003.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_base", ean_upc_base).setParameter("validity_base", validity_base);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
}
