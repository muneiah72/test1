package com.danone.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PRICAT_K003PK implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6706937159742560916L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 10)
	private String prinbr;
	@Column(length = 18)
	private String productgroup;
	@Column(length = 35)
	private String ean_upc_base;
	private java.sql.Date validity_base;
	
	public PRICAT_K003PK() {}
	
	public PRICAT_K003PK(String system, Integer mandt, String prinbr, String productgroup, String ean_upc_base, java.sql.Date validity_base) {
        this.system = system;
		this.mandt = mandt;
        this.prinbr = prinbr;
        this.productgroup = productgroup;
        this.ean_upc_base = ean_upc_base;
        this.validity_base = validity_base;
    }
	
	public String getSystem() {
		return system;
	}
	
	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
	
	public String getPrinbr() {
		return prinbr;
	}
	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}
	
	public String getProductgroup() {
		return productgroup;
	}
	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}
	
	public String getEan_upc_base() {
		return ean_upc_base;
	}
	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}
	
	public Date getValidity_base() {
		return validity_base;
	}
	public void setValidity_base(Date validity_base) {
		this.validity_base = validity_base;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof PRICAT_K003PK) && 
        		system.equals(((PRICAT_K003PK)o).getSystem()) &&
        		mandt.equals(((PRICAT_K003PK)o).getMandt()) &&
        		prinbr.equals(((PRICAT_K003PK)o).getPrinbr()) &&
        		productgroup.equals(((PRICAT_K003PK)o).getProductgroup()) &&
        		ean_upc_base.equals(((PRICAT_K003PK)o).getEan_upc_base()) &&
        		validity_base.equals(((PRICAT_K003PK)o).getValidity_base()));
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()
        		+ prinbr.hashCode() 
        		+ productgroup.hashCode() 
        		+ ean_upc_base.hashCode() 
        		+ validity_base.hashCode(); 
    }	
}
