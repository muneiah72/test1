package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPROWS_ORGPK implements java.io.Serializable  {

	private static final long serialVersionUID = -7339973529919799155L;
	
	@Column (length = 4)
	private String vkorg;
	@Column (length = 2)
	private String vtweg;
	
	
	public ZPROWS_ORGPK() {}	
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPROWS_ORGPK) && 
        		vkorg.equals(((ZPROWS_ORGPK)o).getVkorg()) &&
        		vtweg.equals(((ZPROWS_ORGPK)o).getVtweg()) );
    }
	
    public int hashCode() { 
        return vkorg.hashCode()
        		+ vtweg.hashCode(); 
    }
	
	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

}
