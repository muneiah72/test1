package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPMAR1PK implements java.io.Serializable {
	


	/**
	 * 
	 */
	private static final long serialVersionUID = -65989049826685108L;
	
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zmarki;
	
	public ZPPMAR1PK() {}

	public ZPPMAR1PK(String system, Integer mandt, String zmarki) {
		this.system = system;
		this.setMandt(mandt);
		this.setZmarki(zmarki);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPMAR1PK) && 
        		system.equals(((ZPPMAR1PK)o).getSystem()) &&
        		mandt.equals(((ZPPMAR1PK)o).getMandt()) &&        	
        		zmarki.equals(((ZPPMAR1PK)o).getZmarki()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zmarki.hashCode(); 
    }

	public String getZmarki() {
		return zmarki;
	}

	public void setZmarki(String zmarki) {
		this.zmarki = zmarki;
	}

}
