package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class COMPANYSORGPK implements java.io.Serializable  {

	private static final long serialVersionUID = -5470489434475071842L;

	@Column (length = 50)
	private String company;
	
	public COMPANYSORGPK() {}	
	
	public COMPANYSORGPK(String company) {
		this.company = company;
    }
	
	public boolean equals(Object o) { 
        return ((o instanceof COMPANYSORGPK) && 
        		company.equals(((COMPANYSORGPK)o).getCompany()) );
    }
	
    public int hashCode() { 
        return company.hashCode(); 
    }
	
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

}
