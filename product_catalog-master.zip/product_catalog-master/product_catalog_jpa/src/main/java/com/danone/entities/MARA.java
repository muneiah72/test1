package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="MARA")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class MARA {

	@EmbeddedId	
	private MARAPK key;
	private String gewei;
	private Integer zzby;
	private double mhdhb;
	private Integer stfak;
	private Integer zzcapacity;
	private String zzproces1;
	private String zzproces2;
	private double volum;
	private double ntgew;
	private double brgew;
	private Integer blanz;
	private double zzprotein;
	private Integer zzenerg_fam;
	private Integer zzpyramid;
	private Integer fiber_part1;
	private Integer fiber_part2;
	private Integer fiber_part3;
	private Integer fiber_part4;
	private Integer fiber_part5;
	private Integer size1_atinn;
	private Integer size2_atinn;
	private Integer color_atinn;
	private Integer adspc_spc;
	private double vsor_pal_min_h;
	private double vsor_pal_ovr_d;
	private double vsor_pal_ovr_w;
	private Integer vsor_no_p_gvh;
	private double vsor_tol_b_ht;
	private double vsor_pal_b_ht;
	private Integer vsor_stack_no;
	private Integer bev1luleinh;
	private Integer anp;
	private double qqtime;
	private double maxh;
	private double maxb;
	private double maxl;
	private double maxc_tol;
	private double maxc;
	private Integer cuobf;
	private double inhbr;
	private double vpreh;
	private double inhal;
	private double mhdlp;
	private double mhdrz;
	private double fuelg;
	private double volto;
	private double gewto;
	private double ervol;
	private double ergew;
	private double hoehe;
	private double breit;
	private double laeng;
	private double wesch;
	private Integer compl;
	private String zzoverlay;
	private String zzsignature;
	private String zzflavor;
	private String zzpot_diam;
	private String zzrange;
	private String zzsub_range;
	
	public MARAPK getKey() {
		return key;
	}
	
	public void setKey(MARAPK key){
		this.key = key;
	}
	
	public String getGewei() {
		return gewei;
	}
	
	public void setGewei(String gewei) {
		this.gewei = gewei;
	}
	
	public Integer getZzby() {
		return zzby;
	}
	
	public void setZzby(Integer zzby) {
		this.zzby = zzby;
	}
	
	public double getMhdhb() {
		return mhdhb;
	}
	
	public void setMhdhb(double mhdhb) {
		this.mhdhb = mhdhb;
	}
	
	public Integer getStfak() {
		return stfak;
	}
	
	public void setStfak(Integer stfak) {
		this.stfak = stfak;
	}
	
	public Integer getZzcapacity() {
		return zzcapacity;
	}
	
	public void setZzcapacity(Integer zzcapacity) {
		this.zzcapacity = zzcapacity;
	}
	
	public String getZzproces1() {
		return zzproces1;
	}
	
	public void setZzproces1(String zzproces1) {
		this.zzproces1 = zzproces1;
	}
	
	public String getZzproces2() {
		return zzproces2;
	}
	
	public void setZzproces2(String zzproces2) {
		this.zzproces2 = zzproces2;
	}

	public double getVolum() {
		return volum;
	}

	public void setVolum(double volum) {
		this.volum = volum;
	}

	public double getNtgew() {
		return ntgew;
	}

	public void setNtgew(double ntgew) {
		this.ntgew = ntgew;
	}

	public double getBrgew() {
		return brgew;
	}

	public void setBrgew(double brgew) {
		this.brgew = brgew;
	}

	public Integer getBlanz() {
		return blanz;
	}

	public void setBlanz(Integer blanz) {
		this.blanz = blanz;
	}

	public double getZzprotein() {
		return zzprotein;
	}

	public void setZzprotein(double zzprotein) {
		this.zzprotein = zzprotein;
	}

	public Integer getZzenerg_fam() {
		return zzenerg_fam;
	}

	public void setZzenerg_fam(Integer zzenerg_fam) {
		this.zzenerg_fam = zzenerg_fam;
	}

	public Integer getZzpyramid() {
		return zzpyramid;
	}

	public void setZzpyramid(Integer zzpyramid) {
		this.zzpyramid = zzpyramid;
	}

	public Integer getFiber_part5() {
		return fiber_part5;
	}

	public void setFiber_part5(Integer fiber_part5) {
		this.fiber_part5 = fiber_part5;
	}

	public Integer getFiber_part1() {
		return fiber_part1;
	}

	public void setFiber_part1(Integer fiber_part1) {
		this.fiber_part1 = fiber_part1;
	}

	public Integer getFiber_part2() {
		return fiber_part2;
	}

	public void setFiber_part2(Integer fiber_part2) {
		this.fiber_part2 = fiber_part2;
	}

	public Integer getFiber_part3() {
		return fiber_part3;
	}

	public void setFiber_part3(Integer fiber_part3) {
		this.fiber_part3 = fiber_part3;
	}

	public Integer getFiber_part4() {
		return fiber_part4;
	}

	public void setFiber_part4(Integer fiber_part4) {
		this.fiber_part4 = fiber_part4;
	}

	public Integer getSize1_atinn() {
		return size1_atinn;
	}

	public void setSize1_atinn(Integer size1_atinn) {
		this.size1_atinn = size1_atinn;
	}

	public Integer getSize2_atinn() {
		return size2_atinn;
	}

	public void setSize2_atinn(Integer size2_atinn) {
		this.size2_atinn = size2_atinn;
	}

	public Integer getColor_atinn() {
		return color_atinn;
	}

	public void setColor_atinn(Integer color_atinn) {
		this.color_atinn = color_atinn;
	}

	public Integer getAdspc_spc() {
		return adspc_spc;
	}

	public void setAdspc_spc(Integer adspc_spc) {
		this.adspc_spc = adspc_spc;
	}

	public double getVsor_pal_min_h() {
		return vsor_pal_min_h;
	}

	public void setVsor_pal_min_h(double vsor_pal_min_h) {
		this.vsor_pal_min_h = vsor_pal_min_h;
	}

	public double getVsor_pal_ovr_d() {
		return vsor_pal_ovr_d;
	}

	public void setVsor_pal_ovr_d(double vsor_pal_ovr_d) {
		this.vsor_pal_ovr_d = vsor_pal_ovr_d;
	}

	public double getVsor_pal_ovr_w() {
		return vsor_pal_ovr_w;
	}

	public void setVsor_pal_ovr_w(double vsor_pal_ovr_w) {
		this.vsor_pal_ovr_w = vsor_pal_ovr_w;
	}

	public Integer getVsor_no_p_gvh() {
		return vsor_no_p_gvh;
	}

	public void setVsor_no_p_gvh(Integer vsor_no_p_gvh) {
		this.vsor_no_p_gvh = vsor_no_p_gvh;
	}

	public double getVsor_tol_b_ht() {
		return vsor_tol_b_ht;
	}

	public void setVsor_tol_b_ht(double vsor_tol_b_ht) {
		this.vsor_tol_b_ht = vsor_tol_b_ht;
	}

	public double getVsor_pal_b_ht() {
		return vsor_pal_b_ht;
	}

	public void setVsor_pal_b_ht(double vsor_pal_b_ht) {
		this.vsor_pal_b_ht = vsor_pal_b_ht;
	}

	public Integer getVsor_stack_no() {
		return vsor_stack_no;
	}

	public void setVsor_stack_no(Integer vsor_stack_no) {
		this.vsor_stack_no = vsor_stack_no;
	}

	public Integer getBev1luleinh() {
		return bev1luleinh;
	}

	public void setBev1luleinh(Integer bev1luleinh) {
		this.bev1luleinh = bev1luleinh;
	}

	public Integer getAnp() {
		return anp;
	}

	public void setAnp(Integer anp) {
		this.anp = anp;
	}

	public double getQqtime() {
		return qqtime;
	}

	public void setQqtime(double qqtime) {
		this.qqtime = qqtime;
	}

	public double getMaxh() {
		return maxh;
	}

	public void setMaxh(double maxh) {
		this.maxh = maxh;
	}

	public double getMaxb() {
		return maxb;
	}

	public void setMaxb(double maxb) {
		this.maxb = maxb;
	}

	public double getMaxl() {
		return maxl;
	}

	public void setMaxl(double maxl) {
		this.maxl = maxl;
	}

	public double getMaxc_tol() {
		return maxc_tol;
	}

	public void setMaxc_tol(double maxc_tol) {
		this.maxc_tol = maxc_tol;
	}

	public double getMaxc() {
		return maxc;
	}

	public void setMaxc(double maxc) {
		this.maxc = maxc;
	}

	public Integer getCuobf() {
		return cuobf;
	}

	public void setCuobf(Integer cuobf) {
		this.cuobf = cuobf;
	}

	public double getInhbr() {
		return inhbr;
	}

	public void setInhbr(double inhbr) {
		this.inhbr = inhbr;
	}

	public double getVpreh() {
		return vpreh;
	}

	public void setVpreh(double vpreh) {
		this.vpreh = vpreh;
	}

	public double getInhal() {
		return inhal;
	}

	public void setInhal(double inhal) {
		this.inhal = inhal;
	}

	public double getMhdlp() {
		return mhdlp;
	}

	public void setMhdlp(double mhdlp) {
		this.mhdlp = mhdlp;
	}

	public double getMhdrz() {
		return mhdrz;
	}

	public void setMhdrz(double mhdrz) {
		this.mhdrz = mhdrz;
	}

	public double getFuelg() {
		return fuelg;
	}

	public void setFuelg(double fuelg) {
		this.fuelg = fuelg;
	}

	public double getVolto() {
		return volto;
	}

	public void setVolto(double volto) {
		this.volto = volto;
	}

	public double getGewto() {
		return gewto;
	}

	public void setGewto(double gewto) {
		this.gewto = gewto;
	}

	public double getErvol() {
		return ervol;
	}

	public void setErvol(double ervol) {
		this.ervol = ervol;
	}

	public double getErgew() {
		return ergew;
	}

	public void setErgew(double ergew) {
		this.ergew = ergew;
	}

	public double getHoehe() {
		return hoehe;
	}

	public void setHoehe(double hoehe) {
		this.hoehe = hoehe;
	}

	public double getBreit() {
		return breit;
	}

	public void setBreit(double breit) {
		this.breit = breit;
	}

	public double getLaeng() {
		return laeng;
	}

	public void setLaeng(double laeng) {
		this.laeng = laeng;
	}

	public double getWesch() {
		return wesch;
	}

	public void setWesch(double wesch) {
		this.wesch = wesch;
	}

	public Integer getCompl() {
		return compl;
	}

	public void setCompl(Integer compl) {
		this.compl = compl;
	}
	
	public String getZzoverlay() {
		return zzoverlay;
	}

	public void setZzoverlay(String zzoverlay) {
		this.zzoverlay = zzoverlay;
	}
	
	public String getZzsignature() {
		return zzsignature;
	}

	public void setZzsignature(String zzsignature) {
		this.zzsignature = zzsignature;
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getSBrandValues(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.zzoverlay) FROM MARA m";
		Query query = em.createQuery(queryString, MARA.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getBrandValues(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.zzsignature) FROM MARA m";
		Query query = em.createQuery(queryString, MARA.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getZzproces1(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.zzproces1) FROM MARA m";
		Query query = em.createQuery(queryString, MARA.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getZzproces2(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(m.zzproces2) FROM MARA m";
		Query query = em.createQuery(queryString, MARA.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	public static MARA getMARAByKey(EntityManager em, MARAPK key) {
		return em.find(MARA.class, key);
	}

	public String getZzflavor() {
		return zzflavor;
	}

	public void setZzflavor(String zzflavor) {
		this.zzflavor = zzflavor;
	}

	public String getZzpot_diam() {
		return zzpot_diam;
	}

	public void setZzpot_diam(String zzpot_diam) {
		this.zzpot_diam = zzpot_diam;
	}

	public String getZzrange() {
		return zzrange;
	}

	public void setZzrange(String zzrange) {
		this.zzrange = zzrange;
	}

	public String getZzsub_range() {
		return zzsub_range;
	}

	public void setZzsub_range(String zzsub_range) {
		this.zzsub_range = zzsub_range;
	}
	
}
