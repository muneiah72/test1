package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PRICAT_K002PK implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6012898181794420397L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 10)
	private String prinbr;
	@Column(length = 18)
	private String productgroup;
	
	public PRICAT_K002PK() {}
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
	
	public String getPrinbr() {
		return prinbr;
	}

	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}
	
	public String getProductgroup() {
		return productgroup;
	}

	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof PRICAT_K002PK) && 
        		system.equals(((PRICAT_K002PK)o).getSystem()) &&
        		mandt.equals(((PRICAT_K002PK)o).getMandt()) &&
        		prinbr.equals(((PRICAT_K002PK)o).getPrinbr()) &&
        		productgroup.equals(((PRICAT_K002PK)o).getProductgroup()));
    }

    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()
        		+ prinbr.hashCode() 
        		+ productgroup.hashCode(); 
    }	
}
