package com.danone.persistence;

import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;

import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PersistenceAdapter {

	private static final Logger logger = LoggerFactory.getLogger(PersistenceAdapter.class);
	private static EntityManagerFactory emf = lookupEntityManagerFactory();

	public static EntityManager getEntityManager() {
		return emf.createEntityManager();
	}
	
	private static EntityManagerFactory lookupEntityManagerFactory() {
		DataSource ds;
		try {
			InitialContext ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");
		} catch (NamingException e) {
			String msg = "Could not retrieve DataSource 'DefaultDB' ";
			logger.error(msg, e);
			throw new IllegalStateException(msg, e);
		}
		Map<String, DataSource> properties = new HashMap<String, DataSource>();
		properties.put(PersistenceUnitProperties.NON_JTA_DATASOURCE, ds);
		return Persistence.createEntityManagerFactory("product_catalog_jpa", properties);
	}
	
	public static void clearCache() {
		emf.getCache().evictAll();
	}
}
