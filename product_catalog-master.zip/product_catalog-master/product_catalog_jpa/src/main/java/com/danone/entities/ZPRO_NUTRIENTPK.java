package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPRO_NUTRIENTPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1566372484954284412L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 12)
	private String subid;
	@Column(length = 10)
	private String object;
	@Column(length = 2)
	private String laiso;
	
	public ZPRO_NUTRIENTPK() {}

	public ZPRO_NUTRIENTPK(String system, Integer mandt, String subid, String object, String laiso) {
		this.system = system;
		this.mandt = mandt;
		this.subid = subid;
		this.object = object;
		this.laiso = laiso;
	}
	
	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getSubid() {
		return subid;
	}

	public void setSubid(String subid) {
		this.subid = subid;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getLaiso() {
		return laiso;
	}

	public void setLaiso(String laiso) {
		this.laiso = laiso;
	}

	public boolean equals(Object o) { 
        return ((o instanceof ZPRO_NUTRIENTPK) && 
        		system.equals(((ZPRO_NUTRIENTPK)o).getSystem()) &&
        		mandt.equals(((ZPRO_NUTRIENTPK)o).getMandt()) &&
        		subid.equals(((ZPRO_NUTRIENTPK)o).getSubid()) &&
        		object.equals(((ZPRO_NUTRIENTPK)o).getObject()) &&
        		laiso.equals(((ZPRO_NUTRIENTPK)o).getLaiso()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ subid.hashCode()
        		+ object.hashCode()
        		+ laiso.hashCode(); 
    }
}
