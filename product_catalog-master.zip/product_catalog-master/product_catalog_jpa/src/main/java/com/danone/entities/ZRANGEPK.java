package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZRANGEPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5394062841906829470L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zzrange;
	
	public ZRANGEPK() {}

	public ZRANGEPK(String system, Integer mandt, String zzrange) {
		this.system = system;
		this.setMandt(mandt);
		this.setZzrange(zzrange);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZzrange() {
		return zzrange;
	}

	public void setZzrange(String zzrange) {
		this.zzrange = zzrange;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZRANGEPK) && 
        		system.equals(((ZRANGEPK)o).getSystem()) &&
        		mandt.equals(((ZRANGEPK)o).getMandt()) &&        	
        		zzrange.equals(((ZRANGEPK)o).getZzrange()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zzrange.hashCode(); 
    }

}
