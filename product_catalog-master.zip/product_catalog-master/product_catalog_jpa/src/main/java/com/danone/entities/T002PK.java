package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class T002PK implements java.io.Serializable  {

	
	private static final long serialVersionUID = -7662892087803955699L;
	
	@Column (length = 1)
	private String spras;
		
	
	public T002PK() {}	
	
	public boolean equals(Object o) { 
        return ((o instanceof T002PK) && 
        		spras.equals(((T002PK)o).getSpras()) );
    }
	
    public int hashCode() { 
        return spras.hashCode(); 
    }
	
	public String getSpras() {
		return spras;
	}

	public void setSpras(String spras) {
		this.spras = spras;
	}

}
