package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="PRICAT_K005")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K005 {

	private static final Logger LOGGER = LoggerFactory.getLogger(PRICAT_K005.class);
	
	@EmbeddedId
	private PRICAT_K005PK key;
	private String transport;
	private String text_line;
	private String ean_upc_base;
	
	public PRICAT_K005PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K005PK key) {
		this.key = key;
	}
	
	public String getTransport() {
		return transport;
	}
	
	public void setTransport(String transport) {
		this.transport = transport;
	}

	public String getText_line() {
		return text_line;
	}

	public void setText_line(String text_line) {
		this.text_line = text_line;
	}

	public String getEan_upc_base() {
		return ean_upc_base;
	}

	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K005> getK005With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup,
						String ean_upc_altunit, java.sql.Date validity_unit, String langu_iso, String[] texttypes) {
		
		String queryString = "SELECT p FROM PRICAT_K005 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_altunit = :ean_upc_altunit and p.key.validity_unit = :validity_unit and p.key.langu_iso = :langu_iso";
		
		if (texttypes.length > 0)
		{
			queryString = queryString + " and ( ";
			
			for( int i = 0; i < texttypes.length; i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
			    
				String paramname = "texttyp" + i;
			    queryString = queryString + "p.key.texttyp = :" + paramname + " ";
			}
			
			queryString = queryString + " )";
		}
		
		LOGGER.debug(queryString);
		
		Query query = em.createQuery(queryString, PRICAT_K005.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_altunit", ean_upc_altunit).setParameter("validity_unit", validity_unit).setParameter("langu_iso", langu_iso);
		
		for( int i = 0; i < texttypes.length; i++)
		{
		     String texttyp = texttypes[i];
		     query.setParameter("texttyp" + i, texttyp);
		}
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	public static PRICAT_K005 getPRICAT_K005ByKey(EntityManager em, PRICAT_K005PK key) {
		return em.find(PRICAT_K005.class, key);
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K005> getK005With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup,
						String ean_upc_altunit, java.sql.Date validity_unit) {
		
		String queryString = "SELECT p FROM PRICAT_K005 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_altunit = :ean_upc_altunit and p.key.validity_unit = :validity_unit";
		
		Query query = em.createQuery(queryString, PRICAT_K005.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_altunit", ean_upc_altunit).setParameter("validity_unit", validity_unit);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
}
