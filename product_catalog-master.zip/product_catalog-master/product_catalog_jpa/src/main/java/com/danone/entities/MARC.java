package com.danone.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="MARC")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class MARC {
	
	@EmbeddedId
	private MARCPK key;
	private String herkl;
	private String stawn;
	private double tranz;
	private double ruezt;
	private double bearz;
	private double losfx;
	private double mabst;
	private Integer shzet;
	private double resvp;
	private double abfac;
	private double vktrw;
	private double vkumc;
	private double bstrf;
	private double bstfe;
	private double bstma;
	private double uneto;
	private double ueeto;
	private double maxlz;
	private double dzeit;
	private double wzeit;
	private double prfrq;
	private double umlmc;
	private double lgrad;
	private Integer objid;
	private double vrvez;
	private double takzt;
	private Integer cuobj;
	private double target_stock;
	private Integer max_troc;
	private Integer min_troc;
	private double gi_pr_time;
	private double dplho;
	private double vkglg;
	private double glgmg;
	private Integer cuobv;
	private double vrbfk;
	private Integer vint1;
	private Integer vint2;
	private Integer fxhor;
	private double trame;
	private double vbeaz;
	private double wstgh;
	private double mpdau;
	private double quazt;
	private double sproz;
	private double basmg;
	private double bstmi;
	private double eisbe;
	private double ausss;
	private double webaz;
	private double plifz;
	private double sapmptolprpl;
	private double bwesb;
	private double eislo;
	private Integer lfgja;
	private Integer lfmon;
	private Integer zzest_release;
	private double vbamg;
	private double losgr;
	private double kausf;
	private double minls;
	private double maxls;
	private double fixls;
	private double ltinc;
	private Integer compl;
	private Integer zzsledrule;
	private Integer zzhard_duration;
	private Integer zztotal_duration;
	private double sapmptolprmi;
	private double vzusl;
	private double minbe;
	private Integer zzferm;
	
	public MARCPK getKey() {
		return key;
	}
	
	public void setKey(MARCPK key){
		this.key = key;
	}
	
	public String getHerkl() {
		return herkl;
	}
	
	public void setHerkl(String herkl) {
		this.herkl = herkl;
	}
	
	public String getStawn() {
		return stawn;
	}
	
	public void setStawn(String stawn) {
		this.stawn = stawn;
	}

	public double getTranz() {
		return tranz;
	}
	
	public void setTranz(double tranz) {
		this.tranz = tranz;
	}
	
	public double getRuezt() {
		return ruezt;
	}

	public void setRuezt(double ruezt) {
		this.ruezt = ruezt;
	}

	public double getBearz() {
		return bearz;
	}

	public void setBearz(double bearz) {
		this.bearz = bearz;
	}

	public double getLosfx() {
		return losfx;
	}

	public void setLosfx(double losfx) {
		this.losfx = losfx;
	}

	public double getMabst() {
		return mabst;
	}

	public void setMabst(double mabst) {
		this.mabst = mabst;
	}

	public Integer getShzet() {
		return shzet;
	}

	public void setShzet(Integer shzet) {
		this.shzet = shzet;
	}

	public double getResvp() {
		return resvp;
	}

	public void setResvp(double resvp) {
		this.resvp = resvp;
	}

	public double getAbfac() {
		return abfac;
	}

	public void setAbfac(double abfac) {
		this.abfac = abfac;
	}

	public double getVktrw() {
		return vktrw;
	}

	public void setVktrw(double vktrw) {
		this.vktrw = vktrw;
	}

	public double getVkumc() {
		return vkumc;
	}

	public void setVkumc(double vkumc) {
		this.vkumc = vkumc;
	}

	public double getBstrf() {
		return bstrf;
	}

	public void setBstrf(double bstrf) {
		this.bstrf = bstrf;
	}

	public double getBstfe() {
		return bstfe;
	}

	public void setBstfe(double bstfe) {
		this.bstfe = bstfe;
	}

	public double getBstma() {
		return bstma;
	}

	public void setBstma(double bstma) {
		this.bstma = bstma;
	}

	public double getUneto() {
		return uneto;
	}

	public void setUneto(double uneto) {
		this.uneto = uneto;
	}

	public double getUeeto() {
		return ueeto;
	}

	public void setUeeto(double ueeto) {
		this.ueeto = ueeto;
	}

	public double getMaxlz() {
		return maxlz;
	}

	public void setMaxlz(double maxlz) {
		this.maxlz = maxlz;
	}

	public double getDzeit() {
		return dzeit;
	}

	public void setDzeit(double dzeit) {
		this.dzeit = dzeit;
	}

	public double getWzeit() {
		return wzeit;
	}

	public void setWzeit(double wzeit) {
		this.wzeit = wzeit;
	}

	public double getPrfrq() {
		return prfrq;
	}

	public void setPrfrq(double prfrq) {
		this.prfrq = prfrq;
	}

	public double getUmlmc() {
		return umlmc;
	}

	public void setUmlmc(double umlmc) {
		this.umlmc = umlmc;
	}

	public double getLgrad() {
		return lgrad;
	}

	public void setLgrad(double lgrad) {
		this.lgrad = lgrad;
	}

	public double getVrvez() {
		return vrvez;
	}

	public void setVrvez(double vrvez) {
		this.vrvez = vrvez;
	}

	public Integer getObjid() {
		return objid;
	}

	public void setObjid(Integer objid) {
		this.objid = objid;
	}

	public double getTakzt() {
		return takzt;
	}

	public void setTakzt(double takzt) {
		this.takzt = takzt;
	}

	public Integer getCuobj() {
		return cuobj;
	}

	public void setCuobj(Integer cuobj) {
		this.cuobj = cuobj;
	}

	public double getTarget_stock() {
		return target_stock;
	}

	public void setTarget_stock(double target_stock) {
		this.target_stock = target_stock;
	}

	public Integer getMax_troc() {
		return max_troc;
	}

	public void setMax_troc(Integer max_troc) {
		this.max_troc = max_troc;
	}

	public Integer getMin_troc() {
		return min_troc;
	}

	public void setMin_troc(Integer min_troc) {
		this.min_troc = min_troc;
	}

	public double getGi_pr_time() {
		return gi_pr_time;
	}

	public void setGi_pr_time(double gi_pr_time) {
		this.gi_pr_time = gi_pr_time;
	}

	public double getDplho() {
		return dplho;
	}

	public void setDplho(double dplho) {
		this.dplho = dplho;
	}

	public double getVkglg() {
		return vkglg;
	}

	public void setVkglg(double vkglg) {
		this.vkglg = vkglg;
	}

	public double getGlgmg() {
		return glgmg;
	}

	public void setGlgmg(double glgmg) {
		this.glgmg = glgmg;
	}

	public Integer getCuobv() {
		return cuobv;
	}

	public void setCuobv(Integer cuobv) {
		this.cuobv = cuobv;
	}

	public double getVrbfk() {
		return vrbfk;
	}

	public void setVrbfk(double vrbfk) {
		this.vrbfk = vrbfk;
	}

	public Integer getVint1() {
		return vint1;
	}

	public void setVint1(Integer vint1) {
		this.vint1 = vint1;
	}

	public Integer getVint2() {
		return vint2;
	}

	public void setVint2(Integer vint2) {
		this.vint2 = vint2;
	}

	public Integer getFxhor() {
		return fxhor;
	}

	public void setFxhor(Integer fxhor) {
		this.fxhor = fxhor;
	}

	public double getTrame() {
		return trame;
	}

	public void setTrame(double trame) {
		this.trame = trame;
	}

	public double getVbeaz() {
		return vbeaz;
	}

	public void setVbeaz(double vbeaz) {
		this.vbeaz = vbeaz;
	}

	public double getWstgh() {
		return wstgh;
	}

	public void setWstgh(double wstgh) {
		this.wstgh = wstgh;
	}

	public double getMpdau() {
		return mpdau;
	}

	public void setMpdau(double mpdau) {
		this.mpdau = mpdau;
	}

	public double getQuazt() {
		return quazt;
	}

	public void setQuazt(double quazt) {
		this.quazt = quazt;
	}

	public double getSproz() {
		return sproz;
	}

	public void setSproz(double sproz) {
		this.sproz = sproz;
	}

	public double getBasmg() {
		return basmg;
	}

	public void setBasmg(double basmg) {
		this.basmg = basmg;
	}

	public double getBstmi() {
		return bstmi;
	}

	public void setBstmi(double bstmi) {
		this.bstmi = bstmi;
	}

	public double getEisbe() {
		return eisbe;
	}

	public void setEisbe(double eisbe) {
		this.eisbe = eisbe;
	}

	public double getAusss() {
		return ausss;
	}

	public void setAusss(double ausss) {
		this.ausss = ausss;
	}

	public double getWebaz() {
		return webaz;
	}

	public void setWebaz(double webaz) {
		this.webaz = webaz;
	}

	public double getPlifz() {
		return plifz;
	}

	public void setPlifz(double plifz) {
		this.plifz = plifz;
	}

	public double getSapmptolprpl() {
		return sapmptolprpl;
	}

	public void setSapmptolprpl(double sapmptolprpl) {
		this.sapmptolprpl = sapmptolprpl;
	}

	public double getBwesb() {
		return bwesb;
	}

	public void setBwesb(double bwesb) {
		this.bwesb = bwesb;
	}

	public double getEislo() {
		return eislo;
	}

	public void setEislo(double eislo) {
		this.eislo = eislo;
	}

	public Integer getLfgja() {
		return lfgja;
	}

	public void setLfgja(Integer lfgja) {
		this.lfgja = lfgja;
	}

	public Integer getLfmon() {
		return lfmon;
	}

	public void setLfmon(Integer lfmon) {
		this.lfmon = lfmon;
	}

	public Integer getZzest_release() {
		return zzest_release;
	}

	public void setZzest_release(Integer zzest_release) {
		this.zzest_release = zzest_release;
	}

	public double getVbamg() {
		return vbamg;
	}

	public void setVbamg(double vbamg) {
		this.vbamg = vbamg;
	}

	public double getLosgr() {
		return losgr;
	}

	public void setLosgr(double losgr) {
		this.losgr = losgr;
	}

	public double getKausf() {
		return kausf;
	}

	public void setKausf(double kausf) {
		this.kausf = kausf;
	}

	public double getMinls() {
		return minls;
	}

	public void setMinls(double minls) {
		this.minls = minls;
	}

	public double getMaxls() {
		return maxls;
	}

	public void setMaxls(double maxls) {
		this.maxls = maxls;
	}

	public double getFixls() {
		return fixls;
	}

	public void setFixls(double fixls) {
		this.fixls = fixls;
	}

	public double getLtinc() {
		return ltinc;
	}

	public void setLtinc(double ltinc) {
		this.ltinc = ltinc;
	}

	public Integer getCompl() {
		return compl;
	}

	public void setCompl(Integer compl) {
		this.compl = compl;
	}

	public Integer getZzsledrule() {
		return zzsledrule;
	}

	public void setZzsledrule(Integer zzsledrule) {
		this.zzsledrule = zzsledrule;
	}

	public Integer getZzhard_duration() {
		return zzhard_duration;
	}

	public void setZzhard_duration(Integer zzhard_duration) {
		this.zzhard_duration = zzhard_duration;
	}

	public Integer getZztotal_duration() {
		return zztotal_duration;
	}

	public void setZztotal_duration(Integer zztotal_duration) {
		this.zztotal_duration = zztotal_duration;
	}

	public double getSapmptolprmi() {
		return sapmptolprmi;
	}

	public void setSapmptolprmi(double sapmptolprmi) {
		this.sapmptolprmi = sapmptolprmi;
	}

	public double getVzusl() {
		return vzusl;
	}

	public void setVzusl(double vzusl) {
		this.vzusl = vzusl;
	}

	public double getMinbe() {
		return minbe;
	}

	public void setMinbe(double minbe) {
		this.minbe = minbe;
	}

	public static MARC getMARCByKey(EntityManager em, MARCPK marcpk) {
		return em.find(MARC.class, marcpk);
	}

	public Integer getZzferm() {
		return zzferm;
	}

	public void setZzferm(Integer zzferm) {
		this.zzferm = zzferm;
	}
}
