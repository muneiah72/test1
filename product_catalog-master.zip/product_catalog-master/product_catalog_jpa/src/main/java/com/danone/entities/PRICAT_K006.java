package com.danone.entities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K006")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K006 {
	//private static Logger LOGGER = LoggerFactory.getLogger(PRICAT_K006.class);

	@EmbeddedId
	private PRICAT_K006PK key;
	private String transport;
	private String value;
	private String value_extern;
	private String internal_char;
	private String merkmalstyp;
	
	public PRICAT_K006PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K006PK key) {
		this.key = key;
	}
	
	public String getTransport() {
		return transport;
	}
	
	public void setTransport(String transport) {
		this.transport = transport;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	public String getValue_extern() {
		return value_extern;
	}

	public void setValue_extern(String value_extern) {
		this.value_extern = value_extern;
	}

	public String getInternal_char() {
		return internal_char;
	}

	public void setInternal_char(String internal_char) {
		this.internal_char = internal_char;
	}

	public String getMerkmalstyp() {
		return merkmalstyp;
	}

	public void setMerkmalstyp(String merkmalstyp) {
		this.merkmalstyp = merkmalstyp;
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K006> getK006With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup, String ean_upc_base, java.sql.Date validity_base, ArrayList<String> characteristics) {
		
		String queryString = "SELECT p FROM PRICAT_K006 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_base = :ean_upc_base and p.key.validity_base = :validity_base";
		
		//LOGGER.debug(system);
		//LOGGER.debug(queryString);
		
		if (characteristics.size() > 0)
		{
			queryString = queryString + " and ( ";
			
			for( int i = 0; i < characteristics.size(); i++)
			{
				if (i > 0)
				{
					queryString = queryString + "OR ";
				}
			    
				String paramname = "characteristic" + i;
			    queryString = queryString + "p.key.characteristic = :" + paramname + " ";
			}
			
			queryString = queryString + " )";
		}
		
		Query query = em.createQuery(queryString, PRICAT_K006.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_base", ean_upc_base).setParameter("validity_base", validity_base);
		
		int count = 0;
		for (String str : characteristics)
		{
			query.setParameter("characteristic" + count, str);
			count++;
		}
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getConsumationFrom(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(p.key.description) FROM PRICAT_K006 p where p.key.characteristic = :characteristic";
		Query query = em.createQuery(queryString, PRICAT_K006.class).setParameter("characteristic", "FR8_CONSUMPTION_AGE");
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getAllergens(EntityManager em) {
		
		String queryString = "SELECT DISTINCT(p.key.description) FROM PRICAT_K006 p where p.key.characteristic = :characteristic1 or p.key.characteristic = :characteristic2";
		Query query = em.createQuery(queryString, PRICAT_K006.class).setParameter("characteristic1", "ALLERGENS_NOT_PRESENT").setParameter("characteristic2", "ALLERGENS_PRESENT");
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	public static PRICAT_K006 getPRICAT_K006ByKey(EntityManager em, PRICAT_K006PK key) {
		return em.find(PRICAT_K006.class, key);
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K006> getK006With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup,
						String ean_upc_base, java.sql.Date validity_base) {
		
		String queryString = "SELECT p FROM PRICAT_K006 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_base = :ean_upc_base and p.key.validity_base = :validity_base";
		
		Query query = em.createQuery(queryString, PRICAT_K006.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_base", ean_upc_base).setParameter("validity_base", validity_base);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
}
