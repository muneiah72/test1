package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPRO_ASSORTMENTPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2209838390379189485L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 4)
	private String vkorg;
	@Column(length = 2)
	private String vtweg;
	
	public ZPRO_ASSORTMENTPK() {}

	public ZPRO_ASSORTMENTPK(String system, Integer mandt, String vkorg, String vtweg) {
		this.system = system;
		this.mandt = mandt;
		this.vkorg = vkorg;
		this.vtweg = vtweg;
	}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}	
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPRO_ASSORTMENTPK) && 
        		system.equals(((ZPRO_ASSORTMENTPK)o).getSystem()) &&
        		mandt.equals(((ZPRO_ASSORTMENTPK)o).getMandt()) &&
        		vkorg.equals(((ZPRO_ASSORTMENTPK)o).getVkorg()) &&
        		vtweg.equals(((ZPRO_ASSORTMENTPK)o).getVtweg()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ vkorg.hashCode()
        		+ vtweg.hashCode(); 
    }
}
