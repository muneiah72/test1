package com.danone.entities;

import javax.persistence.Embeddable;

@Embeddable
public class CMSCAROUSELPK implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1354144269828772087L;
	
	private Integer id;
	
	public CMSCAROUSELPK(){}
	
	public CMSCAROUSELPK(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof CMSCAROUSELPK) && 
        		id.equals(((CMSCAROUSELPK) o).getId()) );
    }
	
    public int hashCode() { 
        return id.hashCode();         		
    }

}
