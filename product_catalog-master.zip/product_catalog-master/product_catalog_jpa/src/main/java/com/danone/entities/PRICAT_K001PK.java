package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PRICAT_K001PK implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3807941516120301599L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 10)
	private String prinbr;
	
	public PRICAT_K001PK() {}
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getPrinbr() {
		return prinbr;
	}

	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof PRICAT_K001PK) && 
        		system.equals(((PRICAT_K001PK)o).getSystem()) &&
        		mandt.equals(((PRICAT_K001PK)o).getMandt()) &&
        		prinbr.equals(((PRICAT_K001PK)o).getPrinbr()) );
    }

    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()
        		+ prinbr.hashCode(); 
    }
}
