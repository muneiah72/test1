package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZSUBRANGEPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5394062841906829470L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zzsub_range;
	
	public ZSUBRANGEPK() {}

	public ZSUBRANGEPK(String system, Integer mandt, String zzsub_range) {
		this.system = system;
		this.setMandt(mandt);
		this.setZzsub_range(zzsub_range);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZzsub_range() {
		return zzsub_range;
	}

	public void setZzsub_range(String zzsub_range) {
		this.zzsub_range = zzsub_range;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZSUBRANGEPK) && 
        		system.equals(((ZSUBRANGEPK)o).getSystem()) &&
        		mandt.equals(((ZSUBRANGEPK)o).getMandt()) &&        	
        		zzsub_range.equals(((ZSUBRANGEPK)o).getZzsub_range()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zzsub_range.hashCode(); 
    }

}
