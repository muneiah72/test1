package com.danone.entities;

import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPROEU_PLANT")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPROEU_PLANT {
	
	@EmbeddedId
	private ZPROEU_PLANTPK key;
	private java.sql.Date erdat;
	
	public ZPROEU_PLANTPK getKey() {
		return key;
	}
	
	public void setKey(ZPROEU_PLANTPK key) {
		this.key = key;
	}
	
	public java.sql.Date getErdat() {
		return erdat;
	}
	
	public void setErdat(java.sql.Date erdat) {
		this.erdat = erdat;
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPROEU_PLANT> getZPROEU_PLANTByMandtAndGuid(EntityManager em, String system, Integer mandt, String matnr) {
		String queryString = "SELECT z FROM ZPROEU_PLANT z where z.key.system = :system and z.key.mandt = :mandt and z.key.matnr = :matnr";
		Query query = em.createQuery(queryString, ZPROEU_PLANT.class);
		query.setParameter("mandt", mandt);
		query.setParameter("matnr", matnr);
		query.setParameter("system", system);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return null;
		}
	}
}
