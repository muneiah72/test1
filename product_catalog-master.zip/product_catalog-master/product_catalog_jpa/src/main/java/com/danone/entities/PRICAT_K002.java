package com.danone.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;


@Entity
@Table(name="PRICAT_K002")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K002 {
	
	@EmbeddedId
	private PRICAT_K002PK key;
	private String prodgroup_text;
	
	public PRICAT_K002PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K002PK key) {
		this.key = key;
	}
	
	public String getProdgroup_text() {
		return prodgroup_text;
	}
	
	public void setProdgroup_text(String prodgroup_text) {
		this.prodgroup_text = prodgroup_text;
	}	
	
	public static PRICAT_K002 getPRICAT_K002ByKey(EntityManager em, PRICAT_K002PK key) {
		return em.find(PRICAT_K002.class, key);
	}
}
