package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPRODCAT_HDRPK implements java.io.Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7393315780313892906L;

	@Column (length = 50)
	private String system;
	private Integer mandt;
	private String cat_guid;
	
	public ZPRODCAT_HDRPK() {}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
	
	public String getSystem() {
		return system;
	}
	
	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getCat_guid() {
		return cat_guid;
	}
	
	public void setCat_guid(String cat_guid) {
		this.cat_guid = cat_guid;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPRODCAT_HDRPK) && 
        		system.equals(((ZPRODCAT_HDRPK)o).getSystem()) &&
        		mandt.equals(((ZPRODCAT_HDRPK)o).getMandt()) &&
        		cat_guid.equals(((ZPRODCAT_HDRPK)o).getCat_guid()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ cat_guid.hashCode(); 
    }
}
