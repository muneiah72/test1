package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPRO_NUTBOARDPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8338244764743534927L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 18)
	private String matnr;
	private java.sql.Date datap;
	@Column(length = 20)
	private String porid;
	@Column(length = 12)
	private String nutid;
	
	public ZPRO_NUTBOARDPK() {}

	public ZPRO_NUTBOARDPK(String system, Integer mandt, String matnr, java.sql.Date datap, String porid, String nutid) {
		this.system = system;
		this.mandt = mandt;
		this.matnr = matnr;
		this.datap = datap;
		this.porid = porid;
		this.nutid = nutid;
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	
	public java.sql.Date getDatap() {
		return datap;
	}

	public void setDatap(java.sql.Date datap) {
		this.datap = datap;
	}

	public String getPorid() {
		return porid;
	}

	public void setPorid(String porid) {
		this.porid = porid;
	}

	public String getNutid() {
		return nutid;
	}

	public void setNutid(String nutid) {
		this.nutid = nutid;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPRO_NUTBOARDPK) && 
        		system.equals(((ZPRO_NUTBOARDPK)o).getSystem()) &&
        		mandt.equals(((ZPRO_NUTBOARDPK)o).getMandt()) &&
        		matnr.equals(((ZPRO_NUTBOARDPK)o).getMatnr()) &&
        		datap.equals(((ZPRO_NUTBOARDPK)o).getDatap()) &&
        		porid.equals(((ZPRO_NUTBOARDPK)o).getPorid()) &&
        		nutid.equals(((ZPRO_NUTBOARDPK)o).getNutid()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ matnr.hashCode()
        		+ datap.hashCode()
        		+ porid.hashCode()
        		+ nutid.hashCode();
    }
}
