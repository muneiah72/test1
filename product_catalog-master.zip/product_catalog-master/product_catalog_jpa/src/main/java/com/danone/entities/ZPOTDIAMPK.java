package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPOTDIAMPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5394062841906829470L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zzpot_diam;
	
	public ZPOTDIAMPK() {}

	public ZPOTDIAMPK(String system, Integer mandt, String zzpot_diam) {
		this.system = system;
		this.setMandt(mandt);
		this.setZzpot_diam(zzpot_diam);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZzpot_diam() {
		return zzpot_diam;
	}

	public void setZzpot_diam(String zzpot_diam) {
		this.zzpot_diam = zzpot_diam;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPOTDIAMPK) && 
        		system.equals(((ZPOTDIAMPK)o).getSystem()) &&
        		mandt.equals(((ZPOTDIAMPK)o).getMandt()) &&        	
        		zzpot_diam.equals(((ZPOTDIAMPK)o).getZzpot_diam()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zzpot_diam.hashCode(); 
    }

}
