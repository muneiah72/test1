package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPROCHARVALTXT")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPROCHARVALTXT {

	@EmbeddedId
	private ZPROCHARVALTXTPK key;
	@Column(length = 30)
	private String atwtb;
	@Column(length = 10)	
	private String atinn;
	
	public ZPROCHARVALTXTPK getKey() {
		return key;
	}
	
	public void setKey(ZPROCHARVALTXTPK key) {
		this.key = key;
	}

	public String getAtwtb() {
		return atwtb;
	}

	public void setAtwtb(String atwtb) {
		this.atwtb = atwtb;
	}

	public String getAtinn() {
		return atinn;
	}

	public void setAtinn(String atinn) {
		this.atinn = atinn;
	}
	
	public static ZPROCHARVALTXT getZPROCHARVALTXTByKey(EntityManager em, String system, Integer mandt, String atnam, String atwrt, String spras)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZPROCHARVALTXT p where p.key.system = :system and p.key.mandt = :mandt and p.key.atnam = :atnam and p.key.atwrt = :atwrt and p.key.spras = :spras",
						ZPROCHARVALTXT.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("atnam", atnam);	
		query.setParameter("atwrt", atwrt);
		query.setParameter("spras", spras);

		try {
			@SuppressWarnings("unchecked")
			List<ZPROCHARVALTXT> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZPROCHARVALTXT)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}

}
