package com.danone.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K010_ZPRO_VPRICAT_S")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K010_ZPRO_VPRICAT_S {
	
	@EmbeddedId
	private PRICAT_K010_ZPRO_VPRICAT_SPK key;
	private String vmsta;
	private java.sql.Date zzlaunchdate;
	private String stawn;
	private String zzpaccod;
	
	public PRICAT_K010_ZPRO_VPRICAT_SPK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K010_ZPRO_VPRICAT_SPK key) {
		this.key = key;
	}

	public String getVmsta() {
		return vmsta;
	}

	public void setVmsta(String vmsta) {
		this.vmsta = vmsta;
	}

	public java.sql.Date getZzlaunchdate() {
		return zzlaunchdate;
	}

	public void setZzlaunchdate(java.sql.Date zzlaunchdate) {
		this.zzlaunchdate = zzlaunchdate;
	}

	public String getStawn() {
		return stawn;
	}

	public void setStawn(String stawn) {
		this.stawn = stawn;
	}

	public String getZzpaccod() {
		return zzpaccod;
	}

	public void setZzpaccod(String zzpaccod) {
		this.zzpaccod = zzpaccod;
	}
	
	public static PRICAT_K010_ZPRO_VPRICAT_S getPRICAT_K010_ZPRO_VPRICAT_SByKey(EntityManager em, PRICAT_K010_ZPRO_VPRICAT_SPK key) {
		return em.find(PRICAT_K010_ZPRO_VPRICAT_S.class, key);
	}
}
