package com.danone.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K00A")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K00A {
	
	@EmbeddedId
	private PRICAT_K00APK key;
	
	public PRICAT_K00APK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K00APK key) {
		this.key = key;
	}
	
	public static PRICAT_K00A getPRICAT_K00AByKey(EntityManager em, PRICAT_K00APK key) {
		return em.find(PRICAT_K00A.class, key);
	}
}
