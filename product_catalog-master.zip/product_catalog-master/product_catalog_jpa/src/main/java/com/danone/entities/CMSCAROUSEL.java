package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Lob;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Entity
@Table(name="CMSCAROUSEL")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class CMSCAROUSEL {
	private final static Logger logger = LoggerFactory.getLogger(CMSCAROUSEL.class);
	
	@EmbeddedId
	private CMSCAROUSELPK key;

	private String language;
	private Integer validFrom;
	private Integer validTo;
	
	@Basic
	@Lob @Column(name="Picture")
	private byte[] picture;
	
	@Basic
	@Lob
	@Column(name = "PictureName")
	private String pictureName;
	
	@Basic
	@Lob
	@Column(name = "Document")
	private byte[] document;

	@Basic
	@Lob
	@Column(name = "DocumentName")
	private String documentName;
	
	@Basic
	private long uploadTime;
	private String title;
	

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Integer getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(Integer validFrom) {
		this.validFrom = validFrom;
	}

	public Integer getValidTo() {
		return validTo;
	}

	public void setValidTo(Integer validTo) {
		this.validTo = validTo;
	}	
	
	public long getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(long uploadTime) {
		this.uploadTime = uploadTime;
	}

	public void setKey(CMSCAROUSELPK key){
		this.key = key;		
	}
	
	public CMSCAROUSELPK getKey(){
		return key;
	}

	public void setPicture(byte[] param) {
		this.picture = param;
	}

	public byte[] getPicture() {
		return picture;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDocument(byte[] param) {
		this.document = param;
	}

	public byte[] getDocument() {
		return document;
	}

	public void setDocumentName(String param) {
		this.documentName = param;
	}

	public String getDocumentName() {
		return documentName;
	}

	public String getPictureName() {
		return pictureName;
	}

	public void setPictureName(String pictureName) {
		this.pictureName = pictureName;
	}
	
	@SuppressWarnings("unchecked")
	public static List<CMSCAROUSEL> getAllCarousels(EntityManager em) {
		Query query = em.createQuery("SELECT p FROM CMSCAROUSEL AS p");
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}

	public static CMSCAROUSEL getCarouselByKey(EntityManager em,
			CMSCAROUSELPK key) {
		return em.find(CMSCAROUSEL.class, key);
	}
	
	public static Integer getMaxCarouselId(EntityManager em) {
		logger.debug("getMaxCarousel");
		Query query = em.createQuery("SELECT MAX(c.key.id) FROM CMSCAROUSEL AS c");
		try {
			Integer maxId = (Integer) query.getSingleResult();
			return maxId;		
		} catch (NoResultException e) {
			return -1;
		}
	}	
	
	@SuppressWarnings("unchecked")
	public static List<Object[]> getActives(EntityManager em, String language, Integer curdate) {

		String queryString = "SELECT z.key.id, z.title  FROM CMSCAROUSEL z WHERE z.language = :language AND z.validFrom <= :curdate AND z.validTo >= :curdate ORDER BY z.validFrom DESC";
		Query query = em.createQuery(queryString, CMSCAROUSEL.class);
		query.setParameter("language", language);
		query.setParameter("curdate", curdate);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
		
}
