package com.danone.entities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="AUTHORIZATION")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)

public class AUTHORIZATION {
	
	@Id
	private String role;
	private Boolean draft;
	private Boolean validated;
	private Boolean published_distributeur;
	private Boolean published_consommateur;
	private Boolean archived;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}	
	public Boolean getDraft() {
		return draft;
	}

	public void setDraft(Boolean draft) {
		this.draft = draft;
	}

	public Boolean getValidated() {
		return validated;
	}

	public void setValidated(Boolean validated) {
		this.validated = validated;
	}

	public Boolean getPublished_distributeur() {
		return published_distributeur;
	}

	public void setPublished_distributeur(Boolean published_distributeur) {
		this.published_distributeur = published_distributeur;
	}

	public Boolean getPublished_consommateur() {
		return published_consommateur;
	}

	public void setPublished_consommateur(Boolean published_consommateur) {
		this.published_consommateur = published_consommateur;
	}

	public Boolean getArchived() {
		return archived;
	}

	public void setArchived(Boolean archived) {
		this.archived = archived;
	}
	
	public static AUTHORIZATION getAuthorizationByRole(EntityManager em, String role) {
		return em.find(AUTHORIZATION.class, role);
	}
	
	@SuppressWarnings("unchecked")
	public static List<AUTHORIZATION> getAllAuthorizations(EntityManager em) {
		String queryString = "SELECT a FROM AUTHORIZATION a";
		Query query = em.createQuery(queryString, AUTHORIZATION.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<AUTHORIZATION> getAllAdminRoles(EntityManager em) {
		String queryString = "SELECT a FROM AUTHORIZATION a WHERE a.role LIKE '%ADMIN%'";
		Query query = em.createQuery(queryString, AUTHORIZATION.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}	
	public static List<String> getAuthorizationRequiredByRoleInNumberStringFormat(EntityManager em, String role) {
		AUTHORIZATION auth = getAuthorizationByRole(em, role);
		List<String> list = new ArrayList<String>();
		
		if (auth != null)
		{
			if (auth.getDraft())
			{
				list.add("1");
			}
			if (auth.getValidated())
			{
				list.add("3");
			}
			if (auth.getPublished_distributeur())
			{
				list.add("4");
			}
			if (auth.getPublished_consommateur())
			{
				list.add("5");
			}
			if (auth.getArchived())
			{
				list.add("8");
			}
		}
		
		return list;
	}

}
