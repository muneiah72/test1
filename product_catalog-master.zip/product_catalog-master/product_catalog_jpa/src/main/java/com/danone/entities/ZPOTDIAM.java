package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPOTDIAM")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPOTDIAM {

	@EmbeddedId
	private ZPOTDIAMPK key;
	@Column(length = 30)
	private String zzpot_diam_desc;
	
	public ZPOTDIAMPK getKey() {
		return key;
	}
	
	public void setKey(ZPOTDIAMPK key) {
		this.key = key;
	}

	public String getZzpot_diam_desc() {
		return zzpot_diam_desc;
	}

	public void setZzpot_diam_desc(String zzpot_diam_desc) {
		this.zzpot_diam_desc = zzpot_diam_desc;
	}
	
	public static ZPOTDIAM getZPOTDIAMByKey(EntityManager em, String system, Integer mandt, String zzpot_diam)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZPOTDIAM p where p.key.system = :system and p.key.mandt = :mandt and p.key.zzpot_diam = :zzpot_diam",
						ZPOTDIAM.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("zzpot_diam", zzpot_diam);	

		try {
			@SuppressWarnings("unchecked")
			List<ZPOTDIAM> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZPOTDIAM)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
}
