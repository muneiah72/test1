package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PICTURESPK implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5829751198485426443L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	private String document_type;
	private String document_number;
	private String document_version;
	private String document_part;
	
	public PICTURESPK() {}

	public String getDocument_type() {
		return document_type;
	}

	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}

	public String getDocument_version() {
		return document_version;
	}

	public void setDocument_version(String document_version) {
		this.document_version = document_version;
	}

	public String getDocument_number() {
		return document_number;
	}

	public void setDocument_number(String document_number) {
		this.document_number = document_number;
	}

	public String getDocument_part() {
		return document_part;
	}

	public void setDocument_part(String document_part) {
		this.document_part = document_part;
	}
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()
        		+ document_type.hashCode() 
        		+ document_number.hashCode()
        		+ document_version.hashCode()
        		+ document_part.hashCode();
    }

    public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
	
	public PICTURESPK(String system, Integer mandt, String document_type, String document_number, String document_version, String document_part) {
	    this.system = system;
		this.mandt = mandt;
        this.document_type = document_type;
        this.document_number = document_number;
        this.document_version = document_version;
        this.document_part = document_part;
    }
		
	public boolean equals(Object o) { 
        return ((o instanceof PICTURESPK) && 
        		system.equals(((PICTURESPK)o).getSystem()) &&
        		mandt.equals(((PICTURESPK)o).getMandt()) &&
        		document_type.equals(((PICTURESPK)o).getDocument_type()) &&
        		document_number.equals(((PICTURESPK)o).getDocument_number()) &&
        		document_version.equals(((PICTURESPK)o).getDocument_version()) &&
        		document_part.equals(((PICTURESPK)o).getDocument_part()) );
    }
}
