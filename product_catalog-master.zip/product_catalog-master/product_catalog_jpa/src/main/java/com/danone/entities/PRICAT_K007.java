package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="PRICAT_K007")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K007 {
	
	private static Logger LOGGER = LoggerFactory.getLogger(PRICAT_K007.class);
	
	@EmbeddedId
	private PRICAT_K007PK key;
	private Integer quantity_subline;
	@Column(length = 1)
	private String transport;
	@Column(length = 18)
	private String ean_matnr;
	@Column(length = 3)
	private String meinh;
	@Column(length = 9)
	private String matkl;
	
	public PRICAT_K007PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K007PK key) {
		this.key = key;
	}

	public Integer getQuantity_subline() {
		return quantity_subline;
	}

	public void setQuantity_subline(Integer quantity_subline) {
		this.quantity_subline = quantity_subline;
	}

	public String getTransport() {
		return transport;
	}

	public void setTransport(String transport) {
		this.transport = transport;
	}

	public String getEan_matnr() {
		return ean_matnr;
	}

	public void setEan_matnr(String ean_matnr) {
		this.ean_matnr = ean_matnr;
	}

	public String getMeinh() {
		return meinh;
	}

	public void setMeinh(String meinh) {
		this.meinh = meinh;
	}

	public String getMatkl() {
		return matkl;
	}

	public void setMatkl(String matkl) {
		this.matkl = matkl;
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K007> getK007With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup, String ean_upc_base, java.sql.Date validity_base) {
		
		String queryString = "SELECT p FROM PRICAT_K007 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_base = :ean_upc_base and p.key.validity_base = :validity_base";
		Query query = em.createQuery(queryString, PRICAT_K007.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_base", ean_upc_base).setParameter("validity_base", validity_base);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	public static List<PRICAT_K007> getLatestK007With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup, String ean_upc_base) {
		
		//First get the highest validity_base
		String queryString = "SELECT max(p.key.validity_base) FROM PRICAT_K007 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_base = :ean_upc_base";
		Query query = em.createQuery(queryString, PRICAT_K007.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_base", ean_upc_base);
		
		PRICAT_K007 result = null;
		try {
			result = (PRICAT_K007) query.getSingleResult();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
		
		if (result != null)
		{
			List<PRICAT_K007> list = PRICAT_K007.getK007With(em, system, mandt, prinbr, productgroup, ean_upc_base, result.getKey().getValidity_base());
			return list;
		}else {
			LOGGER.debug("No max validity date returned");
			return Collections.emptyList();
		}
	}
}
