package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="TVM1T")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class TVM1T {

	@EmbeddedId
	private TVM1TPK key;
	@Column(length = 40)
	private String bezei;
	
	public TVM1TPK getKey() {
		return key;
	}
	
	public void setKey(TVM1TPK key) {
		this.key = key;
	}

	public String getBezei() {
		return bezei;
	}

	public void setBezei(String bezei) {
		this.bezei = bezei;
	}
	
	public static TVM1T getTVM1TByKey(EntityManager em, String system, Integer mandt, String spras, String mvgr1)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM TVM1T p where p.key.system = :system and p.key.mandt = :mandt and p.key.spras = :spras and p.key.mvgr1 = :mvgr1",
						TVM1T.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("spras", spras);
		query.setParameter("mvgr1", mvgr1);	

		try {
			@SuppressWarnings("unchecked")
			List<TVM1T> list = query.getResultList();
			if (list.size() > 0)
			{
				return (TVM1T)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
}
