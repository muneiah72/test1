package com.danone.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PRICAT_K005PK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -167611497708159108L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 10)
	private String prinbr;
	@Column(length = 18)
	private String productgroup;
	@Column(length = 35)
	private String ean_upc_altunit;
	private java.sql.Date validity_unit;
	@Column(length = 2)
	private String langu_iso;
	@Column(length = 4)
	private String texttyp;
	private Integer textline_nr;
	
	public PRICAT_K005PK() {}
	
	public String getSystem() {
		return system;
	}
	
	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
	
	public String getPrinbr() {
		return prinbr;
	}
	
	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}
	
	public String getProductgroup() {
		return productgroup;
	}
	
	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}
	
	public String getEan_upc_altunit() {
		return ean_upc_altunit;
	}
	
	public void setEan_upc_altunit(String ean_upc_altunit) {
		this.ean_upc_altunit = ean_upc_altunit;
	}
	
	public Date getValidity_unit() {
		return validity_unit;
	}
	
	public void setValidity_unit(Date validity_unit) {
		this.validity_unit = validity_unit;
	}
	
	public String getLangu_iso() {
		return langu_iso;
	}
	
	public void setLangu_iso(String langu_iso) {
		this.langu_iso = langu_iso;
	}
	
	public String getTexttyp() {
		return texttyp;
	}
	
	public void setTexttype(String texttyp) {
		this.texttyp = texttyp;
	}
	
	public Integer getTextline_nr() {
		return textline_nr;
	}
	
	public void setTextline_nr(Integer textline_nr) {
		this.textline_nr = textline_nr;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof PRICAT_K005PK) && 
        		system.equals(((PRICAT_K005PK)o).getSystem()) &&
        		mandt.equals(((PRICAT_K005PK)o).getMandt()) &&
        		prinbr.equals(((PRICAT_K005PK)o).getPrinbr()) &&
        		productgroup.equals(((PRICAT_K005PK)o).getProductgroup()) &&
        		ean_upc_altunit.equals(((PRICAT_K005PK)o).getEan_upc_altunit()) &&
        		validity_unit.equals(((PRICAT_K005PK)o).getValidity_unit()) &&
        		langu_iso.equals(((PRICAT_K005PK)o).getLangu_iso()) &&
        		texttyp.equals(((PRICAT_K005PK)o).getTexttyp()) &&
        		textline_nr.equals(((PRICAT_K005PK)o).getTextline_nr()));
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ prinbr.hashCode() 
        		+ productgroup.hashCode() 
        		+ ean_upc_altunit.hashCode() 
        		+ validity_unit.hashCode()
        		+ langu_iso.hashCode() 
        		+ texttyp.hashCode() 
        		+ textline_nr.hashCode(); 
    }
}
