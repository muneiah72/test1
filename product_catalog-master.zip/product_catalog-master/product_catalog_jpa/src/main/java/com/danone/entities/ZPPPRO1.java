package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPPPRO1")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPPPRO1 {

	@EmbeddedId
	private ZPPPRO1PK key;
	@Column(length = 30)
	private String zdescription;
	
	public ZPPPRO1PK getKey() {
		return key;
	}
	
	public void setKey(ZPPPRO1PK key) {
		this.key = key;
	}

	public String getZdescription() {
		return zdescription;
	}

	public void setZdescription(String zdescription) {
		this.zdescription = zdescription;
	}
	
	public static ZPPPRO1 getZPPPRO1ByKey(EntityManager em, String system, Integer mandt, String zrocess1)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZPPPRO1 p where p.key.system = :system and p.key.mandt = :mandt and p.key.zrocess1 = :zrocess1",
						ZPPPRO1.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("zrocess1", zrocess1);	

		try {
			@SuppressWarnings("unchecked")
			List<ZPPPRO1> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZPPPRO1)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
}
