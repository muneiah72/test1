package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class TVM1TPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5394062841906829470L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 1)
	private String spras;
	@Column(length = 3)
	private String mvgr1;
	
	public TVM1TPK() {}

	public TVM1TPK(String system, Integer mandt, String spras, String mvgr1) {
		this.system = system;
		this.setMandt(mandt);
		this.setSpras(spras);
		this.setMvgr1(mvgr1);
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getSpras() {
		return spras;
	}

	public void setSpras(String spras) {
		this.spras = spras;
	}
	
	public String getMvgr1() {
		return mvgr1;
	}

	public void setMvgr1(String mvgr1) {
		this.mvgr1 = mvgr1;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof TVM1TPK) && 
        		system.equals(((TVM1TPK)o).getSystem()) &&
        		mandt.equals(((TVM1TPK)o).getMandt()) &&        	
        		spras.equals(((TVM1TPK)o).getSpras()) &&        	
        		mvgr1.equals(((TVM1TPK)o).getMvgr1()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ spras.hashCode()
        		+ mvgr1.hashCode(); 
    }

}
