package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="ZPROWS_ORG")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPROWS_ORG {

	private final static Logger LOGGER = LoggerFactory.getLogger(ZPROWS_ORG.class);

	@EmbeddedId
	private ZPROWS_ORGPK key;

	private String wsprotyp;
	private String status;
	private String laiso;
	private String vkorg_descr;
	private String vtweg_descr;
	private String plant;
	private String ecatd;


	public ZPROWS_ORGPK getKey() {
		return key;
	}

	public void setKey(ZPROWS_ORGPK key) {
		this.key = key;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLaiso() {
		return laiso;
	}

	public void setLaiso(String laiso) {
		this.laiso = laiso;
	}

	public String getVkorg_descr() {
		return vkorg_descr;
	}

	public void setVkorg_descr(String vkorg_descr) {
		this.vkorg_descr = vkorg_descr;
	}

	public String getVtweg_descr() {
		return vtweg_descr;
	}

	public void setVtweg_descr(String vtweg_descr) {
		this.vtweg_descr = vtweg_descr;
	}

	public String getWsprotyp() {
		return wsprotyp;
	}

	public void setWsprotyp(String wsprotyp) {
		this.wsprotyp = wsprotyp;
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPROWS_ORG> getAllSalesorgs(EntityManager em) {
		Query query = em
				.createQuery(
						"SELECT p FROM ZPROWS_ORG p",
						ZPROWS_ORG.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	public static ZPROWS_ORG getByKey(EntityManager em, String vkorg, String vtweg) {
		Query query = em
				.createQuery(
						"SELECT p FROM ZPROWS_ORG p where p.key.vkorg = :vkorg and p.key.vtweg = :vtweg",
						ZPROWS_ORG.class);
		query.setParameter("vkorg", vkorg);
		query.setParameter("vtweg", vtweg);
		try {
			return (ZPROWS_ORG) query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getEcatd() {
		return ecatd;
	}

	public void setEcatd(String ecatd) {
		this.ecatd = ecatd;
	}

}