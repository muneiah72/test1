package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPROEU_PLANTPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -794636509731117064L;
	
	@Column (length = 50)
	private String system;
	@Column(length = 3)
	private Integer mandt;
	@Column(length = 4)
	private String vkorg;
	@Column(length = 18)
	private String matnr;
	@Column(length = 4)
	private String werks;
	@Column(length = 4)
	private String yyprod;
	@Column(length = 2)
	private String mmprod;

	
	public ZPROEU_PLANTPK() {}
	
	public ZPROEU_PLANTPK(String system, Integer mandt, String vkorg, String matnr, String werks, String yyprod, String mmprod) {
		this.system = system;
		this.mandt = mandt;
		this.vkorg = vkorg;
		this.matnr = matnr;
		this.werks = werks;
		this.yyprod = yyprod;
		this.mmprod = mmprod;
	}
	
	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPROEU_PLANTPK) && 
        		system.equals(((ZPROEU_PLANTPK)o).getSystem()) &&
        		mandt.equals(((ZPROEU_PLANTPK)o).getMandt()) &&
        		vkorg.equals(((ZPROEU_PLANTPK)o).getVkorg()) &&
        		matnr.equals(((ZPROEU_PLANTPK)o).getMatnr()) &&
        		werks.equals(((ZPROEU_PLANTPK)o).getwerks()) &&
        		yyprod.equals(((ZPROEU_PLANTPK)o).getyyprod()) &&
        		mmprod.equals(((ZPROEU_PLANTPK)o).getmmprod()) );
    }
	
    public int hashCode() { 
        return system.hashCode() 
        		+ mandt.hashCode()
        		+ vkorg.hashCode() 
        		+ matnr.hashCode()
        		+ werks.hashCode() 
        		+ yyprod.hashCode()
        		+ mmprod.hashCode(); 
    }

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getwerks() {
		return werks;
	}

	public void setwerks(String werks) {
		this.werks = werks;
	}

	public String getmmprod() {
		return mmprod;
	}

	public void setmmprod(String mmprod) {
		this.mmprod = mmprod;
	}

	public String getyyprod() {
		return yyprod;
	}

	public void setyyprod(String yyprod) {
		this.yyprod = yyprod;
	}
}
