package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPMAR3PK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 116505148780872636L;
	/**
	 * 
	 */

	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zmarkiii;
	
	public ZPPMAR3PK() {}

	public ZPPMAR3PK(String system, Integer mandt, String zmarkiii) {
		this.system = system;
		this.setMandt(mandt);
		this.setZmarkiii(zmarkiii);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPMAR3PK) && 
        		system.equals(((ZPPMAR3PK)o).getSystem()) &&
        		mandt.equals(((ZPPMAR3PK)o).getMandt()) &&        	
        		zmarkiii.equals(((ZPPMAR3PK)o).getZmarkiii()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zmarkiii.hashCode(); 
    }

	public String getZmarkiii() {
		return zmarkiii;
	}

	public void setZmarkiii(String zmarkiii) {
		this.zmarkiii = zmarkiii;
	}

}
