package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="ZPRO_NUTBOARD")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPRO_NUTBOARD {
	
	private static Logger LOGGER = LoggerFactory.getLogger(ZPRO_NUTBOARD.class);
	
	@EmbeddedId
	private ZPRO_NUTBOARDPK key;
	@Column(length = 3)
	private String poridun;
	@Column(length = 50)
	private String poridtext;
	private Integer rank;
	private double poridva;
	private double poridvaro;
	@Column(length = 3)
	private String valueun;
	private double ajrc;
	@Column(length = 3)
	private String ajrcun;
	@Column(length = 1)
	private String display;
	private java.sql.Date erdat;
	private java.sql.Date aedat;
	@Column (length = 30)
	private String labelcod;
	@Column(length = 1)
	private String poridsign;
	
	public ZPRO_NUTBOARDPK getKey() {
		return key;
	}
	
	public void setKey(ZPRO_NUTBOARDPK key) {
		this.key = key;
	}
	
	public String getPoridun() {
		return poridun;
	}
	
	public void setPoridun(String poridun) {
		this.poridun = poridun;
	}
	
	public String getPoridtext() {
		return poridtext;
	}
	
	public void setPoridtext(String poridtext) {
		this.poridtext = poridtext;
	}
	
	public Integer getRank() {
		return rank;
	}
	
	public void setRank(Integer rank) {
		this.rank = rank;
	}
	
	public double getPoridva() {
		return poridva;
	}
	
	public void setPoridva(double poridva) {
		this.poridva = poridva;
	}
	
	public double getPoridvaro() {
		return poridvaro;
	}
	
	public void setPoridvaro(double poridvaro) {
		this.poridvaro = poridvaro;
	}
	
	public String getValueun() {
		return valueun;
	}
	
	public void setValueun(String valueun) {
		this.valueun = valueun;
	}
	
	public double getAjrc() {
		return ajrc;
	}
	
	public void setAjrc(double ajrc) {
		this.ajrc = ajrc;
	}
	
	public String getAjrcun() {
		return ajrcun;
	}
	
	public void setAjrcun(String ajrcun) {
		this.ajrcun = ajrcun;
	}
	
	public String getDisplay() {
		return display;
	}
	
	public void setDisplay(String display) {
		this.display = display;
	}
	
	public java.sql.Date getErdat() {
		return erdat;
	}
	
	public void setErdat(java.sql.Date erdat) {
		this.erdat = erdat;
	}
	
	public java.sql.Date getAedat() {
		return aedat;
	}
	
	public void setAedat(java.sql.Date aedat) {
		this.aedat = aedat;
	}
	
	public void setLabelcod(String labelcod) {
		this.labelcod = labelcod;
	}
	
	public String getLabelcod() {
		return labelcod;
	}
	
	public String getPoridsign() {
		return poridsign;
	}

	public void setPoridsign(String poridsign) {
		this.poridsign = poridsign;
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPRO_NUTBOARD> getNutboardByMatnrAndValidityAndLabelcod(EntityManager em, String system, String matnr, String labelcode) {
		LOGGER.debug("getNutboard");
		if (labelcode != null)
		{
			java.sql.Date max_date = getNutboardMaxDate(em, system, matnr, labelcode);
			if (max_date != null)
			{
				Query query = em.createQuery(
						"SELECT n FROM ZPRO_NUTBOARD n where n.key.system = :system and n.key.matnr = :matnr and n.key.datap = :datap and n.labelcod = :labelcod ORDER BY n.rank, n.key.nutid ASC",
						ZPRO_NUTBOARD.class).setParameter("system", system).setParameter("matnr", matnr).setParameter("datap", max_date).setParameter("labelcod", labelcode);
				LOGGER.debug("getNutboard query: " + query.toString());
				try {
					return query.getResultList();
				} catch (NoResultException e) {
					return Collections.emptyList();
				}
			}else {
				LOGGER.debug("No maxdate");
				return Collections.emptyList();
			}
		}else {
			LOGGER.debug("No labelcode");
			return Collections.emptyList();
		}
	}

	public static java.sql.Date getNutboardMaxDate(EntityManager em, String system, String matnr, String labelcode) {
		LOGGER.debug("getNutboardMaxDate");
		Query query = em.createQuery(
				"SELECT MAX(n.key.datap) FROM ZPRO_NUTBOARD n where n.key.system = :system and n.key.matnr = :matnr and n.labelcod = :labelcod",
				ZPRO_NUTBOARD.class).setParameter("system", system).setParameter("matnr", matnr).setParameter("labelcod", labelcode);
		LOGGER.debug("getNutboardMaxDate query: " + query.toString());
		try {
			java.sql.Date maxdate = (java.sql.Date)query.getSingleResult();
			if (maxdate != null)
			 { LOGGER.debug("getNutboardMaxDate max date: " + maxdate.toString()); }
			return maxdate;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPRO_NUTBOARD> getNutboardByMatnr(EntityManager em, String system, Integer mandt, String matnr) {
		Query query = em.createQuery(
				"SELECT n FROM ZPRO_NUTBOARD n where n.key.system = :system and n.key.mandt = :mandt and n.key.matnr = :matnr",
				ZPRO_NUTBOARD.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("matnr", matnr);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}

}
