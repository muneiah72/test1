package com.danone.entities;

import java.sql.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PICTURES")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true) 
public class PICTURES {
	
	@EmbeddedId
	private PICTURESPK key;
	private String image_id;
	private String thumbnail_id;
	private String picture_name;
	private String product_type;
	private String content_type;
	private String main_face;
	private String horizontal_angle;
	private String file_nature;
	private String valid_from;
	private String valid_to;
	private String shooting_date;
	private java.sql.Date creation_date;
	
	/*private Boolean isThumbnail;
	private byte[] picture;*/
	
	public void setKey(PICTURESPK key) {
		this.key = key;
	}
	
	public PICTURESPK getKey() {
		return key;
	}

	public String getFile_nature() {
		return file_nature;
	}

	public void setFile_nature(String file_nature) {
		this.file_nature = file_nature;
	}

	public String getPicture_name() {
		return picture_name;
	}

	public void setPicture_name(String picture_name) {
		this.picture_name = picture_name;
	}

	public String getContent_type() {
		return content_type;
	}

	public void setContent_type(String content_type) {
		this.content_type = content_type;
	}

	public String getProduct_type() {
		return product_type;
	}

	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}

	public String getMain_face() {
		return main_face;
	}

	public void setMain_face(String main_face) {
		this.main_face = main_face;
	}

	public String getHorizontal_angle() {
		return horizontal_angle;
	}

	public void setHorizontal_angle(String horizontal_angle) {
		this.horizontal_angle = horizontal_angle;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public String getImage_id() {
		return image_id;
	}

	public void setImage_id(String image_id) {
		this.image_id = image_id;
	}

	public String getThumbnail_id() {
		return thumbnail_id;
	}

	public void setThumbnail_id(String thumbnail_id) {
		this.thumbnail_id = thumbnail_id;
	}


	public String getValid_from() {
		return valid_from;
	}


	public void setValid_from(String valid_from) {
		this.valid_from = valid_from;
	}


	public String getValid_to() {
		return valid_to;
	}


	public void setValid_to(String valid_to) {
		this.valid_to = valid_to;
	}


	public String getShooting_date() {
		return shooting_date;
	}


	public void setShooting_date(String shooting_date) {
		this.shooting_date = shooting_date;
	}
	

	public static PICTURES getPICTURESByKey(EntityManager em, PICTURESPK key) {
		return em.find(PICTURES.class, key);
	}

}
