package com.danone.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K009")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K009 {

	@EmbeddedId
	private PRICAT_K009PK key;
	
	public PRICAT_K009PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K009PK key) {
		this.key = key;
	}
}
