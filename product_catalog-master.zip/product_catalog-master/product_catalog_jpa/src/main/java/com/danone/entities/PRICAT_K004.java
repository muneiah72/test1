package com.danone.entities;

import java.sql.Date;
import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="PRICAT_K004")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K004 {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PRICAT_K004.class);
	
	@EmbeddedId
	private PRICAT_K004PK key; 
	private java.sql.Date validity_base;
	private String ean_upc_type;
	private String ean_upc_base;
	private String ean_upc_subline;
	private Integer quantity_subline;
	private Integer quantity_unit;
	private Integer delivery_unit_id;
	private Integer invoice_unit_id;
	private Integer order_unit_id;
	private String package_type;
	private String prod_id_sender;
	private String bearb_status;
	private String transport;
	private Integer item_number;
	private String non_public;
	private String non_public_iln;
	private String non_public_iln2;
	private String non_public_iln3;
	private String non_public_iln4;
	private String non_public_iln5;
	private String alt_unit;
	private String alt_unit_iso;
	private double numerator;
	private double denominatr;
	private double length;
	private double width;
	private double height;
	private String unit_length;
	private String unit_length_iso;
	private String unit_width;
	private String unit_width_iso;
	private String unit_height;
	private String unit_height_iso;
	private double volume;
	private String volumeunit;
	private String volumeunit_iso;
	private double gross_wt;
	private String unit_of_wt;
	private String unit_of_wt_iso;
	private String unit_base;
	private String unit_base_iso;
	private String unit_purord;
	private String unit_purord_iso;
	private double net_weight;
	private String unit_of_net;
	private String unit_of_net_iso;
	private String hazard_limit;
	private String barcode_id;
	private String pallet_handl;
	private String pallet_type;
	private Integer pallet_layer;
	private Integer pallet_units;
	private Integer pallet_hight;
	private String unit_palht_iso;
	private Integer pallet_stack;
	private String state_info;
	private String hpean;
	
	public PRICAT_K004PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K004PK key) {
		this.key = key;
	}
	
	public Date getValidity_base() {
		return validity_base;
	}
	
	public void setValidity_base(Date validity_base) {
		this.validity_base = validity_base;
	}
	
	public String getEan_upc_type() {
		return ean_upc_type;
	}
	
	public void setEan_upc_type(String ean_upc_type) {
		this.ean_upc_type = ean_upc_type;
	}
	
	public String getEan_upc_base() {
		return ean_upc_base;
	}
	
	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}
	
	public String getEan_upc_subline() {
		return ean_upc_subline;
	}
	
	public void setEan_upc_subline(String ean_upc_subline) {
		this.ean_upc_subline = ean_upc_subline;
	}
	
	public Integer getQuantity_subline() {
		return quantity_subline;
	}
	
	public void setQuantity_subline(Integer quantity_subline) {
		this.quantity_subline = quantity_subline;
	}
	
	public Integer getQuantity_unit() {
		return quantity_unit;
	}

	public void setQuantity_unit(Integer quantity_unit) {
		this.quantity_unit = quantity_unit;
	}

	public Integer getDelivery_unit_id() {
		return delivery_unit_id;
	}

	public void setDelivery_unit_id(Integer delivery_unit_id) {
		this.delivery_unit_id = delivery_unit_id;
	}

	public Integer getInvoice_unit_id() {
		return invoice_unit_id;
	}

	public void setInvoice_unit_id(Integer invoice_unit_id) {
		this.invoice_unit_id = invoice_unit_id;
	}

	public Integer getOrder_unit_id() {
		return order_unit_id;
	}

	public void setOrder_unit_id(Integer order_unit_id) {
		this.order_unit_id = order_unit_id;
	}

	public String getPackage_type() {
		return package_type;
	}

	public void setPackage_type(String package_type) {
		this.package_type = package_type;
	}

	public String getProd_id_sender() {
		return prod_id_sender;
	}

	public void setProd_id_sender(String prod_id_sender) {
		this.prod_id_sender = prod_id_sender;
	}

	public String getBearb_status() {
		return bearb_status;
	}

	public void setBearb_status(String bearb_status) {
		this.bearb_status = bearb_status;
	}

	public String getTransport() {
		return transport;
	}

	public void setTransport(String transport) {
		this.transport = transport;
	}

	public Integer getItem_number() {
		return item_number;
	}

	public void setItem_number(Integer item_number) {
		this.item_number = item_number;
	}

	public String getNon_public() {
		return non_public;
	}

	public void setNon_public(String non_public) {
		this.non_public = non_public;
	}

	public String getNon_public_iln() {
		return non_public_iln;
	}

	public void setNon_public_iln(String non_public_iln) {
		this.non_public_iln = non_public_iln;
	}

	public String getNon_public_iln2() {
		return non_public_iln2;
	}

	public void setNon_public_iln2(String non_public_iln2) {
		this.non_public_iln2 = non_public_iln2;
	}

	public String getNon_public_iln3() {
		return non_public_iln3;
	}

	public void setNon_public_iln3(String non_public_iln3) {
		this.non_public_iln3 = non_public_iln3;
	}

	public String getNon_public_iln4() {
		return non_public_iln4;
	}

	public void setNon_public_iln4(String non_public_iln4) {
		this.non_public_iln4 = non_public_iln4;
	}

	public String getNon_public_iln5() {
		return non_public_iln5;
	}

	public void setNon_public_iln5(String non_public_iln5) {
		this.non_public_iln5 = non_public_iln5;
	}

	public String getAlt_unit() {
		return alt_unit;
	}

	public void setAlt_unit(String alt_unit) {
		this.alt_unit = alt_unit;
	}

	public String getAlt_unit_iso() {
		return alt_unit_iso;
	}

	public void setAlt_unit_iso(String alt_unit_iso) {
		this.alt_unit_iso = alt_unit_iso;
	}

	public double getNumerator() {
		return numerator;
	}

	public void setNumerator(double numerator) {
		this.numerator = numerator;
	}

	public double getDenominatr() {
		return denominatr;
	}

	public void setDenominator(double denominatr) {
		this.denominatr = denominatr;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getUnit_length() {
		return unit_length;
	}

	public void setUnit_length(String unit_length) {
		this.unit_length = unit_length;
	}

	public String getUnit_length_iso() {
		return unit_length_iso;
	}

	public void setUnit_length_iso(String unit_length_iso) {
		this.unit_length_iso = unit_length_iso;
	}

	public String getUnit_width_iso() {
		return unit_width_iso;
	}

	public void setUnit_width_iso(String unit_width_iso) {
		this.unit_width_iso = unit_width_iso;
	}

	public String getUnit_width() {
		return unit_width;
	}

	public void setUnit_width(String unit_width) {
		this.unit_width = unit_width;
	}

	public String getUnit_height() {
		return unit_height;
	}

	public void setUnit_height(String unit_height) {
		this.unit_height = unit_height;
	}

	public String getUnit_height_iso() {
		return unit_height_iso;
	}

	public void setUnit_height_iso(String unit_height_iso) {
		this.unit_height_iso = unit_height_iso;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeunit() {
		return volumeunit;
	}

	public void setVolumeunit(String volumeunit) {
		this.volumeunit = volumeunit;
	}

	public String getVolumeunit_iso() {
		return volumeunit_iso;
	}

	public void setVolumeunit_iso(String volumeunit_iso) {
		this.volumeunit_iso = volumeunit_iso;
	}

	public double getGross_wt() {
		return gross_wt;
	}

	public void setGross_wt(double gross_wt) {
		this.gross_wt = gross_wt;
	}

	public String getUnit_of_wt() {
		return unit_of_wt;
	}

	public void setUnit_of_wt(String unit_of_wt) {
		this.unit_of_wt = unit_of_wt;
	}

	public String getUnit_of_wt_iso() {
		return unit_of_wt_iso;
	}

	public void setUnit_of_wt_iso(String unit_of_wt_iso) {
		this.unit_of_wt_iso = unit_of_wt_iso;
	}

	public String getUnit_base() {
		return unit_base;
	}

	public void setUnit_base(String unit_base) {
		this.unit_base = unit_base;
	}

	public String getUnit_base_iso() {
		return unit_base_iso;
	}

	public void setUnit_base_iso(String unit_base_iso) {
		this.unit_base_iso = unit_base_iso;
	}

	public String getUnit_purord() {
		return unit_purord;
	}

	public void setUnit_purord(String unit_purord) {
		this.unit_purord = unit_purord;
	}

	public String getUnit_purord_iso() {
		return unit_purord_iso;
	}

	public void setUnit_purord_iso(String unit_purord_iso) {
		this.unit_purord_iso = unit_purord_iso;
	}

	public double getNet_weight() {
		return net_weight;
	}

	public void setNet_weight(double net_weight) {
		this.net_weight = net_weight;
	}

	public String getUnit_of_net() {
		return unit_of_net;
	}

	public void setUnit_of_net(String unit_of_net) {
		this.unit_of_net = unit_of_net;
	}

	public String getUnit_of_net_iso() {
		return unit_of_net_iso;
	}

	public void setUnit_of_net_iso(String unit_of_net_iso) {
		this.unit_of_net_iso = unit_of_net_iso;
	}

	public String getHazard_limit() {
		return hazard_limit;
	}

	public void setHazard_limit(String hazard_limit) {
		this.hazard_limit = hazard_limit;
	}

	public String getBarcode_id() {
		return barcode_id;
	}

	public void setBarcode_id(String barcode_id) {
		this.barcode_id = barcode_id;
	}

	public String getPallet_handl() {
		return pallet_handl;
	}

	public void setPallet_handl(String pallet_handl) {
		this.pallet_handl = pallet_handl;
	}

	public String getPallet_type() {
		return pallet_type;
	}

	public void setPallet_type(String pallet_type) {
		this.pallet_type = pallet_type;
	}

	public Integer getPallet_layer() {
		return pallet_layer;
	}

	public void setPallet_layer(Integer pallet_layer) {
		this.pallet_layer = pallet_layer;
	}

	public Integer getPallet_units() {
		return pallet_units;
	}

	public void setPallet_units(Integer pallet_units) {
		this.pallet_units = pallet_units;
	}

	public Integer getPallet_hight() {
		return pallet_hight;
	}

	public void setPallet_hight(Integer pallet_hight) {
		this.pallet_hight = pallet_hight;
	}

	public String getUnit_palht_iso() {
		return unit_palht_iso;
	}

	public void setUnit_palht_iso(String unit_palht_iso) {
		this.unit_palht_iso = unit_palht_iso;
	}

	public Integer getPallet_stack() {
		return pallet_stack;
	}

	public void setPallet_stack(Integer pallet_stack) {
		this.pallet_stack = pallet_stack;
	}

	public String getState_info() {
		return state_info;
	}

	public void setState_info(String state_info) {
		this.state_info = state_info;
	}

	public String getHpean() {
		return hpean;
	}

	public void setHpean(String hpean) {
		this.hpean = hpean;
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K004> getK004With(EntityManager em, String system, Integer mandt, String prinbr, String productgroup,
						String ean_upc_base, java.sql.Date validity_base) {
		
		String queryString = "SELECT p FROM PRICAT_K004 p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.ean_upc_base = :ean_upc_base and p.validity_base = :validity_base ORDER BY p.quantity_subline ASC";
		
		LOGGER.debug(queryString);
		
		Query query = em.createQuery(queryString, PRICAT_K004.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_base", ean_upc_base).setParameter("validity_base", validity_base);
		
		try {
			LOGGER.debug("Query K004 done");
			return query.getResultList();
		} catch (NoResultException e) {
			LOGGER.debug("Query K004 NoResultException");
			return Collections.emptyList();
		}
	}
	
	public static PRICAT_K004 getPRICAT_K004ByKey(EntityManager em, PRICAT_K004PK key) {
		return em.find(PRICAT_K004.class, key);
	}
}
