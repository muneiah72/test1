package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K003Z")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class PRICAT_K003Z {

	@EmbeddedId
	private PRICAT_K003PK key;
	private String size_dim;
	private String comm_code;
	
	public PRICAT_K003PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K003PK key) {
		this.key = key;
	}
	
	public String getSize_dim() {
		return size_dim;
	}
	
	public void setSize_dim(String size_dim) {
		this.size_dim = size_dim;
	}
	
	public String getComm_code() {
		return comm_code;
	}
	
	public void setComm_code(String comm_code) {
		this.comm_code = comm_code;
	}
	
	public static PRICAT_K003Z getPRICAT_K003ZByKey(EntityManager em, PRICAT_K003PK pricat_k003pk) {
		return em.find(PRICAT_K003Z.class, pricat_k003pk);
	}
	
	@SuppressWarnings("unchecked")
	public static List<PRICAT_K003Z> getK003ZWith(EntityManager em, String system, Integer mandt, String prinbr, String productgroup,
						String ean_upc_base, java.sql.Date validity_base) {
		
		String queryString = "SELECT p FROM PRICAT_K003Z p where p.key.system = :system and p.key.mandt = :mandt and p.key.prinbr = :prinbr and p.key.productgroup = :productgroup and p.key.ean_upc_base = :ean_upc_base and p.key.validity_base = :validity_base";
		
		Query query = em.createQuery(queryString, PRICAT_K003Z.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("prinbr", prinbr).setParameter("productgroup", productgroup).setParameter("ean_upc_base", ean_upc_base).setParameter("validity_base", validity_base);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
}
