package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPRO_ASSORTMENT")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPRO_ASSORTMENT {
	
	@EmbeddedId
	private ZPRO_ASSORTMENTPK key;
	@Column(length = 10)
	private String asort;
	@Column(length = 10)
	private String prinbr;
	
	public ZPRO_ASSORTMENTPK getKey() {
		return key;
	}
	
	public void setKey(ZPRO_ASSORTMENTPK key) {
		this.key = key;
	}
	
	public String getAsort() {
		return asort;
	}
	
	public void setAsort(String asort) {
		this.asort = asort;
	}
	
	public String getPrinbr() {
		return prinbr;
	}
	
	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}
	
	public static ZPRO_ASSORTMENT getZPRO_ASSORTMENTByKey(EntityManager em, ZPRO_ASSORTMENTPK key) {
		return em.find(ZPRO_ASSORTMENT.class, key);
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPRO_ASSORTMENT> getZPRO_ASSORTMENTByVkorg(EntityManager em, String vkorg) {
		String queryString = "SELECT z FROM ZPRO_ASSORTMENT z where z.key.vkorg = :vkorg";
		Query query = em.createQuery(queryString, ZPRO_ASSORTMENT.class);
		query.setParameter("vkorg", vkorg);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
}
