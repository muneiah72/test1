package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZRANGE")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZRANGE {

	@EmbeddedId
	private ZRANGEPK key;
	@Column(length = 30)
	private String zzrange_desc;
	
	public ZRANGEPK getKey() {
		return key;
	}
	
	public void setKey(ZRANGEPK key) {
		this.key = key;
	}

	public String getZzrange_desc() {
		return zzrange_desc;
	}

	public void setZzrange_desc(String zzrange_desc) {
		this.zzrange_desc = zzrange_desc;
	}
	
	public static ZRANGE getZRANGEByKey(EntityManager em, String system, Integer mandt, String zzrange)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZRANGE p where p.key.system = :system and p.key.mandt = :mandt and p.key.zzrange = :zzrange",
						ZRANGE.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("zzrange", zzrange);	

		try {
			@SuppressWarnings("unchecked")
			List<ZRANGE> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZRANGE)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
}
