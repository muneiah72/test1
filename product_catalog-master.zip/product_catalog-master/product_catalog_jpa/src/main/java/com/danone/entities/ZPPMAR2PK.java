package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPMAR2PK implements java.io.Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5594293730105370942L;
	
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zmarkii;
	
	public ZPPMAR2PK() {}

	public ZPPMAR2PK(String system, Integer mandt, String zmarkii) {
		this.system = system;
		this.setMandt(mandt);
		this.setZmarkii(zmarkii);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPMAR2PK) && 
        		system.equals(((ZPPMAR2PK)o).getSystem()) &&
        		mandt.equals(((ZPPMAR2PK)o).getMandt()) &&        	
        		zmarkii.equals(((ZPPMAR2PK)o).getZmarkii()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zmarkii.hashCode(); 
    }

	public String getZmarkii() {
		return zmarkii;
	}

	public void setZmarkii(String zmarkii) {
		this.zmarkii = zmarkii;
	}

}
