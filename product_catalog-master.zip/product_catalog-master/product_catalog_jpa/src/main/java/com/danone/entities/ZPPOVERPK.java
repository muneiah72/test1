package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPOVERPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3089814009580046715L;
	/**
	 * 
	 */

	/**
	 * 
	 */
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zoverlay;
	
	public ZPPOVERPK() {}

	public ZPPOVERPK(String system, Integer mandt, String zrocess1) {
		this.system = system;
		this.setMandt(mandt);
		this.setZoverlay(zoverlay);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZoverlay() {
		return zoverlay;
	}

	public void setZoverlay(String zrocess1) {
		this.zoverlay = zoverlay;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPOVERPK) && 
        		system.equals(((ZPPOVERPK)o).getSystem()) &&
        		mandt.equals(((ZPPOVERPK)o).getMandt()) &&        	
        		zoverlay.equals(((ZPPOVERPK)o).getZoverlay()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zoverlay.hashCode(); 
    }

}
