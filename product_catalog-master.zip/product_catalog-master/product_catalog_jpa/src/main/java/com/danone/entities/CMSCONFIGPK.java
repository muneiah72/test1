package com.danone.entities;

import javax.persistence.Embeddable;

@Embeddable
public class CMSCONFIGPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 968807556781489316L;
	
	private String language;
	private String type;

	private Integer validFrom;
	private Integer validTo;
	
	public CMSCONFIGPK(){}
	
	public CMSCONFIGPK(String language, String type, Integer validFrom, Integer validTo) {
		this.language = language;
		this.type = type;
		this.validFrom = validFrom;
		this.validTo = validTo;
	}
	
	public String getLanguage() {
		return language;
	}
	
	public void setLanguage(String language) {
		this.language = language;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public Integer getValidFrom() {
		return validFrom;
	}
	
	public void setValidFrom(Integer validFrom) {
		this.validFrom = validFrom;
	}
	
	public Integer getValidTo() {
		return validTo;
	}
	
	public void setValidTo(Integer validTo) {
		this.validTo = validTo;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof CMSCONFIGPK) && 
        		language.equals(((CMSCONFIGPK) o).getLanguage()) &&
        		type.equals(((CMSCONFIGPK) o).getType()) &&
        		validFrom.equals(((CMSCONFIGPK) o).getValidFrom()) &&
        		validTo.equals(((CMSCONFIGPK) o).getValidTo()) );
    }
	
    public int hashCode() { 
        return language.hashCode() 
        		+ type.hashCode() 
        		+ validFrom.hashCode()
        		+ validTo.hashCode();
    }
}
