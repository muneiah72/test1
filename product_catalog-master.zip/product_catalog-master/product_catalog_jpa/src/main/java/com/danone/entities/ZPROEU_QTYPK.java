package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPROEU_QTYPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -794636509731117064L;
	
	@Column (length = 50)
	private String system;
	@Column(length = 3)
	private Integer mandt;
	@Column(length = 4)
	private String vkorg;
	@Column(length = 2)
	private String vtweg;
	@Column(length = 2)
	private String spart;
	@Column(length = 4)
	private String yyfac;
	@Column(length = 2)
	private String mmfac;
	@Column(length = 18)
	private String matnr;
	@Column(length = 3)
	private String ctrydest;
	
	public ZPROEU_QTYPK() {}
	
	public ZPROEU_QTYPK(String system, Integer mandt, String vkorg, String vtweg, String spart, String yyfac, String mmfac, String matnr, String ctrydest) {
		this.system = system;
		this.mandt = mandt;
		this.vkorg = vkorg;
		this.vtweg = vtweg;
		this.spart = spart;
		this.yyfac = yyfac;
		this.mmfac = mmfac;
		this.matnr = matnr;
		this.ctrydest = ctrydest;
	}
	
	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getSpart() {
		return spart;
	}

	public void setSpart(String spart) {
		this.spart = spart;
	}
	
	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPROEU_QTYPK) && 
        		system.equals(((ZPROEU_QTYPK)o).getSystem()) &&
        		mandt.equals(((ZPROEU_QTYPK)o).getMandt()) &&
        		vkorg.equals(((ZPROEU_QTYPK)o).getVkorg()) &&
        		vtweg.equals(((ZPROEU_QTYPK)o).getVtweg()) &&
        		spart.equals(((ZPROEU_QTYPK)o).getSpart()) &&
        		yyfac.equals(((ZPROEU_QTYPK)o).getYyfac()) &&
        		mmfac.equals(((ZPROEU_QTYPK)o).getMmfac()) &&
        		matnr.equals(((ZPROEU_QTYPK)o).getMatnr()) &&
        		matnr.equals(((ZPROEU_QTYPK)o).getCtrydest()) );
    }
	
    public int hashCode() { 
        return system.hashCode() 
        		+ mandt.hashCode()
        		+ vkorg.hashCode() 
        		+ vtweg.hashCode() 
        		+ spart.hashCode()
        		+ yyfac.hashCode()
        		+ mmfac.hashCode()
        		+ matnr.hashCode()
        		+ ctrydest.hashCode(); 
    }

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

	public String getMmfac() {
		return mmfac;
	}

	public void setMmfac(String mmfac) {
		this.mmfac = mmfac;
	}

	public String getYyfac() {
		return yyfac;
	}

	public void setYyfac(String yyfac) {
		this.yyfac = yyfac;
	}

	public String getCtrydest() {
		return ctrydest;
	}

	public void setCtrydest(String ctrydest) {
		this.ctrydest = ctrydest;
	}

}
