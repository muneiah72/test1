package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="T179T")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class T179T {

	@EmbeddedId
	private T179TPK key;
	@Column(length = 40)
	private String vtext;
	
	public T179TPK getKey() {
		return key;
	}
	
	public void setKey(T179TPK key) {
		this.key = key;
	}

	public String getVtext() {
		return vtext;
	}

	public void setVtext(String vtext) {
		this.vtext = vtext;
	}
	
	public static T179T getT179TByKey(EntityManager em, String system, Integer mandt, String spras, String prodh)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM T179T p where p.key.system = :system and p.key.mandt = :mandt and p.key.spras = :spras and p.key.prodh = :prodh",
						T179T.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("spras", spras);
		query.setParameter("prodh", prodh);	

		try {
			@SuppressWarnings("unchecked")
			List<T179T> list = query.getResultList();
			if (list.size() > 0)
			{
				return (T179T)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
}
