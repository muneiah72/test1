package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="COMPANYSORG")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)

public class COMPANYSORG {
	
	@EmbeddedId
	private COMPANYSORGPK key;
	@Column (length = 4)
	private String vkorg;
	
	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	
	@SuppressWarnings("unchecked")	
	public static COMPANYSORG getCOMPANYSORGByCompany(EntityManager em, String company)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM COMPANYSORG p where p.key.company = :company",
						COMPANYSORG.class);
		query.setParameter("company", company);

		try {
			List<COMPANYSORG> list = query.getResultList();
			if (list.size() > 0)
			{
				return (COMPANYSORG)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public static COMPANYSORG getCOMPANYSORGByKey(EntityManager em, COMPANYSORGPK key) {
		return em.find(COMPANYSORG.class, key);
	}
	
	@SuppressWarnings("unchecked")
	public static List<COMPANYSORG> getAllCompanysorgs(EntityManager em) {
		String queryString = "SELECT a FROM COMPANYSORG a";
		Query query = em.createQuery(queryString, COMPANYSORG.class);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}

	public COMPANYSORGPK getKey() {
		return key;
	}

	public void setKey(COMPANYSORGPK key) {
		this.key = key;
	}

}
