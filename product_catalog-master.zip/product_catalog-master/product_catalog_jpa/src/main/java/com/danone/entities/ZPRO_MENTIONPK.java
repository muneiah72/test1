package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPRO_MENTIONPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5394062841906829470L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 10)
	private String object;
	@Column(length = 10)
	private String content_type;
	@Column(length = 2)
	private String laiso;
	
	public ZPRO_MENTIONPK() {}

	public ZPRO_MENTIONPK(String system, Integer mandt, String object, String content_type, String laiso) {
		this.system = system;
		this.setMandt(mandt);
		this.setObject(object);
		this.setContent_type(content_type);
		this.setLaiso(laiso);
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getContent_type() {
		return content_type;
	}

	public void setContent_type(String content_type) {
		this.content_type = content_type;
	}

	public String getLaiso() {
		return laiso;
	}

	public void setLaiso(String laiso) {
		this.laiso = laiso;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPRO_MENTIONPK) && 
        		system.equals(((ZPRO_MENTIONPK)o).getSystem()) &&
        		mandt.equals(((ZPRO_MENTIONPK)o).getMandt()) &&
        		object.equals(((ZPRO_MENTIONPK)o).getObject()) &&
        		content_type.equals(((ZPRO_MENTIONPK)o).getContent_type()) &&
        		laiso.equals(((ZPRO_MENTIONPK)o).getLaiso()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ object.hashCode()
        		+ content_type.hashCode()
        		+ laiso.hashCode(); 
    }
}
