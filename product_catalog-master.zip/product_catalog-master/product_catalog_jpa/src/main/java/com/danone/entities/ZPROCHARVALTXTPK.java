package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPROCHARVALTXTPK implements java.io.Serializable {
	
	
	private static final long serialVersionUID = -3133737129454245036L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 30)
	private String atnam;
	@Column(length = 30)	
	private String atwrt;
	@Column(length = 1)	
	private String spras;
	
	public ZPROCHARVALTXTPK() {}

	public ZPROCHARVALTXTPK(String system, Integer mandt, String atnam, String atwrt, String spras) {
		this.system = system;
		this.setMandt(mandt);
		this.setAtnam(atnam);
		this.setAtwrt(atwrt);
		this.setSpras(spras);
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getAtnam() {
		return atnam;
	}

	public void setAtnam(String atnam) {
		this.atnam = atnam;
	}

	public String getAtwrt() {
		return atwrt;
	}

	public void setAtwrt(String atwrt) {
		this.atwrt = atwrt;
	}

	public String getSpras() {
		return spras;
	}

	public void setSpras(String spras) {
		this.spras = spras;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPROCHARVALTXTPK) && 
        		system.equals(((ZPROCHARVALTXTPK)o).getSystem()) &&
        		mandt.equals(((ZPROCHARVALTXTPK)o).getMandt()) &&        	
        		atnam.equals(((ZPROCHARVALTXTPK)o).getAtnam()) &&        	
        		atwrt.equals(((ZPROCHARVALTXTPK)o).getAtwrt()) &&        	
        		spras.equals(((ZPROCHARVALTXTPK)o).getSpras()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ atnam.hashCode()
        		+ atwrt.hashCode()
        		+ spras.hashCode(); 
    }

}
