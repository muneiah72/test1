package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZSUBRANGE")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZSUBRANGE {

	@EmbeddedId
	private ZSUBRANGEPK key;
	@Column(length = 30)
	private String zzsub_range_desc;
	
	public ZSUBRANGEPK getKey() {
		return key;
	}
	
	public void setKey(ZSUBRANGEPK key) {
		this.key = key;
	}

	public String getZzsub_range_desc() {
		return zzsub_range_desc;
	}

	public void setZzsub_range_desc(String zzsub_range_desc) {
		this.zzsub_range_desc = zzsub_range_desc;
	}
	
	public static ZSUBRANGE getZSUBRANGEByKey(EntityManager em, String system, Integer mandt, String zzsub_range)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZSUBRANGE p where p.key.system = :system and p.key.mandt = :mandt and p.key.zzsub_range = :zzsub_range",
						ZSUBRANGE.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("zzsub_range", zzsub_range);	

		try {
			@SuppressWarnings("unchecked")
			List<ZSUBRANGE> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZSUBRANGE)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
}
