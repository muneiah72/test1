package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="ZPROEU_QTY")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPROEU_QTY {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(ZPROEU_QTY.class);
	
	@EmbeddedId
	private ZPROEU_QTYPK key;
	private double fklmg;
	@Column(length = 3)
	private String meins;
	private double ntgew;
	@Column(length = 3)
	private String gewei;
	private java.sql.Date erdat;
	private java.sql.Date aedat;

	
	public ZPROEU_QTYPK getKey() {
		return key;
	}
	
	public void setKey(ZPROEU_QTYPK key) {
		this.key = key;
	}
	
	public double getNtgew() {
		return ntgew;
	}
	
	public void setNtgew(double ntgew) {
		this.ntgew = ntgew;
	}
	
	public String getGewei() {
		return gewei;
	}
	
	public void setGewei(String gewei) {
		this.gewei = gewei;
	}
	
	public java.sql.Date getErdat() {
		return erdat;
	}
	
	public void setErdat(java.sql.Date erdat) {
		this.erdat = erdat;
	}
	
	public java.sql.Date getAedat() {
		return aedat;
	}
	
	public void setAedat(java.sql.Date aedat) {
		this.aedat = aedat;
	}

	public double getFklmg() {
		return fklmg;
	}

	public void setFklmg(double fklmg) {
		this.fklmg = fklmg;
	}

	public String getMeins() {
		return meins;
	}

	public void setMeins(String meins) {
		this.meins = meins;
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueCountries(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.key.ctrydest) FROM ZPROEU_QTY z";
		Query query = em.createQuery(queryString, ZPROEU_QTY.class);
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPROEU_QTY> getZPROEU_QTYBySearch(EntityManager em, String system, Integer mandt, String matnr) {
		String queryString = "SELECT z FROM ZPROEU_QTY z WHERE z.key.mandt = :mandt AND z.key.system = :system AND z.key.matnr = :matnr ORDER BY z.fklmg DESC";
		Query query = em.createQuery(queryString, ZPROEU_QTY.class);
		query.setParameter("mandt", mandt);
		query.setParameter("system", system);
		query.setParameter("matnr", matnr);
		
		try {
			List<ZPROEU_QTY> list = query.getResultList();
			LOGGER.debug("List: " + list.size());
			return list;
		} catch (NoResultException e) {
			LOGGER.debug("ZPROEU_QTY getZPROEU_QTYBySearch: " + e.toString());
			return Collections.emptyList();
		}
	}
}
