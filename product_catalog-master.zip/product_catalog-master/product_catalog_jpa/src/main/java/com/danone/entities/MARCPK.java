package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MARCPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2985067689671526088L;

	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 18)
	private String matnr;
	@Column(length = 4)
	private String werks;
	
	public MARCPK() {}

	public MARCPK(String system, Integer mandt, String matnr, String plant) {
		this.system = system;
        this.mandt = mandt;
        this.matnr = matnr;
        this.werks = plant;
    }
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getWerks() {
		return werks;
	}

	public void setWerks(String werks) {
		this.werks = werks;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof MARCPK) && 
        		system.equals(((MARCPK)o).getSystem()) &&
        		mandt.equals(((MARCPK)o).getMandt()) &&
        		matnr.equals(((MARCPK)o).getMatnr()) &&
        		werks.equals(((MARCPK)o).getWerks()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ matnr.hashCode() 
        		+ werks.hashCode(); 
    }
	
	
}
