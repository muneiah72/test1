package com.danone.entities;

import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="T002")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class T002 {

	@EmbeddedId
	private T002PK key;

	private String laspez;
	private String lahq;
	private String laiso;

	public T002PK getKey() {
		return key;
	}

	public void setKey(T002PK key) {
		this.key = key;
	}

	public String getLaiso() {
		return laiso;
	}

	public void setLaiso(String laiso) {
		this.laiso = laiso;
	}

	public String getLaspez() {
		return laspez;
	}

	public void setLaspez(String laspez) {
		this.laspez = laspez;
	}

	public String getLahq() {
		return lahq;
	}

	public void setLahq(String lahq) {
		this.lahq = lahq;
	}

	public static T002 getByKey(EntityManager em, String spras) {
		Query query = em
				.createQuery(
						"SELECT p FROM T002 p where p.key.spras = :spras",
						T002.class);
		query.setParameter("spras", spras);
		
		try {
			return (T002) query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	@SuppressWarnings("unchecked")	
	public static String getSprasByLaiso(EntityManager em, String laiso)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM T002 p where p.laiso = :laiso",
						T002.class);
		query.setParameter("laiso", laiso);
		
		try {
			List<T002> list = query.getResultList();
			if (list.size() > 0)
			{
				return list.get(0).key.getSpras();
			}else {
				return laiso.substring(0, 1);
			}
		} catch (NoResultException e) {
			return laiso.substring(0, 1);
		}
	}	

}

