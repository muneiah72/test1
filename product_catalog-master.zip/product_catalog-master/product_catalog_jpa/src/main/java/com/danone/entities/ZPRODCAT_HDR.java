package com.danone.entities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.FetchType;
import javax.persistence.NoResultException;
import javax.persistence.OneToMany;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="ZPRODCAT_HDR")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPRODCAT_HDR {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(ZPRODCAT_HDR.class);
	
	@EmbeddedId
	private ZPRODCAT_HDRPK key;
	
	private String matnr;
	private String vkorg;
	private String vtweg;
	private String asort;	
	private Integer verno;
	private String status;
	private java.sql.Date erdat;
	private java.sql.Date erzet;
	private String ernam;
	private java.sql.Date aedat;
	private java.sql.Date aezet;
	private String aenam;
	private String prinbr;
	private String productgroup;
	private String ean_upc_base;
	private String status_prev;
	private java.sql.Date status_date;
	@OneToMany (targetEntity=ZPRODCAT_ITEM.class, 
		    fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	private Collection<ZPRODCAT_ITEM> itemCollection;
	
	public ZPRODCAT_HDR() {
		itemCollection = new ArrayList<ZPRODCAT_ITEM>();
	}
	
	/*
	public void addItem(ZPRODCAT_ITEM item){
		if (!getItems().contains(item)) {
            getItems().add(item);
            if (item.getHdr() != null) {
                item.getHdr().getItems().remove(item);
            }
            item.setHdr(this);
        }
	}
	*/
	
	public Collection<ZPRODCAT_ITEM> getItems() {
        return itemCollection;
    }
	
	public static ZPRODCAT_HDR getHeaderByCatGuid(EntityManager em, String system, String catguid) {
		Query query = em
				.createQuery(
						"SELECT p FROM ZPRODCAT_HDR p where p.key.system = :system and p.key.cat_guid = :catguid",
						ZPRODCAT_HDR.class);
		query.setParameter("system", system);
		query.setParameter("catguid", catguid);
		try {
			return (ZPRODCAT_HDR) query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPRODCAT_HDR> getAllProducts(EntityManager em, String system) {
		Query query = em
				.createQuery(
						"SELECT p FROM ZPRODCAT_HDR p where p.key.system = :system",
						ZPRODCAT_HDR.class);
		query.setParameter("system", system);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPRODCAT_HDR> getAllProductsWithQuery(EntityManager em, Query query) {
		
		LOGGER.debug("ZPRODCAT_HDR getAllProductsWithQuery: " + query);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			LOGGER.debug("Error while fetching all products by query " + query);
			LOGGER.debug(e.toString());
			return Collections.emptyList();
		}
	}
	
	public ZPRODCAT_HDRPK getKey() {
		return key;
	}
	
	public void setKey(ZPRODCAT_HDRPK key) {
		this.key = key;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}

	public String getAsort() {
		return asort;
	}

	public void setAsort(String asort) {
		this.asort = asort;
	}

	public Integer getVerno() {
		return verno;
	}

	public void setVerno(Integer verno) {
		this.verno = verno;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErnam() {
		return ernam;
	}

	public void setErnam(String ernam) {
		this.ernam = ernam;
	}

	public String getAenam() {
		return aenam;
	}

	public void setAenam(String aenam) {
		this.aenam = aenam;
	}

	public Date getErdat() {
		return erdat;
	}

	public void setErdat(Date erdat) {
		this.erdat = erdat;
	}

	public Date getErzet() {
		return erzet;
	}

	public void setErzet(Date erzet) {
		this.erzet = erzet;
	}

	public Date getAedat() {
		return aedat;
	}

	public void setAedat(Date aedat) {
		this.aedat = aedat;
	}

	public Date getAezet() {
		return aezet;
	}

	public void setAezet(Date aezet) {
		this.aezet = aezet;
	}

	public String getPrinbr() {
		return prinbr;
	}

	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}

	public String getProductgroup() {
		return productgroup;
	}

	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}

	public String getEan_upc_base() {
		return ean_upc_base;
	}

	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}
	
	public java.sql.Date getStatus_date() {
		return status_date;
	}

	public void setStatus_date(java.sql.Date status_date) {
		this.status_date = status_date;
	}

	public String getStatus_prev() {
		return status_prev;
	}

	public void setStatus_prev(String status_prev) {
		this.status_prev = status_prev;
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPRODCAT_HDR> getVersions(String system, String vkorg, String vtweg, String matnr, ZPRO_ASSORTMENT asort, EntityManager em) {
		String queryString = "SELECT p FROM ZPRODCAT_HDR p where p.key.system = :system and p.vkorg = :vkorg and p.vtweg = :vtweg and p.matnr = :matnr and p.prinbr = :prinbr ORDER BY p.verno ASC";
		Query query = em.createQuery(queryString, ZPRODCAT_HDR.class).setParameter("vkorg", vkorg).setParameter("vtweg", vtweg).setParameter("matnr", matnr).setParameter("prinbr", asort.getPrinbr()).setParameter("system", system);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
}
