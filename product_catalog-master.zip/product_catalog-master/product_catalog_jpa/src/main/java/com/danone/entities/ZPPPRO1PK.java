package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPPRO1PK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5394062841906829470L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zrocess1;
	
	public ZPPPRO1PK() {}

	public ZPPPRO1PK(String system, Integer mandt, String zrocess1) {
		this.system = system;
		this.setMandt(mandt);
		this.setZrocess1(zrocess1);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZrocess1() {
		return zrocess1;
	}

	public void setZrocess1(String zrocess1) {
		this.zrocess1 = zrocess1;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPPRO1PK) && 
        		system.equals(((ZPPPRO1PK)o).getSystem()) &&
        		mandt.equals(((ZPPPRO1PK)o).getMandt()) &&        	
        		zrocess1.equals(((ZPPPRO1PK)o).getZrocess1()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zrocess1.hashCode(); 
    }

}
