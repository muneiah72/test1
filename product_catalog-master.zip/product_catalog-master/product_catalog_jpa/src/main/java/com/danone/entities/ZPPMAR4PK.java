package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPMAR4PK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 116505148780872636L;
	/**
	 * 
	 */

	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zmarkiv;
	
	public ZPPMAR4PK() {}

	public ZPPMAR4PK(String system, Integer mandt, String zmarkiv) {
		this.system = system;
		this.setMandt(mandt);
		this.setZmarkiv(zmarkiv);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPMAR4PK) && 
        		system.equals(((ZPPMAR4PK)o).getSystem()) &&
        		mandt.equals(((ZPPMAR4PK)o).getMandt()) &&        	
        		zmarkiv.equals(((ZPPMAR4PK)o).getZmarkiv()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zmarkiv.hashCode(); 
    }

	public String getZmarkiv() {
		return zmarkiv;
	}

	public void setZmarkiv(String zmarkiv) {
		this.zmarkiv = zmarkiv;
	}

}
