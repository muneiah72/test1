package com.danone.persistence;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "CACHE_COMMANDS")
@TableGenerator(name = "commandIdGenerator", allocationSize = 1)
public class CacheCommands {

	public static enum Commands {
		ACTIVATE_CACHE, CLEAR_CACHE, DELETE_ENTRY
	}

	@Id
	@GeneratedValue(generator = "commandIdGenerator", strategy = GenerationType.TABLE)
	private long id;

	@Enumerated(EnumType.STRING)
	private Commands command;

	@Column(length = 2048)
	private String value;

	public long getID() {
		return id;
	}

	public Commands getCommand() {
		return command;
	}

	public void setCommand(Commands command) {
		this.command = command;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("ID: ").append(id).append(" Command: ").append(command.toString()).append(" Value: ").append(value);
		return sb.toString();
	}

}
