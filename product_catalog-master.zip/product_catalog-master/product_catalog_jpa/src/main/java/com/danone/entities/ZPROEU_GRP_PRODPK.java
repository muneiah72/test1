package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPROEU_GRP_PRODPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -794636509731117064L;
	
	@Column (length = 50)
	private String system;
	@Column(length = 3)
	private Integer mandt;
	@Column(length = 4)
	private String vkorg;
	@Column(length = 2)
	private String spart;
	@Column(length = 18)
	private String matnr;
	
	public ZPROEU_GRP_PRODPK() {}
	
	public ZPROEU_GRP_PRODPK(String system, Integer mandt, String vkorg, String spart, String matnr) {
		this.system = system;
		this.mandt = mandt;
		this.vkorg = vkorg;
		this.spart = spart;
		this.matnr = matnr;
	}
	
	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getSpart() {
		return spart;
	}

	public void setSpart(String spart) {
		this.spart = spart;
	}
	
	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPROEU_GRP_PRODPK) && 
        		system.equals(((ZPROEU_GRP_PRODPK)o).getSystem()) &&
        		mandt.equals(((ZPROEU_GRP_PRODPK)o).getMandt()) &&
        		vkorg.equals(((ZPROEU_GRP_PRODPK)o).getVkorg()) &&
        		spart.equals(((ZPROEU_GRP_PRODPK)o).getSpart()) &&
        		matnr.equals(((ZPROEU_GRP_PRODPK)o).getMatnr()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()
        		+ vkorg.hashCode() 
        		+ spart.hashCode()
        		+ matnr.hashCode(); 
    }

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
}
