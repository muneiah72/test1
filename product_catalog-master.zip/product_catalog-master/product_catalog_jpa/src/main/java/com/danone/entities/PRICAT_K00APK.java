package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PRICAT_K00APK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3965017352425168832L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	private String prinbr;
	private String assortment;
	
	public PRICAT_K00APK() {}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getPrinbr() {
		return prinbr;
	}

	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}
	
	public String getAssortment() {
		return assortment;
	}

	public void setAssortment(String assortment) {
		this.assortment = assortment;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof PRICAT_K00APK) && 
        		system.equals(((PRICAT_K00APK)o).getSystem()) &&
        		mandt.equals(((PRICAT_K00APK)o).getMandt()) &&
        		prinbr.equals(((PRICAT_K00APK)o).getPrinbr()) &&
        		assortment.equals(((PRICAT_K00APK)o).getAssortment()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ prinbr.hashCode() 
        		+ assortment.hashCode(); 
    }
}
