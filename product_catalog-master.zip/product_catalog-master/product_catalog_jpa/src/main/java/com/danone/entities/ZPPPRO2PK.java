package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPPRO2PK implements java.io.Serializable {
	

	private static final long serialVersionUID = -4988637359341289804L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zrocess2;
	
	public ZPPPRO2PK() {}

	public ZPPPRO2PK(String system, Integer mandt, String zrocess2) {
		this.system = system;
		this.setMandt(mandt);
		this.setZrocess2(zrocess2);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZrocess2() {
		return zrocess2;
	}

	public void setZrocess2(String zrocess2) {
		this.zrocess2 = zrocess2;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPPRO2PK) && 
        		system.equals(((ZPPPRO2PK)o).getSystem()) &&
        		mandt.equals(((ZPPPRO2PK)o).getMandt()) &&        	
        		zrocess2.equals(((ZPPPRO2PK)o).getZrocess2()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zrocess2.hashCode(); 
    }

}
