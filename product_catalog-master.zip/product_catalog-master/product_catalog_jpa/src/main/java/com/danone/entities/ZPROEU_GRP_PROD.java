package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.codehaus.plexus.util.StringUtils;
import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPROEU_GRP_PROD")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPROEU_GRP_PROD {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(ZPROEU_GRP_PROD.class);
	
	@EmbeddedId
	private ZPROEU_GRP_PRODPK key;
	@Column(length = 10)
	private String group1;
	@Column(length = 10)
	private String group2;
	@Column(length = 10)
	private String group3;
	@Column(length = 10)
	private String group4;
	@Column(length = 10)
	private String group5;
	@Column(length = 10)
	private String group6;
	@Column(length = 10)
	private String group7;
	@Column(length = 10)
	private String group8;
	@Column(length = 10)
	private String group9;
	@Column(length = 10)
	private String group10;
	@Column(length = 4)
	private String typbrand;
	@Column(length = 35)
	private String brand;
	@Column(length = 4)
	private String subbrand;
	@Column(length = 4)
	private String level4;
	@Column(length = 3)
	private String zzproces1;
	@Column(length = 31)
	private String zzflavor;
	private Integer zzby;
	@Column(length = 30)
	private String label_code;
	private double ntgew;
	private String gewei;
	private double mhdhb;
	private java.sql.Date erdat;
	private java.sql.Date aedat;
	private double stprs;	
	@Column(length = 22)
	private String uuid;
	@Column(length = 3)
	private String zzpot_diam;
	@Column(length = 3)
	private String zzrange;
	@Column(length = 3)
	private String zzsub_range;
	
	public ZPROEU_GRP_PRODPK getKey() {
		return key;
	}
	
	public void setKey(ZPROEU_GRP_PRODPK key) {
		this.key = key;
	}
	
	public String getGroup1() {
		return group1;
	}
	
	public void setGroup1(String group1) {
		this.group1 = group1;
	}
	
	public String getGroup2() {
		return group2;
	}
	
	public void setGroup2(String group2) {
		this.group2 = group2;
	}
	
	public String getGroup3() {
		return group3;
	}
	
	public void setGroup3(String group3) {
		this.group3 = group3;
	}
	
	public String getGroup4() {
		return group4;
	}
	
	public void setGroup4(String group4) {
		this.group4 = group4;
	}
	
	public String getGroup5() {
		return group5;
	}
	
	public void setGroup5(String group5) {
		this.group5 = group5;
	}
	
	public String getGroup6() {
		return group6;
	}
	
	public void setGroup6(String group6) {
		this.group6 = group6;
	}
	
	public String getGroup7() {
		return group7;
	}
	
	public void setGroup7(String group7) {
		this.group7 = group7;
	}
	
	public String getGroup8() {
		return group8;
	}
	
	public void setGroup8(String group8) {
		this.group8 = group8;
	}
	
	public String getGroup9() {
		return group9;
	}
	
	public void setGroup9(String group9) {
		this.group9 = group9;
	}
	
	public String getGroup10() {
		return group10;
	}
	
	public void setGroup10(String group10) {
		this.group10 = group10;
	}
	
	public String getTypbrand() {
		return typbrand;
	}
	
	public void setTypbrand(String typbrand) {
		this.typbrand = typbrand;
	}
	
	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getSubbrand() {
		return subbrand;
	}
	
	public void setSubbrand(String subbrand) {
		this.subbrand = subbrand;
	}
	
	public String getLevel4() {
		return level4;
	}
	
	public void setLevel4(String level4) {
		this.level4 = level4;
	}
	
	public String getZzproces1() {
		return zzproces1;
	}
	
	public void setZzproces1(String zzproces1) {
		this.zzproces1 = zzproces1;
	}
	
	public String getZzflavor() {
		return zzflavor;
	}
	
	public void setZzflavor(String zzflavor) {
		this.zzflavor = zzflavor;
	}
	
	public Integer getZzby() {
		return zzby;
	}
	
	public void setZzby(Integer zzby) {
		this.zzby = zzby;
	}
	
	public double getNtgew() {
		return ntgew;
	}
	
	public void setNtgew(double ntgew) {
		this.ntgew = ntgew;
	}
	
	public String getGewei() {
		return gewei;
	}
	
	public void setGewei(String gewei) {
		this.gewei = gewei;
	}
	
	public double getMhdhb() {
		return mhdhb;
	}
	
	public void setMhdhb(double mhdhb) {
		this.mhdhb = mhdhb;
	}
	
	public java.sql.Date getErdat() {
		return erdat;
	}
	
	public void setErdat(java.sql.Date erdat) {
		this.erdat = erdat;
	}
	
	public java.sql.Date getAedat() {
		return aedat;
	}
	
	public void setAedat(java.sql.Date aedat) {
		this.aedat = aedat;
	}

	public double getStprs() {
		return stprs;
	}

	public void setStprs(double stprs) {
		this.stprs = stprs;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public String getLabel_code() {
		return label_code;
	}
	
	public void setLabel_code(String labelcode) {
		this.label_code = labelcode;
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPROEU_GRP_PROD> getZPROEU_GRP_PRODBySearch(EntityManager em, String searchString, JSONArray brandArray, JSONArray brandCatArray, JSONArray fatcontentArray, JSONArray subrangeArray,
			JSONArray processTechArray, JSONArray cupTypeArray, JSONArray multilayerArray, JSONObject weight, JSONObject price, JSONArray topperArray, JSONArray weightArray) {
		String queryString = "SELECT z FROM ZPROEU_GRP_PROD z ";
		
		if (searchString.length() > 0 || brandArray.length() > 0 || brandCatArray.length() > 0 || fatcontentArray.length() > 0 
				|| subrangeArray.length() > 0 || processTechArray.length() > 0 || cupTypeArray.length() > 0
				|| multilayerArray.length() > 0 || (weight.has("value1") == true) || (price.has("value1") == true) || topperArray.length() > 0 || weightArray.length() > 0)
		{
			queryString = queryString + "where ";
		}
			
		if (searchString.length() > 0)
		{
			LOGGER.debug("Search string: " + searchString);
			String[] splitStr = StringUtils.split(searchString, " ");
			LOGGER.debug("Search string splitted length: " + splitStr.length);
			if (splitStr.length > 1)
			{
				queryString = queryString + "( ";
				
				for (int i = 0; i < splitStr.length; i++)
				{
					LOGGER.debug(i + " search word: " + splitStr[i]);
					if (i > 0)
					{
						queryString = queryString + "OR ";
					}
					queryString = queryString + "( UPPER(z.zzflavor) = UPPER(:search" + i + ") "
							+ "or UPPER(z.brand) = UPPER(:search" + i + ") or UPPER(z.zzproces1) = UPPER(:search" + i + ") ) ";
				}
				
				queryString = queryString + ") ";
			}else {
				queryString = queryString + "( UPPER(z.zzflavor) = UPPER(:search) "
						+ "or UPPER(z.brand) = UPPER(:search) or UPPER(z.zzproces1) = UPPER(:search) ) ";
			}
		}
		
		if (brandArray.length() > 0 && searchString.length() > 0)
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < brandArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.brand) = UPPER(:pbrand" + i + ") ";
            if (i == (brandArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }

		if (brandCatArray.length() > 0 && searchString.length() > 0)
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < brandCatArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.group8) = UPPER(:pbrandcat" + i + ") ";
            if (i == (brandCatArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }		
		
		if (fatcontentArray.length() > 0 && (searchString.length() > 0 || brandArray.length() > 0))
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < fatcontentArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.subbrand) = UPPER(:psubbrand" + i + ") ";
            if (i == (fatcontentArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }
		
		if (subrangeArray.length() > 0 && (searchString.length() > 0 || brandArray.length() > 0 || fatcontentArray.length() > 0))
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < subrangeArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.level4) = UPPER(:psubrange" + i + ") ";
            if (i == (subrangeArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }
		
		if (processTechArray.length() > 0 && (searchString.length() > 0 || brandArray.length() > 0 || fatcontentArray.length() > 0 || subrangeArray.length() > 0))
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < processTechArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.zzproces1) = UPPER(:pzzproces" + i + ") ";
            if (i == (processTechArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }
		
		if (cupTypeArray.length() > 0 && (searchString.length() > 0 || brandArray.length() > 0 || fatcontentArray.length() > 0 || subrangeArray.length() > 0 || processTechArray.length() > 0))
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < cupTypeArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.zzpot_diam) = UPPER(:pzzcuptype" + i + ") ";
            if (i == (cupTypeArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }
		if (multilayerArray.length() > 0 && (searchString.length() > 0 || brandArray.length() > 0 || fatcontentArray.length() > 0 || subrangeArray.length() > 0 || processTechArray.length() > 0 || cupTypeArray.length() > 0))
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < multilayerArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.zzsub_range) = UPPER(:pmulti" + i + ") ";
            if (i == (multilayerArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }
		if (weight.has("value1") == true && weightArray.length() > 0 && (searchString.length() > 0 || brandArray.length() > 0 || fatcontentArray.length() > 0 || subrangeArray.length() > 0 || processTechArray.length() > 0 || cupTypeArray.length() > 0 || multilayerArray.length() > 0))
		{
			queryString = queryString + "AND ";
		}
		
		if ((weight.has("value1") == true || weightArray.length() > 0))
        {
			if (weight.has("value1") == true)
			{
				if (weightArray.length() > 0)
				{
					queryString = queryString + "( ";
				}
				queryString = queryString + "( z.ntgew BETWEEN :pweightval1 AND :pweightval2 ) ";
			}
			if (weightArray.length() > 0)
			{
				if (weight.has("value1"))
				{
					queryString = queryString + "OR ";
				}
				if (weightArray.length() > 1)
				{
					queryString = queryString + "( ";
				}
				for(int i=0; i < weightArray.length(); i++)
				{
					if (i > 0)
					{
						queryString = queryString + "OR ";
					}
					
					int value = weightArray.getInt(i);
					
					if (value == 1)
					{
						queryString = queryString + "( z.ntgew BETWEEN 500 AND 1000 ) ";
					}else if (value == 2)
					{
						queryString = queryString + "( z.ntgew >= 1000 ) ";
					}
				}
				if (weightArray.length() > 1)
				{
					queryString = queryString + ") ";
				}
				if (weight.has("value1"))
				{
					queryString = queryString + ") ";
				}
			}
        }
		if (price.has("value1") == true && (searchString.length() > 0 || brandArray.length() > 0 || fatcontentArray.length() > 0 || subrangeArray.length() > 0 || processTechArray.length() > 0 || cupTypeArray.length() > 0 || multilayerArray.length() > 0 || (weight.has("value1") == true || weightArray.length() > 0)))
		{
			queryString = queryString + "AND ";
		}
		if (price.has("value1") == true)
        {
			queryString = queryString + "( z.ztprs BETWEEN :ppriceval1 AND :ppriceval2 ) ";
        }
		
		if (topperArray.length() > 0 && (searchString.length() > 0 || brandArray.length() > 0 || fatcontentArray.length() > 0 || subrangeArray.length() > 0 || processTechArray.length() > 0 || cupTypeArray.length() > 0 || multilayerArray.length() > 0 || (weight.has("value1") == true || weightArray.length() > 0) || price.has("value1") == true))
		{
			queryString = queryString + "AND ";
		}
		for(int i=0; i < topperArray.length(); i++)
        {
            if (i == 0)
            {
            	 queryString = queryString + "( ";
            }else {
            	queryString = queryString + "OR ";
            }
            queryString = queryString + "UPPER(z.zzrange) = UPPER(:ptopper" + i + ") ";
            if (i == (topperArray.length() - 1))
            {
            	queryString = queryString + ") ";
            }
        }
		
		queryString = queryString + "ORDER BY z.group1, z.group2, z.group3, z.group4, z.group5, z.group6, z.group7, z.group8, z.group9, z.group10, z.key.matnr";
		LOGGER.debug(queryString);
		
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		if (searchString.length() > 0)
		{
			String[] splitStr = StringUtils.split(searchString, " ");
			LOGGER.debug("Number of search words: " + splitStr.length);
			if (splitStr.length > 1)
			{
				for (int i=0; i < splitStr.length; i++)
				{
					String search = splitStr[i];
		            query.setParameter("search" + i, search);
		            LOGGER.debug("Search on: " + search);
				}
			}else {
				query.setParameter("search", searchString);
			}
			
		}
		for(int i=0; i < brandArray.length(); i++)
        {
			String brand = brandArray.getString(i);
            query.setParameter("pbrand" + i, brand);
        }
		for(int i=0; i < brandCatArray.length(); i++)
        {
			String brandcat = brandCatArray.getString(i);
            query.setParameter("pbrandcat" + i, brandcat);
        }		
		for(int i=0; i < fatcontentArray.length(); i++)
        {
			String subbrand = fatcontentArray.getString(i);
            query.setParameter("psubbrand" + i, subbrand);
        }
		for(int i=0; i < subrangeArray.length(); i++)
        {
			String subrange = subrangeArray.getString(i);
            query.setParameter("psubrange" + i, subrange);
        }
		for(int i=0; i < processTechArray.length(); i++)
        {
			String ptech = processTechArray.getString(i);
            query.setParameter("pzzproces" + i, ptech);
        }
		for(int i=0; i < cupTypeArray.length(); i++)
        {
			String cupType = cupTypeArray.getString(i);
            query.setParameter("pzzcuptype" + i, cupType);
        }
		for(int i=0; i < multilayerArray.length(); i++)
        {
			String multi = multilayerArray.getString(i);
            query.setParameter("pmulti" + i, multi);
        }
		if (weight.has("value1") == true)
        {
			double val1 = weight.getDouble("value1");
			double val2 = weight.getDouble("value2");
			query.setParameter("pweightval1", val1);
			query.setParameter("pweightval2", val2);
        }
		if (price.has("value1") == true)
        {
			double val1 = weight.getDouble("value1");
			double val2 = weight.getDouble("value2");
			query.setParameter("ppriceval1", val1);
			query.setParameter("ppriceval2", val2);
        }
		for(int i=0; i < topperArray.length(); i++)
        {
			String topper = topperArray.getString(i);
            query.setParameter("ptopper" + i, topper);
        }
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueBrands(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.brand) FROM ZPROEU_GRP_PROD z";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueBrandCat(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.group8) FROM ZPROEU_GRP_PROD z where z.group8 != :empty";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		query.setParameter("empty", "");
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueMultilayer(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.group7) FROM ZPROEU_GRP_PROD z where z.group7 != :empty";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		query.setParameter("empty", "");
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueTopper(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.group3) FROM ZPROEU_GRP_PROD z";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniquePotdiams(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.zzpot_diam) FROM ZPROEU_GRP_PROD z";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueProcessTechnology(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.zzproces1) FROM ZPROEU_GRP_PROD z";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueSubrange(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.level4) FROM ZPROEU_GRP_PROD z";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<String> getUniqueFatcontent(EntityManager em) {
		String queryString = "SELECT DISTINCT(z.subbrand) FROM ZPROEU_GRP_PROD z";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		
		try {
			List<String> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public static ZPROEU_GRP_PROD getZPROEU_GRP_PRODByMandtAndGuid(EntityManager em, String system, Integer mandt, String guid) {
		String queryString = "SELECT z FROM ZPROEU_GRP_PROD z where z.key.system = :system and z.key.mandt = :mandt and z.uuid = :guid and z.group1 <> ''";
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		query.setParameter("mandt", mandt);
		query.setParameter("guid", guid);
		query.setParameter("system", system);
		
		try {
			@SuppressWarnings("unchecked")
			List<ZPROEU_GRP_PROD> list = query.getResultList();
			if (list.size() > 0)
			{
				return list.get(0);
			}
			return null;
		} catch (NoResultException e) {
			return null;
		}
	}

	public String getZzpot_diam() {
		return zzpot_diam;
	}

	public void setZzpot_diam(String zzpot_diam) {
		this.zzpot_diam = zzpot_diam;
	}

	public String getZzsub_range() {
		return zzsub_range;
	}

	public void setZzsub_range(String zzsub_range) {
		this.zzsub_range = zzsub_range;
	}

	public String getZzrange() {
		return zzrange;
	}

	public void setZzrange(String zzrange) {
		this.zzrange = zzrange;
	}
	
	public static List<ZPROEU_GRP_PROD> getZPROEU_GRP_PRODByMandt(EntityManager em, String system, Integer mandt, String vkorg, String spart, String group1, String group2, String group3, String group4, String group5, String group6, String group7, String group8, String group9, String group10) {
		//String queryString = "SELECT z FROM ZPROEU_GRP_PROD z where z.key.system = :system and "
		//		+ "z.key.mandt = :mandt and z.key.vkorg = :vkorg and z.key.spart = :spart";
		
		String queryString = "SELECT z FROM ZPROEU_GRP_PROD z where";
		
		queryString = queryString + " z.group1 = :group1";
		queryString = queryString + " and z.group2 = :group2";
		queryString = queryString + " and z.group3 = :group3";
		queryString = queryString + " and z.group4 = :group4";
		queryString = queryString + " and z.group5 = :group5";
		queryString = queryString + " and z.group6 = :group6";
		queryString = queryString + " and z.group7 = :group7";
		queryString = queryString + " and z.group8 = :group8";
		queryString = queryString + " and z.group9 = :group9";
		queryString = queryString + " and z.group10 = :group10";
		
		LOGGER.debug(queryString);
		Query query = em.createQuery(queryString, ZPROEU_GRP_PROD.class);
		
		//query.setParameter("system", system);
		//query.setParameter("mandt", mandt);
		//query.setParameter("vkorg", vkorg);
		//query.setParameter("spart", spart);
		query.setParameter("group1", group1);
		query.setParameter("group2", group2);
		query.setParameter("group3", group3);
		query.setParameter("group4", group4);
		query.setParameter("group5", group5);
		query.setParameter("group6", group6);
		query.setParameter("group7", group7);
		query.setParameter("group8", group8);
		query.setParameter("group9", group9);
		query.setParameter("group10", group10);
		
		try {
			@SuppressWarnings("unchecked")
			List<ZPROEU_GRP_PROD> list = query.getResultList();
			return list;
		} catch (NoResultException e) {
			return null;
		}
	}
}
