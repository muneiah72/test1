package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ReplicationInfo")
@TableGenerator(name = "replicationIdGenerator", allocationSize = 1)
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ReplicationInfo {
	
	@Id
	@GeneratedValue(generator = "replicationIdGenerator", strategy = GenerationType.TABLE)
	private long id;
	
	private java.sql.Date startDate;
	private java.sql.Time time;
	private Boolean isManual;
	private String user;
	
	public java.sql.Date getStartDate() {
		return startDate;
	}
	
	public void setStartDate(java.sql.Date startDate) {
		this.startDate = startDate;
	}

	public Boolean getIsManual() {
		return isManual;
	}

	public void setIsManual(Boolean isManual) {
		this.isManual = isManual;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	public java.sql.Time getTime() {
		return time;
	}

	public void setTime(java.sql.Time time) {
		this.time = time;
	}
	
	@SuppressWarnings("unchecked")
	public static List<ReplicationInfo> getAllReplicationInfo(EntityManager em) {
		Query query = em.createQuery("SELECT r FROM ReplicationInfo AS r ORDER BY r.id DESC");

		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
}
