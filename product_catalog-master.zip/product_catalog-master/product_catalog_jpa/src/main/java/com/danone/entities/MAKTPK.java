package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MAKTPK implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5795409903514422343L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 18)
	private String matnr;
	@Column(length = 1)
	private String spras;
	
	public MAKTPK() {}

	public MAKTPK(String system, Integer mandt, String matnr, String spras) {
		this.system = system;
        this.mandt = mandt;
        this.matnr = matnr;
        this.spras = spras;
    }
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getSpras() {
		return spras;
	}

	public void setSpras(String spras) {
		this.spras = spras;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof MAKTPK) && 
        		system.equals(((MAKTPK)o).getSystem()) &&
        		mandt.equals(((MAKTPK)o).getMandt()) &&
        		matnr.equals(((MAKTPK)o).getMatnr()) &&
        		spras.equals(((MAKTPK)o).getSpras()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ matnr.hashCode() 
        		+ spras.hashCode();
    }
}
