package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EntityManager;

@Embeddable
public class MARAPK implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1131036499661395168L;

	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 18)
	private String matnr;
	
	public MARAPK() {}
	
	public MARAPK(String system, Integer mandt, String matnr) {
		this.system = system;
        this.mandt = mandt;
        this.matnr = matnr;
    }
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof MARAPK) && 
        		system.equals(((MARAPK)o).getSystem()) &&
        		mandt.equals(((MARAPK)o).getMandt()) &&
        		matnr.equals(((MARAPK)o).getMatnr()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ matnr.hashCode(); 
    }
    
}
