package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MVKEPK implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7726600837849073387L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 18)
	private String matnr;
	@Column(length = 4)
	private String vkorg;
	@Column(length = 2)
	private String vtweg;
	
	public MVKEPK() {}
	
	public MVKEPK(String system, Integer mandt, String matnr, String vkorg, String vtweg) {
		this.system = system;
        this.mandt = mandt;
        this.matnr = matnr;
        this.vkorg = vkorg;
        this.vtweg = vtweg;
    }
	
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	
	public Integer getMandt() {
		return mandt;
	}
	
	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getMatnr() {
		return matnr;
	}

	public void setMatnr(String matnr) {
		this.matnr = matnr;
	}

	public String getVkorg() {
		return vkorg;
	}

	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}

	public String getVtweg() {
		return vtweg;
	}

	public void setVtweg(String vtweg) {
		this.vtweg = vtweg;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof MVKEPK) && 
        		system.equals(((MVKEPK)o).getSystem()) &&
        		mandt.equals(((MVKEPK)o).getMandt()) &&
        		matnr.equals(((MVKEPK)o).getMatnr()) &&
        		vkorg.equals(((MVKEPK)o).getVkorg()) &&
        		vtweg.equals(((MVKEPK)o).getVtweg()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ matnr.hashCode() 
        		+ vkorg.hashCode() 
        		+ vtweg.hashCode();
    }
}
