package com.danone.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="MAKT")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class MAKT {
	
	@EmbeddedId
	private MAKTPK key;
	private String maktx;
	
	public MAKTPK getKey() {
		return key;
	}
	
	public void setKey(MAKTPK key){
		this.key = key;
	}
	
	public String getMaktx() {
		return maktx;
	}
	
	public void setMaktx(String maktx) {
		this.maktx = maktx;
	}
	
	public static MAKT getMAKTByKey(EntityManager em, MAKTPK key) {
		return em.find(MAKT.class, key);
	}
}
