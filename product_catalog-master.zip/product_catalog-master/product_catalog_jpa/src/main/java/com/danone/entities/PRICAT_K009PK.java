package com.danone.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PRICAT_K009PK implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8781728799210432225L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 10)
	private String prinbr;
	@Column(length = 18)
	private String productgroup;
	@Column(length = 35)
	private String ean_upc_altunit;
	private java.sql.Date validity_unit;
	@Column(length = 3)
	private String cond_qualifier;
	@Column(length = 4)
	private String cond_type;
	@Column(length = 4)
	private String line_number;
	
	public PRICAT_K009PK() {}
	
	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}
	
	public String getSystem() {
		return system;
	}
	
	public void setSystem(String system) {
		this.system = system;
	}
	
	public String getPrinbr() {
		return prinbr;
	}
	
	public void setPrinbr(String prinbr) {
		this.prinbr = prinbr;
	}

	public String getProductgroup() {
		return productgroup;
	}

	public void setProductgroup(String productgroup) {
		this.productgroup = productgroup;
	}

	public String getEan_upc_altunit() {
		return ean_upc_altunit;
	}

	public void setEan_upc_altunit(String ean_upc_altunit) {
		this.ean_upc_altunit = ean_upc_altunit;
	}

	public Date getValidity_unit() {
		return validity_unit;
	}

	public void setValidity_unit(Date validity_unit) {
		this.validity_unit = validity_unit;
	}

	public String getCond_qualifier() {
		return cond_qualifier;
	}

	public void setCond_qualifier(String cond_qualifier) {
		this.cond_qualifier = cond_qualifier;
	}

	public String getCond_type() {
		return cond_type;
	}

	public void setCond_type(String cond_type) {
		this.cond_type = cond_type;
	}

	public String getLine_number() {
		return line_number;
	}

	public void setLine_number(String line_number) {
		this.line_number = line_number;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof PRICAT_K009PK) && 
        		system.equals(((PRICAT_K009PK)o).getSystem()) &&
        		mandt.equals(((PRICAT_K009PK)o).getMandt()) &&
        		prinbr.equals(((PRICAT_K009PK)o).getPrinbr()) &&
        		productgroup.equals(((PRICAT_K009PK)o).getProductgroup()) &&
        		ean_upc_altunit.equals(((PRICAT_K009PK)o).getEan_upc_altunit()) &&
        		validity_unit.equals(((PRICAT_K009PK)o).getValidity_unit()) &&
        		cond_qualifier.equals(((PRICAT_K009PK)o).getCond_qualifier()) &&
        		cond_type.equals(((PRICAT_K009PK)o).getCond_type()) &&
        		line_number.equals(((PRICAT_K009PK)o).getLine_number()));
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode() 
        		+ prinbr.hashCode() 
        		+ productgroup.hashCode() 
        		+ ean_upc_altunit.hashCode() 
        		+ validity_unit.hashCode()
        		+ cond_qualifier.hashCode() 
        		+ cond_type.hashCode() 
        		+ line_number.hashCode(); 
    }
}
