package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class T179TPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8610811492621351851L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 1)
	private String spras;
	@Column(length = 18)
	private String prodh;
	
	public T179TPK() {}

	public T179TPK(String system, Integer mandt, String spras, String prodh) {
		this.system = system;
		this.setMandt(mandt);
		this.setSpras(spras);
		this.setProdh(prodh);
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getSpras() {
		return spras;
	}

	public void setSpras(String spras) {
		this.spras = spras;
	}
	
	public String getProdh() {
		return prodh;
	}

	public void setProdh(String prodh) {
		this.prodh = prodh;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof T179TPK) && 
        		system.equals(((T179TPK)o).getSystem()) &&
        		mandt.equals(((T179TPK)o).getMandt()) &&        	
        		spras.equals(((T179TPK)o).getSpras()) &&        	
        		prodh.equals(((T179TPK)o).getProdh()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ spras.hashCode()
        		+ prodh.hashCode(); 
    }

}
