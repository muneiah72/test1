package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPSIGNPK implements java.io.Serializable  {


	private static final long serialVersionUID = 7237749397035244122L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column (length = 3)
	private String zsignature;	
	
	public ZPPSIGNPK() {}	
	
	public ZPPSIGNPK(String system, Integer mandt, String zsignature) {
		this.system = system;
		this.setMandt(mandt);
		this.setZsignature(zsignature);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZsignature() {
		return zsignature;
	}

	public void setZsignature(String zsignature) {
		this.zsignature = zsignature;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPSIGNPK) && 
        		system.equals(((ZPPSIGNPK)o).getSystem()) &&
        		mandt.equals(((ZPPSIGNPK)o).getMandt()) &&        	
        		zsignature.equals(((ZPPSIGNPK)o).getZsignature()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zsignature.hashCode(); 
    }
}
