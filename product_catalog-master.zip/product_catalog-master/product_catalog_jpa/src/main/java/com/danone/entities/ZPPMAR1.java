package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPPMAR1")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPPMAR1 {

	@EmbeddedId
	private ZPPMAR1PK key;
	@Column(length = 30)
	private String zdescription;
	
	public ZPPMAR1PK getKey() {
		return key;
	}
	
	public void setKey(ZPPMAR1PK key) {
		this.key = key;
	}

	public static ZPPMAR1 getZPPMAR1ByKey(EntityManager em, String system, Integer mandt, String zmarki)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZPPMAR1 p where p.key.system = :system and p.key.mandt = :mandt and p.key.zmarki = :zmarki",
						ZPPMAR1.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("zmarki", zmarki);	

		try {
			@SuppressWarnings("unchecked")
			List<ZPPMAR1> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZPPMAR1)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}

	public String getZdescription() {
		return zdescription;
	}

	public void setZdescription(String zdescription) {
		this.zdescription = zdescription;
	}
}
