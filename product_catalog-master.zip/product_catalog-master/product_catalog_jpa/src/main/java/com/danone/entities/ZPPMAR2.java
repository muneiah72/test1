package com.danone.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPPMAR2")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPPMAR2 {

	@EmbeddedId
	private ZPPMAR2PK key;
	@Column(length = 30)
	private String zdescription;
	
	public ZPPMAR2PK getKey() {
		return key;
	}
	
	public void setKey(ZPPMAR2PK key) {
		this.key = key;
	}

	public static ZPPMAR2 getZPPMAR2ByKey(EntityManager em, String system, Integer mandt, String zmarkii)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZPPMAR2 p where p.key.system = :system and p.key.mandt = :mandt and p.key.zmarkii = :zmarkii",
						ZPPMAR2.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("zmarkii", zmarkii);	

		try {
			@SuppressWarnings("unchecked")
			List<ZPPMAR2> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZPPMAR2)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}

	public String getZdescription() {
		return zdescription;
	}

	public void setZdescription(String zdescription) {
		this.zdescription = zdescription;
	}
}
