package com.danone.entities;

import java.sql.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="PRICAT_K001")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true) 
public class PRICAT_K001 {
	
	@EmbeddedId
	private PRICAT_K001PK key;
	private String iln_sender;
	private String unique_reference;
	private String assortment;
	private java.sql.Date datefrom;
	private java.sql.Date dateto;
	private String salesorg;
	private String distr_chan;
	private String division;
	private Integer weekly_recur;
	private Integer view_period;
	private Integer chmginterval;
	
	public PRICAT_K001PK getKey() {
		return key;
	}
	
	public void setKey(PRICAT_K001PK key) {
		this.key = key;
	}
	
	public String getIln_sender() {
		return iln_sender;
	}
	
	public void setIln_sender(String iln_sender) {
		this.iln_sender = iln_sender;
	}
	
	public String getUnique_reference() {
		return unique_reference;
	}
	
	public void setUnique_reference(String unique_reference) {
		this.unique_reference = unique_reference;
	}

	public String getAssortment() {
		return assortment;
	}

	public void setAssortment(String assortment) {
		this.assortment = assortment;
	}

	public String getSalesorg() {
		return salesorg;
	}

	public void setSalesorg(String salesorg) {
		this.salesorg = salesorg;
	}

	public String getDistr_chan() {
		return distr_chan;
	}

	public void setDistr_chan(String distr_chan) {
		this.distr_chan = distr_chan;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public Integer getWeekly_recur() {
		return weekly_recur;
	}

	public void setWeekly_recur(Integer weekly_recur) {
		this.weekly_recur = weekly_recur;
	}

	public Integer getView_period() {
		return view_period;
	}

	public void setView_period(Integer view_period) {
		this.view_period = view_period;
	}

	public Integer getChmginterval() {
		return chmginterval;
	}

	public void setChmginterval(Integer chmginterval) {
		this.chmginterval = chmginterval;
	}

	public Date getDatefrom() {
		return datefrom;
	}

	public void setDatefrom(Date datefrom) {
		this.datefrom = datefrom;
	}

	public Date getDateto() {
		return dateto;
	}

	public void setDateto(Date dateto) {
		this.dateto = dateto;
	}
	
	public static PRICAT_K001 getPRICAT_K001ByKey(EntityManager em, PRICAT_K001PK key) {
		return em.find(PRICAT_K001.class, key);
	}
}
