package com.danone.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ZPPFLAVPK implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5394062841906829470L;
	
	@Column (length = 50)
	private String system;
	private Integer mandt;
	@Column(length = 3)
	private String zflavor;
	
	public ZPPFLAVPK() {}

	public ZPPFLAVPK(String system, Integer mandt, String zflavor) {
		this.system = system;
		this.setMandt(mandt);
		this.setZflavor(zflavor);		
	}

	public Integer getMandt() {
		return mandt;
	}

	public void setMandt(Integer mandt) {
		this.mandt = mandt;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}		

	public String getZflavor() {
		return zflavor;
	}

	public void setZflavor(String zflavor) {
		this.zflavor = zflavor;
	}
	
	public boolean equals(Object o) { 
        return ((o instanceof ZPPFLAVPK) && 
        		system.equals(((ZPPFLAVPK)o).getSystem()) &&
        		mandt.equals(((ZPPFLAVPK)o).getMandt()) &&        	
        		zflavor.equals(((ZPPFLAVPK)o).getZflavor()) );
    }
	
    public int hashCode() { 
        return system.hashCode()
        		+ mandt.hashCode()         	
        		+ zflavor.hashCode(); 
    }

}
