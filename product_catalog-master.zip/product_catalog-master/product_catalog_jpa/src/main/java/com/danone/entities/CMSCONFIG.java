package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Lob;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="CMSCONFIG")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class CMSCONFIG {
	
	@EmbeddedId
	private CMSCONFIGPK key;
	
	@Basic
	@Lob
	@Column(name = "Document")
	private byte[] document;

	@Basic
	@Lob
	@Column(name = "DocumentName")
	private String documentName;
	
	public CMSCONFIGPK getKey() {
		return key;
	}

	public void setDocument(byte[] param) {
		this.document = param;
	}

	public byte[] getDocument() {
		return document;
	}

	public void setDocumentName(String param) {
		this.documentName = param;
	}

	public String getDocumentName() {
		return documentName;
	}
	
	@SuppressWarnings("unchecked")
	public static List<CMSCONFIG> getAllDocuments(EntityManager em) {
		Query query = em.createQuery("SELECT p FROM CMSCONFIG AS p");
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}

	public static CMSCONFIG getDocumentByKey(EntityManager em,
			CMSCONFIGPK key) {
		return em.find(CMSCONFIG.class, key);
	}
	
	@SuppressWarnings("unchecked")
	public static List<CMSCONFIG> getDocumentByDate(EntityManager em,
									String language, String type, Integer curdate) {

		String queryString = "SELECT z FROM CMSCONFIG z WHERE z.key.language = :language AND z.key.type = :type AND z.key.validFrom <= :curdate AND z.key.validTo >= :curdate ORDER BY z.key.validFrom DESC";
		Query query = em.createQuery(queryString, CMSCONFIG.class);
		query.setParameter("language", language);
		query.setParameter("type", type);
		query.setParameter("curdate", curdate);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}	
	
}
