package com.danone.entities;

import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPPFLAV")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPPFLAV {

	@EmbeddedId
	private ZPPFLAVPK key;
	@Column(length = 30)
	private String zdescription;
	
	public ZPPFLAVPK getKey() {
		return key;
	}
	
	public void setKey(ZPPFLAVPK key) {
		this.key = key;
	}

	public String getZdescription() {
		return zdescription;
	}

	public void setZdescription(String zdescription) {
		this.zdescription = zdescription;
	}
	
	public static ZPPFLAV getZPPFLAVByKey(EntityManager em, String system, Integer mandt, String zflavor)
	{
		Query query = em
				.createQuery(
						"SELECT p FROM ZPPFLAV p where p.key.system = :system and p.key.mandt = :mandt and p.key.zflavor = :zflavor",
						ZPPFLAV.class);
		query.setParameter("system", system);
		query.setParameter("mandt", mandt);
		query.setParameter("zflavor", zflavor);	

		try {
			@SuppressWarnings("unchecked")
			List<ZPPFLAV> list = query.getResultList();
			if (list.size() > 0)
			{
				return (ZPPFLAV)list.get(0);
			}else {
				return null;
			}
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<Object[]> getFlavorList(EntityManager em)
	{
		Query query = em
				.createQuery(
						"SELECT distinct p.key.zflavor, p.zdescription FROM ZPPFLAV p order by p.key.zflavor",
						ZPPFLAV.class);
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}

}
