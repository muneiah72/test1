package com.danone.entities;

import java.sql.Date;
import java.util.Collections;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.config.CacheIsolationType;

@Entity
@Table(name="ZPRODCAT_ITEM")
@Cache(isolation=CacheIsolationType.ISOLATED, expiry=0, alwaysRefresh=true)
public class ZPRODCAT_ITEM {
	
	@EmbeddedId
	private ZPRODCAT_ITEMPK key;
	
	private String cat_postyp;
	private String ean_upc_base;
	private java.sql.Date validity_base;
	private String dokar;
	private String doknr;
	private String dokvr;
	private String doktl;
	private Boolean thumbnail_ind;
	
	/*
	@ManyToOne(fetch=FetchType.LAZY)
	private ZPRODCAT_HDR hdr;
	*/
	
	public ZPRODCAT_ITEMPK getKey() {
		return key;
	}
	
	public static ZPRODCAT_ITEM getItemByGuidAndPostyp(EntityManager em, String system, String cat_guid, String cat_postyp) {
		Query query = em
				.createQuery(
						"SELECT p FROM ZPRODCAT_ITEM p where p.key.system = :system and p.key.cat_guid = :cat_guid and p.cat_postyp = :cat_postyp",
						ZPRODCAT_HDR.class).setParameter("cat_guid", cat_guid).setParameter("cat_postyp", cat_postyp).setParameter("system", system);
		try {
			return (ZPRODCAT_ITEM) query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<ZPRODCAT_ITEM> getItemsByType(EntityManager em, String system, Integer mandt, String cat_guid, String cat_postyp) {
		String queryString = "SELECT p FROM ZPRODCAT_ITEM p where p.key.system = :system and p.key.mandt = :mandt and p.key.cat_guid = :cat_guid and p.cat_postyp = :cat_postyp";
		Query query = em.createQuery(queryString, ZPRODCAT_ITEM.class).setParameter("system", system).setParameter("mandt", mandt).setParameter("cat_guid", cat_guid).setParameter("cat_postyp", cat_postyp);
		
		try {
			return query.getResultList();
		} catch (NoResultException e) {
			return Collections.emptyList();
		}
	}
	//p.dokar, p.doknr, p.dokvr, p.doktl
	
	public void setKey(ZPRODCAT_ITEMPK key) {
		this.key = key;
	}
	
	/*
	public ZPRODCAT_HDR getHdr() {
		return hdr;
	}

	public void setHdr(ZPRODCAT_HDR hdr) {
		this.hdr = hdr;
	}
	*/
	
	public String getCat_postyp() {
		return cat_postyp;
	}

	public void setCat_postyp(String cat_postyp) {
		this.cat_postyp = cat_postyp;
	}

	public String getEan_upc_base() {
		return ean_upc_base;
	}

	public void setEan_upc_base(String ean_upc_base) {
		this.ean_upc_base = ean_upc_base;
	}

	public String getDokar() {
		return dokar;
	}

	public void setDokar(String dokar) {
		this.dokar = dokar;
	}

	public String getDokvr() {
		return dokvr;
	}

	public void setDokvr(String dokvr) {
		this.dokvr = dokvr;
	}

	public String getDoknr() {
		return doknr;
	}

	public void setDoknr(String doknr) {
		this.doknr = doknr;
	}

	public String getDoktl() {
		return doktl;
	}

	public void setDoktl(String doktl) {
		this.doktl = doktl;
	}

	public Date getValidity_base() {
		return validity_base;
	}

	public void setValidity_base(Date validity_base) {
		this.validity_base = validity_base;
	}

	public Boolean getThumbnail_ind() {
		return thumbnail_ind;
	}

	public void setThumbnail_ind(Boolean thumbnail_ind) {
		this.thumbnail_ind = thumbnail_ind;
	}
}
